# Dark Monia — 5.0 nativo (etapa 8)

**8:** tela inicial repaginada (continuar de onde parou, desafio do dia, busca, favoritos, estatísticas, saudação com seu nome), Lixeira de 30 dias, cópia de segurança .zip e importar projeto, estúdio do pincel (espaçamento, opacidade, fino mínimo, ponta, grão, pressão) com amostra ao vivo e tela cheia (⛶ ou 4 dedos).

**7.1:** corrigido o bug em que a tela de desenho sumia nas animações; voltou a abertura "DARK MONIA / ANIMATOR 2D" da 5.0.

App Android **nativo em Java puro** (sem WebView). Pacote `com.darkmonia.animator`.

## Tela inicial (igual à 5.0 Creative Studio)
- Fundo escuro com brilhos e partículas, cabeçalho com a marca, "Dark Monia / CREATIVE STUDIO · 5.0" e ⚙
- Saudação pela hora (Bom dia / Boa tarde / Boa noite) + "O que vamos criar hoje?"
- Cartões **Novo desenho**, **Nova animação** e **Abrir imagem** com as mesmas ilustrações
- **Começar rápido**: Quadrado, Retrato, Story, Paisagem, A4, A5, Papel de parede, 4K, Ícone, Quadrinho, Pixel art e "Outro tamanho"
- **Minha galeria**: contador, ordenar (Recentes / Nome / Antigos), grade ou lista, abas com contagem, miniaturas com selo (Desenho / N quadros) e data relativa
- Botão **+**, folha de novo projeto (Desenho/Animação, tamanhos, personalizado com ⇄, fundos incl. transparente; formato, orientação, resolução, quadros e fps)
- Opções do projeto: renomear, editar, assistir, exportar, duplicar, excluir (toque duplo)
- Configurações: 6 cores do app e gestos

## Editor (mesmo layout da 5.0 HTML)
- Barra de cima: ← início, nome do projeto / "Dark Monia Animator 2D · v5.0", desfazer, refazer, ▶ e **Projeto**
- Palco com fundo de estúdio, contador de quadros, zoom − 100% + e indicador de giro (toque para endireitar)
- Fileira de camadas rápida, **doca 1**: Pincel · Borracha · Seleção ◢ · Formas ◢ · Preencher ◢ · Transf. · Retocar ◢ · Mais ◢
- **Doca 2**: Cor · Camadas · Fantasma · Ajustes · Traço · Mídia · Animação (no modo desenho só as 5 que importam)
- Tamanho e opacidade embaixo, painéis que abrem acima das ferramentas, linha do tempo com fps −/+, Repetir, voltar/avançar, copiar, apagar e **Novo**
- Novidades da etapa 7: polilinha, polígono por toques e curva; medir; luz e sombra automáticas; traço do pincel em forma (reta/retângulo/elipse); afinar início/fim em qualquer pincel; guias terços e centro; +5/+12/+24 quadros; papel de seda até 4 quadros; fundo da tela por imagem; **30 fundos de estúdio**; importar vídeo para rotoscopia; filtros rápidos em todos os quadros; Repetir liga/desliga; apagar todos os desenhos; tela deitada com ferramentas à direita
- **+60 pincéis** em 8 categorias (G-Pen, Taper, Lápis com grão, Aquarela, Aerógrafo, Carvão, Giz, Pastel, Pincel seco, Neon, Fogo, Nuvem, Grama, Rocha, Árvores, Água, Cristais, Magma, Campo estelar, Pixel art, Arco-íris, Tracejado, Hachura…)
- Borracha dura / suave / lápis, **dedo (borrar)** e **desfocar**
- Pressão da caneta, **estabilizador**, pontas afiladas, **QuickShape** (reta, curva, círculo, elipse, triângulo, retângulo, polígono)
- **Simetria** vertical, horizontal, 4 lados e **radial/mandala**
- **Guias**: grade, perspectiva de 1 e 2 pontos, isométrica, com **régua** que trava o traço
- Balde com tolerância, **fechar falhas**, expandir e "todas as camadas"
- **Seleção**: retângulo, elipse, laço, polígono, varinha mágica, por cor; somar/tirar, inverter, copiar/recortar/colar, para nova camada
- **Transformar**: mover, escalar, girar (ímã de 45°), distorcer, espelhar, ajustar à tela
- Formas (reta, retângulo, elipse, estrela, polígono, seta), **degradê** linear/radial, **texto** com fontes e contorno
- **Liquidificar** (empurrar, girar, contrair, inflar), **carimbo/clone**, **recolorir**, laço de tinta e laço borracha
- **Camadas**: até 24, 17 modos de mesclagem, opacidade, recorte (clipping), trava alfa, bloquear, duplicar, juntar, espelhar
- **17 filtros** com prévia: matiz/saturação/brilho, contraste, desfoque, nitidez, ruído, extrair traço, colorir, bloom, contorno, sombra, aberração cromática, posterizar, limiar, pixelizar, P&B, sépia, inverter
- Roda de cores + HEX + recentes + paleta salva + harmonias + 2ª cor
- Janela de **referência** flutuante (toque pega a cor), quadros de **HQ**, importar imagem como camada
- Gestos: 2 dedos desfaz, 3 refaz, pinça/zoom/girar, segurar = conta-gotas, modo "só caneta"
- Desfazer por região (economiza memória) e **time-lapse** automático

## Animação
Linha do tempo com miniaturas, duração por quadro (exposição), papel vegetal colorido (até 3 antes/depois), fps 1–60, repetir ou vai-e-volta.

## Exportar
PNG, JPG, PNG transparente, PNG 2×, camadas (.zip), **MP4** 720p/1080p, **GIF** (normal, grande, transparente), sequência PNG (.zip), folha de sprites, **vídeo time-lapse**. Tudo vai para a Galeria (Pictures/Movies › DarkMonia) ou Downloads/DarkMonia, com botão de compartilhar.

## Como gerar o APK
**GitHub (recomendado, grátis):** suba esta pasta num repositório → aba *Actions* → *Compilar APK* → baixe o artefato **DarkMonia-APK**.

**AndroidIDE (no celular):** abra a pasta e use *Build › Assemble Release*.

**Android Studio:** abra a pasta → *Build › Build APK(s)*.

O projeto já tem uma chave fixa (`app/darkmonia.keystore`, senha `darkmonia`): as próximas versões instalam **por cima** sem apagar seus desenhos. Se o Android disser "conflito com pacote existente", desinstale a versão antiga **uma vez** (era assinada com outra chave).
