package com.darkmonia.animator;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Tela inicial idêntica à do Dark Monia 5.0 (Creative Studio). */
public class HomeActivity extends Activity {
    private static final int REQ_OPEN_IMAGE = 42, REQ_IMPORT_PROJ = 43;

    static final String[] SIZE_NAMES = {"Quadrado", "Retrato", "Story", "Paisagem", "A4", "A5", "Papel de parede", "Tela 4K", "Ícone", "Quadrinho", "Pixel art"};
    static final String[] SIZE_SUB = {"Post", "Feed 4:5", "Celular 9:16", "HD 16:9", "Papel 300 dpi", "Caderno", "Celular", "Monitor", "Avatar", "Página de HQ", "Retrô"};
    static final int[][] SIZES = {{1080, 1080}, {1080, 1350}, {1080, 1920}, {1920, 1080}, {2480, 3508}, {1748, 2480}, {1440, 3200}, {3840, 2160}, {512, 512}, {1988, 2810}, {256, 256}};
    static final int[] PAPERS = {0xFFFBFAF6, 0xFFFFFFFF, 0xFFF1E9D2, 0xFFD9DDE2, 0xFF2B2A28, 0xFF101018, 0xFF000000, 0xFFBFE3FF, 0xFFFFD9B3, 0xFF1B2A4A, 0xFFCFE8C4, 0xFFF6C1D0};
    static final int[] ACCENTS = {0xFFE5476B, 0xFF8D7AFF, 0xFF4D8DFF, 0xFF22C3A6, 0xFFFF8A3D, 0xFFF2C94C};
    static final String[] ACCENT_NAMES = {"Rosa", "Violeta", "Azul", "Verde-água", "Laranja", "Amarelo"};

    private static boolean introShown;
    private HomeBg bgView;
    private LinearLayout heroBox;
    private TextView statsTv;
    private String query = "";
    private LinearLayout gal, tabs;
    private TextView countTv, hiTv;
    private Button sortBtn;
    private ImageView viewIcon;
    private int filter, sort;
    private boolean list;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final HashMap<String, Bitmap> thumbs = new HashMap<>();
    private float dens;
    private boolean wide;

    private int dp(float v) { return Ui.dp(this, v); }

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        Prefs.init(this);
        dens = getResources().getDisplayMetrics().density;
        wide = getResources().getDisplayMetrics().widthPixels / dens >= 720;
        filter = Prefs.num(this, "filter", 0);
        sort = Prefs.num(this, "sort", 0);
        list = Prefs.on(this, "list", false);
        getWindow().setStatusBarColor(Ui.HOME_BG);
        getWindow().setNavigationBarColor(Ui.HOME_BG);
        build();
        if (!introShown) { introShown = true; intro(); }
    }

    private void build() {
        FrameLayout shell = new FrameLayout(this);
        bgView = new HomeBg(this);
        shell.addView(bgView, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipToPadding(false);
        LinearLayout root = Ui.col(this);
        root.setPadding(0, dp(74), 0, dp(116));
        sv.addView(root);
        shell.addView(sv, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        /* saudação */
        LinearLayout hello = Ui.col(this);
        hello.setPadding(dp(20), dp(10), dp(20), dp(2));
        hiTv = Ui.text(this, greet(), wide ? 40 : 32, Ui.FG, true);
        hiTv.setLetterSpacing(-0.035f);
        hello.addView(hiTv);
        TextView sub = Ui.text(this, "O que vamos criar hoje?", 15, 0xFFA9B0CC, false);
        sub.setPadding(0, dp(8), 0, 0);
        hello.addView(sub);
        statsTv = Ui.mono(this, "", 11, 0xFF7F87A6);
        statsTv.setPadding(0, dp(8), 0, 0);
        hello.addView(statsTv);
        root.addView(hello);

        /* cartões grandes */
        LinearLayout acts = Ui.row(this);
        acts.setPadding(dp(18), dp(16), dp(18), dp(4));
        acts.setGravity(Gravity.TOP);
        View draw = actCard("Novo desenho", "Ilustração com camadas", 0xFFFF6B8F, 0xFFB44DFF, "art_draw");
        View anim = actCard("Nova animação", "Quadro a quadro", 0xFF3B82FF, 0xFF12C2B0, "art_anim");
        draw.setOnClickListener(v -> newProject(false));
        anim.setOnClickListener(v -> newProject(true));
        LinearLayout.LayoutParams a1 = new LinearLayout.LayoutParams(0, dp(156), 1);
        a1.rightMargin = dp(6);
        LinearLayout.LayoutParams a2 = new LinearLayout.LayoutParams(0, dp(156), 1);
        a2.leftMargin = dp(6);
        acts.addView(draw, a1);
        acts.addView(anim, a2);
        View imp;
        if (wide) {
            imp = actCard("Abrir imagem", "Pinte por cima de uma foto ou rascunho", 0xFF23273B, 0xFF171A29, "art_import");
            LinearLayout.LayoutParams a3 = new LinearLayout.LayoutParams(0, dp(156), 1);
            a3.leftMargin = dp(12);
            acts.addView(imp, a3);
            root.addView(acts);
        } else {
            root.addView(acts);
            imp = importCard();
            LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP);
            il.setMargins(dp(18), dp(8), dp(18), 0);
            root.addView(imp, il);
        }
        imp.setOnClickListener(v -> openImage());

        /* continuar de onde parou + desafio do dia */
        heroBox = Ui.col(this);
        heroBox.setPadding(dp(18), 0, dp(18), 0);
        root.addView(heroBox);

        /* começar rápido */
        root.addView(secHead("Começar rápido", "toque e já desenhe", null));
        HorizontalScrollView qs = new HorizontalScrollView(this);
        qs.setHorizontalScrollBarEnabled(false);
        qs.setClipToPadding(false);
        qs.setPadding(dp(18), dp(2), dp(18), dp(6));
        LinearLayout qrow = Ui.row(this);
        for (int i = 0; i < SIZES.length; i++) {
            final int fi = i;
            View q = quickTile(SIZE_NAMES[i], SIZES[i][0] + "×" + SIZES[i][1], SIZES[i][0], SIZES[i][1], false);
            q.setOnClickListener(v -> create(null, SIZES[fi][0], SIZES[fi][1], false, 0xFFFFFFFF, 12, 1));
            LinearLayout.LayoutParams ql = new LinearLayout.LayoutParams(dp(94), Ui.WRAP);
            ql.rightMargin = dp(10);
            qrow.addView(q, ql);
        }
        View more = quickTile("Outro tamanho", "personalizado", 0, 0, true);
        more.setOnClickListener(v -> newProjectSheet(false, true));
        qrow.addView(more, new LinearLayout.LayoutParams(dp(94), Ui.WRAP));
        qs.addView(qrow);
        root.addView(qs);

        /* galeria */
        LinearLayout tools = Ui.row(this);
        sortBtn = galBtn("sort", "Recentes");
        sortBtn.setOnClickListener(v -> { sort = (sort + 1) % 3; Prefs.put(this, "sort", sort); refresh(); });
        FrameLayout vb = new FrameLayout(this);
        vb.setBackground(Ui.bgStroke(0x0FFFFFFF, 0x17FFFFFF, dp(12), dp(1)));
        viewIcon = Ui.iconView(this, "list", 0xFFD9DDF0, 18);
        FrameLayout.LayoutParams vil = new FrameLayout.LayoutParams(dp(18), dp(18));
        vil.gravity = Gravity.CENTER;
        vb.addView(viewIcon, vil);
        vb.setOnClickListener(v -> { list = !list; Prefs.set(this, "list", list); refresh(); });
        tools.addView(sortBtn, new LinearLayout.LayoutParams(Ui.WRAP, dp(36)));
        LinearLayout.LayoutParams vbl = new LinearLayout.LayoutParams(dp(42), dp(36));
        vbl.leftMargin = dp(8);
        tools.addView(Ui.pressable(vb), vbl);
        countTv = Ui.mono(this, "0", 11, 0xFFC9CFE8);
        countTv.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        countTv.setBackground(Ui.bg(0x14FFFFFF, dp(999)));
        countTv.setPadding(dp(8), dp(3), dp(8), dp(3));
        root.addView(secHead("Minha galeria", null, tools));
        LinearLayout sr = Ui.row(this);
        sr.setPadding(dp(12), 0, dp(12), 0);
        sr.setBackground(Ui.bgStroke(0xFF141726, 0x17FFFFFF, dp(14), dp(1)));
        sr.addView(Ui.iconView(this, "search", 0xFF7F87A6, 18));
        final EditText search = new EditText(this);
        search.setHint("Buscar nos meus projetos…");
        search.setHintTextColor(0xFF6A7090);
        search.setTextColor(Ui.FG);
        search.setTextSize(14);
        search.setSingleLine(true);
        search.setBackground(null);
        search.setPadding(dp(10), dp(10), dp(6), dp(10));
        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void afterTextChanged(android.text.Editable e) { query = e.toString().trim().toLowerCase(); refresh(); }
        });
        sr.addView(search, Ui.lpw(1));
        LinearLayout.LayoutParams srl = new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP);
        srl.setMargins(dp(18), 0, dp(18), dp(10));
        root.addView(sr, srl);

        tabs = Ui.row(this);
        HorizontalScrollView ts = new HorizontalScrollView(this);
        ts.setHorizontalScrollBarEnabled(false);
        ts.setClipToPadding(false);
        ts.setPadding(dp(18), 0, dp(18), dp(12));
        ts.addView(tabs);
        root.addView(ts);

        gal = Ui.col(this);
        gal.setPadding(dp(18), 0, dp(18), 0);
        root.addView(gal);

        TextView foot = Ui.mono(this, "DARK MONIA CREATIVE STUDIO · V5.0", 10, 0xFF555C7A);
        foot.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        foot.setLetterSpacing(0.14f);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(dp(20), dp(30), dp(20), dp(8));
        root.addView(foot, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));

        /* topo fixo */
        shell.addView(header(), new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.TOP));

        /* botão + */
        FrameLayout fab = new FrameLayout(this);
        fab.setBackground(Ui.grad(Ui.ACC, Ui.VIOLET, dp(21)));
        fab.setElevation(dp(10));
        FrameLayout.LayoutParams fil = new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER);
        fab.addView(Ui.iconView(this, "plus", 0xFFFFFFFF, 28), fil);
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(dp(62), dp(62), Gravity.BOTTOM | Gravity.END);
        fl.setMargins(0, 0, dp(18), dp(18));
        shell.addView(Ui.pressable(fab), fl);
        fab.setOnClickListener(v -> createSheet());

        Ui.padInsets(shell, true);
        setContentView(shell);
    }

    /** Abertura da 5.0: tela preta com "DARK MONIA / ANIMATOR 2D" por 3 s e some devagar (toque pula). */
    private void intro() {
        final FrameLayout box = new FrameLayout(this);
        box.setBackgroundColor(0xFF000000);
        box.setClickable(true);
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float wdp = dm.widthPixels / dm.density, hdp = dm.heightPixels / dm.density;
        float size = Ui.clampf(Math.min(wdp * .09f, hdp * .13f), 26, 72);
        LinearLayout col = Ui.col(this);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView t = new TextView(this);
        t.setText("DARK MONIA");
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(size);
        t.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        t.setLetterSpacing(0.06f);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        col.addView(t);
        TextView s = new TextView(this);
        s.setText("ANIMATOR 2D");
        s.setTextColor(0xFFC9B6FF);
        s.setTextSize(size * .5f);
        s.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        s.setLetterSpacing(0.34f);
        s.setGravity(Gravity.CENTER);
        s.setPadding(0, Math.round(dp(size * .3f)), 0, 0);
        col.addView(s);
        box.addView(col, new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER));
        final android.view.ViewGroup decor = (android.view.ViewGroup) getWindow().getDecorView();
        decor.addView(box, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        t.setAlpha(0f);
        t.setScaleX(1.06f);
        t.setScaleY(1.06f);
        t.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start();
        s.setAlpha(0f);
        s.animate().alpha(1f).setStartDelay(350).setDuration(700).start();
        final Runnable out = () -> {
            if (box.getParent() == null) return;
            box.setClickable(false);
            box.animate().alpha(0f).setDuration(400).start();
            ui.postDelayed(() -> { if (box.getParent() != null) decor.removeView(box); }, 420);
        };
        box.setOnClickListener(v -> out.run());
        ui.postDelayed(out, 3000);
    }

    static final String[] PROMPTS = {"Um gato astronauta", "Sua comida favorita com rosto", "Uma ilha flutuante", "Um dragão minúsculo",
            "Uma cidade à noite na chuva", "Um robô jardineiro", "Seu personagem correndo", "Uma casa na árvore", "Um monstro fofo",
            "Um herói de anime em pose de luta", "Um peixe no espaço", "Um café mágico", "Uma floresta de cogumelos", "Um cavaleiro cansado",
            "Uma bruxa de bicicleta", "Um carro voando", "Um lobo sob a lua", "Seu quarto visto de cima", "Um planeta de doces",
            "Um samurai na neve", "Um polvo cozinheiro", "Uma torre caída", "Um mapa do tesouro", "Uma raposa com cachecol",
            "Um vilão sorrindo", "Um trem atravessando nuvens", "Um sapo músico", "Um cristal gigante", "Uma tempestade no mar",
            "Uma bola quicando (animação)", "Uma chama dançando (animação)", "Um olho piscando (animação)", "Uma folha caindo (animação)",
            "Seu autorretrato em 3 cores", "Um personagem com 5 expressões", "Uma paisagem só com formas", "Um pássaro de origami",
            "Uma cena de luta em 1 quadro", "Um mascote para o Dark Monia"};

    static String todayPrompt() {
        int d = Calendar.getInstance().get(Calendar.DAY_OF_YEAR) + Calendar.getInstance().get(Calendar.YEAR) * 7;
        return PROMPTS[Math.abs(d) % PROMPTS.length];
    }

    /** "Continuar de onde parou" e "Desafio do dia". */
    private void fillHero(ArrayList<Project> all) {
        heroBox.removeAllViews();
        if (!all.isEmpty() && query.isEmpty()) {
            Project last = all.get(0);
            for (Project p : all) if (p.updated > last.updated) last = p;
            final Project lp = last;
            LinearLayout c = Ui.row(this);
            c.setPadding(dp(10), dp(10), dp(14), dp(10));
            GradientDrawable g = Ui.grad(0xFF1E2236, 0xFF131624, dp(22));
            g.setStroke(dp(1), 0x17FFFFFF);
            c.setBackground(g);
            ThumbView tv = new ThumbView(this);
            tv.setBackground(Ui.bg(0xFF0C0E18, dp(14)));
            tv.setClipToOutline(true);
            c.addView(tv, new LinearLayout.LayoutParams(dp(96), dp(96)));
            loadThumb(lp, tv);
            LinearLayout tx = Ui.col(this);
            tx.setPadding(dp(14), 0, dp(6), 0);
            TextView k = Ui.mono(this, "CONTINUAR DE ONDE PAROU", 9.5f, Ui.ACC);
            k.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            k.setLetterSpacing(0.12f);
            tx.addView(k);
            TextView n = Ui.text(this, lp.name, 17, Ui.FG, true);
            n.setSingleLine(true);
            n.setEllipsize(TextUtils.TruncateAt.END);
            n.setPadding(0, dp(6), 0, dp(3));
            tx.addView(n);
            tx.addView(Ui.text(this, (lp.anim ? lp.frames.size() + " quadros · " : "Desenho · ") + when(lp.updated), 12, Ui.DIM, false));
            TextView go = Ui.text(this, "Continuar  ›", 13, 0xFFFFFFFF, true);
            go.setPadding(dp(14), dp(7), dp(14), dp(7));
            go.setBackground(Ui.bg(Ui.ACC, dp(999)));
            LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
            gl.topMargin = dp(10);
            tx.addView(go, gl);
            c.addView(tx, Ui.lpw(1));
            c.setOnClickListener(v -> open(lp, null));
            heroBox.addView(Ui.pressable(c), new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        }
        final String pr = todayPrompt();
        LinearLayout d = Ui.row(this);
        d.setPadding(dp(12), dp(12), dp(12), dp(12));
        d.setBackground(Ui.bgStroke(0xFF141726, 0x17FFFFFF, dp(18), dp(1)));
        FrameLayout ic = new FrameLayout(this);
        ic.setBackground(Ui.grad(0xFFF2C94C, 0xFFFF8A3D, dp(12)));
        ic.addView(Ui.iconView(this, "spark", 0xFFFFFFFF, 22), new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        d.addView(ic, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout dt = Ui.col(this);
        dt.setPadding(dp(12), 0, dp(8), 0);
        TextView dk = Ui.mono(this, "DESAFIO DO DIA", 9.5f, 0xFFF2C94C);
        dk.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        dk.setLetterSpacing(0.12f);
        dt.addView(dk);
        TextView dp2 = Ui.text(this, pr, 14.5f, Ui.FG, true);
        dp2.setPadding(0, dp(4), 0, 0);
        dt.addView(dp2);
        d.addView(dt, Ui.lpw(1));
        TextView b = Ui.text(this, "Topar", 12.5f, 0xFF1A1206, true);
        b.setPadding(dp(12), dp(7), dp(12), dp(7));
        b.setBackground(Ui.bg(0xFFF2C94C, dp(999)));
        d.addView(b);
        final boolean anim = pr.contains("(animação)");
        d.setOnClickListener(v -> create("Desafio · " + pr.replace(" (animação)", ""), anim ? 1920 : 1080, 1080, anim, 0xFFFFFFFF, 12, anim ? 12 : 1));
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP);
        dl.topMargin = dp(heroBox.getChildCount() > 0 ? 10 : 6);
        heroBox.addView(Ui.pressable(d), dl);
    }

    private static String mb(long b) {
        return b < 1024 * 1024 ? Math.max(1, b / 1024) + " KB" : String.format(Locale.US, "%.1f MB", b / 1048576f);
    }

    private void importProject() {
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.setType("*/*");
        it.addCategory(Intent.CATEGORY_OPENABLE);
        try { startActivityForResult(Intent.createChooser(it, "Escolher cópia (.zip)"), REQ_IMPORT_PROJ); }
        catch (Exception e) { Ui.toast(this, "Não há app de arquivos"); }
    }

    /** Cópia de segurança do projeto inteiro em Downloads/DarkMonia. */
    private void backup(final Project p) {
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 7);
            Ui.toast(this, "Permita salvar arquivos e toque de novo em \"Cópia .zip\"");
            return;
        }
        Ui.toast(this, "Criando cópia…");
        io.execute(() -> {
            String safe = p.name.replaceAll("[^A-Za-z0-9À-ÿ _-]", "").trim().replace(' ', '_');
            final String name = (safe.isEmpty() ? "projeto" : safe) + "_darkmonia.zip";
            File tmp = new File(getCacheDir(), name);
            Uri u = null;
            boolean ok = false;
            try {
                java.io.FileOutputStream fo = new java.io.FileOutputStream(tmp);
                p.zipTo(fo);
                u = Media.publish(this, tmp, name);
                ok = true;
            } catch (Exception ignored) { }
            tmp.delete();
            final Uri fu = u;
            final boolean fok = ok;
            ui.post(() -> {
                if (!fok) { Ui.toast(this, "Não consegui criar a cópia"); return; }
                Ui.toast(this, "Cópia salva em Downloads/DarkMonia");
                if (fu != null) Media.share(this, fu, "application/zip");
            });
        });
    }

    private void trashSheet() {
        final Sheet s = new Sheet(this, "Lixeira");
        final ArrayList<Project> L = Project.listTrash(this);
        if (L.isEmpty()) {
            TextView e = Ui.text(this, "Nada aqui. Projetos excluídos ficam 30 dias na Lixeira antes de sumir.", 13, Ui.MUTE, false);
            e.setLineSpacing(0, 1.25f);
            s.add(e);
        }
        for (final Project p : L) {
            LinearLayout r = Ui.row(this);
            r.setPadding(dp(8), dp(8), dp(8), dp(8));
            r.setBackground(Ui.bgStroke(Ui.PANEL2, Ui.LINE, dp(14), dp(1)));
            ThumbView tv = new ThumbView(this);
            r.addView(tv, new LinearLayout.LayoutParams(dp(52), dp(52)));
            loadThumb(p, tv);
            LinearLayout tx = Ui.col(this);
            tx.setPadding(dp(10), 0, dp(6), 0);
            TextView n = Ui.text(this, p.name, 13.5f, Ui.FG, true);
            n.setSingleLine(true);
            n.setEllipsize(TextUtils.TruncateAt.END);
            tx.addView(n);
            long left = Math.max(0, 30 - (System.currentTimeMillis() - p.deletedAt()) / 86400000L);
            tx.addView(Ui.text(this, "some em " + left + (left == 1 ? " dia" : " dias"), 11, Ui.MUTE, false));
            r.addView(tx, Ui.lpw(1));
            Button rs = Ui.btn(this, "Restaurar");
            rs.setOnClickListener(v -> { p.restore(this); s.dismiss(); refresh(); Ui.toast(this, "\"" + p.name + "\" voltou para a galeria"); });
            r.addView(rs);
            s.add(r, gapBottom(8));
        }
        if (!L.isEmpty()) {
            final Button all = Ui.btn(this, "Esvaziar lixeira");
            final boolean[] armed = {false};
            all.setOnClickListener(v -> {
                if (!armed[0]) { armed[0] = true; all.setText("Toque de novo: apaga para sempre"); Ui.sel(all, true); return; }
                for (Project p : L) p.deleteAll();
                s.dismiss();
                Ui.toast(this, "Lixeira esvaziada");
            });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
            l.topMargin = dp(6);
            s.add(all, l);
        }
        addClose(s, closeBtn(s, "Fechar"));
        s.show();
    }

    /* ---------------- peças da tela ---------------- */

    private View header() {
        LinearLayout h = Ui.row(this);
        h.setPadding(dp(18), dp(14), dp(18), dp(16));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Ui.HOME_BG, Ui.HOME_BG, 0xEE0A0B12, 0x000A0B12});
        h.setBackground(g);
        FrameLayout mark = new FrameLayout(this);
        mark.setBackground(Ui.grad(Ui.ACC, Ui.VIOLET, dp(14)));
        mark.setElevation(dp(6));
        ImageView mi = new ImageView(this);
        mi.setImageDrawable(Ui.art(this, "art_mark"));
        mark.addView(mi, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        h.addView(mark, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout t = Ui.col(this);
        t.setPadding(dp(11), 0, 0, 0);
        TextView a = Ui.text(this, "Dark Monia", 19, Ui.FG, true);
        a.setLetterSpacing(-0.025f);
        TextView b = Ui.mono(this, "CREATIVE STUDIO · 5.0", 9.5f, 0xFF8F97B8);
        b.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        b.setLetterSpacing(0.16f);
        b.setPadding(0, dp(3), 0, 0);
        t.addView(a);
        t.addView(b);
        h.addView(t, Ui.lpw(1));
        FrameLayout gear = new FrameLayout(this);
        gear.setBackground(Ui.bgStroke(0x0FFFFFFF, 0x17FFFFFF, dp(14), dp(1)));
        gear.addView(Ui.iconView(this, "gear", 0xFFDFE3F5, 22), new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        h.addView(Ui.pressable(gear), new LinearLayout.LayoutParams(dp(44), dp(44)));
        gear.setOnClickListener(v -> settingsSheet());
        return h;
    }

    private View actCard(String title, String sub, int c1, int c2, String art) {
        FrameLayout f = new FrameLayout(this);
        GradientDrawable g = Ui.grad(c1, c2, dp(24));
        if (c1 == 0xFF23273B) g.setStroke(dp(1), 0x14FFFFFF);
        f.setBackground(g);
        f.setElevation(dp(4));
        f.setClipToOutline(true);
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(Ui.art(this, art));
        FrameLayout.LayoutParams al = new FrameLayout.LayoutParams(dp(96), dp(96), Gravity.TOP | Gravity.END);
        al.setMargins(0, -dp(4), -dp(6), 0);
        f.addView(iv, al);
        LinearLayout tx = Ui.col(this);
        tx.setPadding(dp(16), 0, dp(16), dp(16));
        TextView t = Ui.text(this, title, 18.5f, 0xFFFFFFFF, true);
        t.setLetterSpacing(-0.015f);
        TextView s = Ui.text(this, sub, 12.5f, 0xE0FFFFFF, false);
        s.setPadding(0, dp(4), 0, 0);
        tx.addView(t);
        tx.addView(s);
        f.addView(tx, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM));
        return Ui.pressable(f);
    }

    private View importCard() {
        LinearLayout r = Ui.row(this);
        r.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable g = Ui.grad(0xFF23273B, 0xFF171A29, dp(24));
        g.setStroke(dp(1), 0x14FFFFFF);
        r.setBackground(g);
        r.setMinimumHeight(dp(82));
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(Ui.art(this, "art_import"));
        r.addView(iv, new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout tx = Ui.col(this);
        tx.setPadding(dp(14), 0, dp(10), 0);
        TextView t = Ui.text(this, "Abrir imagem", 18.5f, 0xFFFFFFFF, true);
        TextView s = Ui.text(this, "Pinte por cima de uma foto ou rascunho", 12.5f, 0xE0FFFFFF, false);
        s.setPadding(0, dp(4), 0, 0);
        tx.addView(t);
        tx.addView(s);
        r.addView(tx, Ui.lpw(1));
        FrameLayout go = new FrameLayout(this);
        go.setBackground(Ui.bg(0x14FFFFFF, dp(12)));
        go.addView(Ui.iconView(this, "next", 0xFFFFFFFF, 20), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
        r.addView(go, new LinearLayout.LayoutParams(dp(34), dp(34)));
        return Ui.pressable(r);
    }

    private View secHead(String title, String small, View right) {
        LinearLayout h = Ui.row(this);
        h.setPadding(dp(20), dp(24), dp(20), dp(10));
        TextView t = Ui.text(this, title, 17.5f, Ui.FG, true);
        t.setLetterSpacing(-0.015f);
        h.addView(t);
        if (right != null) {
            h.addView(Ui.gap(this, 8, 1));
            h.addView(countTv);
            h.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
            h.addView(right);
        } else if (small != null) {
            TextView s = Ui.text(this, small, 12, 0xFF7F87A6, false);
            s.setPadding(dp(10), 0, 0, 0);
            h.addView(s);
        }
        return h;
    }

    /** Miniatura de proporção (retângulo branco) usada no "Começar rápido" e no novo projeto. */
    static class RatioBox extends View {
        int w, h, max;
        boolean plus;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), sh = new Paint(Paint.ANTI_ALIAS_FLAG);
        RatioBox(android.content.Context c, int w, int h, int maxDp) {
            super(c);
            this.w = w; this.h = h; max = Ui.dp(c, maxDp);
            sh.setColor(0x55000000);
        }
        @Override protected void onDraw(Canvas c) {
            if (w <= 0 || h <= 0) return;
            float k = max / (float) Math.max(w, h);
            float bw = Math.max(Ui.dp(getContext(), 8), w * k), bh = Math.max(Ui.dp(getContext(), 8), h * k);
            float l = (getWidth() - bw) / 2f, t = (getHeight() - bh) / 2f, r = Ui.dp(getContext(), 4);
            c.drawRoundRect(l, t + Ui.dp(getContext(), 3), l + bw, t + bh + Ui.dp(getContext(), 3), r, r, sh);
            p.setShader(new android.graphics.LinearGradient(l, t, l + bw * .4f, t + bh, 0xFFFFFFFF, 0xFFDFE3F3, android.graphics.Shader.TileMode.CLAMP));
            c.drawRoundRect(l, t, l + bw, t + bh, r, r, p);
        }
    }

    private View quickTile(String name, String dims, int w, int h, boolean more) {
        LinearLayout q = Ui.col(this);
        q.setGravity(Gravity.CENTER_HORIZONTAL);
        q.setPadding(dp(8), dp(10), dp(8), dp(10));
        q.setBackground(Ui.bgStroke(0xFF141726, 0x12FFFFFF, dp(18), dp(1)));
        View box;
        if (more) {
            FrameLayout f = new FrameLayout(this);
            f.setBackground(Ui.dashed(0x38FFFFFF, dp(14), dp(1.5f), dp(5)));
            f.addView(Ui.iconView(this, "plus", Ui.ACC, 24), new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
            box = f;
        } else box = new RatioBox(this, w, h, 46);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(dp(56), dp(56));
        bl.bottomMargin = dp(5);
        q.addView(box, bl);
        TextView n = Ui.text(this, name, 12, 0xFFE9ECF8, true);
        n.setSingleLine(true);
        n.setEllipsize(TextUtils.TruncateAt.END);
        n.setGravity(Gravity.CENTER);
        q.addView(n, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        TextView d = Ui.mono(this, dims, 9.5f, 0xFF8A91AE);
        d.setPadding(0, dp(3), 0, 0);
        d.setGravity(Gravity.CENTER);
        q.addView(d, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        return Ui.pressable(q);
    }

    private Button galBtn(String icon, String text) {
        Button b = Ui.btn(this, text);
        b.setTextColor(0xFFD9DDF0);
        b.setBackground(Ui.bgStroke(0x0FFFFFFF, 0x17FFFFFF, dp(12), dp(1)));
        b.setCompoundDrawablesRelativeWithIntrinsicBounds(Ui.icon(this, icon, 0xFFD9DDF0), null, null, null);
        b.setCompoundDrawablePadding(dp(6));
        b.setPadding(dp(11), 0, dp(12), 0);
        return b;
    }

    private Button tab(String label, int count, boolean on) {
        Button b = Ui.btn(this, label + "  " + count);
        b.setTextSize(13);
        b.setPadding(dp(14), 0, dp(14), 0);
        b.setTextColor(on ? 0xFFFFFFFF : 0xFFAEB5CF);
        b.setBackground(on ? Ui.bg(Ui.ACC, dp(999)) : Ui.bgStroke(0x0DFFFFFF, 0x17FFFFFF, dp(999), dp(1)));
        return b;
    }

    /* ---------------- galeria ---------------- */

    @Override protected void onResume() {
        super.onResume();
        if (bgView != null) { bgView.running = true; bgView.invalidate(); }
        if (hiTv != null) hiTv.setText(greet());
        Project.purgeTrash(this);
        refresh();
    }

    @Override protected void onPause() {
        super.onPause();
        if (bgView != null) bgView.running = false;
    }

    private String greet() {
        String n = Prefs.get(this).getString("userName", "").trim();
        String h = hello();
        return n.isEmpty() ? h : h.substring(0, h.length() - 1) + ", " + n + "!";
    }

    private static String hello() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return h >= 5 && h < 12 ? "Bom dia!" : h >= 12 && h < 18 ? "Boa tarde!" : "Boa noite!";
    }

    private void refresh() {
        ArrayList<Project> all = Project.list(this);
        int nd = 0, na = 0;
        for (Project p : all) { if (p.anim) na++; else nd++; }
        countTv.setText(String.valueOf(all.size()));
        int nf = 0, frames = 0, favs = 0;
        for (Project p : all) { frames += p.frames.size(); if (p.fav) favs++; }
        nf = frames;
        statsTv.setText(all.isEmpty() ? "Seu primeiro projeto começa com um toque."
                : nd + (nd == 1 ? " desenho" : " desenhos") + " · " + na + (na == 1 ? " animação" : " animações") + " · " + nf + " quadros");
        fillHero(all);
        sortBtn.setText(sort == 1 ? "Nome" : sort == 2 ? "Antigos" : "Recentes");
        viewIcon.setImageDrawable(Ui.icon(this, list ? "grid" : "list", 0xFFD9DDF0));
        tabs.removeAllViews();
        String[] names = {"Tudo", "Desenhos", "Animações", "★ Favoritos"};
        int[] counts = {all.size(), nd, na, favs};
        for (int i = 0; i < 4; i++) {
            final int fi = i;
            Button b = tab(names[i], counts[i], filter == i);
            b.setOnClickListener(v -> { filter = fi; Prefs.put(this, "filter", fi); refresh(); });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.WRAP, dp(34));
            l.rightMargin = dp(6);
            tabs.addView(b, l);
        }
        ArrayList<Project> L = new ArrayList<>();
        for (Project p : all) {
            boolean ok = filter == 0 || (filter == 3 ? p.fav : (filter == 1) == !p.anim);
            if (ok && !query.isEmpty() && !p.name.toLowerCase().contains(query)) ok = false;
            if (ok) L.add(p);
        }
        if (sort == 1) Collections.sort(L, (a, b) -> a.name.compareToIgnoreCase(b.name));
        else if (sort == 2) Collections.sort(L, (a, b) -> Long.compare(a.created, b.created));
        gal.removeAllViews();
        if (L.isEmpty()) { gal.addView(empty(!all.isEmpty())); return; }
        if (sort == 0) Collections.sort(L, (a, b) -> a.fav == b.fav ? 0 : a.fav ? -1 : 1);
        if (list) {
            for (int i = 0; i < L.size(); i++) {
                View c = listCard(L.get(i));
                LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP);
                l.bottomMargin = dp(8);
                gal.addView(c, l);
                enter(c, i);
            }
            return;
        }
        int wdp = (int) (getResources().getDisplayMetrics().widthPixels / dens);
        int cols = wide ? Math.max(3, (wdp - 36) / 200) : 2;
        LinearLayout row = null;
        for (int i = 0; i < L.size(); i++) {
            if (i % cols == 0) {
                row = Ui.row(this);
                row.setGravity(Gravity.TOP);
                LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP);
                rl.bottomMargin = dp(12);
                gal.addView(row, rl);
            }
            View c = gridCard(L.get(i));
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, Ui.WRAP, 1);
            if (i % cols > 0) l.leftMargin = dp(12);
            row.addView(c, l);
            enter(c, i);
        }
        int rest = L.size() % cols;
        if (rest > 0) for (int k = rest; k < cols; k++) {
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, 1, 1);
            l.leftMargin = dp(12);
            row.addView(new View(this), l);
        }
    }

    private void enter(View v, int k) {
        v.setAlpha(0f);
        v.setTranslationY(dp(10));
        v.animate().alpha(1f).translationY(0).setStartDelay(Math.min(500, 40L * k)).setDuration(420).start();
    }

    private View empty(boolean filtered) {
        LinearLayout e = Ui.col(this);
        e.setGravity(Gravity.CENTER_HORIZONTAL);
        e.setPadding(dp(20), dp(24), dp(20), dp(28));
        e.setBackground(Ui.dashed(0x1FFFFFFF, dp(22), dp(1.5f), dp(5)));
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(Ui.art(this, "art_empty"));
        e.addView(iv, new LinearLayout.LayoutParams(dp(170), dp(128)));
        TextView t = Ui.text(this, filtered ? "Nada nesta aba ainda" : "Sua galeria está vazia", 16, 0xFFEEF0FA, true);
        t.setPadding(0, dp(6), 0, dp(6));
        e.addView(t);
        TextView s = Ui.text(this, filtered ? "Troque de aba ou crie algo novo." : "Crie um desenho ou uma animação. Tudo fica salvo aqui no aparelho.", 13, 0xFF9AA1BD, false);
        s.setGravity(Gravity.CENTER);
        s.setLineSpacing(0, 1.3f);
        e.addView(s, new LinearLayout.LayoutParams(dp(300), Ui.WRAP));
        return e;
    }

    private static String when(long t) {
        long d = (System.currentTimeMillis() - t) / 1000;
        if (d < 60) return "agora";
        if (d < 3600) return (d / 60) + " min atrás";
        if (d < 86400) return (d / 3600) + " h atrás";
        if (d < 172800) return "ontem";
        return new SimpleDateFormat("dd MMM", new Locale("pt", "BR")).format(new Date(t));
    }

    private void loadThumb(Project p, ThumbView tv) {
        final String key = p.thumbFile().getPath() + ":" + p.thumbFile().lastModified();
        Bitmap c = thumbs.get(key);
        if (c != null) { tv.setBitmap(c); return; }
        if (!p.thumbFile().exists()) return;
        io.execute(() -> {
            Bitmap b = BitmapFactory.decodeFile(p.thumbFile().getPath());
            if (b == null) return;
            ui.post(() -> { thumbs.put(key, b); tv.setBitmap(b); });
        });
    }

    private View badge(Project p) {
        LinearLayout b = Ui.row(this);
        b.setPadding(dp(6), dp(4), dp(9), dp(4));
        b.setBackground(Ui.bg(0xC7090A12, dp(999)));
        if (p.fav) {
            TextView st = Ui.text(this, "★", 11, 0xFFF2C94C, true);
            st.setPadding(0, 0, dp(4), 0);
            b.addView(st);
        }
        b.addView(Ui.iconView(this, p.anim ? "film" : "brush", p.anim ? 0xFF6FD3FF : 0xFFFF8FB0, 13));
        TextView t = Ui.text(this, p.anim ? p.frames.size() + (p.frames.size() == 1 ? " quadro" : " quadros") : "Desenho", 10.5f, 0xFFFFFFFF, true);
        t.setPadding(dp(4), 0, 0, 0);
        b.addView(t);
        return b;
    }

    private View meta(final Project p, int padL) {
        LinearLayout m = Ui.row(this);
        m.setPadding(padL, dp(10), dp(6), dp(11));
        LinearLayout tx = Ui.col(this);
        TextView n = Ui.text(this, p.name, 13.5f, 0xFFF0F2FB, true);
        n.setSingleLine(true);
        n.setEllipsize(TextUtils.TruncateAt.END);
        TextView i = Ui.text(this, p.w + "×" + p.h + " · " + when(p.updated), 11, Ui.DIM, false);
        i.setSingleLine(true);
        i.setPadding(0, dp(3), 0, 0);
        tx.addView(n);
        tx.addView(i);
        m.addView(tx, Ui.lpw(1));
        FrameLayout more = new FrameLayout(this);
        more.addView(Ui.iconView(this, "dots", 0xFF9AA1BD, 22), new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        more.setOnClickListener(v -> projectSheet(p));
        m.addView(more, new LinearLayout.LayoutParams(dp(34), dp(34)));
        return m;
    }

    private View gridCard(final Project p) {
        LinearLayout c = Ui.col(this);
        c.setBackground(Ui.bgStroke(Ui.CARD, 0x12FFFFFF, dp(20), dp(1)));
        c.setClipToOutline(true);
        FrameLayout th = new FrameLayout(this);
        ThumbView tv = new ThumbView(this);
        th.addView(tv, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP | Gravity.START);
        bl.setMargins(dp(8), dp(8), 0, 0);
        th.addView(badge(p), bl);
        c.addView(th);
        c.addView(meta(p, dp(12)));
        loadThumb(p, tv);
        c.setOnClickListener(v -> open(p, null));
        c.setOnLongClickListener(v -> { projectSheet(p); return true; });
        return Ui.pressable(c);
    }

    private View listCard(final Project p) {
        LinearLayout c = Ui.row(this);
        c.setBackground(Ui.bgStroke(Ui.CARD, 0x12FFFFFF, dp(16), dp(1)));
        c.setClipToOutline(true);
        ThumbView tv = new ThumbView(this);
        c.addView(tv, new LinearLayout.LayoutParams(dp(78), dp(78)));
        c.addView(meta(p, dp(14)), Ui.lpw(1));
        loadThumb(p, tv);
        c.setOnClickListener(v -> open(p, null));
        c.setOnLongClickListener(v -> { projectSheet(p); return true; });
        return Ui.pressable(c);
    }

    /* ---------------- ações ---------------- */

    private void open(Project p, String action) {
        Intent it = new Intent(this, EditorActivity.class);
        it.putExtra("dir", p.dir.getPath());
        if (action != null) it.putExtra("action", action);
        startActivity(it);
    }

    private Project create(String name, int w, int h, boolean anim, int paper, int fps, int frames) {
        int nd = 0, na = 0;
        for (Project q : Project.list(this)) { if (q.anim) na++; else nd++; }
        if (name == null || name.trim().isEmpty()) name = anim ? "Animação " + (na + 1) : "Desenho " + (nd + 1);
        Project p = Project.create(this, name.length() > 40 ? name.substring(0, 40) : name, w, h, anim);
        p.paper = paper;
        p.fps = fps;
        for (int i = 1; i < frames; i++) p.frames.add(p.nextFrame++);
        p.save();
        open(p, null);
        return p;
    }

    private void newProject(boolean anim) { newProjectSheet(anim, false); }

    private void openImage() {
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.setType("image/*");
        it.addCategory(Intent.CATEGORY_OPENABLE);
        try { startActivityForResult(Intent.createChooser(it, "Abrir imagem"), REQ_OPEN_IMAGE); }
        catch (Exception e) { Ui.toast(this, "Não há app de galeria"); }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_IMPORT_PROJ && res == RESULT_OK && data != null && data.getData() != null) {
            final Uri u = data.getData();
            Ui.toast(this, "Importando…");
            io.execute(() -> {
                Project p = null;
                try { InputStream in = getContentResolver().openInputStream(u); p = Project.importZip(this, in); } catch (Exception ignored) { }
                final Project fp = p;
                ui.post(() -> { Ui.toast(this, fp == null ? "Esse arquivo não é um projeto do Dark Monia" : "Projeto \"" + fp.name + "\" importado"); refresh(); });
            });
            return;
        }
        if (req != REQ_OPEN_IMAGE || res != RESULT_OK || data == null || data.getData() == null) return;
        try {
            Uri uri = data.getData();
            Bitmap src = decodeUri(uri, Project.MAX_SIDE);
            if (src == null) { Ui.toast(this, "Não consegui ler essa imagem"); return; }
            int[] s = Project.fit(src.getWidth(), src.getHeight());
            Bitmap scaled = Bitmap.createScaledBitmap(src, s[0], s[1], true);
            if (scaled != src) src.recycle();
            int nd = 0;
            for (Project q : Project.list(this)) if (!q.anim) nd++;
            Project p = Project.create(this, "Desenho " + (nd + 1), s[0], s[1], false);
            p.layers.get(0).name = "Imagem";
            Project.writePng(scaled, p.layerFile(p.frames.get(0), p.layers.get(0).id));
            p.addLayer("Desenho");
            float k = 320f / Math.max(s[0], s[1]);
            Bitmap t = Bitmap.createScaledBitmap(scaled, Math.max(1, Math.round(s[0] * k)), Math.max(1, Math.round(s[1] * k)), true);
            Project.writePng(t, p.thumbFile());
            scaled.recycle();
            p.save();
            open(p, null);
        } catch (Throwable e) {
            Ui.toast(this, "Não consegui abrir essa imagem");
        }
    }

    Bitmap decodeUri(Uri uri, int maxSide) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream in = getContentResolver().openInputStream(uri);
        BitmapFactory.decodeStream(in, null, o);
        if (in != null) in.close();
        int ss = 1;
        while (Math.max(o.outWidth, o.outHeight) / (ss * 2) >= maxSide) ss *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = ss;
        in = getContentResolver().openInputStream(uri);
        Bitmap b = BitmapFactory.decodeStream(in, null, o2);
        if (in != null) in.close();
        return b;
    }

    /* ---------------- folhas ---------------- */

    private View sheetRow(String icon, String title, String sub) {
        LinearLayout r = Ui.row(this);
        r.setPadding(dp(14), dp(14), dp(14), dp(14));
        r.setBackground(Ui.bgStroke(Ui.PANEL2, Ui.LINE, dp(16), dp(1)));
        r.addView(Ui.iconView(this, icon, Ui.ACC, 28));
        LinearLayout t = Ui.col(this);
        t.setPadding(dp(14), 0, 0, 0);
        t.addView(Ui.text(this, title, 15, Ui.FG, true));
        TextView s = Ui.text(this, sub, 12, Ui.MUTE, false);
        s.setPadding(0, dp(3), 0, 0);
        t.addView(s);
        r.addView(t, Ui.lpw(1));
        return Ui.pressable(r);
    }

    private LinearLayout.LayoutParams gapBottom(int d) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP);
        l.bottomMargin = dp(d);
        return l;
    }

    private Button closeBtn(Sheet s, String t) {
        Button b = Ui.btn(this, t);
        b.setBackground(null);
        b.setTextColor(Ui.MUTE);
        b.setOnClickListener(v -> s.dismiss());
        return b;
    }

    private void addClose(Sheet s, Button b) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        l.gravity = Gravity.END;
        l.topMargin = dp(8);
        s.add(b, l);
    }

    private void createSheet() {
        Sheet s = new Sheet(this, "Criar");
        View a = sheetRow("brush", "Novo desenho", "uma tela, várias camadas");
        View b = sheetRow("film", "Nova animação", "quadro a quadro");
        View c = sheetRow("image", "Abrir imagem", "pintar por cima");
        a.setOnClickListener(v -> { s.dismiss(); newProject(false); });
        b.setOnClickListener(v -> { s.dismiss(); newProject(true); });
        c.setOnClickListener(v -> { s.dismiss(); openImage(); });
        s.add(a, gapBottom(10));
        s.add(b, gapBottom(10));
        s.add(c, gapBottom(10));
        View z = sheetRow("down", "Importar projeto", "abrir uma cópia .zip do Dark Monia");
        z.setOnClickListener(v -> { s.dismiss(); importProject(); });
        s.add(z, gapBottom(4));
        addClose(s, closeBtn(s, "Fechar"));
        s.show();
    }

    static EditText input(android.content.Context c, String hint) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(0xFF6A7090);
        e.setTextColor(Ui.FG);
        e.setTextSize(15);
        e.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        e.setSingleLine(true);
        int p = Ui.dp(c, 12);
        e.setPadding(p, Ui.dp(c, 11), p, Ui.dp(c, 11));
        e.setBackground(Ui.bgStroke(Ui.PANEL2, Ui.LINE, Ui.dp(c, 12), Ui.dp(c, 1)));
        return e;
    }

    private View paperRow(final int[] chosen, boolean transparent) {
        final LinearLayout wrap = Ui.col(this);
        final ArrayList<View> all = new ArrayList<>();
        final ArrayList<Integer> cols = new ArrayList<>();
        if (transparent) cols.add(0);
        for (int c : PAPERS) cols.add(c);
        LinearLayout row = null;
        for (int i = 0; i < cols.size(); i++) {
            if (i % 7 == 0) {
                row = Ui.row(this);
                wrap.addView(row, gapBottom(10));
            }
            final int col = cols.get(i);
            View sw = new View(this) {
                final Paint ck = new Paint();
                @Override protected void onDraw(Canvas c) {
                    if (col == 0) {
                        int cell = Ui.dp(getContext(), 6);
                        for (int y = 0; y < getHeight(); y += cell)
                            for (int x = 0; x < getWidth(); x += cell) {
                                ck.setColor(((x + y) / cell) % 2 == 0 ? 0xFFFFFFFF : 0xFFCFD2DC);
                                c.drawRect(x, y, x + cell, y + cell, ck);
                            }
                    }
                }
            };
            sw.setClipToOutline(true);
            all.add(sw);
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(dp(40), dp(40));
            l.rightMargin = dp(10);
            row.addView(sw, l);
            sw.setOnClickListener(v -> {
                chosen[0] = col;
                for (int j = 0; j < all.size(); j++) paintSwatch(all.get(j), cols.get(j), cols.get(j) == chosen[0]);
            });
        }
        for (int j = 0; j < all.size(); j++) paintSwatch(all.get(j), cols.get(j), cols.get(j) == chosen[0]);
        return wrap;
    }

    private void paintSwatch(View v, int col, boolean on) {
        GradientDrawable g = Ui.bg(col == 0 ? 0xFFFFFFFF : col, dp(12));
        if (on) g.setStroke(dp(3), Ui.ACC);
        else g.setStroke(dp(1), 0x73808080);
        v.setBackground(g);
        v.invalidate();
    }

    private Button chip(String t, boolean on) {
        Button b = Ui.btn(this, t);
        b.setTextSize(14);
        b.setPadding(dp(14), dp(9), dp(14), dp(9));
        Ui.sel(b, on);
        if (!on) b.setBackground(Ui.bg(Ui.PANEL2, dp(999)));
        return b;
    }

    /** Novo projeto (desenho ou animação), com as mesmas opções do app 5.0. */
    private void newProjectSheet(boolean animStart, boolean customStart) {
        final Sheet s = new Sheet(this, animStart ? "Nova animação" : "Novo desenho");
        final boolean[] anim = {animStart};
        final int[] size = {customStart ? -1 : 0};
        final int[] paper = {0xFFFFFFFF};
        final int[] apaper = {0xFFFBFAF6};
        final int[] ratio = {0}, res = {2}, fps = {12};
        final boolean[] vert = {false}, acustom = {false};
        final String[] RATIOS = {"16:9", "4:3", "1:1", "21:9", "Outro"};
        final int[][] RV = {{16, 9}, {4, 3}, {1, 1}, {21, 9}};
        final String[] RES = {"480p", "720p", "1080p", "2K", "4K"};
        final int[] RESV = {480, 720, 1080, 1440, 2160};
        final int[] FPS = {6, 8, 12, 15, 24, 30};

        LinearLayout seg = Ui.row(this);
        seg.setBackground(Ui.bg(Ui.PANEL2, dp(12)));
        seg.setPadding(dp(3), dp(3), dp(3), dp(3));
        final Button sd = segBtn("brush", "Desenho"), sa = segBtn("film", "Animação");
        seg.addView(sd, Ui.lpw(1));
        seg.addView(sa, Ui.lpw(1));
        s.add(seg, gapBottom(14));
        final EditText name = input(this, "Nome do projeto");
        s.add(name);

        final LinearLayout drawSec = Ui.col(this), animSec = Ui.col(this);
        s.add(drawSec);
        s.add(animSec);

        /* --- desenho --- */
        drawSec.addView(secTitle("Tamanho da tela"));
        final LinearLayout sizes = Ui.col(this);
        drawSec.addView(sizes);
        final LinearLayout cust = Ui.row(this);
        final EditText dw = input(this, "Largura"), dh = input(this, "Altura");
        dw.setInputType(InputType.TYPE_CLASS_NUMBER);
        dh.setInputType(InputType.TYPE_CLASS_NUMBER);
        dw.setText("1080");
        dh.setText("1080");
        dw.setGravity(Gravity.CENTER);
        dh.setGravity(Gravity.CENTER);
        Button swap = Ui.btn(this, "⇄");
        swap.setTextSize(18);
        swap.setBackground(Ui.bgStroke(Ui.PANEL2, Ui.LINE, dp(12), dp(1)));
        swap.setOnClickListener(v -> { CharSequence t = dw.getText(); dw.setText(dh.getText()); dh.setText(t); });
        cust.addView(dw, new LinearLayout.LayoutParams(dp(100), Ui.WRAP));
        LinearLayout.LayoutParams swl = new LinearLayout.LayoutParams(dp(44), dp(44));
        swl.setMargins(dp(8), 0, dp(8), 0);
        cust.addView(swap, swl);
        cust.addView(dh, new LinearLayout.LayoutParams(dp(100), Ui.WRAP));
        TextView px = Ui.text(this, "px", 13, Ui.MUTE, false);
        px.setPadding(dp(8), 0, 0, 0);
        cust.addView(px);
        LinearLayout.LayoutParams cl = gapBottom(0);
        cl.topMargin = dp(10);
        drawSec.addView(cust, cl);
        final TextView dinfo = Ui.mono(this, "", 12, Ui.MUTE);
        dinfo.setPadding(0, dp(10), 0, 0);
        drawSec.addView(dinfo);
        drawSec.addView(secTitle("Fundo"));
        drawSec.addView(paperRow(paper, true));

        /* --- animação --- */
        animSec.addView(secTitle("Formato"));
        final LinearLayout ratios = Ui.row(this);
        animSec.addView(wrapH(ratios));
        final LinearLayout ori = Ui.row(this);
        ori.setBackground(Ui.bg(Ui.PANEL2, dp(12)));
        ori.setPadding(dp(3), dp(3), dp(3), dp(3));
        final Button oh = segBtn(null, "Horizontal"), ov = segBtn(null, "Vertical");
        ori.addView(oh, Ui.lpw(1));
        ori.addView(ov, Ui.lpw(1));
        LinearLayout.LayoutParams ol = gapBottom(0);
        ol.topMargin = dp(10);
        animSec.addView(ori, ol);
        final TextView resT = secTitle("Resolução");
        animSec.addView(resT);
        final LinearLayout resRow = Ui.row(this);
        animSec.addView(wrapH(resRow));
        final LinearLayout acust = Ui.row(this);
        final EditText aw = input(this, "Largura"), ah = input(this, "Altura");
        aw.setInputType(InputType.TYPE_CLASS_NUMBER);
        ah.setInputType(InputType.TYPE_CLASS_NUMBER);
        aw.setText("1920");
        ah.setText("1080");
        aw.setGravity(Gravity.CENTER);
        ah.setGravity(Gravity.CENTER);
        acust.addView(aw, new LinearLayout.LayoutParams(dp(100), Ui.WRAP));
        TextView x = Ui.text(this, "×", 15, Ui.MUTE, true);
        x.setPadding(dp(10), 0, dp(10), 0);
        acust.addView(x);
        acust.addView(ah, new LinearLayout.LayoutParams(dp(100), Ui.WRAP));
        animSec.addView(acust, ol);
        final TextView ainfo = Ui.mono(this, "", 12, Ui.MUTE);
        ainfo.setPadding(0, dp(10), 0, 0);
        animSec.addView(ainfo);
        animSec.addView(secTitle("Quadros"));
        LinearLayout fr = Ui.row(this);
        final EditText nf = input(this, "12");
        nf.setInputType(InputType.TYPE_CLASS_NUMBER);
        nf.setText("12");
        nf.setGravity(Gravity.CENTER);
        fr.addView(nf, new LinearLayout.LayoutParams(dp(84), Ui.WRAP));
        for (int v : new int[]{1, 12, 24, 48, 100}) {
            Button b = chip(String.valueOf(v), false);
            b.setOnClickListener(q -> nf.setText(String.valueOf(v)));
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
            l.leftMargin = dp(8);
            fr.addView(b, l);
        }
        animSec.addView(wrapH(fr));
        animSec.addView(secTitle("Velocidade (fps)"));
        final LinearLayout fpsRow = Ui.row(this);
        animSec.addView(wrapH(fpsRow));
        animSec.addView(secTitle("Fundo inicial"));
        animSec.addView(paperRow(apaper, false));

        final Button go = new Button(this);
        go.setAllCaps(false);
        go.setTextColor(0xFFFFFFFF);
        go.setTextSize(15);
        go.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        go.setBackground(Ui.grad(Ui.ACC, Ui.VIOLET, dp(14)));
        go.setStateListAnimator(null);
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(Ui.MATCH, dp(52));
        gl.topMargin = dp(20);
        s.add(go, gl);
        addClose(s, closeBtn(s, "Cancelar"));

        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            boolean a = anim[0];
            s.title.setText(a ? "Nova animação" : "Novo desenho");
            go.setText(a ? "Criar animação" : "Criar desenho");
            segPaint(sd, !a);
            segPaint(sa, a);
            drawSec.setVisibility(a ? View.GONE : View.VISIBLE);
            animSec.setVisibility(a ? View.VISIBLE : View.GONE);
            int n = 0;
            for (Project q : Project.list(this)) if (q.anim == a) n++;
            name.setHint((a ? "Animação " : "Desenho ") + (n + 1));
            /* tamanhos */
            sizes.removeAllViews();
            LinearLayout row = null;
            int total = SIZES.length + 1;
            for (int i = 0; i < total; i++) {
                if (i % 3 == 0) { row = Ui.row(this); sizes.addView(row, gapBottom(8)); }
                final int fi = i < SIZES.length ? i : -1;
                View b = sizeBtn(fi, size[0] == fi);
                b.setOnClickListener(v -> {
                    size[0] = fi;
                    if (fi >= 0) { dw.setText(String.valueOf(SIZES[fi][0])); dh.setText(String.valueOf(SIZES[fi][1])); }
                    render[0].run();
                });
                LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, Ui.WRAP, 1);
                if (i % 3 > 0) l.leftMargin = dp(8);
                row.addView(b, l);
            }
            for (int k = total % 3; k > 0 && k < 3; k++) {
                LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, 1, 1);
                l.leftMargin = dp(8);
                row.addView(new View(this), l);
            }
            cust.setVisibility(size[0] == -1 ? View.VISIBLE : View.GONE);
            int[] d = drawDims(size[0], dw, dh);
            int[] f = Project.fit(d[0], d[1]);
            dinfo.setText(d[0] + " × " + d[1] + " px" + ((f[0] != d[0] || f[1] != d[1]) ? " · tela de trabalho " + f[0] + "×" + f[1] : ""));
            /* animação */
            ratios.removeAllViews();
            for (int i = 0; i < RATIOS.length; i++) {
                final int fi = i;
                boolean on = fi == 4 ? acustom[0] : (!acustom[0] && ratio[0] == fi);
                Button b = chip(RATIOS[i], on);
                b.setOnClickListener(v -> { if (fi == 4) acustom[0] = true; else { acustom[0] = false; ratio[0] = fi; } render[0].run(); });
                LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
                l.rightMargin = dp(8);
                ratios.addView(b, l);
            }
            boolean sq = !acustom[0] && ratio[0] == 2;
            ori.setVisibility(acustom[0] || sq ? View.GONE : View.VISIBLE);
            segPaint(oh, !vert[0]);
            segPaint(ov, vert[0]);
            resT.setVisibility(acustom[0] ? View.GONE : View.VISIBLE);
            resRow.setVisibility(acustom[0] ? View.GONE : View.VISIBLE);
            acust.setVisibility(acustom[0] ? View.VISIBLE : View.GONE);
            resRow.removeAllViews();
            for (int i = 0; i < RES.length; i++) {
                final int fi = i;
                Button b = chip(RES[i], res[0] == fi);
                b.setOnClickListener(v -> { res[0] = fi; render[0].run(); });
                LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
                l.rightMargin = dp(8);
                resRow.addView(b, l);
            }
            fpsRow.removeAllViews();
            for (int v : FPS) {
                Button b = chip(String.valueOf(v), fps[0] == v);
                b.setOnClickListener(q -> { fps[0] = v; render[0].run(); });
                LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
                l.rightMargin = dp(8);
                fpsRow.addView(b, l);
            }
            int[] ad = animDims(acustom[0], ratio[0], RV, RESV[res[0]], vert[0], aw, ah);
            int[] af = Project.fit(ad[0], ad[1]);
            ainfo.setText(ad[0] + " × " + ad[1] + " px" + ((af[0] != ad[0] || af[1] != ad[1]) ? " · tela de trabalho " + af[0] + "×" + af[1] : ""));
        };
        sd.setOnClickListener(v -> { anim[0] = false; render[0].run(); });
        sa.setOnClickListener(v -> { anim[0] = true; render[0].run(); });
        oh.setOnClickListener(v -> { vert[0] = false; render[0].run(); });
        ov.setOnClickListener(v -> { vert[0] = true; render[0].run(); });
        go.setOnClickListener(v -> {
            String nm = name.getText().toString().trim();
            if (anim[0]) {
                int[] ad = animDims(acustom[0], ratio[0], RV, RESV[res[0]], vert[0], aw, ah);
                int n = 12;
                try { n = Ui.clamp(Integer.parseInt(nf.getText().toString().trim()), 1, 500); } catch (Exception ignored) { }
                s.dismiss();
                create(nm, ad[0], ad[1], true, apaper[0], fps[0], n);
            } else {
                int[] d = drawDims(size[0], dw, dh);
                s.dismiss();
                create(nm, d[0], d[1], false, paper[0], 12, 1);
            }
        });
        render[0].run();
        s.show();
    }

    private int[] drawDims(int size, EditText w, EditText h) {
        if (size >= 0) return SIZES[size];
        return new int[]{num(w, 1080, 16, 8000), num(h, 1080, 16, 8000)};
    }

    private int[] animDims(boolean custom, int ratio, int[][] RV, int res, boolean vert, EditText w, EditText h) {
        if (custom) return new int[]{num(w, 1920, 64, 7680) / 2 * 2, num(h, 1080, 64, 7680) / 2 * 2};
        int rw = RV[ratio][0], rh = RV[ratio][1];
        int ww = Math.round(res * rw / (float) rh) / 2 * 2, hh = res;
        if (rw != rh && vert) { int t = ww; ww = hh; hh = t; }
        return new int[]{ww, hh};
    }

    private static int num(EditText e, int def, int min, int max) {
        try { return Ui.clamp(Integer.parseInt(e.getText().toString().trim()), min, max); }
        catch (Exception ex) { return def; }
    }

    private View wrapH(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }

    private TextView secTitle(String t) {
        TextView v = Ui.text(this, t.toUpperCase(), 11, Ui.MUTE, true);
        v.setLetterSpacing(0.07f);
        v.setPadding(0, dp(18), 0, dp(10));
        return v;
    }

    private Button segBtn(String icon, String t) {
        Button b = Ui.btn(this, t);
        b.setTextSize(14);
        b.setPadding(0, dp(10), 0, dp(10));
        if (icon != null) {
            b.setCompoundDrawablesRelativeWithIntrinsicBounds(Ui.icon(this, icon, Ui.MUTE), null, null, null);
            b.setCompoundDrawablePadding(dp(7));
            b.setTag(icon);
        }
        return b;
    }

    private void segPaint(Button b, boolean on) {
        b.setBackground(on ? Ui.bg(Ui.ACC, dp(9)) : null);
        b.setTextColor(on ? 0xFFFFFFFF : Ui.MUTE);
        Object ic = b.getTag();
        if (ic instanceof String)
            b.setCompoundDrawablesRelativeWithIntrinsicBounds(Ui.icon(this, (String) ic, on ? 0xFFFFFFFF : Ui.MUTE), null, null, null);
    }

    private View sizeBtn(int i, boolean on) {
        LinearLayout b = Ui.col(this);
        b.setGravity(Gravity.CENTER_HORIZONTAL);
        b.setPadding(dp(4), dp(9), dp(4), dp(8));
        GradientDrawable g = Ui.bg(on ? blend(Ui.ACC, Ui.PANEL2, 0.14f) : Ui.PANEL2, dp(14));
        g.setStroke(dp(on ? 2 : 1), on ? Ui.ACC : Ui.LINE);
        b.setBackground(g);
        View box;
        if (i < 0) {
            FrameLayout f = new FrameLayout(this);
            f.addView(Ui.iconView(this, "plus", Ui.ACC, 22), new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
            box = f;
        } else box = new RatioBox(this, SIZES[i][0], SIZES[i][1], 30);
        b.addView(box, new LinearLayout.LayoutParams(dp(40), dp(36)));
        TextView n = Ui.text(this, i < 0 ? "Outro" : SIZE_NAMES[i], 12, Ui.FG, true);
        n.setSingleLine(true);
        n.setEllipsize(TextUtils.TruncateAt.END);
        n.setPadding(0, dp(3), 0, dp(2));
        b.addView(n);
        b.addView(Ui.mono(this, i < 0 ? "escolher" : SIZES[i][0] + "×" + SIZES[i][1], 9, Ui.MUTE));
        return Ui.pressable(b);
    }

    static int blend(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) * t + ((b >> 16) & 255) * (1 - t));
        int g = Math.round(((a >> 8) & 255) * t + ((b >> 8) & 255) * (1 - t));
        int bl = Math.round((a & 255) * t + (b & 255) * (1 - t));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Opções de um projeto (botão ⋯). */
    private void projectSheet(final Project p) {
        final Sheet s = new Sheet(this, null);
        ThumbView tv = new ThumbView(this);
        tv.square = false;
        tv.setBackground(Ui.bg(0xFF0C0E18, dp(14)));
        tv.setClipToOutline(true);
        s.add(tv, new LinearLayout.LayoutParams(Ui.MATCH, dp(190)));
        loadThumb(p, tv);
        final EditText name = input(this, "Nome do projeto");
        name.setText(p.name);
        LinearLayout.LayoutParams nl = gapBottom(0);
        nl.topMargin = dp(14);
        s.add(name, nl);
        TextView info = Ui.mono(this, p.w + "×" + p.h + " px · " + (p.anim ? p.frames.size() + " quadros · " + p.fps + " fps" : "desenho"), 12, Ui.MUTE);
        info.setPadding(0, dp(10), 0, dp(12));
        s.add(info);
        Button edit = bigBtn("Editar");
        edit.setOnClickListener(v -> { s.dismiss(); open(p, null); });
        s.add(edit, gapBottom(8));
        if (p.anim) {
            Button play = bigBtn("▶  Assistir animação");
            play.setBackground(Ui.bgStroke(Ui.PANEL2, Ui.LINE, dp(14), dp(1)));
            play.setOnClickListener(v -> { s.dismiss(); open(p, "play"); });
            s.add(play, gapBottom(8));
        }
        LinearLayout opts = Ui.row(this);
        View ex = opt(p.anim ? "Salvar vídeo" : "Exportar", p.anim ? "mp4 · gif" : "imagem");
        View dup = opt("Duplicar", "fazer cópia");
        final LinearLayout del = (LinearLayout) opt("Excluir", "apagar");
        ex.setOnClickListener(v -> { s.dismiss(); open(p, "export"); });
        dup.setOnClickListener(v -> {
            Project d = p.duplicate(this);
            s.dismiss();
            Ui.toast(this, d == null ? "Não consegui duplicar" : "Projeto duplicado");
            refresh();
        });
        final boolean[] armed = {false};
        del.setOnClickListener(v -> {
            if (!armed[0]) {
                armed[0] = true;
                ((TextView) del.getChildAt(0)).setText("Certeza?");
                ((TextView) del.getChildAt(1)).setText("toque de novo");
                del.setBackground(Ui.bgStroke(0x33E5476B, Ui.ACC, dp(14), dp(1)));
                ui.postDelayed(() -> {
                    if (!armed[0]) return;
                    armed[0] = false;
                    ((TextView) del.getChildAt(0)).setText("Excluir");
                    ((TextView) del.getChildAt(1)).setText("apagar");
                    del.setBackground(Ui.bg(Ui.PANEL2, dp(14)));
                }, 2500);
                return;
            }
            final Project tp = p;
            boolean ok = p.moveToTrash(this);
            s.dismiss();
            refresh();
            Ui.toast(this, ok ? "Foi para a Lixeira (fica 30 dias)" : "Não consegui excluir");
            if (!ok) tp.deleteAll();
        });
        LinearLayout extra = Ui.row(this);
        View fav = opt(p.fav ? "★ Favorito" : "☆ Favoritar", p.fav ? "tirar estrela" : "fica no topo");
        fav.setOnClickListener(v -> { p.fav = !p.fav; p.save(); s.dismiss(); refresh(); });
        View bak = opt("Cópia .zip", "backup completo");
        bak.setOnClickListener(v -> { s.dismiss(); backup(p); });
        extra.addView(fav, Ui.lpw(1));
        LinearLayout.LayoutParams e2 = Ui.lpw(1);
        e2.leftMargin = dp(8);
        extra.addView(bak, e2);
        s.add(extra, gapBottom(8));
        opts.addView(ex, Ui.lpw(1));
        LinearLayout.LayoutParams l2 = Ui.lpw(1);
        l2.leftMargin = dp(8);
        opts.addView(dup, l2);
        LinearLayout.LayoutParams l3 = Ui.lpw(1);
        l3.leftMargin = dp(8);
        opts.addView(del, l3);
        s.add(opts);
        addClose(s, closeBtn(s, "Fechar"));
        s.setOnDismissListener(d -> {
            String n = name.getText().toString().trim();
            if (!n.isEmpty() && !n.equals(p.name)) {
                p.name = n.length() > 40 ? n.substring(0, 40) : n;
                p.save();
                refresh();
            }
        });
        s.show();
    }

    private Button bigBtn(String t) {
        Button b = Ui.btn(this, t);
        b.setTextSize(15);
        b.setTextColor(0xFFFFFFFF);
        b.setBackground(Ui.bg(Ui.ACC, dp(14)));
        b.setPadding(0, dp(14), 0, dp(14));
        return b;
    }

    private View opt(String t, String sub) {
        LinearLayout o = Ui.col(this);
        o.setGravity(Gravity.CENTER_HORIZONTAL);
        o.setPadding(dp(4), dp(12), dp(4), dp(12));
        o.setBackground(Ui.bg(Ui.PANEL2, dp(14)));
        TextView a = Ui.text(this, t, 14, Ui.FG, true);
        a.setGravity(Gravity.CENTER);
        o.addView(a);
        TextView b = Ui.mono(this, sub, 11, Ui.MUTE);
        b.setPadding(0, dp(4), 0, 0);
        o.addView(b);
        return Ui.pressable(o);
    }

    /** Configurações: cor do app e gestos. */
    private void settingsSheet() {
        final Sheet s = new Sheet(this, "Configurações");
        s.section("Cor do app");
        LinearLayout grid = Ui.col(this);
        LinearLayout row = null;
        for (int i = 0; i < ACCENTS.length; i++) {
            if (i % 3 == 0) { row = Ui.row(this); grid.addView(row, gapBottom(8)); }
            final int c = ACCENTS[i];
            LinearLayout b = Ui.row(this);
            b.setPadding(dp(10), dp(10), dp(10), dp(10));
            GradientDrawable g = Ui.bg(Ui.PANEL2, dp(12));
            g.setStroke(dp(c == Ui.ACC ? 2 : 1), c == Ui.ACC ? c : Ui.LINE);
            b.setBackground(g);
            View dot = new View(this);
            dot.setBackground(Ui.bg(c, dp(10)));
            b.addView(dot, new LinearLayout.LayoutParams(dp(20), dp(20)));
            TextView t = Ui.text(this, ACCENT_NAMES[i], 12.5f, Ui.FG, true);
            t.setPadding(dp(8), 0, 0, 0);
            t.setSingleLine(true);
            b.addView(t);
            b.setOnClickListener(v -> {
                Prefs.put(this, "accent", c);
                Ui.ACC = c;
                s.dismiss();
                recreate();
            });
            LinearLayout.LayoutParams l = Ui.lpw(1);
            if (i % 3 > 0) l.leftMargin = dp(8);
            row.addView(Ui.pressable(b), l);
        }
        s.add(grid);
        s.section("Gestos");
        s.add(toggle("twoUndo", true, "Toque com 2 dedos desfaz", "3 dedos refaz, como no Procreate e no Ibis Paint"), gapBottom(8));
        s.add(toggle("longPick", true, "Segurar o dedo pega a cor", "conta-gotas rápido sem trocar de ferramenta"), gapBottom(8));
        s.add(toggle("qshape", true, "QuickShape", "segure no fim do traço e ele vira reta, círculo, retângulo…"), gapBottom(8));
        s.add(toggle("rotate", true, "Girar a tela com dois dedos", "gire como uma folha de papel; ímã a cada 90°"), gapBottom(8));
        s.section("Desenho");
        s.add(toggle("tlapse", true, "Gravar time-lapse", "guarda cada passo do desenho para virar um vídeo acelerado"), gapBottom(8));
        s.add(toggle("pressure", true, "Pressão da caneta", "a espessura muda com a força (caneta stylus)"), gapBottom(8));
        s.section("Você");
        final EditText nm = input(this, "Como quer ser chamado?");
        nm.setText(Prefs.get(this).getString("userName", ""));
        s.add(nm, gapBottom(4));
        s.setOnDismissListener(d -> {
            String n = nm.getText().toString().trim();
            Prefs.get(this).edit().putString("userName", n.length() > 20 ? n.substring(0, 20) : n).apply();
            if (hiTv != null) hiTv.setText(greet());
        });
        s.section("Projetos");
        final int nt = Project.listTrash(this).size();
        View tr = sheetRow("trash", "Lixeira" + (nt > 0 ? " · " + nt : ""), "projetos excluídos ficam 30 dias aqui");
        tr.setOnClickListener(v -> { s.dismiss(); trashSheet(); });
        s.add(tr, gapBottom(8));
        View ip = sheetRow("down", "Importar projeto (.zip)", "trazer uma cópia de outro aparelho");
        ip.setOnClickListener(v -> { s.dismiss(); importProject(); });
        s.add(ip, gapBottom(8));
        TextView st = Ui.mono(this, "Espaço usado: " + mb(Project.dirSize(Project.root(this)) + Project.dirSize(Project.trash(this))), 12, Ui.MUTE);
        st.setPadding(0, dp(4), 0, 0);
        s.add(st);
        s.section("Ajuda");
        Button tips = Ui.btn(this, "Ver dicas de novo");
        tips.setOnClickListener(v -> { Prefs.set(this, "tipSeen", false); Ui.toast(this, "As dicas aparecem ao abrir um projeto"); });
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        s.add(tips, tl);
        TextView ver = Ui.mono(this, "Dark Monia Animator 2D · versão 5.0 Studio nativa", 12, Ui.MUTE);
        ver.setPadding(0, dp(16), 0, 0);
        s.add(ver);
        addClose(s, closeBtn(s, "Fechar"));
        s.show();
    }

    private View toggle(final String key, boolean def, String title, String sub) {
        LinearLayout r = Ui.row(this);
        r.setPadding(dp(12), dp(11), dp(12), dp(11));
        r.setBackground(Ui.bgStroke(Ui.PANEL2, Ui.LINE, dp(14), dp(1)));
        LinearLayout t = Ui.col(this);
        t.addView(Ui.text(this, title, 13.5f, Ui.FG, true));
        TextView s = Ui.text(this, sub, 11.5f, Ui.MUTE, false);
        s.setPadding(0, dp(3), 0, 0);
        t.addView(s);
        r.addView(t, Ui.lpw(1));
        final Switch sw = new Switch(this);
        sw.setChecked(Prefs.on(this, key, def));
        android.content.res.ColorStateList th = new android.content.res.ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}}, new int[]{0xFFFFFFFF, 0xFFFFFFFF});
        android.content.res.ColorStateList tr = new android.content.res.ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}}, new int[]{Ui.ACC, 0xFF3A3F57});
        sw.setThumbTintList(th);
        sw.setTrackTintList(tr);
        sw.setOnCheckedChangeListener((b, on) -> Prefs.set(this, key, on));
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        return r;
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }
}
