# Dark Monia Nativo — etapa 1

Versão 100% nativa (Java puro, sem WebView e sem bibliotecas) do Dark Monia Animator.
É um app separado (`com.darkmonia.nativo`), então instala ao lado do Dark Monia Animator 2D sem apagar nada.

## O que já tem
- Tela inicial com "Novo desenho", "Nova animação" e galeria (segure um projeto para renomear ou excluir).
- Pincéis: Lápis, G-Pen (pressão da caneta ou velocidade do dedo), Marcador, Aerógrafo e Borracha.
- Balde, conta-gotas, tamanho e opacidade, seletor de cor (paleta + matiz/saturação/brilho).
- Zoom e mover com dois dedos; toque rápido com dois dedos desfaz. Desfazer/refazer (8 passos).
- Camadas (até 8): criar, excluir, subir/descer, ocultar, opacidade.
- Animação: linha do tempo com miniaturas, novo quadro, duplicar, apagar, fantasma, fps e reprodução.
- Exportar PNG (com ou sem fundo) e todos os quadros em PNG para Imagens/DarkMonia.
- Salvamento automático ao sair do editor.

## O que fica para as próximas etapas
Seleção e transformar, formas, texto, filtros, liquidificar, mesclagem de camadas, simetria,
QuickShape, girar a tela, áudio, exportar vídeo/GIF e os outros pincéis.

## Compilar
- **AndroidIDE / Android Studio:** abra esta pasta e use Build > Build APK.
- **GitHub:** envie esta pasta (com `.github`) para um repositório; na aba Actions a tarefa "Compilar APK"
  gera o `app-debug.apk` em Artifacts.

Aviso: o código foi conferido só contra um molde da API do Android, sem o SDK real. Se a compilação
acusar algum erro, mande a mensagem de erro.
