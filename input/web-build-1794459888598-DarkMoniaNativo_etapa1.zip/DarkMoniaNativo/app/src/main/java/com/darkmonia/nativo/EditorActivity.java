package com.darkmonia.nativo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

/** Editor: tela de desenho, ferramentas, camadas e (nas animações) linha do tempo. */
public class EditorActivity extends Activity implements CanvasView.Listener {
    private Project p;
    private CanvasView cv;
    private LinearLayout strip;
    private TextView frameLbl, sizeLbl, opLbl, fpsLbl;
    private Button colorBtn, undoBtn, redoBtn, playBtn, onionBtn;
    private final Button[] toolBtns = new Button[8];
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ConcurrentHashMap<Integer, Bitmap> thumbs = new ConcurrentHashMap<>();
    private ArrayList<Bitmap> playFrames;
    private boolean playing;
    private int playI;

    private static final String[] TOOLS = {"Lápis", "G-Pen", "Marcador", "Aerógrafo", "Borracha", "Balde", "Conta-gotas", "Mover"};
    private static final int[] SWATCHES = {0xFF16161D, 0xFFFFFFFF, 0xFF8B8680, 0xFFE5472B, 0xFFFF6A1A, 0xFFF2A516, 0xFFFFE27A, 0xFF3F9D4B,
            0xFF1F6B3A, 0xFF39E6FF, 0xFF2D6CDF, 0xFF7B4BD1, 0xFFFF4FD8, 0xFFE58FB1, 0xFF7A5230, 0xFFD9A066};

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        String dir = getIntent().getStringExtra("dir");
        p = dir == null ? null : Project.load(new File(dir));
        if (p == null) { finish(); return; }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.PANEL);
        int g = Ui.dp(this, 4);

        /* barra superior */
        LinearLayout top = row();
        top.setPadding(g, g, g, g);
        Button back = Ui.btn(this, "‹");
        back.setTextSize(18);
        back.setOnClickListener(v -> finish());
        top.addView(back);
        TextView title = new TextView(this);
        title.setText(p.name);
        title.setTextColor(Ui.FG);
        title.setTextSize(15);
        title.setSingleLine(true);
        title.setPadding(Ui.dp(this, 10), 0, 0, 0);
        top.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        undoBtn = Ui.btn(this, "↶");
        redoBtn = Ui.btn(this, "↷");
        undoBtn.setOnClickListener(v -> cv.undo());
        redoBtn.setOnClickListener(v -> cv.redo());
        add(top, undoBtn, g);
        add(top, redoBtn, g);
        if (p.anim) {
            playBtn = Ui.btn(this, "▶");
            Ui.sel(playBtn, true);
            playBtn.setOnClickListener(v -> { if (playing) stopPlay(); else startPlay(); });
            add(top, playBtn, g);
        }
        Button menu = Ui.btn(this, "⋮");
        menu.setOnClickListener(v -> menu());
        add(top, menu, g);
        root.addView(top);

        /* tela */
        cv = new CanvasView(this);
        cv.listener = this;
        root.addView(cv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        /* ferramentas */
        HorizontalScrollView ts = new HorizontalScrollView(this);
        ts.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = row();
        tools.setPadding(g, g, g, 0);
        colorBtn = Ui.btn(this, "  Cor  ");
        colorBtn.setOnClickListener(v -> pickColor());
        add(tools, colorBtn, g);
        Button ly = Ui.btn(this, "Camadas");
        ly.setOnClickListener(v -> layersDialog());
        add(tools, ly, g);
        for (int i = 0; i < TOOLS.length; i++) {
            final int t = i;
            toolBtns[i] = Ui.btn(this, TOOLS[i]);
            toolBtns[i].setOnClickListener(v -> setTool(t));
            add(tools, toolBtns[i], g);
        }
        ts.addView(tools);
        root.addView(ts);

        /* tamanho e opacidade */
        LinearLayout sl = row();
        sl.setPadding(Ui.dp(this, 8), 0, Ui.dp(this, 8), 0);
        sizeLbl = label("");
        opLbl = label("");
        SeekBar sz = new SeekBar(this), op = new SeekBar(this);
        sz.setMax(99);
        op.setMax(99);
        sl.addView(sizeLbl);
        sl.addView(sz, new LinearLayout.LayoutParams(0, Ui.dp(this, 36), 1));
        sl.addView(opLbl);
        sl.addView(op, new LinearLayout.LayoutParams(0, Ui.dp(this, 36), 1));
        root.addView(sl);

        /* linha do tempo (só animação) */
        if (p.anim) {
            HorizontalScrollView fs = new HorizontalScrollView(this);
            fs.setHorizontalScrollBarEnabled(false);
            LinearLayout fr = row();
            fr.setPadding(g, 0, g, 0);
            frameLbl = label("");
            fr.addView(frameLbl);
            Button prev = Ui.btn(this, "◀"), next = Ui.btn(this, "▶ ");
            Button addF = Ui.btn(this, "+ Quadro"), dup = Ui.btn(this, "Duplicar"), del = Ui.btn(this, "Apagar");
            onionBtn = Ui.btn(this, "Fantasma");
            Button fm = Ui.btn(this, "−"), fp = Ui.btn(this, "+");
            fpsLbl = label("");
            prev.setOnClickListener(v -> goFrame(cv.frameIdx - 1));
            next.setOnClickListener(v -> goFrame(cv.frameIdx + 1));
            addF.setOnClickListener(v -> addFrame(false));
            dup.setOnClickListener(v -> addFrame(true));
            del.setOnClickListener(v -> deleteFrame());
            onionBtn.setOnClickListener(v -> { cv.onion = !cv.onion; Ui.sel(onionBtn, cv.onion); cv.invalidate(); });
            fm.setOnClickListener(v -> setFps(p.fps - 1));
            fp.setOnClickListener(v -> setFps(p.fps + 1));
            add(fr, prev, g); add(fr, next, g); add(fr, addF, g); add(fr, dup, g); add(fr, del, g); add(fr, onionBtn, g);
            add(fr, fm, g); fr.addView(fpsLbl); add(fr, fp, g);
            fs.addView(fr);
            root.addView(fs);
            Ui.sel(onionBtn, true);

            HorizontalScrollView ss = new HorizontalScrollView(this);
            strip = row();
            strip.setPadding(g, g, g, g);
            ss.addView(strip);
            root.addView(ss);
        }
        View bottomPad = new View(this);
        root.addView(bottomPad, new LinearLayout.LayoutParams(1, g));
        setContentView(root);

        cv.setProject(p);
        sz.setProgress(cv.size - 1);
        op.setProgress(cv.opacity - 1);
        sz.setOnSeekBarChangeListener(new Ui.Seek() { @Override void change(int v) { cv.size = v + 1; labels(); } });
        op.setOnSeekBarChangeListener(new Ui.Seek() { @Override void change(int v) { cv.opacity = v + 1; labels(); } });
        setTool(CanvasView.GPEN);
        setColor(cv.color);
        labels();
        onChanged();
        if (p.anim) { setFps(p.fps); rebuildStrip(); }
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private void add(LinearLayout parent, View v, int gap) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(gap, 0, 0, 0);
        parent.addView(v, lp);
    }

    private TextView label(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(Ui.MUTE);
        v.setTextSize(12);
        v.setPadding(Ui.dp(this, 6), 0, Ui.dp(this, 6), 0);
        return v;
    }

    private void labels() {
        sizeLbl.setText("Tam. " + cv.size);
        opLbl.setText("Opac. " + cv.opacity + "%");
    }

    private void setTool(int t) {
        cv.tool = t;
        for (int i = 0; i < toolBtns.length; i++) Ui.sel(toolBtns[i], i == t);
    }

    private void setColor(int c) {
        cv.color = c | 0xFF000000;
        colorBtn.setBackground(Ui.bg(cv.color, Ui.dp(this, 10)));
        float[] hsv = new float[3];
        Color.colorToHSV(cv.color, hsv);
        colorBtn.setTextColor(hsv[2] > 0.6f && hsv[1] < 0.6f ? 0xFF000000 : 0xFFFFFFFF);
    }

    /* ---------- retorno da tela ---------- */
    @Override public void onChanged() {
        undoBtn.setAlpha(cv.canUndo() ? 1f : 0.35f);
        redoBtn.setAlpha(cv.canRedo() ? 1f : 0.35f);
    }

    @Override public void onColorPicked(int c) {
        setColor(c);
        setTool(CanvasView.GPEN);
        Ui.toast(this, "Cor capturada");
    }

    @Override public void onMessage(String m) { Ui.toast(this, m); }

    /* ---------- cores ---------- */
    private void pickColor() {
        final float[] hsv = new float[3];
        Color.colorToHSV(cv.color, hsv);
        int pad = Ui.dp(this, 16);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, 0);
        final View prev = new View(this);
        prev.setBackground(Ui.bg(cv.color, Ui.dp(this, 10)));
        box.addView(prev, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 44)));
        final SeekBar sh = new SeekBar(this), ss = new SeekBar(this), sv = new SeekBar(this);
        sh.setMax(360); ss.setMax(100); sv.setMax(100);
        for (int r = 0; r < 2; r++) {
            LinearLayout line = row();
            line.setPadding(0, Ui.dp(this, 8), 0, 0);
            for (int i = 0; i < 8; i++) {
                final int col = SWATCHES[r * 8 + i];
                View sw = new View(this);
                sw.setBackground(Ui.bg(col, Ui.dp(this, 8)));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 32), 1);
                lp.setMargins(Ui.dp(this, 2), 0, Ui.dp(this, 2), 0);
                line.addView(sw, lp);
                sw.setOnClickListener(v -> {
                    Color.colorToHSV(col, hsv);
                    sh.setProgress(Math.round(hsv[0])); ss.setProgress(Math.round(hsv[1] * 100)); sv.setProgress(Math.round(hsv[2] * 100));
                    prev.setBackground(Ui.bg(col, Ui.dp(this, 10)));
                });
            }
            box.addView(line);
        }
        String[] names = {"Matiz", "Saturação", "Brilho"};
        SeekBar[] bars = {sh, ss, sv};
        for (int i = 0; i < 3; i++) {
            TextView t = label(names[i]);
            t.setPadding(0, Ui.dp(this, 10), 0, 0);
            box.addView(t);
            box.addView(bars[i], new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 36)));
        }
        sh.setProgress(Math.round(hsv[0])); ss.setProgress(Math.round(hsv[1] * 100)); sv.setProgress(Math.round(hsv[2] * 100));
        Ui.Seek upd = new Ui.Seek() {
            @Override void change(int v) {
                hsv[0] = sh.getProgress(); hsv[1] = ss.getProgress() / 100f; hsv[2] = sv.getProgress() / 100f;
                prev.setBackground(Ui.bg(Color.HSVToColor(hsv), Ui.dp(EditorActivity.this, 10)));
            }
        };
        sh.setOnSeekBarChangeListener(upd); ss.setOnSeekBarChangeListener(upd); sv.setOnSeekBarChangeListener(upd);
        new AlertDialog.Builder(this).setTitle("Cor").setView(box)
                .setPositiveButton("OK", (d, w) -> setColor(Color.HSVToColor(hsv)))
                .setNegativeButton("Cancelar", null).show();
    }

    /* ---------- camadas ---------- */
    private void layersDialog() {
        ScrollView sc = new ScrollView(this);
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 12);
        box.setPadding(pad, pad, pad, 0);
        sc.addView(box);
        fillLayers(box);
        new AlertDialog.Builder(this).setTitle("Camadas").setView(sc).setPositiveButton("Fechar", null).show();
    }

    private void fillLayers(final LinearLayout box) {
        box.removeAllViews();
        int g = Ui.dp(this, 4);
        for (int i = p.layers.size() - 1; i >= 0; i--) {
            final int idx = i;
            final Project.Layer l = p.layers.get(i);
            LinearLayout r = row();
            r.setPadding(0, 0, 0, g * 2);
            Button name = Ui.btn(this, l.name);
            Ui.sel(name, idx == cv.active);
            name.setOnClickListener(v -> { cv.active = idx; fillLayers(box); });
            r.addView(name, new LinearLayout.LayoutParams(Ui.dp(this, 104), LinearLayout.LayoutParams.WRAP_CONTENT));
            Button eye = Ui.btn(this, l.visible ? "Visível" : "Oculta");
            eye.setOnClickListener(v -> { l.visible = !l.visible; p.save(); cv.invalidate(); fillLayers(box); });
            add(r, eye, g);
            SeekBar op = new SeekBar(this);
            op.setMax(255);
            op.setProgress(l.opacity);
            op.setOnSeekBarChangeListener(new Ui.Seek() { @Override void change(int v) { l.opacity = v; cv.invalidate(); } });
            r.addView(op, new LinearLayout.LayoutParams(0, Ui.dp(this, 36), 1));
            box.addView(r);
        }
        LinearLayout acts = row();
        Button addL = Ui.btn(this, "+ Camada"), up = Ui.btn(this, "Subir"), dn = Ui.btn(this, "Descer"), del = Ui.btn(this, "Excluir");
        addL.setOnClickListener(v -> {
            if (p.layers.size() >= 8) { Ui.toast(this, "Limite de 8 camadas nesta etapa"); return; }
            Project.Layer n = new Project.Layer();
            n.id = p.nextLayer++;
            n.name = "Camada " + n.id;
            p.layers.add(cv.active + 1, n);
            cv.active++;
            p.save();
            fillLayers(box);
        });
        up.setOnClickListener(v -> moveLayer(1, box));
        dn.setOnClickListener(v -> moveLayer(-1, box));
        del.setOnClickListener(v -> {
            if (p.layers.size() < 2) { Ui.toast(this, "Precisa existir pelo menos uma camada"); return; }
            Project.Layer l = p.layers.remove(cv.active);
            cv.removeLayerBitmap(l.id);
            for (int fid : p.frames) p.layerFile(fid, l.id).delete();
            cv.active = Math.max(0, Math.min(cv.active, p.layers.size() - 1));
            p.save();
            thumbs.clear();
            onChanged();
            cv.invalidate();
            fillLayers(box);
        });
        acts.addView(addL); add(acts, up, g); add(acts, dn, g); add(acts, del, g);
        box.addView(acts);
    }

    private void moveLayer(int d, LinearLayout box) {
        int j = cv.active + d;
        if (j < 0 || j >= p.layers.size()) return;
        Project.Layer a = p.layers.get(cv.active);
        p.layers.set(cv.active, p.layers.get(j));
        p.layers.set(j, a);
        cv.active = j;
        p.save();
        cv.invalidate();
        fillLayers(box);
    }

    /* ---------- quadros ---------- */
    private void setFps(int f) {
        p.fps = Math.max(1, Math.min(30, f));
        fpsLbl.setText(p.fps + " fps");
        p.save();
    }

    private void goFrame(int i) {
        if (playing || i < 0 || i >= p.frames.size()) return;
        thumbs.remove(cv.frameId());
        cv.loadFrame(i);
        onChanged();
        rebuildStrip();
    }

    private void addFrame(boolean copy) {
        if (playing) return;
        cv.saveCurrent();
        int src = cv.frameId(), fid = p.nextFrame++;
        if (copy) for (Project.Layer l : p.layers) copyFile(p.layerFile(src, l.id), p.layerFile(fid, l.id));
        p.frames.add(cv.frameIdx + 1, fid);
        p.save();
        goFrame(cv.frameIdx + 1);
    }

    private void deleteFrame() {
        if (playing) return;
        if (p.frames.size() == 1) { cv.clearFrame(); onChanged(); return; }
        new AlertDialog.Builder(this).setTitle("Apagar este quadro?")
                .setPositiveButton("Apagar", (d, w) -> {
                    int idx = cv.frameIdx, fid = cv.frameId();
                    cv.clearFrame();
                    cv.saveCurrent();
                    p.deleteFrameFiles(fid);
                    p.frames.remove(idx);
                    p.save();
                    thumbs.remove(fid);
                    cv.loadFrame(Math.min(idx, p.frames.size() - 1));
                    onChanged();
                    rebuildStrip();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private static void copyFile(File a, File b) {
        if (!a.exists()) return;
        try {
            FileInputStream in = new FileInputStream(a);
            FileOutputStream out = new FileOutputStream(b);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            out.close();
        } catch (Exception e) { /* melhor esforço */ }
    }

    private void rebuildStrip() {
        if (strip == null) return;
        frameLbl.setText((cv.frameIdx + 1) + " / " + p.frames.size());
        strip.removeAllViews();
        int th = Ui.dp(this, 52), tw = Math.max(Ui.dp(this, 30), Math.min(Ui.dp(this, 110), th * p.w / p.h)), b = Ui.dp(this, 2);
        for (int i = 0; i < p.frames.size(); i++) {
            final int idx = i;
            int fid = p.frames.get(i);
            ImageView iv = new ImageView(this);
            iv.setTag(fid);
            iv.setScaleType(ImageView.ScaleType.FIT_XY);
            iv.setPadding(b, b, b, b);
            iv.setBackgroundColor(i == cv.frameIdx ? Ui.ACC : 0xFF3A3E55);
            Bitmap t = thumbs.get(fid);
            if (t != null) iv.setImageBitmap(t);
            iv.setOnClickListener(v -> goFrame(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(tw, th);
            lp.setMargins(0, 0, Ui.dp(this, 5), 0);
            strip.addView(iv, lp);
        }
        final ArrayList<Integer> ids = new ArrayList<>(p.frames);
        final int curId = cv.frameId();
        new Thread(() -> {
            for (final int fid : ids) {
                if (fid == curId || thumbs.containsKey(fid)) continue;
                final Bitmap bm = p.composite(fid, 160, true);
                runOnUiThread(() -> {
                    thumbs.put(fid, bm);
                    View v = strip.findViewWithTag(fid);
                    if (v instanceof ImageView) ((ImageView) v).setImageBitmap(bm);
                });
            }
        }).start();
    }

    /* ---------- reprodução ---------- */
    private void startPlay() {
        if (playing || p.frames.size() < 2) { if (!playing) Ui.toast(this, "Crie mais quadros para animar"); return; }
        playing = true;
        playBtn.setText("■");
        cv.saveCurrent();
        final ArrayList<Integer> ids = new ArrayList<>(p.frames);
        new Thread(() -> {
            final ArrayList<Bitmap> fr = new ArrayList<>();
            int side = ids.size() > 60 ? 480 : 720;
            for (int fid : ids) fr.add(p.composite(fid, side, false));
            runOnUiThread(() -> {
                if (!playing) { for (Bitmap b : fr) b.recycle(); return; }
                playFrames = fr;
                playI = 0;
                tick.run();
            });
        }).start();
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!playing || playFrames == null) return;
            cv.playBmp = playFrames.get(playI);
            cv.invalidate();
            playI = (playI + 1) % playFrames.size();
            h.postDelayed(this, 1000 / Math.max(1, p.fps));
        }
    };

    private void stopPlay() {
        playing = false;
        h.removeCallbacks(tick);
        cv.playBmp = null;
        cv.invalidate();
        if (playFrames != null) { for (Bitmap b : playFrames) b.recycle(); playFrames = null; }
        if (playBtn != null) playBtn.setText("▶");
    }

    /* ---------- menu e exportação ---------- */
    private void menu() {
        String[] items = p.anim
                ? new String[]{"Salvar quadro na galeria (PNG)", "Salvar todos os quadros (PNG)", "Ajustar à tela"}
                : new String[]{"Salvar na galeria (PNG)", "Salvar sem fundo (PNG transparente)", "Ajustar à tela"};
        new AlertDialog.Builder(this).setTitle(p.name).setItems(items, (d, i) -> {
            if (i == 2) { cv.fitView(); return; }
            if (!canSave()) return;
            if (i == 0) exportOne(true);
            else if (p.anim) exportAll();
            else exportOne(false);
        }).show();
    }

    private boolean canSave() {
        if (Build.VERSION.SDK_INT >= 29) return true;
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) return true;
        requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        Ui.toast(this, "Permita o acesso e toque em salvar de novo");
        return false;
    }

    private boolean savePng(Bitmap b, String name) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (Build.VERSION.SDK_INT >= 29) v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DarkMonia");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (u == null) return false;
            OutputStream os = getContentResolver().openOutputStream(u);
            if (os == null) return false;
            b.compress(Bitmap.CompressFormat.PNG, 100, os);
            os.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String fileBase() { return p.name.replaceAll("[^a-zA-Z0-9À-ÿ_-]+", "_") + "_" + (System.currentTimeMillis() / 1000 % 100000); }

    private void exportOne(boolean paper) {
        Bitmap b = cv.renderComposite(paper);
        boolean ok = savePng(b, fileBase() + ".png");
        b.recycle();
        Ui.toast(this, ok ? "Salvo em Imagens/DarkMonia" : "Não consegui salvar a imagem");
    }

    private void exportAll() {
        cv.saveCurrent();
        final ArrayList<Integer> ids = new ArrayList<>(p.frames);
        final String base = fileBase();
        Ui.toast(this, "Salvando " + ids.size() + " quadros…");
        new Thread(() -> {
            int ok = 0;
            for (int i = 0; i < ids.size(); i++) {
                Bitmap b = p.composite(ids.get(i), Math.max(p.w, p.h), true);
                if (savePng(b, base + "_" + String.format("%04d", i + 1) + ".png")) ok++;
                b.recycle();
            }
            final int n = ok;
            runOnUiThread(() -> Ui.toast(this, n + " quadros salvos em Imagens/DarkMonia"));
        }).start();
    }

    /* ---------- ciclo de vida ---------- */
    @Override protected void onPause() {
        super.onPause();
        if (p == null || cv == null) return;
        if (playing) stopPlay();
        cv.saveCurrent();
        try {
            Bitmap full = cv.renderComposite(true);
            float k = 320f / Math.max(p.w, p.h);
            Bitmap t = Bitmap.createScaledBitmap(full, Math.max(1, Math.round(p.w * k)), Math.max(1, Math.round(p.h * k)), true);
            Project.writePng(t, p.thumbFile());
            if (t != full) t.recycle();
            full.recycle();
        } catch (Throwable e) { /* a miniatura é opcional */ }
        p.updated = System.currentTimeMillis();
        p.save();
    }
}
