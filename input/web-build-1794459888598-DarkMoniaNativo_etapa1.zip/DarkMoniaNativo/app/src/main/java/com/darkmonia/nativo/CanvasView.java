package com.darkmonia.nativo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/** Tela de desenho nativa: camadas em Bitmap, pincéis, zoom com dois dedos, desfazer e balde. */
public class CanvasView extends View {
    static final int PENCIL = 0, GPEN = 1, MARKER = 2, AIR = 3, ERASER = 4, FILL = 5, PICK = 6, PAN = 7;

    interface Listener {
        void onChanged();          // desenho mudou (atualizar desfazer/refazer)
        void onColorPicked(int c);
        void onMessage(String m);
    }

    Project p;
    Listener listener;
    int frameIdx = 0, active = 0;
    int tool = GPEN, color = 0xFF16161D, size = 8, opacity = 100;
    boolean onion = true;
    Bitmap playBmp;

    private final HashMap<Integer, Bitmap> cur = new HashMap<>();
    private final HashSet<Integer> dirty = new HashSet<>();
    private Bitmap strokeBmp, onionBmp, dab;
    private Canvas strokeCv;
    private boolean stroking, panning, pinching, gMoved;
    private int maxPtr;
    private long downT;
    private float px, py, mx, my, lw, lastX, lastY, f0x, f0y, d0, airRem;
    private final Matrix m = new Matrix(), inv = new Matrix(), m0 = new Matrix();
    private final Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG), lp = new Paint(Paint.FILTER_BITMAP_FLAG),
            sp = new Paint(Paint.FILTER_BITMAP_FLAG), paperP = new Paint(), onionP = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Path path = new Path();
    private final RectF full = new RectF();
    private final float[] tmp = new float[2];

    private static class Undo { int layer; Bitmap bmp; }
    private final ArrayList<Undo> undo = new ArrayList<>(), redo = new ArrayList<>();
    private static final int MAX_UNDO = 8;

    public CanvasView(Context c) {
        super(c);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeCap(Paint.Cap.ROUND);
        bp.setStrokeJoin(Paint.Join.ROUND);
        onionP.setAlpha(70);
    }

    /* ---------- projeto e quadros ---------- */
    void setProject(Project pr) {
        p = pr;
        strokeBmp = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
        strokeCv = new Canvas(strokeBmp);
        full.set(0, 0, p.w, p.h);
        active = p.layers.size() - 1;
        loadFrame(0);
    }

    int frameId() { return p.frames.get(frameIdx); }

    void loadFrame(int idx) {
        saveCurrent();
        for (Bitmap b : cur.values()) b.recycle();
        cur.clear();
        clearHistory();
        frameIdx = Math.max(0, Math.min(p.frames.size() - 1, idx));
        int fid = frameId();
        for (Project.Layer l : p.layers) {
            Bitmap b = p.loadLayer(fid, l.id);
            if (b != null) cur.put(l.id, b);
        }
        if (onionBmp != null) { onionBmp.recycle(); onionBmp = null; }
        if (p.anim && frameIdx > 0) onionBmp = p.composite(p.frames.get(frameIdx - 1), 1024, false);
        if (active >= p.layers.size()) active = p.layers.size() - 1;
        invalidate();
    }

    /** Grava no disco as camadas alteradas do quadro atual. */
    void saveCurrent() {
        if (p == null || dirty.isEmpty()) return;
        int fid = frameId();
        for (int id : dirty) {
            Bitmap b = cur.get(id);
            if (b == null) p.layerFile(fid, id).delete();
            else Project.writePng(b, p.layerFile(fid, id));
        }
        dirty.clear();
    }

    void clearHistory() {
        for (Undo u : undo) if (u.bmp != null) u.bmp.recycle();
        for (Undo u : redo) if (u.bmp != null) u.bmp.recycle();
        undo.clear();
        redo.clear();
    }

    void removeLayerBitmap(int layerId) {
        Bitmap b = cur.remove(layerId);
        if (b != null) b.recycle();
        dirty.remove(layerId);
        clearHistory();
    }

    void clearFrame() {
        for (Project.Layer l : p.layers) {
            Bitmap b = cur.remove(l.id);
            if (b != null) b.recycle();
            dirty.add(l.id);
        }
        clearHistory();
        invalidate();
    }

    /* ---------- desfazer / refazer ---------- */
    boolean canUndo() { return !undo.isEmpty(); }
    boolean canRedo() { return !redo.isEmpty(); }

    private Undo snap(int layerId) {
        Undo u = new Undo();
        u.layer = layerId;
        Bitmap b = cur.get(layerId);
        u.bmp = b == null ? null : b.copy(Bitmap.Config.ARGB_8888, true);
        return u;
    }

    private void swap(ArrayList<Undo> from, ArrayList<Undo> to) {
        if (from.isEmpty()) return;
        Undo u = from.remove(from.size() - 1);
        to.add(snap(u.layer));
        Bitmap old = cur.get(u.layer);
        if (old != null) old.recycle();
        if (u.bmp == null) cur.remove(u.layer); else cur.put(u.layer, u.bmp);
        dirty.add(u.layer);
        invalidate();
        if (listener != null) listener.onChanged();
    }

    void undo() { swap(undo, redo); }
    void redo() { swap(redo, undo); }

    private void pushUndo(int layerId) {
        undo.add(snap(layerId));
        if (undo.size() > MAX_UNDO) { Undo o = undo.remove(0); if (o.bmp != null) o.bmp.recycle(); }
        for (Undo u : redo) if (u.bmp != null) u.bmp.recycle();
        redo.clear();
    }

    /* ---------- visão ---------- */
    void fitView() {
        if (p == null || getWidth() == 0) return;
        float s = Math.min(getWidth() / (float) p.w, getHeight() / (float) p.h) * 0.94f;
        m.reset();
        m.postScale(s, s);
        m.postTranslate((getWidth() - p.w * s) / 2f, (getHeight() - p.h * s) / 2f);
        invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) { fitView(); }

    private float[] map(float x, float y) {
        m.invert(inv);
        tmp[0] = x; tmp[1] = y;
        inv.mapPoints(tmp);
        return tmp;
    }

    /* ---------- desenho na tela ---------- */
    private Paint strokePaint() {
        sp.setAlpha(Math.round(opacity * 2.55f));
        sp.setXfermode(tool == ERASER ? new PorterDuffXfermode(PorterDuff.Mode.DST_OUT) : null);
        return sp;
    }

    private void drawLayers(Canvas c, boolean withStroke) {
        for (int i = 0; i < p.layers.size(); i++) {
            Project.Layer l = p.layers.get(i);
            if (!l.visible) continue;
            Bitmap b = cur.get(l.id);
            if (withStroke && i == active && stroking) {
                int sc = c.saveLayerAlpha(0, 0, p.w, p.h, l.opacity);
                if (b != null) c.drawBitmap(b, 0, 0, null);
                c.drawBitmap(strokeBmp, 0, 0, strokePaint());
                c.restoreToCount(sc);
            } else if (b != null) {
                lp.setAlpha(l.opacity);
                c.drawBitmap(b, 0, 0, lp);
            }
        }
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(Ui.BG);
        if (p == null) return;
        c.save();
        c.concat(m);
        paperP.setColor(p.paper);
        c.drawRect(full, paperP);
        if (playBmp != null) {
            c.drawBitmap(playBmp, null, full, lp);
        } else {
            if (onion && onionBmp != null) c.drawBitmap(onionBmp, null, full, onionP);
            lp.setAlpha(255);
            drawLayers(c, true);
        }
        c.restore();
    }

    /** Imagem final do quadro atual, em tamanho real. */
    Bitmap renderComposite(boolean withPaper) {
        Bitmap out = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        if (withPaper) c.drawColor(p.paper);
        drawLayers(c, false);
        return out;
    }

    /* ---------- toque ---------- */
    @Override public boolean onTouchEvent(MotionEvent e) {
        if (p == null || playBmp != null) return true;
        int n = e.getPointerCount();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                maxPtr = 1; downT = e.getEventTime(); gMoved = false; pinching = false;
                lastX = e.getX(); lastY = e.getY();
                if (tool == PAN) panning = true;
                else if (tool != PICK && tool != FILL) startStroke(e);
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                maxPtr = Math.max(maxPtr, n);
                cancelStroke();
                panning = false;
                if (n == 2) beginPinch(e);
                break;
            case MotionEvent.ACTION_MOVE:
                if (n >= 2 && pinching) doPinch(e);
                else if (panning) {
                    m.postTranslate(e.getX() - lastX, e.getY() - lastY);
                    lastX = e.getX(); lastY = e.getY();
                    invalidate();
                } else if (stroking && n == 1) {
                    boolean pen = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS;
                    for (int i = 0; i < e.getHistorySize(); i++)
                        addPoint(e.getHistoricalX(i), e.getHistoricalY(i), e.getHistoricalPressure(i), pen);
                    addPoint(e.getX(), e.getY(), e.getPressure(), pen);
                    invalidate();
                }
                break;
            case MotionEvent.ACTION_POINTER_UP:
                pinching = false;
                break;
            case MotionEvent.ACTION_UP:
                if (stroking) endStroke();
                else if (maxPtr == 1 && tool == PICK) pick(e.getX(), e.getY());
                else if (maxPtr == 1 && tool == FILL) fill(e.getX(), e.getY());
                else if (maxPtr == 2 && !gMoved && e.getEventTime() - downT < 350) undo();
                panning = false; pinching = false;
                break;
            case MotionEvent.ACTION_CANCEL:
                cancelStroke();
                panning = false; pinching = false;
                break;
            default:
                break;
        }
        return true;
    }

    private void beginPinch(MotionEvent e) {
        pinching = true;
        m0.set(m);
        f0x = (e.getX(0) + e.getX(1)) / 2f; f0y = (e.getY(0) + e.getY(1)) / 2f;
        d0 = Math.max(10f, (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)));
    }

    private void doPinch(MotionEvent e) {
        float fx = (e.getX(0) + e.getX(1)) / 2f, fy = (e.getY(0) + e.getY(1)) / 2f;
        float d = Math.max(10f, (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)));
        if (Math.abs(d - d0) > 24 || Math.hypot(fx - f0x, fy - f0y) > 24) gMoved = true;
        float base = m0.mapRadius(1f), s = d / d0;
        float minS = 0.1f, maxS = 30f;
        if (base * s < minS) s = minS / base;
        if (base * s > maxS) s = maxS / base;
        m.set(m0);
        m.postTranslate(fx - f0x, fy - f0y);
        m.postScale(s, s, fx, fy);
        invalidate();
    }

    /* ---------- traço ---------- */
    private float widthFor(float pr, float dist, boolean pen) {
        switch (tool) {
            case PENCIL: return Math.max(1f, size * 0.5f) * (pen ? 0.5f + 0.5f * pr : 1f);
            case GPEN: return Math.max(0.8f, pen ? size * (0.15f + 0.85f * pr) : size * (1.1f - Math.min(0.65f, dist / (size * 3f + 30f))));
            default: return size;
        }
    }

    private void startStroke(MotionEvent e) {
        Project.Layer l = p.layers.get(active);
        if (!l.visible) { if (listener != null) listener.onMessage("A camada ativa está oculta"); return; }
        if (tool == ERASER && cur.get(l.id) == null) return;
        stroking = true;
        strokeBmp.eraseColor(0);
        boolean pen = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS;
        float[] q = map(e.getX(), e.getY());
        px = mx = q[0]; py = my = q[1];
        lw = widthFor(e.getPressure(), 0, pen);
        int col = tool == ERASER ? 0xFF000000 : (tool == PENCIL ? (color & 0x00FFFFFF) | 0xD0000000 : color | 0xFF000000);
        bp.setColor(col);
        bp.setShader(null);
        if (tool == AIR) {
            int r = Math.max(2, Math.round(size * 1.5f));
            if (dab != null) dab.recycle();
            dab = Bitmap.createBitmap(r * 2, r * 2, Bitmap.Config.ARGB_8888);
            Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
            int rgb = color & 0x00FFFFFF;
            g.setShader(new RadialGradient(r, r, r, new int[]{0x30000000 | rgb, rgb}, null, Shader.TileMode.CLAMP));
            new Canvas(dab).drawCircle(r, r, r, g);
            airRem = 0;
            strokeCv.drawBitmap(dab, px - r, py - r, null);
        } else {
            bp.setStyle(Paint.Style.FILL);
            strokeCv.drawCircle(px, py, lw / 2f, bp);
            bp.setStyle(Paint.Style.STROKE);
        }
        invalidate();
    }

    private void addPoint(float vx, float vy, float pr, boolean pen) {
        float[] q = map(vx, vy);
        float x = q[0], y = q[1], d = (float) Math.hypot(x - px, y - py);
        if (d < 1.2f) return;
        if (tool == AIR) {
            float r = dab.getWidth() / 2f, step = Math.max(1f, r * 0.2f), pos = airRem;
            while (pos <= d) {
                float k = pos / d;
                strokeCv.drawBitmap(dab, px + (x - px) * k - r, py + (y - py) * k - r, null);
                pos += step;
            }
            airRem = pos - d;
        } else {
            lw = lw * 0.65f + widthFor(pr, d, pen) * 0.35f;
            float nmx = (px + x) / 2f, nmy = (py + y) / 2f;
            path.rewind();
            path.moveTo(mx, my);
            path.quadTo(px, py, nmx, nmy);
            bp.setStrokeWidth(lw);
            strokeCv.drawPath(path, bp);
            mx = nmx; my = nmy;
        }
        px = x; py = y;
    }

    private void endStroke() {
        if (tool != AIR) {
            bp.setStrokeWidth(lw);
            strokeCv.drawLine(mx, my, px, py, bp);
        }
        commit();
    }

    private void cancelStroke() {
        if (!stroking) return;
        stroking = false;
        strokeBmp.eraseColor(0);
        invalidate();
    }

    /** Junta o traço temporário na camada ativa (com a opacidade escolhida). */
    private void commit() {
        Project.Layer l = p.layers.get(active);
        pushUndo(l.id);
        Bitmap b = cur.get(l.id);
        if (b == null) {
            b = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
            cur.put(l.id, b);
        }
        new Canvas(b).drawBitmap(strokeBmp, 0, 0, strokePaint());
        strokeBmp.eraseColor(0);
        stroking = false;
        dirty.add(l.id);
        invalidate();
        if (listener != null) listener.onChanged();
    }

    /* ---------- conta-gotas e balde ---------- */
    private void pick(float vx, float vy) {
        float[] q = map(vx, vy);
        int x = (int) q[0], y = (int) q[1];
        if (x < 0 || y < 0 || x >= p.w || y >= p.h) return;
        Bitmap c = renderComposite(true);
        int col = c.getPixel(x, y) | 0xFF000000;
        c.recycle();
        if (listener != null) listener.onColorPicked(col);
    }

    private static boolean near(int a, int b) {
        int d = Math.abs((a >>> 24) - (b >>> 24)) + Math.abs(((a >> 16) & 255) - ((b >> 16) & 255))
                + Math.abs(((a >> 8) & 255) - ((b >> 8) & 255)) + Math.abs((a & 255) - (b & 255));
        return d <= 96;
    }

    private void fill(float vx, float vy) {
        Project.Layer l = p.layers.get(active);
        if (!l.visible) { if (listener != null) listener.onMessage("A camada ativa está oculta"); return; }
        float[] q = map(vx, vy);
        final int w = p.w, h = p.h, sx = (int) q[0], sy = (int) q[1];
        if (sx < 0 || sy < 0 || sx >= w || sy >= h) return;
        Bitmap comp = renderComposite(true);
        int[] src = new int[w * h];
        comp.getPixels(src, 0, w, 0, 0, w, h);
        comp.recycle();
        final int target = src[sy * w + sx];
        boolean[] seen = new boolean[w * h];
        int[] stack = new int[4096];
        int top = 0;
        stack[top++] = sx; stack[top++] = sy;
        while (top > 0) {
            int y = stack[--top], x = stack[--top], i = y * w + x;
            while (x > 0 && !seen[i - 1] && near(src[i - 1], target)) { x--; i--; }
            boolean up = false, dn = false;
            while (x < w && !seen[i] && near(src[i], target)) {
                seen[i] = true;
                if (y > 0) {
                    boolean a = !seen[i - w] && near(src[i - w], target);
                    if (a && !up) { if (top + 2 > stack.length) stack = java.util.Arrays.copyOf(stack, stack.length * 2); stack[top++] = x; stack[top++] = y - 1; up = true; }
                    else if (!a) up = false;
                }
                if (y < h - 1) {
                    boolean b2 = !seen[i + w] && near(src[i + w], target);
                    if (b2 && !dn) { if (top + 2 > stack.length) stack = java.util.Arrays.copyOf(stack, stack.length * 2); stack[top++] = x; stack[top++] = y + 1; dn = true; }
                    else if (!b2) dn = false;
                }
                x++; i++;
            }
        }
        // pinta a área e mais 1 px de borda, para não sobrar frestas junto ao traço
        int col = color | 0xFF000000;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                boolean on = seen[i] || (x > 0 && seen[i - 1]) || (x < w - 1 && seen[i + 1]) || (y > 0 && seen[i - w]) || (y < h - 1 && seen[i + w]);
                src[i] = on ? col : 0;
            }
        }
        strokeBmp.setPixels(src, 0, w, 0, 0, w, h);
        stroking = true;
        commit();
    }
}
