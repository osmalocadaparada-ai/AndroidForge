package com.darkmonia.nativo;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Toast;

/** Pequenos ajudantes de interface (tudo é montado em código, sem XML). */
final class Ui {
    static final int BG = 0xFF12131C, PANEL = 0xFF1B1D2B, BTN = 0xFF2A2D42, ACC = 0xFFE5476B, FG = 0xFFECEEF7, MUTE = 0xFF9AA0B8;

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    static GradientDrawable bg(int col, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(col);
        g.setCornerRadius(r);
        return g;
    }

    static Button btn(Context c, String t) {
        Button b = new Button(c);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(FG);
        b.setTextSize(13);
        b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(0); b.setMinimumHeight(0);
        int p = dp(c, 11);
        b.setPadding(p, dp(c, 9), p, dp(c, 9));
        b.setBackground(bg(BTN, dp(c, 10)));
        return b;
    }

    static void sel(Button b, boolean on) { b.setBackground(bg(on ? ACC : BTN, dp(b.getContext(), 10))); }

    static void toast(Context c, String s) { Toast.makeText(c, s, Toast.LENGTH_SHORT).show(); }

    /** Listener de SeekBar que só exige o método de mudança. */
    abstract static class Seek implements SeekBar.OnSeekBarChangeListener {
        abstract void change(int v);
        @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) { change(v); }
        @Override public void onStartTrackingTouch(SeekBar s) { }
        @Override public void onStopTrackingTouch(SeekBar s) { }
    }
}
