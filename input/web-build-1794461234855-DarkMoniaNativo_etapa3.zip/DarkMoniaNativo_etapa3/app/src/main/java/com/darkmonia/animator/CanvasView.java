package com.darkmonia.animator;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/**
 * Tela de desenho nativa: camadas, pincéis, formas, seleção, zoom e desfazer.
 */
public class CanvasView extends View {
    static final int PENCIL = 0, GPEN = 1, MARKER = 2, AIR = 3, ERASER = 4;
    static final int FILL = 5, PICK = 6, PAN = 7;
    static final int SELECT = 8, LINE = 9, RECT = 10, ELLIPSE = 11;

    interface Listener {
        void onChanged();
        void onColorPicked(int c);
        void onMessage(String m);
        void onSelectionChanged(boolean has);
    }

    Project p;
    Listener listener;
    int frameIdx = 0, active = 0;
    int tool = GPEN, color = 0xFF16161D, size = 8, opacity = 100;
    boolean onion = true;
    Bitmap playBmp;

    /** Seleção em coordenadas do canvas (pode ser vazia). */
    final RectF sel = new RectF();
    boolean hasSel = false;
    Bitmap clipboard;

    private final HashMap<Integer, Bitmap> cur = new HashMap<>();
    private final HashSet<Integer> dirty = new HashSet<>();
    private Bitmap strokeBmp, onionBmp, dab;
    private Canvas strokeCv;
    private boolean stroking, panning, pinching, shaping, selecting, movingSel, gMoved;
    private int maxPtr;
    private long downT;
    private float px, py, mx, my, lw, lastX, lastY, f0x, f0y, d0, airRem, shapeX0, shapeY0, moveOffX, moveOffY;
    private final Matrix m = new Matrix(), inv = new Matrix(), m0 = new Matrix();
    private final Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lp = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint sp = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint paperP = new Paint();
    private final Paint onionP = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint selP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint checkerP = new Paint();
    private final Path path = new Path();
    private final RectF full = new RectF();
    private final float[] tmp = new float[2];
    private final RectF tmpR = new RectF();

    private static class Undo {
        int layer;
        Bitmap bmp;
        RectF sel;
        boolean hasSel;
    }

    private final ArrayList<Undo> undo = new ArrayList<>(), redo = new ArrayList<>();
    private static final int MAX_UNDO = 24;

    public CanvasView(Context c) {
        super(c);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeCap(Paint.Cap.ROUND);
        bp.setStrokeJoin(Paint.Join.ROUND);
        onionP.setAlpha(70);
        selP.setStyle(Paint.Style.STROKE);
        selP.setStrokeWidth(2f);
        selP.setColor(0xFFE8C04A);
        selP.setPathEffect(new DashPathEffect(new float[]{10, 8}, 0));
        checkerP.setColor(0xFF2A2D3A);
    }

    /* ---------- projeto e quadros ---------- */
    void setProject(Project pr) {
        p = pr;
        strokeBmp = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
        strokeCv = new Canvas(strokeBmp);
        full.set(0, 0, p.w, p.h);
        active = p.layers.size() - 1;
        clearSelection();
        loadFrame(0);
    }

    int frameId() {
        return p.frames.get(frameIdx);
    }

    void loadFrame(int idx) {
        saveCurrent();
        for (Bitmap b : cur.values()) b.recycle();
        cur.clear();
        clearHistory();
        clearSelection();
        frameIdx = Math.max(0, Math.min(p.frames.size() - 1, idx));
        int fid = frameId();
        for (Project.Layer l : p.layers) {
            Bitmap b = p.loadLayer(fid, l.id);
            if (b != null) cur.put(l.id, b);
        }
        if (onionBmp != null) {
            onionBmp.recycle();
            onionBmp = null;
        }
        if (p.anim && frameIdx > 0) onionBmp = p.composite(p.frames.get(frameIdx - 1), 1024, false);
        if (active >= p.layers.size()) active = p.layers.size() - 1;
        invalidate();
    }

    void saveCurrent() {
        if (p == null || dirty.isEmpty()) return;
        int fid = frameId();
        for (int id : dirty) {
            Bitmap b = cur.get(id);
            if (b == null) p.layerFile(fid, id).delete();
            else Project.writePng(b, p.layerFile(fid, id));
        }
        dirty.clear();
    }

    void clearHistory() {
        for (Undo u : undo) if (u.bmp != null) u.bmp.recycle();
        for (Undo u : redo) if (u.bmp != null) u.bmp.recycle();
        undo.clear();
        redo.clear();
    }

    void removeLayerBitmap(int layerId) {
        Bitmap b = cur.remove(layerId);
        if (b != null) b.recycle();
        dirty.remove(layerId);
        clearHistory();
        clearSelection();
    }

    void clearFrame() {
        for (Project.Layer l : p.layers) {
            Bitmap b = cur.remove(l.id);
            if (b != null) b.recycle();
            dirty.add(l.id);
        }
        clearHistory();
        clearSelection();
        invalidate();
    }

    /* ---------- desfazer / refazer ---------- */
    boolean canUndo() {
        return !undo.isEmpty();
    }

    boolean canRedo() {
        return !redo.isEmpty();
    }

    private Undo snap(int layerId) {
        Undo u = new Undo();
        u.layer = layerId;
        Bitmap b = cur.get(layerId);
        u.bmp = b == null ? null : b.copy(Bitmap.Config.ARGB_8888, true);
        u.hasSel = hasSel;
        u.sel = hasSel ? new RectF(sel) : null;
        return u;
    }

    private void swap(ArrayList<Undo> from, ArrayList<Undo> to) {
        if (from.isEmpty()) return;
        Undo u = from.remove(from.size() - 1);
        to.add(snap(u.layer));
        Bitmap old = cur.get(u.layer);
        if (old != null) old.recycle();
        if (u.bmp == null) cur.remove(u.layer);
        else cur.put(u.layer, u.bmp);
        dirty.add(u.layer);
        if (u.hasSel && u.sel != null) {
            sel.set(u.sel);
            hasSel = true;
        } else {
            clearSelection();
        }
        invalidate();
        notifySel();
        if (listener != null) listener.onChanged();
    }

    void undo() {
        swap(undo, redo);
    }

    void redo() {
        swap(redo, undo);
    }

    private void pushUndo(int layerId) {
        undo.add(snap(layerId));
        if (undo.size() > MAX_UNDO) {
            Undo o = undo.remove(0);
            if (o.bmp != null) o.bmp.recycle();
        }
        for (Undo u : redo) if (u.bmp != null) u.bmp.recycle();
        redo.clear();
    }

    /* ---------- visão ---------- */
    void fitView() {
        if (p == null || getWidth() == 0) return;
        float s = Math.min(getWidth() / (float) p.w, getHeight() / (float) p.h) * 0.94f;
        m.reset();
        m.postScale(s, s);
        m.postTranslate((getWidth() - p.w * s) / 2f, (getHeight() - p.h * s) / 2f);
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        fitView();
    }

    private float[] map(float x, float y) {
        m.invert(inv);
        tmp[0] = x;
        tmp[1] = y;
        inv.mapPoints(tmp);
        return tmp;
    }

    /* ---------- desenho na tela ---------- */
    private Paint strokePaint() {
        sp.setAlpha(Math.round(opacity * 2.55f));
        sp.setXfermode(tool == ERASER ? new PorterDuffXfermode(PorterDuff.Mode.DST_OUT) : null);
        return sp;
    }

    private void drawLayers(Canvas c, boolean withStroke) {
        for (int i = 0; i < p.layers.size(); i++) {
            Project.Layer l = p.layers.get(i);
            if (!l.visible) continue;
            Bitmap b = cur.get(l.id);
            if (withStroke && i == active && (stroking || shaping)) {
                int sc = c.saveLayerAlpha(0, 0, p.w, p.h, l.opacity);
                if (b != null) c.drawBitmap(b, 0, 0, null);
                c.drawBitmap(strokeBmp, 0, 0, strokePaint());
                c.restoreToCount(sc);
            } else if (b != null) {
                lp.setAlpha(l.opacity);
                c.drawBitmap(b, 0, 0, lp);
            }
        }
    }

    private void drawChecker(Canvas c) {
        int cell = Math.max(8, Math.min(p.w, p.h) / 32);
        checkerP.setColor(0xFF1A1C28);
        c.drawRect(full, checkerP);
        checkerP.setColor(0xFF252836);
        for (int y = 0; y < p.h; y += cell) {
            for (int x = 0; x < p.w; x += cell) {
                if (((x / cell) + (y / cell)) % 2 == 0)
                    c.drawRect(x, y, Math.min(x + cell, p.w), Math.min(y + cell, p.h), checkerP);
            }
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(Ui.BG);
        if (p == null) return;
        c.save();
        c.concat(m);
        boolean transparent = (p.paper >>> 24) == 0;
        if (transparent) drawChecker(c);
        else {
            paperP.setColor(p.paper);
            c.drawRect(full, paperP);
        }
        if (playBmp != null) {
            c.drawBitmap(playBmp, null, full, lp);
        } else {
            if (onion && onionBmp != null) c.drawBitmap(onionBmp, null, full, onionP);
            lp.setAlpha(255);
            drawLayers(c, true);
            if (hasSel) {
                selP.setStrokeWidth(2f / m.mapRadius(1f));
                c.drawRect(sel, selP);
            }
        }
        c.restore();
    }

    Bitmap renderComposite(boolean withPaper) {
        Bitmap out = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        if (withPaper && (p.paper >>> 24) != 0) c.drawColor(p.paper);
        drawLayers(c, false);
        return out;
    }

    /* ---------- seleção ---------- */
    void clearSelection() {
        hasSel = false;
        sel.setEmpty();
        notifySel();
        invalidate();
    }

    private void notifySel() {
        if (listener != null) listener.onSelectionChanged(hasSel);
    }

    private boolean activeLocked() {
        if (active < 0 || active >= p.layers.size()) return true;
        return p.layers.get(active).locked;
    }

    private Bitmap ensureLayer() {
        Project.Layer l = p.layers.get(active);
        Bitmap b = cur.get(l.id);
        if (b == null) {
            b = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
            cur.put(l.id, b);
        }
        return b;
    }

    /** Apaga o conteúdo dentro da seleção. */
    void deleteSelection() {
        if (!hasSel || activeLocked()) return;
        pushUndo(p.layers.get(active).id);
        Bitmap b = ensureLayer();
        Canvas c = new Canvas(b);
        Paint x = new Paint();
        x.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        c.drawRect(sel, x);
        dirty.add(p.layers.get(active).id);
        clearSelection();
        if (listener != null) listener.onChanged();
        invalidate();
    }

    /** Preenche a seleção com a cor atual. */
    void fillSelection() {
        if (!hasSel || activeLocked()) return;
        pushUndo(p.layers.get(active).id);
        Bitmap b = ensureLayer();
        Canvas c = new Canvas(b);
        Paint f = new Paint();
        f.setColor(color);
        f.setAlpha(Math.round(opacity * 2.55f));
        c.drawRect(sel, f);
        dirty.add(p.layers.get(active).id);
        if (listener != null) listener.onChanged();
        invalidate();
    }

    void cutSelection() {
        if (!hasSel || activeLocked()) return;
        copySelection();
        deleteSelection();
    }

    void copySelection() {
        if (!hasSel) return;
        Bitmap layer = cur.get(p.layers.get(active).id);
        if (layer == null) {
            if (clipboard != null) {
                clipboard.recycle();
                clipboard = null;
            }
            return;
        }
        int l = Math.max(0, (int) Math.floor(sel.left));
        int t = Math.max(0, (int) Math.floor(sel.top));
        int r = Math.min(p.w, (int) Math.ceil(sel.right));
        int btm = Math.min(p.h, (int) Math.ceil(sel.bottom));
        if (r <= l || btm <= t) return;
        if (clipboard != null) clipboard.recycle();
        clipboard = Bitmap.createBitmap(layer, l, t, r - l, btm - t);
        if (listener != null) listener.onMessage("Copiado");
    }

    void pasteClipboard() {
        if (clipboard == null || clipboard.isRecycled() || activeLocked()) {
            if (listener != null) listener.onMessage("Nada na área de transferência");
            return;
        }
        pushUndo(p.layers.get(active).id);
        Bitmap b = ensureLayer();
        Canvas c = new Canvas(b);
        float x = hasSel ? sel.left : (p.w - clipboard.getWidth()) / 2f;
        float y = hasSel ? sel.top : (p.h - clipboard.getHeight()) / 2f;
        c.drawBitmap(clipboard, x, y, null);
        dirty.add(p.layers.get(active).id);
        sel.set(x, y, x + clipboard.getWidth(), y + clipboard.getHeight());
        hasSel = true;
        notifySel();
        if (listener != null) listener.onChanged();
        invalidate();
    }

    /* ---------- toque ---------- */
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (p == null || playBmp != null) return true;
        int n = e.getPointerCount();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                maxPtr = 1;
                downT = e.getEventTime();
                gMoved = false;
                pinching = false;
                lastX = e.getX();
                lastY = e.getY();
                if (tool == PAN) panning = true;
                else if (tool == SELECT) beginSelect(e);
                else if (tool == LINE || tool == RECT || tool == ELLIPSE) beginShape(e);
                else if (tool != PICK && tool != FILL) startStroke(e);
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                maxPtr = Math.max(maxPtr, n);
                cancelStroke();
                cancelShape();
                cancelSelectDrag();
                panning = false;
                if (n == 2) beginPinch(e);
                break;
            case MotionEvent.ACTION_MOVE:
                if (n >= 2 && pinching) doPinch(e);
                else if (panning) {
                    m.postTranslate(e.getX() - lastX, e.getY() - lastY);
                    lastX = e.getX();
                    lastY = e.getY();
                    invalidate();
                } else if (selecting && n == 1) dragSelect(e);
                else if (movingSel && n == 1) dragMoveSel(e);
                else if (shaping && n == 1) dragShape(e);
                else if (stroking && n == 1) {
                    boolean pen = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS;
                    for (int i = 0; i < e.getHistorySize(); i++)
                        addPoint(e.getHistoricalX(i), e.getHistoricalY(i), e.getHistoricalPressure(i), pen);
                    addPoint(e.getX(), e.getY(), e.getPressure(), pen);
                    invalidate();
                }
                break;
            case MotionEvent.ACTION_POINTER_UP:
                pinching = false;
                break;
            case MotionEvent.ACTION_UP:
                if (stroking) endStroke();
                else if (shaping) endShape();
                else if (selecting) endSelect();
                else if (movingSel) endMoveSel();
                else if (maxPtr == 1 && tool == PICK) pick(e.getX(), e.getY());
                else if (maxPtr == 1 && tool == FILL) fill(e.getX(), e.getY());
                else if (maxPtr == 2 && !gMoved && e.getEventTime() - downT < 350) undo();
                else if (maxPtr >= 3 && !gMoved && e.getEventTime() - downT < 400) redo();
                panning = false;
                pinching = false;
                break;
            case MotionEvent.ACTION_CANCEL:
                cancelStroke();
                cancelShape();
                cancelSelectDrag();
                panning = false;
                pinching = false;
                break;
            default:
                break;
        }
        return true;
    }

    private void beginPinch(MotionEvent e) {
        pinching = true;
        m0.set(m);
        f0x = (e.getX(0) + e.getX(1)) / 2f;
        f0y = (e.getY(0) + e.getY(1)) / 2f;
        d0 = Math.max(10f, (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)));
    }

    private void doPinch(MotionEvent e) {
        float fx = (e.getX(0) + e.getX(1)) / 2f, fy = (e.getY(0) + e.getY(1)) / 2f;
        float d = Math.max(10f, (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)));
        if (Math.abs(d - d0) > 24 || Math.hypot(fx - f0x, fy - f0y) > 24) gMoved = true;
        float base = m0.mapRadius(1f), s = d / d0;
        float minS = 0.08f, maxS = 40f;
        if (base * s < minS) s = minS / base;
        if (base * s > maxS) s = maxS / base;
        m.set(m0);
        m.postTranslate(fx - f0x, fy - f0y);
        m.postScale(s, s, fx, fy);
        invalidate();
    }

    /* ---------- seleção por toque ---------- */
    private void beginSelect(MotionEvent e) {
        float[] q = map(e.getX(), e.getY());
        if (hasSel && sel.contains(q[0], q[1])) {
            movingSel = true;
            moveOffX = q[0] - sel.left;
            moveOffY = q[1] - sel.top;
            pushUndo(p.layers.get(active).id);
            return;
        }
        selecting = true;
        shapeX0 = q[0];
        shapeY0 = q[1];
        sel.set(q[0], q[1], q[0], q[1]);
        hasSel = true;
        notifySel();
        invalidate();
    }

    private void dragSelect(MotionEvent e) {
        float[] q = map(e.getX(), e.getY());
        sel.set(
                Math.min(shapeX0, q[0]), Math.min(shapeY0, q[1]),
                Math.max(shapeX0, q[0]), Math.max(shapeY0, q[1])
        );
        invalidate();
    }

    private void endSelect() {
        selecting = false;
        if (sel.width() < 4 || sel.height() < 4) clearSelection();
        else {
            sel.left = Math.max(0, sel.left);
            sel.top = Math.max(0, sel.top);
            sel.right = Math.min(p.w, sel.right);
            sel.bottom = Math.min(p.h, sel.bottom);
            notifySel();
        }
        invalidate();
    }

    private void cancelSelectDrag() {
        selecting = false;
        movingSel = false;
    }

    private void dragMoveSel(MotionEvent e) {
        float[] q = map(e.getX(), e.getY());
        float w = sel.width(), h = sel.height();
        float nl = q[0] - moveOffX, nt = q[1] - moveOffY;
        sel.set(nl, nt, nl + w, nt + h);
        invalidate();
    }

    private void endMoveSel() {
        if (!movingSel) return;
        movingSel = false;
        // Conteúdo não é movido automaticamente ao arrastar a moldura;
        // use recortar + colar para mover pixels. A moldura só reposiciona a área.
        if (listener != null) listener.onMessage("Área movida — use Recortar/Colar para mover pixels");
        notifySel();
        invalidate();
    }

    /* ---------- formas ---------- */
    private void beginShape(MotionEvent e) {
        if (activeLocked()) {
            if (listener != null) listener.onMessage("Camada bloqueada");
            return;
        }
        Project.Layer l = p.layers.get(active);
        if (!l.visible) {
            if (listener != null) listener.onMessage("Camada oculta");
            return;
        }
        shaping = true;
        strokeBmp.eraseColor(0);
        float[] q = map(e.getX(), e.getY());
        shapeX0 = q[0];
        shapeY0 = q[1];
        prepareShapePaint();
        invalidate();
    }

    private void prepareShapePaint() {
        int col = tool == ERASER ? 0xFF000000 : (color | 0xFF000000);
        bp.setColor(col);
        bp.setShader(null);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeWidth(Math.max(1f, size));
        bp.setAlpha(Math.round(opacity * 2.55f));
        if (tool == ERASER) bp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        else bp.setXfermode(null);
    }

    private void dragShape(MotionEvent e) {
        float[] q = map(e.getX(), e.getY());
        strokeBmp.eraseColor(0);
        prepareShapePaint();
        if (tool == LINE) {
            strokeCv.drawLine(shapeX0, shapeY0, q[0], q[1], bp);
        } else if (tool == RECT) {
            tmpR.set(Math.min(shapeX0, q[0]), Math.min(shapeY0, q[1]),
                    Math.max(shapeX0, q[0]), Math.max(shapeY0, q[1]));
            strokeCv.drawRect(tmpR, bp);
        } else if (tool == ELLIPSE) {
            tmpR.set(Math.min(shapeX0, q[0]), Math.min(shapeY0, q[1]),
                    Math.max(shapeX0, q[0]), Math.max(shapeY0, q[1]));
            strokeCv.drawOval(tmpR, bp);
        }
        invalidate();
    }

    private void endShape() {
        if (!shaping) return;
        shaping = false;
        commit();
    }

    private void cancelShape() {
        if (!shaping) return;
        shaping = false;
        strokeBmp.eraseColor(0);
        invalidate();
    }

    /* ---------- traço livre ---------- */
    private float widthFor(float pr, float dist, boolean pen) {
        switch (tool) {
            case PENCIL:
                return Math.max(1f, size * 0.5f) * (pen ? 0.5f + 0.5f * pr : 1f);
            case GPEN:
                return Math.max(0.8f, pen ? size * (0.15f + 0.85f * pr) : size * (1.1f - Math.min(0.65f, dist / (size * 3f + 30f))));
            case MARKER:
                return size * 1.15f;
            default:
                return size;
        }
    }

    private void startStroke(MotionEvent e) {
        Project.Layer l = p.layers.get(active);
        if (!l.visible) {
            if (listener != null) listener.onMessage("A camada ativa está oculta");
            return;
        }
        if (l.locked) {
            if (listener != null) listener.onMessage("Camada bloqueada");
            return;
        }
        if (tool == ERASER && cur.get(l.id) == null) return;
        stroking = true;
        strokeBmp.eraseColor(0);
        boolean pen = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS;
        float[] q = map(e.getX(), e.getY());
        px = mx = q[0];
        py = my = q[1];
        lw = widthFor(e.getPressure(), 0, pen);
        int col = tool == ERASER ? 0xFF000000 : (tool == PENCIL ? (color & 0x00FFFFFF) | 0xD0000000 : color | 0xFF000000);
        bp.setColor(col);
        bp.setShader(null);
        bp.setXfermode(null);
        bp.setAlpha(255);
        if (tool == AIR) {
            int r = Math.max(2, Math.round(size * 1.5f));
            if (dab != null) dab.recycle();
            dab = Bitmap.createBitmap(r * 2, r * 2, Bitmap.Config.ARGB_8888);
            Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
            int rgb = color & 0x00FFFFFF;
            g.setShader(new RadialGradient(r, r, r, new int[]{0x30000000 | rgb, 0x00000000 | rgb}, null, Shader.TileMode.CLAMP));
            new Canvas(dab).drawCircle(r, r, r, g);
            airRem = 0;
            strokeCv.drawBitmap(dab, px - r, py - r, null);
        } else {
            bp.setStyle(Paint.Style.FILL);
            strokeCv.drawCircle(px, py, lw / 2f, bp);
            bp.setStyle(Paint.Style.STROKE);
        }
        invalidate();
    }

    private void addPoint(float vx, float vy, float pr, boolean pen) {
        float[] q = map(vx, vy);
        float x = q[0], y = q[1], d = (float) Math.hypot(x - px, y - py);
        if (d < 1.2f) return;
        if (tool == AIR) {
            float r = dab.getWidth() / 2f, step = Math.max(1f, r * 0.2f), pos = airRem;
            while (pos <= d) {
                float k = pos / d;
                strokeCv.drawBitmap(dab, px + (x - px) * k - r, py + (y - py) * k - r, null);
                pos += step;
            }
            airRem = pos - d;
        } else {
            lw = lw * 0.65f + widthFor(pr, d, pen) * 0.35f;
            float nmx = (px + x) / 2f, nmy = (py + y) / 2f;
            path.rewind();
            path.moveTo(mx, my);
            path.quadTo(px, py, nmx, nmy);
            bp.setStrokeWidth(lw);
            strokeCv.drawPath(path, bp);
            mx = nmx;
            my = nmy;
        }
        px = x;
        py = y;
    }

    private void endStroke() {
        if (tool != AIR) {
            bp.setStrokeWidth(lw);
            strokeCv.drawLine(mx, my, px, py, bp);
        }
        commit();
    }

    private void cancelStroke() {
        if (!stroking) return;
        stroking = false;
        strokeBmp.eraseColor(0);
        invalidate();
    }

    private void commit() {
        stroking = false;
        shaping = false;
        Project.Layer l = p.layers.get(active);
        pushUndo(l.id);
        Bitmap b = ensureLayer();
        Canvas c = new Canvas(b);
        Paint pt = strokePaint();
        if (tool == ERASER) {
            pt.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
            pt.setAlpha(Math.round(opacity * 2.55f));
        } else {
            pt.setXfermode(null);
            pt.setAlpha(Math.round(opacity * 2.55f));
        }
        c.drawBitmap(strokeBmp, 0, 0, pt);
        strokeBmp.eraseColor(0);
        dirty.add(l.id);
        if (listener != null) listener.onChanged();
        invalidate();
    }

    /* ---------- conta-gotas e balde ---------- */
    private void pick(float vx, float vy) {
        float[] q = map(vx, vy);
        int x = Math.round(q[0]), y = Math.round(q[1]);
        if (x < 0 || y < 0 || x >= p.w || y >= p.h) return;
        int c = Color.TRANSPARENT;
        for (int i = p.layers.size() - 1; i >= 0; i--) {
            Project.Layer l = p.layers.get(i);
            if (!l.visible) continue;
            Bitmap b = cur.get(l.id);
            if (b == null) continue;
            int px = b.getPixel(x, y);
            if ((px >>> 24) > 16) {
                c = px | 0xFF000000;
                break;
            }
        }
        if (c == Color.TRANSPARENT && (p.paper >>> 24) != 0) c = p.paper | 0xFF000000;
        if (listener != null) listener.onColorPicked(c);
    }

    private void fill(float vx, float vy) {
        if (activeLocked()) {
            if (listener != null) listener.onMessage("Camada bloqueada");
            return;
        }
        float[] q = map(vx, vy);
        int x = Math.round(q[0]), y = Math.round(q[1]);
        if (x < 0 || y < 0 || x >= p.w || y >= p.h) return;
        Project.Layer l = p.layers.get(active);
        if (!l.visible) return;
        pushUndo(l.id);
        Bitmap b = ensureLayer();
        int target = b.getPixel(x, y);
        int repl = (color & 0x00FFFFFF) | (Math.round(opacity * 2.55f) << 24);
        if (target == repl) return;
        flood(b, x, y, target, repl);
        dirty.add(l.id);
        if (listener != null) listener.onChanged();
        invalidate();
    }

    private void flood(Bitmap bmp, int sx, int sy, int target, int repl) {
        int w = bmp.getWidth(), h = bmp.getHeight();
        int[] pix = new int[w * h];
        bmp.getPixels(pix, 0, w, 0, 0, w, h);
        if (pix[sy * w + sx] != target) return;
        int[] stack = new int[w * h];
        int top = 0;
        stack[top++] = sy * w + sx;
        int tol = 24;
        while (top > 0) {
            int i = stack[--top];
            if (i < 0 || i >= pix.length) continue;
            int c = pix[i];
            if (!near(c, target, tol)) continue;
            pix[i] = repl;
            int x = i % w, y = i / w;
            if (x > 0) stack[top++] = i - 1;
            if (x + 1 < w) stack[top++] = i + 1;
            if (y > 0) stack[top++] = i - w;
            if (y + 1 < h) stack[top++] = i + w;
        }
        bmp.setPixels(pix, 0, w, 0, 0, w, h);
    }

    private static boolean near(int a, int b, int tol) {
        return Math.abs(((a >> 16) & 255) - ((b >> 16) & 255)) <= tol
                && Math.abs(((a >> 8) & 255) - ((b >> 8) & 255)) <= tol
                && Math.abs((a & 255) - (b & 255)) <= tol
                && Math.abs(((a >> 24) & 255) - ((b >> 24) & 255)) <= tol;
    }
}
