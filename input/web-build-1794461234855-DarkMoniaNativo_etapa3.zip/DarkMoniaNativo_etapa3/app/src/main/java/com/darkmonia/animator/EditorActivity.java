package com.darkmonia.animator;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

/** Editor: desenho, formas, seleção, camadas e timeline. */
public class EditorActivity extends Activity implements CanvasView.Listener {
    private Project p;
    private CanvasView cv;
    private LinearLayout strip;
    private TextView frameLbl, sizeLbl, opLbl, fpsLbl;
    private Button colorBtn, undoBtn, redoBtn, playBtn, onionBtn;
    private LinearLayout selBar;
    private final Button[] toolBtns = new Button[12];
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ConcurrentHashMap<Integer, Bitmap> thumbs = new ConcurrentHashMap<>();
    private ArrayList<Bitmap> playFrames;
    private boolean playing;
    private int playI;
    private Integer clipFrameId;

    private static final String[] TOOLS = {
            "Lápis", "G-Pen", "Marcador", "Aerógrafo", "Borracha",
            "Balde", "Conta-gotas", "Mover",
            "Seleção", "Reta", "Retângulo", "Elipse"
    };

    private static final int[] SWATCHES = {
            0xFF16161D, 0xFFFFFFFF, 0xFF8B8680, 0xFFE5472B, 0xFFFF6A1A, 0xFFF2A516, 0xFFFFE27A, 0xFF3F9D4B,
            0xFF1F6B3A, 0xFF39E6FF, 0xFF2D6CDF, 0xFF7B4BD1, 0xFFFF4FD8, 0xFFE58FB1, 0xFF7A5230, 0xFFD9A066
    };

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        String dir = getIntent().getStringExtra("dir");
        p = dir == null ? null : Project.load(new File(dir));
        if (p == null) {
            finish();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.PANEL);
        int g = Ui.dp(this, 4);

        /* barra superior */
        LinearLayout top = row();
        top.setPadding(g, g, g, g);
        Button back = Ui.btn(this, "‹");
        back.setTextSize(18);
        back.setOnClickListener(v -> finish());
        top.addView(back);
        TextView title = new TextView(this);
        title.setText(p.name);
        title.setTextColor(Ui.FG);
        title.setTextSize(15);
        title.setSingleLine(true);
        title.setPadding(Ui.dp(this, 10), 0, 0, 0);
        top.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        undoBtn = Ui.btn(this, "↶");
        redoBtn = Ui.btn(this, "↷");
        undoBtn.setOnClickListener(v -> cv.undo());
        redoBtn.setOnClickListener(v -> cv.redo());
        add(top, undoBtn, g);
        add(top, redoBtn, g);
        if (p.anim) {
            playBtn = Ui.btn(this, "▶");
            Ui.sel(playBtn, true);
            playBtn.setOnClickListener(v -> {
                if (playing) stopPlay();
                else startPlay();
            });
            add(top, playBtn, g);
        }
        Button menu = Ui.btn(this, "⋮");
        menu.setOnClickListener(v -> menu());
        add(top, menu, g);
        root.addView(top);

        /* tela */
        cv = new CanvasView(this);
        cv.listener = this;
        root.addView(cv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        /* barra de seleção (aparece quando há seleção) */
        selBar = row();
        selBar.setPadding(g, 0, g, 0);
        selBar.setVisibility(View.GONE);
        for (String[] act : new String[][]{
                {"Apagar", "del"}, {"Preencher", "fill"}, {"Recortar", "cut"},
                {"Copiar", "copy"}, {"Colar", "paste"}, {"Limpar sel.", "clear"}
        }) {
            Button b = Ui.btn(this, act[0]);
            String id = act[1];
            b.setOnClickListener(v -> {
                switch (id) {
                    case "del":
                        cv.deleteSelection();
                        break;
                    case "fill":
                        cv.fillSelection();
                        break;
                    case "cut":
                        cv.cutSelection();
                        break;
                    case "copy":
                        cv.copySelection();
                        break;
                    case "paste":
                        cv.pasteClipboard();
                        break;
                    case "clear":
                        cv.clearSelection();
                        break;
                }
            });
            add(selBar, b, g);
        }
        root.addView(selBar);

        /* ferramentas */
        HorizontalScrollView ts = new HorizontalScrollView(this);
        ts.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = row();
        tools.setPadding(g, g, g, 0);
        colorBtn = Ui.btn(this, "  Cor  ");
        colorBtn.setOnClickListener(v -> pickColor());
        add(tools, colorBtn, g);
        Button ly = Ui.btn(this, "Camadas");
        ly.setOnClickListener(v -> layersDialog());
        add(tools, ly, g);
        for (int i = 0; i < TOOLS.length; i++) {
            final int t = i;
            toolBtns[i] = Ui.btn(this, TOOLS[i]);
            toolBtns[i].setOnClickListener(v -> setTool(t));
            add(tools, toolBtns[i], g);
        }
        ts.addView(tools);
        root.addView(ts);

        /* tamanho e opacidade */
        LinearLayout sl = row();
        sl.setPadding(Ui.dp(this, 8), 0, Ui.dp(this, 8), 0);
        sizeLbl = Ui.label(this, "");
        opLbl = Ui.label(this, "");
        SeekBar sz = new SeekBar(this), op = new SeekBar(this);
        sz.setMax(99);
        op.setMax(99);
        sl.addView(sizeLbl);
        sl.addView(sz, new LinearLayout.LayoutParams(0, Ui.dp(this, 36), 1));
        sl.addView(opLbl);
        sl.addView(op, new LinearLayout.LayoutParams(0, Ui.dp(this, 36), 1));
        root.addView(sl);

        /* timeline */
        if (p.anim) {
            HorizontalScrollView fs = new HorizontalScrollView(this);
            fs.setHorizontalScrollBarEnabled(false);
            LinearLayout fr = row();
            fr.setPadding(g, 0, g, 0);
            frameLbl = Ui.label(this, "");
            fr.addView(frameLbl);
            Button prev = Ui.btn(this, "◀"), next = Ui.btn(this, "▶ ");
            Button addF = Ui.btn(this, "+ Quadro"), dup = Ui.btn(this, "Duplicar"), del = Ui.btn(this, "Apagar");
            Button copyF = Ui.btn(this, "Copiar Q"), pasteF = Ui.btn(this, "Colar Q");
            onionBtn = Ui.btn(this, "Fantasma");
            Button fm = Ui.btn(this, "−"), fp = Ui.btn(this, "+");
            fpsLbl = Ui.label(this, "");
            prev.setOnClickListener(v -> goFrame(cv.frameIdx - 1));
            next.setOnClickListener(v -> goFrame(cv.frameIdx + 1));
            addF.setOnClickListener(v -> addFrame(false));
            dup.setOnClickListener(v -> addFrame(true));
            del.setOnClickListener(v -> deleteFrame());
            copyF.setOnClickListener(v -> {
                clipFrameId = cv.frameId();
                Ui.toast(this, "Quadro copiado");
            });
            pasteF.setOnClickListener(v -> pasteFrame());
            onionBtn.setOnClickListener(v -> {
                cv.onion = !cv.onion;
                Ui.sel(onionBtn, cv.onion);
                cv.invalidate();
            });
            fm.setOnClickListener(v -> setFps(p.fps - 1));
            fp.setOnClickListener(v -> setFps(p.fps + 1));
            add(fr, prev, g);
            add(fr, next, g);
            add(fr, addF, g);
            add(fr, dup, g);
            add(fr, del, g);
            add(fr, copyF, g);
            add(fr, pasteF, g);
            add(fr, onionBtn, g);
            add(fr, fm, g);
            fr.addView(fpsLbl);
            add(fr, fp, g);
            fs.addView(fr);
            root.addView(fs);
            Ui.sel(onionBtn, true);

            HorizontalScrollView ss = new HorizontalScrollView(this);
            strip = row();
            strip.setPadding(g, g, g, g);
            ss.addView(strip);
            root.addView(ss);
        }
        View bottomPad = new View(this);
        root.addView(bottomPad, new LinearLayout.LayoutParams(1, g));
        setContentView(root);

        cv.setProject(p);
        sz.setProgress(cv.size - 1);
        op.setProgress(cv.opacity - 1);
        sz.setOnSeekBarChangeListener(new Ui.Seek() {
            @Override
            void change(int v) {
                cv.size = v + 1;
                labels();
            }
        });
        op.setOnSeekBarChangeListener(new Ui.Seek() {
            @Override
            void change(int v) {
                cv.opacity = v + 1;
                labels();
            }
        });
        setTool(CanvasView.GPEN);
        setColor(cv.color);
        labels();
        onChanged();
        if (p.anim) {
            setFps(p.fps);
            rebuildStrip();
        }
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private void add(LinearLayout parent, View v, int gap) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(gap, 0, 0, 0);
        parent.addView(v, lp);
    }

    private void labels() {
        sizeLbl.setText("Tam. " + cv.size);
        opLbl.setText("Opac. " + cv.opacity + "%");
    }

    private void setTool(int t) {
        cv.tool = t;
        for (int i = 0; i < toolBtns.length; i++) Ui.sel(toolBtns[i], i == t);
        if (t != CanvasView.SELECT) {
            // seleção permanece até o usuário limpar
        }
    }

    private void setColor(int c) {
        cv.color = c | 0xFF000000;
        colorBtn.setBackground(Ui.bg(cv.color, Ui.dp(this, 10)));
        float[] hsv = new float[3];
        Color.colorToHSV(cv.color, hsv);
        colorBtn.setTextColor(hsv[2] > 0.6f && hsv[1] < 0.6f ? 0xFF000000 : 0xFFFFFFFF);
    }

    @Override
    public void onChanged() {
        undoBtn.setAlpha(cv.canUndo() ? 1f : 0.35f);
        redoBtn.setAlpha(cv.canRedo() ? 1f : 0.35f);
    }

    @Override
    public void onColorPicked(int c) {
        setColor(c);
        setTool(CanvasView.GPEN);
        Ui.toast(this, "Cor capturada");
    }

    @Override
    public void onMessage(String m) {
        Ui.toast(this, m);
    }

    @Override
    public void onSelectionChanged(boolean has) {
        selBar.setVisibility(has ? View.VISIBLE : View.GONE);
    }

    /* ---------- cores ---------- */
    private void pickColor() {
        final float[] hsv = new float[3];
        Color.colorToHSV(cv.color, hsv);
        int pad = Ui.dp(this, 16);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, 0);
        final View prev = new View(this);
        prev.setBackground(Ui.bg(cv.color, Ui.dp(this, 10)));
        box.addView(prev, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 44)));
        final SeekBar sh = new SeekBar(this), ss = new SeekBar(this), sv = new SeekBar(this);
        sh.setMax(360);
        ss.setMax(100);
        sv.setMax(100);
        for (int r = 0; r < 2; r++) {
            LinearLayout line = row();
            line.setPadding(0, Ui.dp(this, 8), 0, 0);
            for (int i = 0; i < 8; i++) {
                final int col = SWATCHES[r * 8 + i];
                View sw = new View(this);
                sw.setBackground(Ui.bg(col, Ui.dp(this, 8)));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 32), 1);
                lp.setMargins(Ui.dp(this, 2), 0, Ui.dp(this, 2), 0);
                line.addView(sw, lp);
                sw.setOnClickListener(v -> {
                    Color.colorToHSV(col, hsv);
                    sh.setProgress(Math.round(hsv[0]));
                    ss.setProgress(Math.round(hsv[1] * 100));
                    sv.setProgress(Math.round(hsv[2] * 100));
                    prev.setBackground(Ui.bg(col, Ui.dp(this, 10)));
                });
            }
            box.addView(line);
        }
        String[] names = {"Matiz", "Saturação", "Brilho"};
        SeekBar[] bars = {sh, ss, sv};
        for (int i = 0; i < 3; i++) {
            TextView t = Ui.label(this, names[i]);
            t.setPadding(0, Ui.dp(this, 10), 0, 0);
            box.addView(t);
            box.addView(bars[i], new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 36)));
        }
        sh.setProgress(Math.round(hsv[0]));
        ss.setProgress(Math.round(hsv[1] * 100));
        sv.setProgress(Math.round(hsv[2] * 100));
        Ui.Seek upd = new Ui.Seek() {
            @Override
            void change(int v) {
                hsv[0] = sh.getProgress();
                hsv[1] = ss.getProgress() / 100f;
                hsv[2] = sv.getProgress() / 100f;
                prev.setBackground(Ui.bg(Color.HSVToColor(hsv), Ui.dp(EditorActivity.this, 10)));
            }
        };
        sh.setOnSeekBarChangeListener(upd);
        ss.setOnSeekBarChangeListener(upd);
        sv.setOnSeekBarChangeListener(upd);
        new AlertDialog.Builder(this).setTitle("Cor").setView(box)
                .setPositiveButton("OK", (d, w) -> setColor(Color.HSVToColor(hsv)))
                .setNegativeButton("Cancelar", null).show();
    }

    /* ---------- camadas ---------- */
    private void layersDialog() {
        ScrollView sc = new ScrollView(this);
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 12);
        box.setPadding(pad, pad, pad, 0);
        sc.addView(box);
        fillLayers(box);
        new AlertDialog.Builder(this)
                .setTitle("Camadas")
                .setView(sc)
                .setPositiveButton("Fechar", null)
                .setNeutralButton("+ Camada", (d, w) -> {
                    if (p.layers.size() >= 12) {
                        Ui.toast(this, "Máximo de 12 camadas");
                        return;
                    }
                    cv.saveCurrent();
                    Project.Layer l = p.addLayer("Camada " + p.layers.size());
                    p.save();
                    cv.active = p.layers.size() - 1;
                    Ui.toast(this, "Camada criada");
                })
                .show();
    }

    private void fillLayers(final LinearLayout box) {
        box.removeAllViews();
        int g = Ui.dp(this, 4);
        for (int i = p.layers.size() - 1; i >= 0; i--) {
            final int idx = i;
            final Project.Layer l = p.layers.get(i);
            LinearLayout r = row();
            r.setPadding(0, 0, 0, g * 2);

            Button name = Ui.btn(this, (l.locked ? "🔒 " : "") + l.name);
            Ui.sel(name, idx == cv.active);
            name.setOnClickListener(v -> {
                cv.active = idx;
                fillLayers(box);
            });
            name.setOnLongClickListener(v -> {
                renameLayer(l, box);
                return true;
            });
            r.addView(name, new LinearLayout.LayoutParams(Ui.dp(this, 110), LinearLayout.LayoutParams.WRAP_CONTENT));

            Button eye = Ui.btn(this, l.visible ? "👁" : "—");
            eye.setOnClickListener(v -> {
                l.visible = !l.visible;
                p.save();
                cv.invalidate();
                fillLayers(box);
            });
            add(r, eye, g);

            Button lock = Ui.btn(this, l.locked ? "🔒" : "🔓");
            lock.setOnClickListener(v -> {
                l.locked = !l.locked;
                p.save();
                fillLayers(box);
            });
            add(r, lock, g);

            Button up = Ui.btn(this, "↑");
            up.setOnClickListener(v -> {
                if (idx + 1 < p.layers.size()) {
                    Project.Layer tmp = p.layers.remove(idx);
                    p.layers.add(idx + 1, tmp);
                    if (cv.active == idx) cv.active = idx + 1;
                    else if (cv.active == idx + 1) cv.active = idx;
                    p.save();
                    cv.invalidate();
                    fillLayers(box);
                }
            });
            add(r, up, g);

            Button dn = Ui.btn(this, "↓");
            dn.setOnClickListener(v -> {
                if (idx > 0) {
                    Project.Layer tmp = p.layers.remove(idx);
                    p.layers.add(idx - 1, tmp);
                    if (cv.active == idx) cv.active = idx - 1;
                    else if (cv.active == idx - 1) cv.active = idx;
                    p.save();
                    cv.invalidate();
                    fillLayers(box);
                }
            });
            add(r, dn, g);

            Button dup = Ui.btn(this, "Dup");
            dup.setOnClickListener(v -> duplicateLayer(idx));
            add(r, dup, g);

            if (p.layers.size() > 1) {
                Button del = Ui.btn(this, "✕");
                del.setOnClickListener(v -> {
                    cv.saveCurrent();
                    cv.removeLayerBitmap(l.id);
                    for (int fid : p.frames) p.layerFile(fid, l.id).delete();
                    p.layers.remove(idx);
                    if (cv.active >= p.layers.size()) cv.active = p.layers.size() - 1;
                    p.save();
                    cv.invalidate();
                    fillLayers(box);
                });
                add(r, del, g);
            }

            SeekBar op = new SeekBar(this);
            op.setMax(255);
            op.setProgress(l.opacity);
            op.setOnSeekBarChangeListener(new Ui.Seek() {
                @Override
                void change(int v) {
                    l.opacity = v;
                    cv.invalidate();
                }
            });
            LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(Ui.dp(this, 90), Ui.dp(this, 36));
            olp.setMargins(g, 0, 0, 0);
            r.addView(op, olp);

            box.addView(r);
        }
    }

    private void renameLayer(Project.Layer l, LinearLayout box) {
        EditText et = new EditText(this);
        et.setText(l.name);
        new AlertDialog.Builder(this).setTitle("Renomear camada").setView(et)
                .setPositiveButton("OK", (d, w) -> {
                    String s = et.getText().toString().trim();
                    if (s.length() > 0) {
                        l.name = s.length() > 24 ? s.substring(0, 24) : s;
                        p.save();
                        fillLayers(box);
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    private void duplicateLayer(int idx) {
        if (p.layers.size() >= 12) {
            Ui.toast(this, "Máximo de 12 camadas");
            return;
        }
        cv.saveCurrent();
        Project.Layer src = p.layers.get(idx);
        Project.Layer nl = p.addLayer(src.name + " cópia");
        nl.opacity = src.opacity;
        nl.visible = src.visible;
        // copia arquivos de camada em todos os quadros
        for (int fid : p.frames) {
            File sf = p.layerFile(fid, src.id);
            if (sf.exists()) {
                try {
                    java.io.FileInputStream in = new java.io.FileInputStream(sf);
                    java.io.FileOutputStream out = new java.io.FileOutputStream(p.layerFile(fid, nl.id));
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    in.close();
                    out.close();
                } catch (Exception ignored) {
                }
            }
        }
        p.save();
        cv.loadFrame(cv.frameIdx);
        cv.active = p.layers.size() - 1;
        Ui.toast(this, "Camada duplicada");
    }

    /* ---------- frames ---------- */
    private void goFrame(int idx) {
        if (idx < 0 || idx >= p.frames.size()) return;
        if (playing) stopPlay();
        cv.loadFrame(idx);
        updateFrameLbl();
        rebuildStrip();
    }

    private void updateFrameLbl() {
        if (frameLbl != null)
            frameLbl.setText("Q " + (cv.frameIdx + 1) + "/" + p.frames.size());
    }

    private void setFps(int f) {
        p.fps = Math.max(1, Math.min(60, f));
        if (fpsLbl != null) fpsLbl.setText(p.fps + " fps");
        p.save();
    }

    private void addFrame(boolean dup) {
        cv.saveCurrent();
        int curId = cv.frameId();
        int nid = p.nextFrame++;
        if (dup) p.copyFrameFiles(curId, nid);
        p.frames.add(cv.frameIdx + 1, nid);
        p.save();
        goFrame(cv.frameIdx + 1);
    }

    private void deleteFrame() {
        if (p.frames.size() <= 1) {
            Ui.toast(this, "Precisa de pelo menos 1 quadro");
            return;
        }
        cv.saveCurrent();
        int id = p.frames.remove(cv.frameIdx);
        p.deleteFrameFiles(id);
        p.save();
        thumbs.remove(id);
        int ni = Math.min(cv.frameIdx, p.frames.size() - 1);
        cv.loadFrame(ni);
        updateFrameLbl();
        rebuildStrip();
    }

    private void pasteFrame() {
        if (clipFrameId == null) {
            Ui.toast(this, "Nenhum quadro copiado");
            return;
        }
        cv.saveCurrent();
        int nid = p.nextFrame++;
        p.copyFrameFiles(clipFrameId, nid);
        p.frames.add(cv.frameIdx + 1, nid);
        p.save();
        goFrame(cv.frameIdx + 1);
        Ui.toast(this, "Quadro colado");
    }

    private void rebuildStrip() {
        if (strip == null) return;
        strip.removeAllViews();
        int g = Ui.dp(this, 4);
        updateFrameLbl();
        for (int i = 0; i < p.frames.size(); i++) {
            final int idx = i;
            final int fid = p.frames.get(i);
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setPadding(g, g, g, g);
            cell.setBackground(Ui.bg(idx == cv.frameIdx ? Ui.ACC : Ui.BTN, Ui.dp(this, 8)));
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackgroundColor(0xFF0C0D14);
            int side = Ui.dp(this, 56);
            strip.addView(cell, new LinearLayout.LayoutParams(side + g * 2, LinearLayout.LayoutParams.WRAP_CONTENT));
            cell.addView(iv, new LinearLayout.LayoutParams(side, side));
            TextView n = new TextView(this);
            n.setText(String.valueOf(i + 1));
            n.setTextColor(Ui.FG);
            n.setTextSize(10);
            n.setGravity(Gravity.CENTER);
            cell.addView(n);
            cell.setOnClickListener(v -> goFrame(idx));
            Bitmap th = thumbs.get(fid);
            if (th != null) iv.setImageBitmap(th);
            else {
                new Thread(() -> {
                    Bitmap b = p.composite(fid, 128, true);
                    thumbs.put(fid, b);
                    runOnUiThread(() -> {
                        if (iv.getParent() != null) iv.setImageBitmap(b);
                    });
                }).start();
            }
        }
    }

    /* ---------- play ---------- */
    private void startPlay() {
        cv.saveCurrent();
        playFrames = new ArrayList<>();
        for (int fid : p.frames) playFrames.add(p.composite(fid, Math.max(p.w, p.h), true));
        playing = true;
        playI = 0;
        playBtn.setText("■");
        tick();
    }

    private void stopPlay() {
        playing = false;
        if (playBtn != null) playBtn.setText("▶");
        if (playFrames != null) {
            for (Bitmap b : playFrames) b.recycle();
            playFrames = null;
        }
        cv.playBmp = null;
        cv.invalidate();
    }

    private void tick() {
        if (!playing || playFrames == null) return;
        cv.playBmp = playFrames.get(playI % playFrames.size());
        cv.invalidate();
        playI++;
        h.postDelayed(this::tick, Math.max(16, 1000 / Math.max(1, p.fps)));
    }

    /* ---------- menu ---------- */
    private void menu() {
        ArrayList<String> items = new ArrayList<>();
        items.add("Salvar na galeria (PNG)");
        items.add("Salvar sem fundo (PNG transparente)");
        if (p.anim) items.add("Exportar todos os quadros (PNG)");
        items.add(p.paper == 0 ? "Fundo branco" : "Fundo transparente");
        items.add("Ajustar à tela");
        items.add("Limpar quadro atual");
        items.add("Renomear projeto");
        new AlertDialog.Builder(this)
                .setTitle("Projeto")
                .setItems(items.toArray(new String[0]), (d, which) -> {
                    String it = items.get(which);
                    if (it.startsWith("Salvar na galeria")) exportOne(true);
                    else if (it.startsWith("Salvar sem fundo")) exportOne(false);
                    else if (it.startsWith("Exportar todos")) exportAll();
                    else if (it.contains("transparente") || it.contains("branco")) {
                        p.paper = p.paper == 0 ? 0xFFFFFFFF : 0;
                        p.save();
                        cv.invalidate();
                        Ui.toast(this, p.paper == 0 ? "Fundo transparente" : "Fundo branco");
                    } else if (it.startsWith("Ajustar")) cv.fitView();
                    else if (it.startsWith("Limpar")) {
                        new AlertDialog.Builder(this).setTitle("Limpar quadro?")
                                .setPositiveButton("Limpar", (a, b) -> {
                                    cv.clearFrame();
                                    onChanged();
                                }).setNegativeButton("Cancelar", null).show();
                    } else if (it.startsWith("Renomear")) renameProject();
                }).show();
    }

    private void renameProject() {
        EditText et = new EditText(this);
        et.setText(p.name);
        new AlertDialog.Builder(this).setTitle("Renomear").setView(et)
                .setPositiveButton("OK", (d, w) -> {
                    String s = et.getText().toString().trim();
                    if (s.length() > 0) {
                        p.name = s.length() > 40 ? s.substring(0, 40) : s;
                        p.save();
                        // atualiza título se possível — reinicia não é necessário
                        Ui.toast(this, "Renomeado");
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    private boolean savePng(Bitmap b, String name) {
        try {
            if (Build.VERSION.SDK_INT < 29 &&
                    checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return false;
            }
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (Build.VERSION.SDK_INT >= 29)
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DarkMonia");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (u == null) return false;
            OutputStream os = getContentResolver().openOutputStream(u);
            if (os == null) return false;
            b.compress(Bitmap.CompressFormat.PNG, 100, os);
            os.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String fileBase() {
        return p.name.replaceAll("[^a-zA-Z0-9À-ÿ_-]+", "_") + "_" + (System.currentTimeMillis() / 1000 % 100000);
    }

    private void exportOne(boolean paper) {
        Bitmap b = cv.renderComposite(paper);
        boolean ok = savePng(b, fileBase() + ".png");
        b.recycle();
        Ui.toast(this, ok ? "Salvo em Imagens/DarkMonia" : "Não consegui salvar a imagem");
    }

    private void exportAll() {
        cv.saveCurrent();
        final ArrayList<Integer> ids = new ArrayList<>(p.frames);
        final String base = fileBase();
        Ui.toast(this, "Salvando " + ids.size() + " quadros…");
        new Thread(() -> {
            int ok = 0;
            for (int i = 0; i < ids.size(); i++) {
                Bitmap b = p.composite(ids.get(i), Math.max(p.w, p.h), true);
                if (savePng(b, base + "_" + String.format("%04d", i + 1) + ".png")) ok++;
                b.recycle();
            }
            final int n = ok;
            runOnUiThread(() -> Ui.toast(this, n + " quadros salvos em Imagens/DarkMonia"));
        }).start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (p == null || cv == null) return;
        if (playing) stopPlay();
        cv.saveCurrent();
        try {
            Bitmap full = cv.renderComposite(true);
            float k = 320f / Math.max(p.w, p.h);
            Bitmap t = Bitmap.createScaledBitmap(full, Math.max(1, Math.round(p.w * k)), Math.max(1, Math.round(p.h * k)), true);
            Project.writePng(t, p.thumbFile());
            if (t != full) t.recycle();
            full.recycle();
        } catch (Throwable e) { /* miniatura opcional */ }
        p.updated = System.currentTimeMillis();
        p.save();
    }
}
