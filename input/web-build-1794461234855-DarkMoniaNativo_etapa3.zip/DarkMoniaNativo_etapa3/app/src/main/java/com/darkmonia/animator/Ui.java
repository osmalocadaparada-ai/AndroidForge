package com.darkmonia.animator;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/** Helpers de interface (tudo montado em código, sem XML de layout). */
final class Ui {
    static final int BG = 0xFF0C0D14;
    static final int PANEL = 0xFF161822;
    static final int CARD = 0xFF1B1D2B;
    static final int BTN = 0xFF2A2D42;
    static final int ACC = 0xFFE5476B;
    static final int ACC2 = 0xFF2F8FD9;
    static final int FG = 0xFFECEEF7;
    static final int MUTE = 0xFF9AA0B8;
    static final int LINE = 0xFF2E3148;

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable bg(int col, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(col);
        g.setCornerRadius(r);
        return g;
    }

    static GradientDrawable bgStroke(int fill, int stroke, float r, int sw) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(r);
        g.setStroke(sw, stroke);
        return g;
    }

    static Button btn(Context c, String t) {
        Button b = new Button(c);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(FG);
        b.setTextSize(12);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        int p = dp(c, 10);
        b.setPadding(p, dp(c, 8), p, dp(c, 8));
        b.setBackground(bg(BTN, dp(c, 10)));
        return b;
    }

    static void sel(Button b, boolean on) {
        b.setBackground(bg(on ? ACC : BTN, dp(b.getContext(), 10)));
    }

    static void selAlt(Button b, boolean on, int accent) {
        b.setBackground(bg(on ? accent : BTN, dp(b.getContext(), 10)));
    }

    static TextView label(Context c, String t) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextColor(MUTE);
        v.setTextSize(12);
        v.setPadding(dp(c, 6), 0, dp(c, 6), 0);
        return v;
    }

    static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
    }

    abstract static class Seek implements SeekBar.OnSeekBarChangeListener {
        abstract void change(int v);

        @Override
        public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
            change(v);
        }

        @Override
        public void onStartTrackingTouch(SeekBar s) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar s) {
        }
    }
}
