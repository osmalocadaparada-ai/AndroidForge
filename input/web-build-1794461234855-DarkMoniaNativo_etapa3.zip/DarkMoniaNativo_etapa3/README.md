# Dark Monia — nativo etapa 3

App de desenho e animação **100% em Java** (sem WebView, sem bibliotecas externas).

`applicationId`: `com.darkmonia.animator` — instala **no lugar** da versão HTML.

## Novidades da etapa 3

### Ferramentas novas
- **Seleção retangular** com barra de ações: apagar, preencher, recortar, copiar, colar, limpar seleção
- **Formas:** reta, retângulo, elipse (usam tamanho/opacidade/cor atuais)
- Até **12 camadas** (antes 8)
- Camada **bloqueada** (cadeado)
- **Duplicar camada** e renomear (toque longo no nome)
- **Copiar / colar quadro** na timeline
- **Fundo transparente** ou branco (menu ⋮)
- Desfazer/refazer com **24 passos**
- Toque com **3 dedos** = refazer; 2 dedos = desfazer
- Home com filtros **Tudo / Desenhos / Animações**
- Mais tamanhos (A4, A5, 4K, pixel art, wallpaper…)

### Já existia (etapa 1–2)
- Pincéis: Lápis, G-Pen (pressão/velocidade), Marcador, Aerógrafo, Borracha
- Balde (com tolerância), conta-gotas, zoom/pan com 2 dedos
- Camadas: criar, excluir, subir/descer, ocultar, opacidade
- Timeline, onion skin, fps, play
- Export PNG com/sem fundo e sequência de quadros
- Salvamento automático

## Ainda não portado da v5.0 HTML
Seleção livre/laço/varinha, transformar com alças, texto, filtros, liquidificar, blend modes, máscara de recorte, simetria, QuickShape, girar tela, áudio, export vídeo/GIF, time-lapse, assistentes de perspectiva.

## Compilar
1. Abra esta pasta no **Android Studio** ou **AndroidIDE**
2. **Build → Build APK**
3. Ou use a GitHub Action em `.github/workflows`

## Estrutura
```
app/src/main/java/com/darkmonia/animator/
  HomeActivity.java      # home + galeria com filtros
  EditorActivity.java    # editor, seleção, formas, timeline
  CanvasView.java        # desenho, gestos, seleção, formas
  Project.java           # persistência
  Ui.java                # helpers
```
