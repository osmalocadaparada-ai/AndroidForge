package com.darkmonia.animator;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Editor nativo: pincéis, camadas, cores, seleção, filtros, guias, animação e exportação. */
public class EditorActivity extends Activity implements CanvasView.Listener {
    private static final int REQ_IMPORT = 7, REQ_REF = 8, REQ_PERM = 9, REQ_BG = 10, REQ_VID = 11;

    static final Object[][] TOOLS = {
            {CanvasView.T_BRUSH, "brush", "Pincel"}, {CanvasView.T_ERASER, "eraser", "Borracha"},
            {CanvasView.T_FILL, "bucket", "Balde"}, {CanvasView.T_PICK, "pipette", "Conta-gotas"},
            {CanvasView.T_SELECT, "lasso", "Seleção"}, {CanvasView.T_TRANSFORM, "transform", "Transformar"},
            {CanvasView.T_SHAPE, "rect", "Formas"}, {CanvasView.T_GRADIENT, "gradient", "Degradê"},
            {CanvasView.T_TEXT, "text", "Texto"}, {CanvasView.T_LIQUIFY, "liquify", "Liquidificar"},
            {CanvasView.T_CLONE, "clone", "Carimbo"}, {CanvasView.T_RECOLOR, "recolor", "Recolorir"},
            {CanvasView.T_LASSOFILL, "lassofill", "Laço de tinta"}, {CanvasView.T_LASSOERASE, "lassoerase", "Laço borracha"},
            {CanvasView.T_GUIDES, "assist", "Guias"}, {CanvasView.T_HAND, "hand", "Mover tela"},
    };
    static final int[] PALETTE = {0xFF16161D, 0xFFFFFFFF, 0xFF6B6F80, 0xFFC9CCD6, 0xFFE5476B, 0xFFFF6B8F, 0xFFFF8A3D, 0xFFF2C94C,
            0xFFFFE27A, 0xFF22C3A6, 0xFF2BB673, 0xFF1B7F4B, 0xFF4D8DFF, 0xFF1B2A8A, 0xFF8D7AFF, 0xFFB44DFF,
            0xFF7A4A2A, 0xFFC68B59, 0xFFF6D2B8, 0xFFFFC7A8, 0xFF9E2B25, 0xFF2B2A28, 0xFF6FD3FF, 0xFFFFB3D9};
    static final String[] BLEND_NAMES = {"Normal", "Multiplicar", "Tela", "Sobrepor", "Luz suave", "Luz forte", "Escurecer", "Clarear",
            "Subexpor cor", "Superexpor cor", "Adição", "Diferença", "Exclusão", "Matiz", "Saturação", "Cor", "Luminosidade"};

    private Project p;
    private CanvasView cv;
    private FrameLayout root;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private final ArrayList<Integer> recent = new ArrayList<>();
    private final HashMap<Integer, Bitmap> frameThumbs = new HashMap<>();
    private Pop layersSheet;
    private boolean playing, busy;
    private Runnable pendingPerm;
    private FrameLayout refWin;
    private Bitmap refBmp;
    private View playCover;
    private final Runnable autosave = () -> { if (cv != null && !playing) cv.saveCurrent(); };
    private final Runnable thumbRefresh = this::refreshCurrentThumb;

    private int dp(float v) { return Ui.dp(this, v); }

    /* ================================================================ ciclo de vida */

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        Prefs.init(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        String dir = getIntent().getStringExtra("dir");
        p = dir == null ? null : Project.load(new File(dir));
        if (p == null) { Ui.toast(this, "Não consegui abrir o projeto"); finish(); return; }
        build();
        loadToolPrefs();
        cv.setProject(p);
        setTool(CanvasView.T_BRUSH);
        syncAll();
        refreshTimeline();
        String action = getIntent().getStringExtra("action");
        if ("play".equals(action)) ui.postDelayed(this::play, 400);
        else if ("export".equals(action)) ui.postDelayed(this::exportSheet, 300);
        else if (!Prefs.on(this, "tipSeen", false)) ui.postDelayed(this::tips, 500);
    }

    private void loadToolPrefs() {
        cv.brushId = Prefs.get(this).getString("brush", "gpen");
        cv.brushSize = Prefs.get(this).getFloat("bsize", Brushes.get(cv.brushId).defSize);
        cv.eraserSize = Prefs.get(this).getFloat("esize", 30);
        cv.opacity = Prefs.num(this, "bop", 100);
        cv.color = Prefs.num(this, "color", 0xFF16161D);
        cv.color2 = Prefs.num(this, "color2", 0xFFFFFFFF);
        cv.stabilizer = Prefs.num(this, "stab", 15);
        cv.eraserType = Prefs.get(this).getString("etype", "e_round");
        cv.taperIn = Prefs.num(this, "tin", 0);
        cv.taperOut = Prefs.num(this, "tout", 0);
        cv.onionPrev = Prefs.num(this, "onPrev", 1);
        cv.onionNext = Prefs.num(this, "onNext", 1);
        cv.onionAlpha = Prefs.num(this, "onAlpha", 35);
        cv.onion = Prefs.on(this, "onion", true);
        cv.onionColor = Prefs.on(this, "onColor", true);
        recent.addAll(Prefs.colors(this, "recent", new int[]{}));
        colorDot.set(cv.color);
    }

    private void saveToolPrefs() {
        Prefs.get(this).edit().putString("brush", cv.brushId).putFloat("bsize", cv.brushSize).putFloat("esize", cv.eraserSize)
                .putString("etype", cv.eraserType).apply();
        Prefs.put(this, "bop", cv.opacity);
        Prefs.put(this, "color", cv.color);
        Prefs.put(this, "color2", cv.color2);
        Prefs.put(this, "stab", cv.stabilizer);
        Prefs.put(this, "tin", cv.taperIn);
        Prefs.put(this, "tout", cv.taperOut);
        Prefs.colors(this, "recent", recent);
    }

    @Override protected void onPause() {
        super.onPause();
        if (cv == null) return;
        stopPlay();
        cv.commitFloating();
        cv.saveCurrent();
        saveToolPrefs();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (cv != null) {
            cv.flush();
            cv.release();
            cv.io.shutdown();
        }
        work.shutdown();
    }

    @Override public void onBackPressed() {
        if (playing) { stopPlay(); return; }
        if (pop != null) { if (!pop.modal) pop.dismiss(); return; }
        if (cv.shapePending()) { cv.cancelShapePts(); return; }
        if (cv.flt != null) { cv.commitFloating(); setTool(CanvasView.T_BRUSH); return; }
        cv.saveCurrent();
        cv.flush();
        finish();
    }

    /* ================================================================ interface (layout da 5.0) */

    static final String[][] G_SEL = {{"sel:2", "Laço livre", "lasso"}, {"sel:0", "Retângulo", "selrect"}, {"sel:1", "Elipse", "selell"},
            {"sel:3", "Polígono", "selpoly"}, {"sel:4", "Varinha mágica", "wand"}, {"sel:5", "Mesma cor", "selcolor"}};
    static final String[][] G_SHAPE = {{"shape:0", "Reta", "line"}, {"shape:1", "Retângulo", "rect"}, {"shape:2", "Elipse", "ellipse"},
            {"shape:3", "Estrela", "star"}, {"shape:4", "Polígono regular", "polygon"}, {"shape:6", "Polilinha", "polyline"},
            {"shape:7", "Polígono", "polygon"}, {"shape:8", "Curva", "curve"}, {"shape:5", "Seta", "line"}};
    static final String[][] G_FILL = {{"fill", "Balde", "bucket"}, {"gradient", "Degradê", "gradient"}, {"lassofill", "Laço de tinta", "lassofill"}};
    static final String[][] G_RET = {{"liquify", "Liquidificar", "liquify"}, {"clone", "Carimbo", "clone"}, {"smudge", "Dedo (borrar)", "smudge"},
            {"blur", "Desfocar", "blur"}, {"recolor", "Recolorir", "recolor"}, {"lassoerase", "Laço borracha", "lassoerase"}};
    static final String[][] G_UTIL = {{"pick", "Pipeta", "pipette"}, {"text", "Texto", "text"}, {"measure", "Medir", "measure"},
            {"guides", "Assistentes", "assist"}, {"hand", "Mover tela", "hand"}, {"light", "Luz e sombra", "glow"},
            {"sym", "Simetria", "act_sym"}, {"ref", "Referência", "act_ref"}, {"comic", "Quadrinhos", "act_comic"}};
    static final String[] GROUP_IDS = {"sel", "shape", "fill", "ret", "util"};
    static final String[] GROUP_NAMES = {"Seleção", "Formas", "Preencher", "Retocar", "Mais"};
    private final HashMap<String, String> grpLast = new HashMap<>();

    private static String[][] group(String g) {
        switch (g) {
            case "sel": return G_SEL;
            case "shape": return G_SHAPE;
            case "fill": return G_FILL;
            case "ret": return G_RET;
            default: return G_UTIL;
        }
    }

    /** Chave da ferramenta atual (para saber qual grupo acender). */
    private String curKey() {
        switch (cv.tool) {
            case CanvasView.T_SELECT: return "sel:" + cv.selMode;
            case CanvasView.T_SHAPE: return "shape:" + cv.shapeType;
            case CanvasView.T_FILL: return "fill";
            case CanvasView.T_GRADIENT: return "gradient";
            case CanvasView.T_LASSOFILL: return "lassofill";
            case CanvasView.T_LIQUIFY: return "liquify";
            case CanvasView.T_CLONE: return "clone";
            case CanvasView.T_SMUDGE: return "smudge";
            case CanvasView.T_BLUR: return "blur";
            case CanvasView.T_RECOLOR: return "recolor";
            case CanvasView.T_LASSOERASE: return "lassoerase";
            case CanvasView.T_PICK: return "pick";
            case CanvasView.T_TEXT: return "text";
            case CanvasView.T_MEASURE: return "measure";
            case CanvasView.T_GUIDES: return "guides";
            case CanvasView.T_HAND: return "hand";
            case CanvasView.T_LIGHT: return "light";
            case CanvasView.T_ERASER: return "eraser";
            case CanvasView.T_TRANSFORM: return "transform";
            default: return "brush";
        }
    }

    private void applyKey(String k) {
        if (k.startsWith("sel:")) { cv.selMode = Integer.parseInt(k.substring(4)); setTool(CanvasView.T_SELECT); return; }
        if (k.startsWith("shape:")) { cv.cancelShapePts(); cv.shapeType = Integer.parseInt(k.substring(6)); setTool(CanvasView.T_SHAPE); return; }
        switch (k) {
            case "fill": setTool(CanvasView.T_FILL); break;
            case "gradient": setTool(CanvasView.T_GRADIENT); break;
            case "lassofill": setTool(CanvasView.T_LASSOFILL); break;
            case "liquify": setTool(CanvasView.T_LIQUIFY); break;
            case "clone": setTool(CanvasView.T_CLONE); break;
            case "smudge": setTool(CanvasView.T_SMUDGE); break;
            case "blur": setTool(CanvasView.T_BLUR); break;
            case "recolor": setTool(CanvasView.T_RECOLOR); break;
            case "lassoerase": setTool(CanvasView.T_LASSOERASE); break;
            case "pick": setTool(CanvasView.T_PICK); break;
            case "text": setTool(CanvasView.T_TEXT); break;
            case "measure": setTool(CanvasView.T_MEASURE); break;
            case "guides": setTool(CanvasView.T_GUIDES); break;
            case "hand": setTool(CanvasView.T_HAND); break;
            case "light": setTool(CanvasView.T_LIGHT); break;
            case "sym": guidesSheet(); break;
            case "ref": pickImage(REQ_REF); break;
            case "comic": comicSheet(); break;
            default: break;
        }
    }

    private LinearLayout lyBar, dock1, dock2, optRow, frameRow;
    private FrameLayout stage, popHost;
    private View timeline, optWrap, sizeRow, opRow;
    private ImageView undoB, redoB, playB, loopB;
    private TextView counterTv, zoomTv, rotTv, sizeOut, opOut, fpsTv;
    private SeekBar sizeBar, opBar;
    private ColorDot colorDot;
    private final HashMap<String, View> dockBtns = new HashMap<>();
    private Pop pop;
    private boolean syncing;

    private void build() {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        boolean land = dm.widthPixels > dm.heightPixels * 1.15f;
        root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        if (cv == null) {
            cv = new CanvasView(this);
            cv.listener = this;
            cv.drawOnly = !p.anim;
        } else if (cv.getParent() != null) ((android.view.ViewGroup) cv.getParent()).removeView(cv);
        dockBtns.clear();

        /* barra de cima */
        LinearLayout top = Ui.row(this);
        top.setPadding(dp(4), dp(4), dp(8), dp(4));
        top.setBackgroundColor(Ui.PANEL);
        top.addView(iconBtn("prev", v -> onBackPressed()));
        LinearLayout brand = Ui.col(this);
        brand.setPadding(dp(2), 0, dp(6), 0);
        TextView bn = Ui.text(this, p.name, 15, Ui.FG, true);
        bn.setSingleLine(true);
        bn.setEllipsize(TextUtils.TruncateAt.END);
        TextView bv = Ui.mono(this, "Dark Monia Animator 2D · v5.0", 10, Ui.MUTE);
        bv.setSingleLine(true);
        bv.setPadding(0, dp(2), 0, 0);
        brand.addView(bn);
        brand.addView(bv);
        top.addView(brand, Ui.lpw(1));
        undoB = iconBtn("undo", v -> { if (!cv.undo()) Ui.toast(this, "Nada para desfazer"); });
        redoB = iconBtn("redo", v -> { if (!cv.redo()) Ui.toast(this, "Nada para refazer"); });
        top.addView(undoB);
        top.addView(redoB);
        if (p.anim) {
            playB = new ImageView(this);
            playB.setImageDrawable(Ui.icon(this, playing ? "pause" : "play", 0xFFFFFFFF));
            playB.setPadding(dp(13), dp(8), dp(13), dp(8));
            playB.setBackground(Ui.bg(Ui.ACC, dp(18)));
            playB.setOnClickListener(v -> { if (playing) stopPlay(); else play(); });
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(dp(48), dp(36));
            pl.setMargins(dp(4), 0, dp(4), 0);
            top.addView(Ui.pressable(playB), pl);
        }
        LinearLayout menu = Ui.row(this);
        menu.setPadding(dp(10), 0, dp(12), 0);
        menu.setBackground(Ui.bg(Ui.PANEL2, dp(18)));
        menu.addView(Ui.iconView(this, "menu", Ui.FG, 18));
        TextView mt = Ui.text(this, "Projeto", 13, Ui.FG, true);
        mt.setPadding(dp(6), 0, 0, 0);
        menu.addView(mt);
        menu.setOnClickListener(v -> menuSheet());
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(Ui.WRAP, dp(36));
        ml.leftMargin = dp(4);
        top.addView(Ui.pressable(menu), ml);

        /* palco */
        stage = new FrameLayout(this);
        stage.addView(cv, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        counterTv = badge("1 / 1");
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP | Gravity.START);
        cl.setMargins(dp(10), dp(10), 0, 0);
        stage.addView(counterTv, cl);
        counterTv.setVisibility(p.anim ? View.VISIBLE : View.GONE);
        LinearLayout zoom = Ui.row(this);
        rotTv = zoomBtn("0°", v -> cv.resetRotation());
        rotTv.setTextColor(Ui.ACC);
        rotTv.setVisibility(View.GONE);
        zoom.addView(rotTv);
        zoom.addView(zoomBtn("−", v -> cv.zoomBy(1 / 1.25f)));
        zoomTv = zoomBtn("100%", v -> cv.fitView());
        zoom.addView(zoomTv);
        zoom.addView(zoomBtn("+", v -> cv.zoomBy(1.25f)));
        FrameLayout.LayoutParams zl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP | Gravity.END);
        zl.setMargins(0, dp(10), dp(10), 0);
        stage.addView(zoom, zl);
        HorizontalScrollView os = new HorizontalScrollView(this);
        os.setHorizontalScrollBarEnabled(false);
        optRow = Ui.row(this);
        optRow.setPadding(dp(8), dp(6), dp(8), dp(6));
        os.addView(optRow);
        os.setBackground(Ui.bgStroke(0xF0171925, Ui.LINE, dp(14), dp(1)));
        optWrap = os;
        FrameLayout.LayoutParams oll = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        oll.setMargins(dp(8), 0, dp(8), dp(8));
        stage.addView(os, oll);
        popHost = new FrameLayout(this);
        FrameLayout.LayoutParams phl = new FrameLayout.LayoutParams(land ? dp(420) : Ui.MATCH, Ui.WRAP, Gravity.BOTTOM | Gravity.END);
        phl.setMargins(dp(8), dp(8), dp(8), dp(8));
        stage.addView(popHost, phl);
        if (refWin != null) { if (refWin.getParent() != null) ((android.view.ViewGroup) refWin.getParent()).removeView(refWin); stage.addView(refWin, refWin.getLayoutParams()); }

        /* ferramentas */
        LinearLayout tools = Ui.col(this);
        tools.setBackgroundColor(Ui.PANEL);
        tools.setPadding(dp(8), dp(6), dp(8), dp(4));
        HorizontalScrollView lys = new HorizontalScrollView(this);
        lys.setHorizontalScrollBarEnabled(false);
        lyBar = Ui.row(this);
        lys.addView(lyBar);
        tools.addView(lys, gapB(5));
        dock1 = Ui.row(this);
        dock1.addView(dockBtn("brush", "brush", "Pincel", false));
        dock1.addView(dockBtn("eraser", "eraser", "Borracha", false));
        dock1.addView(dockBtn("sel", "selrect", "Seleção", true));
        dock1.addView(dockBtn("shape", "rect", "Formas", true));
        dock1.addView(dockBtn("fill", "bucket", "Preencher", true));
        dock1.addView(dockBtn("transform", "transform", "Transf.", false));
        dock1.addView(dockBtn("ret", "liquify", "Retocar", true));
        dock1.addView(dockBtn("util", "pipette", "Mais", true));
        tools.addView(dock1, gapB(3));
        dock2 = Ui.row(this);
        View colorB = dockBtn("color", null, "Cor", false);
        colorDot = new ColorDot(this);
        ((LinearLayout) ((FrameLayout) colorB).getChildAt(0)).addView(colorDot, 0, new LinearLayout.LayoutParams(dp(20), dp(20)));
        dock2.addView(colorB);
        dock2.addView(dockBtn("layers", "layers", "Camadas", false));
        if (p.anim) dock2.addView(dockBtn("onion", "onion", "Fantasma", false));
        dock2.addView(dockBtn("adjust", "adjust", "Ajustes", false));
        dock2.addView(dockBtn("stroke", "stroke", "Traço", false));
        dock2.addView(dockBtn("media", "image", "Mídia", false));
        if (p.anim) dock2.addView(dockBtn("anim", "anim", "Animação", false));
        tools.addView(dock2, gapB(4));
        LinearLayout ow = Ui.row(this);
        sizeRow = sliderRow("Tamanho", 1000, 0, true);
        opRow = sliderRow("Opac.", 99, 99, false);
        ow.addView(sizeRow, Ui.lpw(1));
        LinearLayout.LayoutParams orl = Ui.lpw(1);
        orl.leftMargin = dp(12);
        ow.addView(opRow, orl);
        tools.addView(ow);

        /* linha do tempo */
        timeline = p.anim ? buildTimeline() : null;

        LinearLayout main;
        if (land) {
            main = Ui.row(this);
            LinearLayout left = Ui.col(this);
            left.addView(top, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
            left.addView(line());
            left.addView(stage, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1));
            if (timeline != null) { left.addView(line()); left.addView(timeline, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)); }
            main.addView(left, new LinearLayout.LayoutParams(0, Ui.MATCH, 1));
            View vl = new View(this);
            vl.setBackgroundColor(Ui.LINE);
            main.addView(vl, new LinearLayout.LayoutParams(dp(1), Ui.MATCH));
            android.widget.ScrollView ts = new android.widget.ScrollView(this);
            ts.setBackgroundColor(Ui.PANEL);
            ts.addView(tools);
            main.addView(ts, new LinearLayout.LayoutParams(dp(360), Ui.MATCH));
        } else {
            main = Ui.col(this);
            main.addView(top, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
            main.addView(line());
            main.addView(stage, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1));
            main.addView(line());
            main.addView(tools, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
            if (timeline != null) { main.addView(line()); main.addView(timeline, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)); }
        }
        root.addView(main, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        Ui.padInsets(root, true);
        setContentView(root);
    }

    @Override public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        if (cv == null) return;
        stopPlay();
        if (pop != null) { cv.inputLocked = false; pop.dismiss(); }
        build();
        syncAll();
        refreshTimeline();
        ui.postDelayed(cv::fitView, 150);
    }

    private View line() {
        View v = new View(this);
        v.setBackgroundColor(Ui.LINE);
        v.setLayoutParams(new LinearLayout.LayoutParams(Ui.MATCH, dp(1)));
        return v;
    }

    private TextView badge(String t) {
        TextView v = Ui.mono(this, t, 12, Ui.FG);
        v.setPadding(dp(9), dp(4), dp(9), dp(4));
        v.setBackground(Ui.bgStroke(0xCC171925, Ui.LINE, dp(999), dp(1)));
        return v;
    }

    private TextView zoomBtn(String t, View.OnClickListener l) {
        TextView v = Ui.text(this, t, 13, Ui.FG, true);
        v.setGravity(Gravity.CENTER);
        v.setMinWidth(dp(36));
        v.setPadding(dp(8), dp(6), dp(8), dp(6));
        v.setBackground(Ui.bgStroke(0xCC171925, Ui.LINE, dp(10), dp(1)));
        v.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        lp.leftMargin = dp(4);
        v.setLayoutParams(lp);
        return Ui.pressable(v);
    }

    /** Botão da doca: ícone em cima, nome embaixo, barrinha de destaque quando ligado. */
    private View dockBtn(final String key, String icon, String label, boolean group) {
        FrameLayout f = new FrameLayout(this);
        LinearLayout c = Ui.col(this);
        c.setGravity(Gravity.CENTER);
        if (icon != null) {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(Ui.icon(this, icon, Ui.MUTE));
            c.addView(iv, new LinearLayout.LayoutParams(dp(19), dp(19)));
        }
        TextView t = Ui.text(this, label, 9, Ui.MUTE, true);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(1), dp(3), dp(1), 0);
        c.addView(t, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        f.addView(c, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        View bar = new View(this);
        bar.setBackgroundColor(Ui.ACC);
        bar.setVisibility(View.GONE);
        f.addView(bar, new FrameLayout.LayoutParams(Ui.MATCH, dp(2), Gravity.BOTTOM));
        TextView b = Ui.mono(this, "", 9.5f, 0xFFFFFFFF);
        b.setPadding(dp(5), 0, dp(5), dp(1));
        b.setBackground(Ui.bg(Ui.ACC, dp(8)));
        b.setVisibility(View.GONE);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP | Gravity.END);
        bl.setMargins(0, dp(3), dp(4), 0);
        f.addView(b, bl);
        if (group) {
            TextView tri = Ui.text(this, "◢", 7, Ui.MUTE, false);
            FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.END);
            tl.setMargins(0, 0, dp(4), dp(4));
            f.addView(tri, tl);
        }
        f.setTag(new View[]{c, bar, b});
        f.setOnClickListener(v -> dockTap(key));
        f.setOnLongClickListener(v -> { dockHold(key); return true; });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(group || icon != null ? 44 : 44), 1);
        lp.setMargins(dp(1), 0, dp(1), 0);
        f.setLayoutParams(lp);
        dockBtns.put(key, f);
        return Ui.pressable(f);
    }

    private void dockState(String key, boolean on, String icon, String label, String badgeTxt) {
        View f = dockBtns.get(key);
        if (f == null) return;
        View[] parts = (View[]) f.getTag();
        LinearLayout c = (LinearLayout) parts[0];
        f.setBackground(on ? Ui.bg(Ui.PANEL2, dp(10)) : null);
        parts[1].setVisibility(on ? View.VISIBLE : View.GONE);
        for (int i = 0; i < c.getChildCount(); i++) {
            View ch = c.getChildAt(i);
            if (ch instanceof ImageView && icon != null) ((ImageView) ch).setImageDrawable(Ui.icon(this, icon, on ? Ui.ACC : Ui.MUTE));
            if (ch instanceof TextView) {
                ((TextView) ch).setTextColor(on ? Ui.FG : Ui.MUTE);
                if (label != null) ((TextView) ch).setText(label);
            }
        }
        TextView b = (TextView) parts[2];
        b.setVisibility(badgeTxt == null ? View.GONE : View.VISIBLE);
        if (badgeTxt != null) b.setText(badgeTxt);
    }

    private void dockTap(String key) {
        switch (key) {
            case "brush":
                if (cv.tool == CanvasView.T_BRUSH) togglePop("brush", this::brushSheet); else setTool(CanvasView.T_BRUSH);
                return;
            case "eraser":
                if (cv.tool == CanvasView.T_ERASER) togglePop("eraser", this::eraserPop); else setTool(CanvasView.T_ERASER);
                return;
            case "transform":
                if (cv.tool == CanvasView.T_TRANSFORM && cv.flt != null) { cv.commitFloating(); setTool(CanvasView.T_BRUSH); }
                else setTool(CanvasView.T_TRANSFORM);
                return;
            case "color": togglePop("color", this::colorSheet); return;
            case "layers": togglePop("layers", this::layersSheet); return;
            case "onion":
                cv.onion = !cv.onion;
                Prefs.set(this, "onion", cv.onion);
                cv.invalidate();
                syncDock();
                return;
            case "adjust": togglePop("adjust", this::adjustPop); return;
            case "stroke": togglePop("stroke", this::strokePop); return;
            case "media": togglePop("media", this::mediaPop); return;
            case "anim": togglePop("anim", this::animSheet); return;
            default:
                break;
        }
        String[][] g = group(key);
        boolean in = false;
        String cur = curKey();
        for (String[] it : g) if (it[0].equals(cur)) in = true;
        if (in) togglePop("grp" + key, () -> groupPop(key));
        else {
            String last = grpLast.get(key);
            applyKey(last != null ? last : g[0][0]);
        }
    }

    private void dockHold(String key) {
        switch (key) {
            case "brush": brushSheet(); return;
            case "onion": animSheet(); return;
            case "sel": case "shape": case "fill": case "ret": case "util": groupPop(key); return;
            default: dockTap(key);
        }
    }

    private void togglePop(String key, Runnable open) {
        if (pop != null && key.equals(pop.key)) { pop.dismiss(); return; }
        open.run();
    }

    private void groupPop(final String key) {
        String[][] g = group(key);
        String name = GROUP_NAMES[java.util.Arrays.asList(GROUP_IDS).indexOf(key)];
        final Pop s = new Pop(name);
        s.key = "grp" + key;
        LinearLayout grid = Ui.col(this);
        LinearLayout row = null;
        String cur = curKey();
        for (int i = 0; i < g.length; i++) {
            if (i % 4 == 0) { row = Ui.row(this); grid.addView(row, gapB(6)); }
            final String[] it = g[i];
            boolean on = it[0].equals(cur);
            LinearLayout b = Ui.col(this);
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(4), dp(10), dp(4), dp(8));
            GradientDrawable bg = Ui.bg(on ? HomeActivity.blend(Ui.ACC, Ui.PANEL2, .2f) : Ui.PANEL2, dp(12));
            bg.setStroke(dp(on ? 2 : 1), on ? Ui.ACC : Ui.LINE);
            b.setBackground(bg);
            b.addView(Ui.iconView(this, it[2], on ? Ui.ACC : Ui.FG, 22));
            TextView t = Ui.text(this, it[1], 10.5f, Ui.FG, true);
            t.setGravity(Gravity.CENTER);
            t.setMaxLines(2);
            t.setPadding(0, dp(5), 0, 0);
            b.addView(t, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
            b.setOnClickListener(v -> { s.dismiss(); applyKey(it[0]); });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, Ui.WRAP, 1);
            if (i % 4 > 0) l.leftMargin = dp(6);
            row.addView(Ui.pressable(b), l);
        }
        if (g.length % 4 != 0) for (int k = g.length % 4; k < 4; k++) {
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, 1, 1);
            l.leftMargin = dp(6);
            row.addView(new View(this), l);
        }
        s.add(grid);
        s.show();
    }

    /** Linha "Tamanho"/"Opac." com controle deslizante e número, como na 5.0. */
    private View sliderRow(String label, int max, int value, final boolean size) {
        LinearLayout r = Ui.row(this);
        TextView l = Ui.text(this, label, 11, Ui.MUTE, true);
        r.addView(l);
        final TextView out = Ui.mono(this, "", 11, Ui.FG);
        out.setGravity(Gravity.END);
        SeekBar sb = Ui.seek(this, max, value, new Ui.Seek() {
            void change(int v) {
                if (syncing) return;
                if (size) {
                    float t = v / 1000f, mx = maxSize();
                    float sz = Math.max(1, 1 + (mx - 1) * t * t);
                    setSize(sz);
                    out.setText(String.valueOf(Math.round(sz)));
                } else {
                    int o = v + 1;
                    if (cv.tool == CanvasView.T_ERASER) cv.eraserOpacity = o; else cv.opacity = o;
                    out.setText(o + "%");
                }
            }
        });
        r.addView(sb, new LinearLayout.LayoutParams(0, dp(30), 1));
        r.addView(out, new LinearLayout.LayoutParams(dp(36), Ui.WRAP));
        if (size) { sizeBar = sb; sizeOut = out; } else { opBar = sb; opOut = out; }
        return r;
    }

    private float maxSize() {
        return cv.tool == CanvasView.T_ERASER ? 500 : cv.tool == CanvasView.T_LIQUIFY ? 600 : 400;
    }

    private void setSize(float sz) {
        if (cv.tool == CanvasView.T_ERASER) cv.eraserSize = sz;
        else if (cv.tool == CanvasView.T_LIQUIFY) cv.liqSize = sz;
        else cv.brushSize = sz;
    }

    private float curSize() {
        return cv.tool == CanvasView.T_ERASER ? cv.eraserSize : cv.tool == CanvasView.T_LIQUIFY ? cv.liqSize : cv.brushSize;
    }

    private void syncSliders() {
        syncing = true;
        float max = maxSize();
        sizeBar.setProgress(Math.round((float) Math.sqrt(Math.max(0, (curSize() - 1) / (max - 1))) * 1000));
        sizeOut.setText(String.valueOf(Math.round(curSize())));
        int o = cv.tool == CanvasView.T_ERASER ? cv.eraserOpacity : cv.opacity;
        opBar.setProgress(o - 1);
        opOut.setText(o + "%");
        syncing = false;
        int t = cv.tool;
        boolean noSize = t == CanvasView.T_HAND || t == CanvasView.T_PICK || t == CanvasView.T_FILL || t == CanvasView.T_SELECT
                || t == CanvasView.T_TRANSFORM || t == CanvasView.T_MEASURE || t == CanvasView.T_GUIDES || t == CanvasView.T_GRADIENT
                || t == CanvasView.T_TEXT || t == CanvasView.T_LASSOFILL || t == CanvasView.T_LASSOERASE || t == CanvasView.T_LIGHT;
        boolean noOp = t == CanvasView.T_HAND || t == CanvasView.T_PICK || t == CanvasView.T_SELECT || t == CanvasView.T_TRANSFORM
                || t == CanvasView.T_MEASURE || t == CanvasView.T_GUIDES || t == CanvasView.T_LIQUIFY || t == CanvasView.T_LASSOERASE
                || t == CanvasView.T_RECOLOR || t == CanvasView.T_LIGHT || t == CanvasView.T_SMUDGE || t == CanvasView.T_BLUR || t == CanvasView.T_TEXT;
        sizeRow.setVisibility(noSize ? View.INVISIBLE : View.VISIBLE);
        opRow.setVisibility(noOp ? View.INVISIBLE : View.VISIBLE);
    }

    private ImageView iconBtn(String icon, View.OnClickListener l) {
        ImageView b = new ImageView(this);
        b.setImageDrawable(Ui.icon(this, icon, Ui.FG));
        b.setPadding(dp(8), dp(8), dp(8), dp(8));
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        b.setBackground(Ui.bg(0, dp(12)));
        b.setOnClickListener(l);
        return Ui.pressable(b);
    }

    /** Atualiza doca, barra de camadas, contador e controles. */
    private void syncAll() {
        if (colorDot != null) colorDot.set(cv.color);
        syncDock();
        syncSliders();
        refreshLayerBar();
        buildOptions();
        onHistory();
        onViewChanged();
        updateCounter();
    }

    private void syncDock() {
        if (dock1 == null) return;
        String cur = curKey();
        Brushes.B b = Brushes.get(cv.brushId);
        String bi = Ui.icon(this, b.id, 0) != null ? b.id : "brush";
        dockState("brush", cv.tool == CanvasView.T_BRUSH, bi, b.name, null);
        dockState("eraser", cv.tool == CanvasView.T_ERASER, "eraser", null, null);
        dockState("transform", cv.tool == CanvasView.T_TRANSFORM, "transform", null, null);
        for (int gi = 0; gi < GROUP_IDS.length; gi++) {
            String g = GROUP_IDS[gi];
            String[] show = null;
            boolean on = false;
            for (String[] it : group(g)) if (it[0].equals(cur)) { show = it; on = true; }
            if (on) grpLast.put(g, cur);
            if (show == null) {
                String last = grpLast.get(g);
                for (String[] it : group(g)) if (it[0].equals(last)) show = it;
                if (show == null) show = group(g)[0];
            }
            dockState(g, on, show[2], GROUP_NAMES[gi], null);
        }
        dockState("color", false, null, null, null);
        dockState("layers", popOpen("layers"), "layers", null, String.valueOf(p.layers.size()));
        dockState("onion", cv.onion, "onion", null, null);
        dockState("adjust", popOpen("adjust"), "adjust", null, cv.layer().alpha ? "α" : null);
        int lvl = Math.round(cv.stabilizer * 15 / 100f);
        dockState("stroke", popOpen("stroke"), "stroke", null, lvl > 0 ? String.valueOf(lvl) : null);
        dockState("media", popOpen("media"), "image", null, null);
        dockState("anim", popOpen("anim"), "anim", null, null);
    }

    private boolean popOpen(String key) { return pop != null && key.equals(pop.key); }

    /** Fileira de camadas rápida (acima da doca). */
    void refreshLayerBar() {
        if (lyBar == null) return;
        lyBar.removeAllViews();
        for (int i = p.layers.size() - 1; i >= 0; i--) {
            final int idx = i;
            Project.Layer l = p.layers.get(i);
            boolean on = i == cv.active;
            TextView b = Ui.text(this, (l.clip ? "↳ " : "") + l.name, 12, on ? 0xFFFFFFFF : Ui.MUTE, true);
            b.setSingleLine(true);
            b.setPadding(dp(11), dp(5), dp(11), dp(5));
            b.setBackground(Ui.bg(on ? Ui.ACC : Ui.PANEL2, dp(999)));
            if (!l.visible) b.setAlpha(.5f);
            b.setOnClickListener(v -> { cv.active = idx; refreshLayerBar(); buildOptions(); syncDock(); if (popOpen("layers")) fillLayers(); });
            b.setOnLongClickListener(v -> { cv.active = idx; refreshLayerBar(); togglePop("layers", this::layersSheet); return true; });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
            lp.rightMargin = dp(5);
            lyBar.addView(b, lp);
        }
        TextView add = Ui.text(this, "+", 14, Ui.FG, true);
        add.setPadding(dp(12), dp(3), dp(12), dp(3));
        add.setBackground(Ui.bgStroke(0, Ui.LINE, dp(999), dp(1)));
        add.setOnClickListener(v -> { if (cv.addLayer("Camada " + p.nextLayer) != null) { refreshLayerBar(); syncDock(); } });
        lyBar.addView(add);
    }

    void updateCounter() {
        if (counterTv != null) counterTv.setText((cv.frameIdx + 1) + " / " + p.frames.size());
    }

    void setTool(int t) {
        if (cv.tool == CanvasView.T_TRANSFORM && t != CanvasView.T_TRANSFORM && cv.flt != null) cv.commitFloating();
        if (cv.tool == CanvasView.T_SELECT && cv.polyOpen() && t != CanvasView.T_SELECT) cv.closePoly();
        if (cv.tool == CanvasView.T_SHAPE && t != CanvasView.T_SHAPE) cv.cancelShapePts();
        cv.tool = t;
        if (t == CanvasView.T_TRANSFORM && cv.flt == null) cv.liftFloating();
        if (pop != null && pop.key != null && pop.key.startsWith("grp")) pop.dismiss();
        syncDock();
        buildOptions();
        syncSliders();
        cv.invalidate();
    }

    /* ---------------- barra de opções de cada ferramenta ---------------- */

    private Button chip(String t, boolean on, View.OnClickListener l) {
        Button b = Ui.btn(this, t);
        Ui.sel(b, on);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.WRAP, dp(34));
        lp.rightMargin = dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    private View mini(String label, int max, int value, Ui.Seek s) {
        LinearLayout r = Ui.row(this);
        TextView t = Ui.text(this, label, 11.5f, Ui.MUTE, true);
        r.addView(t);
        SeekBar sb = Ui.seek(this, max, value, s);
        r.addView(sb, new LinearLayout.LayoutParams(dp(120), Ui.WRAP));
        r.setPadding(0, 0, dp(6), 0);
        return r;
    }

    /** Linha de ajuste dentro dos painéis: nome · controle · valor. */
    private View prow(String label, int min, int max, int value, String suffix, final IntL on) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, dp(2), 0, dp(2));
        TextView t = Ui.text(this, label, 12.5f, Ui.FG, true);
        r.addView(t, new LinearLayout.LayoutParams(dp(96), Ui.WRAP));
        final TextView out = Ui.mono(this, value + suffix, 11.5f, Ui.MUTE);
        out.setGravity(Gravity.END);
        final int mn = min;
        SeekBar sb = Ui.seek(this, max - min, value - min, new Ui.Seek() {
            void change(int v) { out.setText((v + mn) + suffix); on.on(v + mn); }
        });
        r.addView(sb, new LinearLayout.LayoutParams(0, dp(32), 1));
        r.addView(out, new LinearLayout.LayoutParams(dp(46), Ui.WRAP));
        return r;
    }

    private void hint(String s) {
        TextView t = Ui.text(this, s, 12, Ui.MUTE, false);
        t.setPadding(dp(4), 0, dp(8), 0);
        optRow.addView(t);
    }

    private void buildOptions() {
        if (optRow == null) return;
        optRow.removeAllViews();
        int t = cv.tool;
        switch (t) {
            case CanvasView.T_BRUSH:
                if (cv.symMode != 0) optRow.addView(chip("Simetria ✓", true, v -> guidesSheet()));
                if (cv.strokeShape != 0) optRow.addView(chip(new String[]{"", "Traço: reta", "Traço: retângulo", "Traço: elipse"}[cv.strokeShape] + " ✕", true, v -> { cv.strokeShape = 0; buildOptions(); }));
                if (cv.layer().alpha) optRow.addView(chip("Trava alfa ✓", true, v -> { cv.layer().alpha = false; p.save(); buildOptions(); syncDock(); }));
                break;
            case CanvasView.T_FILL:
                optRow.addView(mini("Tolerância", 255, cv.fillTol, new Ui.Seek() { void change(int v) { cv.fillTol = v; } }));
                optRow.addView(mini("Fechar falhas", 12, cv.fillGap, new Ui.Seek() { void change(int v) { cv.fillGap = v; } }));
                optRow.addView(mini("Expandir", 6, cv.fillExpand, new Ui.Seek() { void change(int v) { cv.fillExpand = v; } }));
                optRow.addView(chip("Todas as camadas", cv.fillAll, v -> { cv.fillAll = !cv.fillAll; buildOptions(); }));
                break;
            case CanvasView.T_PICK:
                hint("Toque ou arraste para pegar a cor.");
                break;
            case CanvasView.T_SELECT: {
                String[] ops = {"Nova", "Somar", "Tirar"};
                for (int i = 0; i < 3; i++) {
                    final int fi = i;
                    optRow.addView(chip(ops[i], cv.selOp == i, v -> { cv.selOp = fi; buildOptions(); }));
                }
                if (cv.selMode == 3) optRow.addView(chip("Fechar polígono", false, v -> cv.closePoly()));
                if (cv.selMode >= 4) optRow.addView(mini("Tolerância", 255, cv.fillTol, new Ui.Seek() { void change(int v) { cv.fillTol = v; } }));
                optRow.addView(chip("Tudo", false, v -> cv.selectAll()));
                optRow.addView(chip("Do desenho", false, v -> cv.selectLayerContent()));
                if (cv.hasSel()) {
                    optRow.addView(chip("Inverter", false, v -> cv.invertSelection()));
                    optRow.addView(chip("Limpar", false, v -> cv.clearSelection()));
                    optRow.addView(chip("Copiar", false, v -> cv.copySel()));
                    optRow.addView(chip("Recortar", false, v -> cv.cutSel()));
                    optRow.addView(chip("Apagar", false, v -> cv.deleteSel()));
                    optRow.addView(chip("Preencher", false, v -> cv.fillSel()));
                    optRow.addView(chip("→ Nova camada", false, v -> { if (cv.selToLayer(false)) { Ui.toast(this, "Copiado para nova camada"); refreshLayerBar(); } }));
                    optRow.addView(chip("Transformar", false, v -> setTool(CanvasView.T_TRANSFORM)));
                }
                optRow.addView(chip("Colar", false, v -> cv.pasteSel()));
                break;
            }
            case CanvasView.T_TRANSFORM:
                optRow.addView(chip("Uniforme", cv.tfMode == 0, v -> { cv.tfMode = 0; buildOptions(); }));
                optRow.addView(chip("Distorcer", cv.tfMode == 1, v -> { cv.tfMode = 1; buildOptions(); }));
                optRow.addView(chip("⇋", false, v -> cv.flipFloat(true)));
                optRow.addView(chip("⇵", false, v -> cv.flipFloat(false)));
                optRow.addView(chip("↻ 90°", false, v -> cv.rotateFloat(90)));
                optRow.addView(chip("Ajustar à tela", false, v -> cv.fitFloat()));
                optRow.addView(chip("Cancelar", false, v -> { cv.cancelFloating(); setTool(CanvasView.T_BRUSH); }));
                optRow.addView(chip("✓ Aplicar", true, v -> { cv.commitFloating(); setTool(CanvasView.T_BRUSH); }));
                break;
            case CanvasView.T_SHAPE:
                if (cv.shapeType >= 1 && cv.shapeType != 5 && cv.shapeType != 6 && cv.shapeType != 8)
                    optRow.addView(chip("Preenchida", cv.shapeFill, v -> { cv.shapeFill = !cv.shapeFill; buildOptions(); }));
                if (cv.shapeType == 3 || cv.shapeType == 4)
                    optRow.addView(mini("Pontas", 12, cv.polySides, new Ui.Seek() { void change(int v) { cv.polySides = Math.max(3, v); } }));
                if (cv.shapeType == 6 || cv.shapeType == 7) {
                    hint(cv.shapeType == 6 ? "Toque para pôr pontos; toque 2× no último para terminar." : "Toque para pôr pontos; toque no 1º para fechar.");
                    optRow.addView(chip("✓ Concluir", true, v -> cv.finishShapePts()));
                    optRow.addView(chip("Descartar", false, v -> cv.cancelShapePts()));
                }
                if (cv.shapeType == 8) hint("Arraste para a reta, depois arraste de novo para curvar.");
                break;
            case CanvasView.T_GRADIENT:
                optRow.addView(chip("Linear", cv.gradType == 0, v -> { cv.gradType = 0; buildOptions(); }));
                optRow.addView(chip("Radial", cv.gradType == 1, v -> { cv.gradType = 1; buildOptions(); }));
                optRow.addView(chip("→ transparente", !cv.gradTwo, v -> { cv.gradTwo = false; buildOptions(); }));
                optRow.addView(chip("→ 2ª cor", cv.gradTwo, v -> { cv.gradTwo = true; buildOptions(); }));
                break;
            case CanvasView.T_TEXT:
                hint("Toque na tela onde o texto deve ficar.");
                break;
            case CanvasView.T_LIQUIFY: {
                String[] lm = {"Empurrar", "Girar", "Contrair", "Inflar"};
                for (int i = 0; i < lm.length; i++) {
                    final int fi = i;
                    optRow.addView(chip(lm[i], cv.liqMode == i, v -> { cv.liqMode = fi; buildOptions(); }));
                }
                optRow.addView(mini("Força", 100, cv.liqStrength, new Ui.Seek() { void change(int v) { cv.liqStrength = Math.max(1, v); } }));
                break;
            }
            case CanvasView.T_CLONE:
                optRow.addView(chip("Marcar nova origem", false, v -> { cv.resetClone(); Ui.toast(this, "Toque no ponto que quer copiar"); }));
                break;
            case CanvasView.T_RECOLOR:
                optRow.addView(mini("Tolerância", 255, cv.recolorTol, new Ui.Seek() { void change(int v) { cv.recolorTol = v; } }));
                break;
            case CanvasView.T_LASSOFILL:
                hint("Contorne a área para pintar com a cor atual.");
                break;
            case CanvasView.T_LASSOERASE:
                hint("Contorne a área para apagar.");
                break;
            case CanvasView.T_MEASURE:
                hint("Arraste para medir distância e ângulo.");
                break;
            case CanvasView.T_LIGHT:
                optRow.addView(mini("Raio", 700, cv.lightR, new Ui.Seek() { void change(int v) { cv.lightR = Math.max(80, v); } }));
                optRow.addView(mini("Força", 100, cv.lightI, new Ui.Seek() { void change(int v) { cv.lightI = Math.max(20, v); } }));
                optRow.addView(mini("Sombra", 100, cv.lightS, new Ui.Seek() { void change(int v) { cv.lightS = v; } }));
                for (final int c : new int[]{0xFFFFD27A, 0xFFFFFFFF, 0xFF8FC8FF, 0xFFFF8FD0, 0xFFFF6A45}) {
                    View sw = new View(this);
                    GradientDrawable g = Ui.bg(c, dp(15));
                    if (c == cv.lightColor) g.setStroke(dp(2), Ui.ACC);
                    sw.setBackground(g);
                    sw.setOnClickListener(v -> { cv.lightColor = c; buildOptions(); });
                    LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(dp(30), dp(30));
                    l.rightMargin = dp(6);
                    optRow.addView(sw, l);
                }
                optRow.addView(chip("Sair", false, v -> setTool(CanvasView.T_BRUSH)));
                break;
            case CanvasView.T_GUIDES:
                guideOptions();
                break;
            case CanvasView.T_HAND:
                optRow.addView(chip("Ajustar", false, v -> cv.fitView()));
                optRow.addView(chip("100%", false, v -> cv.zoom100()));
                optRow.addView(chip("Espelhar visão", false, v -> cv.flipView()));
                break;
            default:
                break;
        }
        optWrap.setVisibility(optRow.getChildCount() == 0 ? View.GONE : View.VISIBLE);
    }

    private void guideOptions() {
        String[] g = {"Sem guia", "Grade", "Perspectiva 1", "Perspectiva 2", "Isométrica", "Terços", "Centro"};
        for (int i = 0; i < g.length; i++) {
            final int fi = i;
            optRow.addView(chip(g[i], cv.guide == i, v -> { cv.guide = fi; cv.invalidate(); buildOptions(); }));
        }
        optRow.addView(chip("Régua (travar traço)", cv.snapGuide, v -> { cv.snapGuide = !cv.snapGuide; buildOptions(); }));
        optRow.addView(mini("Grade", 256, cv.gridSize, new Ui.Seek() { void change(int v) { cv.gridSize = Math.max(8, v); cv.invalidate(); } }));
    }

    /* ---------------- painéis da doca de baixo (como os "pops" da 5.0) ---------------- */

    interface DL { void on(Object o); }

    /** Painel que abre por cima da tela, logo acima das ferramentas. */
    final class Pop {
        final LinearLayout body;
        final TextView title;
        private final View view;
        private Runnable onClose;
        private boolean showing;
        boolean modal;
        String key;

        Pop(String t) {
            LinearLayout box = Ui.col(EditorActivity.this);
            box.setBackground(Ui.bgStroke(Ui.PANEL, Ui.LINE, dp(16), dp(1)));
            box.setElevation(dp(14));
            LinearLayout head = Ui.row(EditorActivity.this);
            head.setPadding(dp(14), dp(8), dp(4), 0);
            title = Ui.text(EditorActivity.this, t == null ? "" : t.toUpperCase(), 11, Ui.MUTE, true);
            title.setLetterSpacing(0.08f);
            head.addView(title, Ui.lpw(1));
            TextView x = Ui.text(EditorActivity.this, "✕", 15, Ui.MUTE, true);
            x.setPadding(dp(12), dp(6), dp(12), dp(6));
            x.setOnClickListener(v -> dismiss());
            head.addView(x);
            box.addView(head);
            int maxH = Math.max(dp(220), (int) ((stage.getHeight() > 0 ? stage.getHeight() : getResources().getDisplayMetrics().heightPixels / 2) * .78f));
            Sheet.MaxScroll sc = new Sheet.MaxScroll(EditorActivity.this, maxH);
            body = Ui.col(EditorActivity.this);
            body.setPadding(dp(14), dp(4), dp(14), dp(14));
            sc.addView(body);
            box.addView(sc);
            box.setClickable(true);
            view = box;
        }

        TextView section(String s) {
            TextView t = Ui.text(EditorActivity.this, s.toUpperCase(), 11, Ui.MUTE, true);
            t.setLetterSpacing(0.08f);
            t.setPadding(0, dp(12), 0, dp(6));
            body.addView(t);
            return t;
        }

        void add(View v) { body.addView(v); }

        void add(View v, LinearLayout.LayoutParams lp) { body.addView(v, lp); }

        void show() {
            if (pop != null && pop != this) pop.dismiss();
            pop = this;
            showing = true;
            popHost.addView(view, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM));
            view.setAlpha(0f);
            view.setTranslationY(dp(14));
            view.animate().alpha(1f).translationY(0).setDuration(160).start();
            syncDock();
        }

        void dismiss() {
            if (!showing) return;
            showing = false;
            popHost.removeView(view);
            if (pop == this) pop = null;
            if (onClose != null) onClose.run();
            syncDock();
        }

        boolean isShowing() { return showing; }

        void setOnDismissListener(DL l) { onClose = () -> l.on(this); }
    }

    private void eraserPop() {
        final Pop s = new Pop("Borracha");
        s.key = "eraser";
        LinearLayout r = Ui.row(this);
        String[][] ty = {{"e_round", "Dura"}, {"e_soft", "Suave"}, {"e_grain", "Lápis"}};
        for (String[] e : ty) r.addView(chip(e[1], cv.eraserType.equals(e[0]), v -> { cv.eraserType = e[0]; s.dismiss(); }));
        s.add(r);
        s.show();
    }

    /** Ajustes: camada ativa, visão e filtros (painel "Ajustes" da 5.0). */
    private void adjustPop() {
        final Pop s = new Pop("Ajustes");
        s.key = "adjust";
        s.section("Camada ativa");
        LinearLayout r1 = Ui.row(this);
        final Project.Layer l = cv.layer();
        r1.addView(chip(l.alpha ? "Bloquear transparência ✓" : "Bloquear transparência", l.alpha, v -> { l.alpha = !l.alpha; p.save(); s.dismiss(); adjustPop(); buildOptions(); }));
        r1.addView(chip("Espelhar ↔", false, v -> cv.flipLayer(true)));
        r1.addView(chip("Espelhar ↕", false, v -> cv.flipLayer(false)));
        r1.addView(chip("Limpar camada", false, v -> cv.clearLayer(cv.active)));
        s.add(wrapH(r1));
        s.section("Visão");
        LinearLayout r2 = Ui.row(this);
        r2.addView(chip("Espelhar visão", false, v -> cv.flipView()));
        r2.addView(chip("Ajustar à tela", false, v -> cv.fitView()));
        r2.addView(chip("Endireitar", false, v -> cv.resetRotation()));
        s.add(wrapH(r2));
        s.section(cv.hasSel() ? "Filtros (dentro da seleção)" : "Filtros da camada");
        LinearLayout grid = Ui.col(this);
        LinearLayout row = null;
        for (int i = 0; i < Filters.ALL.length; i++) {
            if (i % 2 == 0) { row = Ui.row(this); grid.addView(row, gapB(6)); }
            final Filters.F f = Filters.ALL[i];
            TextView b = Ui.text(this, f.name, 12.5f, Ui.FG, true);
            b.setPadding(dp(12), dp(11), dp(10), dp(11));
            b.setBackground(Ui.bgStroke(Ui.PANEL2, Ui.LINE, dp(12), dp(1)));
            b.setOnClickListener(v -> { s.dismiss(); filterPanel(f); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.WRAP, 1);
            if (i % 2 == 1) lp.leftMargin = dp(6);
            row.addView(Ui.pressable(b), lp);
        }
        if (Filters.ALL.length % 2 == 1) { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1); lp.leftMargin = dp(6); row.addView(new View(this), lp); }
        s.add(grid);
        s.show();
    }

    /** Traço: estabilizador, afinar ponta e forma (painel "Traço" da 5.0). */
    private void strokePop() {
        final Pop s = new Pop("Traço");
        s.key = "stroke";
        s.section("Estabilizador de traço");
        final TextView hint = Ui.text(this, "", 11.5f, Ui.MUTE, false);
        final Runnable hs = () -> {
            int lvl = Math.round(cv.stabilizer * 15 / 100f);
            hint.setText(lvl == 0 ? "0 = desligado · 15 = estabilidade máxima" : "Nível " + lvl + " de 15" + (lvl >= 12 ? " · bem pesado, traço mais lento" : ""));
        };
        s.add(prow("Nível", 0, 15, Math.round(cv.stabilizer * 15 / 100f), "", v -> { cv.stabilizer = Math.round(v * 100 / 15f); hs.run(); syncDock(); }));
        hs.run();
        s.add(hint);
        s.section("Afinar ponta (qualquer pincel)");
        s.add(prow("Início", 0, 100, cv.taperIn, "", v -> cv.taperIn = v));
        s.add(prow("Fim", 0, 100, cv.taperOut, "", v -> cv.taperOut = v));
        TextView h2 = Ui.text(this, "A ponta do fim afina quando você solta o dedo. Quanto maior, mais comprida a ponta.", 11.5f, Ui.MUTE, false);
        s.add(h2);
        s.section("Forma");
        final LinearLayout fr = Ui.row(this);
        final String[] fs = {"Livre", "Reta", "Retângulo", "Elipse"};
        final Runnable[] rf = new Runnable[1];
        rf[0] = () -> {
            fr.removeAllViews();
            for (int i = 0; i < fs.length; i++) {
                final int fi = i;
                fr.addView(chip(fs[i], cv.strokeShape == i, v -> { cv.strokeShape = fi; rf[0].run(); buildOptions(); }));
            }
        };
        rf[0].run();
        s.add(wrapH(fr));
        s.section("Caneta e gestos");
        s.add(toggleRow("pressure", true, "Pressão da caneta"), gapB(6));
        s.add(toggleRow("qshape", true, "QuickShape (segure no fim do traço)"), gapB(6));
        s.add(toggleRow("stylusOnly", false, "Só a caneta desenha (dedo move)"));
        s.show();
    }

    /** Mídia: fundo, imagem, vídeo, filtros rápidos, luz e sombra (painel "Mídia" da 5.0). */
    private void mediaPop() {
        final Pop s = new Pop("Mídia");
        s.key = "media";
        s.section("Importar da galeria");
        TextView n = Ui.text(this, "Use uma imagem como cenário, coloque sobre o desenho" + (p.anim ? " ou importe um vídeo quadro a quadro para fazer rotoscopia." : "."), 12, Ui.MUTE, false);
        n.setLineSpacing(0, 1.2f);
        s.add(n, gapB(8));
        LinearLayout r = Ui.row(this);
        r.addView(mediaCard("▧", "Fundo da tela", "Imagem atrás do desenho", v -> { s.dismiss(); pickImage(REQ_BG); }), Ui.lpw(1));
        LinearLayout.LayoutParams l2 = Ui.lpw(1);
        l2.leftMargin = dp(6);
        r.addView(mediaCard("▣", "Inserir imagem", "Redimensionar e mover", v -> { s.dismiss(); pickImage(REQ_IMPORT); }), l2);
        if (p.anim) {
            LinearLayout.LayoutParams l3 = Ui.lpw(1);
            l3.leftMargin = dp(6);
            r.addView(mediaCard("▶", "Importar vídeo", "Separar em quadros", v -> { s.dismiss(); pickVideo(); }), l3);
        }
        s.add(r);
        LinearLayout fit = Ui.row(this);
        fit.setPadding(0, dp(10), 0, 0);
        int bf = Prefs.num(this, "bgFit", 0);
        String[] fits = {"Preencher (corta)", "Imagem inteira", "Esticar"};
        for (int i = 0; i < 3; i++) {
            final int fi = i;
            fit.addView(chip(fits[i], bf == i, v -> { Prefs.put(this, "bgFit", fi); s.dismiss(); mediaPop(); }));
        }
        if (cv.bgBmp != null) fit.addView(chip("Remover fundo", false, v -> { cv.setBgImage(null); s.dismiss(); }));
        s.add(wrapH(fit));
        s.section("Filtros na camada ativa");
        final boolean[] all = {false};
        LinearLayout fr = Ui.row(this);
        Object[][] qf = {{"P&B", "gray", new int[]{}}, {"Sépia", "sepia", new int[]{100}}, {"Inverter", "invert", new int[]{}},
                {"Brilho +", "hsb", new int[]{0, 0, 15}}, {"Brilho −", "hsb", new int[]{0, 0, -15}}, {"Contraste", "contrast", new int[]{30, 0}},
                {"Cor +", "hsb", new int[]{0, 50, 0}}, {"Frio", "cool", new int[]{}}, {"Quente", "warm", new int[]{}}};
        for (Object[] q : qf) fr.addView(chip((String) q[0], false, v -> { cv.quickFilter((String) q[1], (int[]) q[2], all[0]); Ui.toast(this, q[0] + " aplicado"); }));
        s.add(wrapH(fr));
        if (p.anim) {
            LinearLayout ar = Ui.row(this);
            ar.setPadding(0, dp(6), 0, 0);
            final Button ab = chip("Aplicar em todos os quadros", false, null);
            ab.setOnClickListener(v -> { all[0] = !all[0]; Ui.sel(ab, all[0]); });
            ar.addView(ab);
            s.add(ar);
        }
        s.section("Luz e sombra automáticas");
        LinearLayout lr = Ui.row(this);
        lr.addView(chip("Colocar ponto de luz", true, v -> { s.dismiss(); setTool(CanvasView.T_LIGHT); Ui.toast(this, "Toque ou arraste onde a luz fica"); }));
        s.add(lr);
        TextView lh = Ui.text(this, "Age na camada ativa e cria as camadas \"Sombra\" e \"Luz\" recortadas nela.", 11.5f, Ui.MUTE, false);
        lh.setPadding(0, dp(6), 0, 0);
        s.add(lh);
        s.show();
    }

    private View mediaCard(String ic, String t, String sub, View.OnClickListener l) {
        LinearLayout c = Ui.col(this);
        c.setPadding(dp(10), dp(10), dp(10), dp(10));
        c.setBackground(Ui.bgStroke(Ui.PANEL2, Ui.LINE, dp(14), dp(1)));
        c.addView(Ui.text(this, ic, 18, Ui.ACC, true));
        TextView a = Ui.text(this, t, 12.5f, Ui.FG, true);
        a.setPadding(0, dp(6), 0, dp(2));
        c.addView(a);
        TextView b = Ui.text(this, sub, 10.5f, Ui.MUTE, false);
        c.addView(b);
        c.setOnClickListener(l);
        return Ui.pressable(c);
    }

    /* ================================================================ eventos da tela */

    @Override public void onColorPicked(int c) { setColor(c, true); }

    @Override public void onChanged() {
        ui.removeCallbacks(autosave);
        ui.postDelayed(autosave, 20000);
        if (p.anim) { ui.removeCallbacks(thumbRefresh); ui.postDelayed(thumbRefresh, 500); }
        if (layersSheet != null && layersSheet.isShowing()) { ui.removeCallbacks(layersRefresh); ui.postDelayed(layersRefresh, 300); }
        ui.removeCallbacks(barRefresh);
        ui.postDelayed(barRefresh, 250);
    }

    private final Runnable barRefresh = () -> { refreshLayerBar(); syncDock(); };

    private final Runnable layersRefresh = () -> { if (layersSheet != null && layersSheet.isShowing()) fillLayers(); };

    @Override public void onSelection(boolean has) { if (cv.tool == CanvasView.T_SELECT) buildOptions(); }

    @Override public void onTransform(boolean on) {
        if (on && cv.tool != CanvasView.T_TRANSFORM) cv.tool = CanvasView.T_TRANSFORM;
        syncDock();
        buildOptions();
        syncSliders();
        refreshLayerBar();
    }

    @Override public void onMessage(String s) { Ui.toast(this, s); }

    @Override public void onTextAt(float x, float y) { textSheet(x, y); }

    @Override public void onHistory() {
        if (undoB == null) return;
        undoB.setAlpha(cv.canUndo() || cv.flt != null ? 1f : .3f);
        redoB.setAlpha(cv.canRedo() ? 1f : .3f);
    }

    @Override public void onTouchStart() {
        if (pop != null && !pop.modal) pop.dismiss();
    }

    @Override public void onViewChanged() {
        if (zoomTv == null) return;
        zoomTv.setText(cv.zoomPercent() + "%");
        int r = Math.round(cv.rotation());
        if (r > 180) r -= 360;
        rotTv.setVisibility(Math.abs(r) >= 1 ? View.VISIBLE : View.GONE);
        rotTv.setText(r + "°");
    }

    void setColor(int c, boolean remember) {
        cv.color = c | 0xFF000000;
        if (colorDot != null) colorDot.set(cv.color);
        if (remember) addRecent(cv.color);
    }

    private void addRecent(int c) {
        recent.remove((Integer) c);
        recent.add(0, c);
        while (recent.size() > 14) recent.remove(recent.size() - 1);
    }

    /* ================================================================ pincéis */

    private void brushSheet() {
        final Pop s = new Pop("Pincéis");
        s.key = "brush";
        for (String cat : Brushes.CATS) {
            s.section(cat);
            LinearLayout grid = Ui.col(this);
            LinearLayout row = null;
            int i = 0;
            for (final Brushes.B b : Brushes.ALL) {
                if (!b.cat.equals(cat)) continue;
                if (i % 2 == 0) { row = Ui.row(this); grid.addView(row, gapB(8)); }
                LinearLayout card = Ui.row(this);
                card.setPadding(dp(10), dp(10), dp(10), dp(10));
                boolean on = b.id.equals(cv.brushId);
                GradientDrawable g = Ui.bg(on ? HomeActivity.blend(Ui.ACC, Ui.PANEL2, .18f) : Ui.PANEL2, dp(14));
                g.setStroke(dp(on ? 2 : 1), on ? Ui.ACC : Ui.LINE);
                card.setBackground(g);
                ImageView iv = new ImageView(this);
                android.graphics.drawable.Drawable d = Ui.icon(this, b.id, on ? Ui.ACC : Ui.FG);
                iv.setImageDrawable(d != null ? d : Ui.icon(this, "brush", on ? Ui.ACC : Ui.FG));
                card.addView(iv, new LinearLayout.LayoutParams(dp(30), dp(30)));
                LinearLayout tx = Ui.col(this);
                tx.setPadding(dp(10), 0, 0, 0);
                TextView n = Ui.text(this, b.name, 13, Ui.FG, true);
                n.setSingleLine(true);
                n.setEllipsize(TextUtils.TruncateAt.END);
                TextView hn = Ui.text(this, b.hint, 10.5f, Ui.MUTE, false);
                hn.setMaxLines(2);
                hn.setPadding(0, dp(2), 0, 0);
                tx.addView(n);
                tx.addView(hn);
                card.addView(tx, Ui.lpw(1));
                card.setOnClickListener(v -> {
                    cv.brushId = b.id;
                    if (!Prefs.get(this).contains("bsize_" + b.id)) cv.brushSize = b.defSize;
                    else cv.brushSize = Prefs.get(this).getFloat("bsize_" + b.id, b.defSize);
                    s.dismiss();
                    setTool(CanvasView.T_BRUSH);
                });
                LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, Ui.WRAP, 1);
                if (i % 2 == 1) l.leftMargin = dp(8);
                row.addView(Ui.pressable(card), l);
                i++;
            }
            if (i % 2 == 1) {
                LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, 1, 1);
                l.leftMargin = dp(8);
                row.addView(new View(this), l);
            }
            s.add(grid);
        }
        final String prev = cv.brushId;
        final float prevSize = cv.brushSize;
        s.setOnDismissListener(d -> Prefs.get(this).edit().putFloat("bsize_" + prev, prevSize).apply());
        s.show();
    }

    private LinearLayout.LayoutParams gapB(int d) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP);
        l.bottomMargin = dp(d);
        return l;
    }

    /* ================================================================ cores */

    private void colorSheet() {
        final Pop s = new Pop("Cor");
        s.key = "color";
        final ColorWheel wheel = new ColorWheel(this);
        wheel.set(cv.color);
        s.add(wheel, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        LinearLayout info = Ui.row(this);
        info.setPadding(0, dp(12), 0, 0);
        final View now = new View(this);
        now.setBackground(Ui.bg(cv.color, dp(10)));
        info.addView(now, new LinearLayout.LayoutParams(dp(44), dp(36)));
        final View sec = new View(this);
        sec.setBackground(Ui.bgStroke(cv.color2, Ui.LINE, dp(10), dp(1)));
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(dp(30), dp(26));
        sl.leftMargin = dp(6);
        info.addView(sec, sl);
        final EditText hex = HomeActivity.input(this, "#RRGGBB");
        hex.setText(Ui.hex(cv.color));
        hex.setTypeface(Typeface.MONOSPACE);
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(0, Ui.WRAP, 1);
        hl.leftMargin = dp(10);
        info.addView(hex, hl);
        Button ok = Ui.btn(this, "OK");
        LinearLayout.LayoutParams okl = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        okl.leftMargin = dp(6);
        info.addView(ok, okl);
        s.add(info);
        final Runnable[] upd = new Runnable[1];
        upd[0] = () -> {
            now.setBackground(Ui.bg(cv.color, dp(10)));
            sec.setBackground(Ui.bgStroke(cv.color2, Ui.LINE, dp(10), dp(1)));
            if (!hex.hasFocus()) hex.setText(Ui.hex(cv.color));
        };
        wheel.listener = (c, done) -> { setColor(c, done); upd[0].run(); };
        ok.setOnClickListener(v -> {
            try {
                String t = hex.getText().toString().trim();
                if (!t.startsWith("#")) t = "#" + t;
                int c = Color.parseColor(t);
                setColor(c, true);
                wheel.set(cv.color);
                upd[0].run();
            } catch (Exception e) { Ui.toast(this, "Cor inválida"); }
        });
        sec.setOnClickListener(v -> {
            int t = cv.color; setColor(cv.color2, true); cv.color2 = t;
            wheel.set(cv.color);
            upd[0].run();
        });
        if (!recent.isEmpty()) {
            s.section("Recentes");
            s.add(swatches(recent, c -> { setColor(c, true); wheel.set(c); upd[0].run(); }, null));
        }
        s.section("Paleta");
        final ArrayList<Integer> pal = Prefs.colors(this, "palette", PALETTE);
        final LinearLayout[] palBox = new LinearLayout[1];
        final Runnable[] drawPal = new Runnable[1];
        palBox[0] = Ui.col(this);
        drawPal[0] = () -> {
            palBox[0].removeAllViews();
            palBox[0].addView(swatches(pal, c -> { setColor(c, true); wheel.set(c); upd[0].run(); }, c -> {
                pal.remove((Integer) c);
                Prefs.colors(this, "palette", pal);
                drawPal[0].run();
                Ui.toast(this, "Cor removida da paleta");
            }));
        };
        drawPal[0].run();
        s.add(palBox[0]);
        LinearLayout acts = Ui.row(this);
        acts.setPadding(0, dp(10), 0, 0);
        acts.addView(chip("+ Salvar cor na paleta", false, v -> {
            if (!pal.contains(cv.color)) { pal.add(cv.color); Prefs.colors(this, "palette", pal); drawPal[0].run(); }
        }));
        acts.addView(chip("Harmonias", false, v -> {
            ArrayList<Integer> hs = new ArrayList<>();
            for (float d : new float[]{0, 30, -30, 180, 150, 210, 120, 240}) hs.add(Brushes.hueShift(cv.color, d, 0));
            for (float dv : new float[]{-.3f, -.15f, .15f, .3f}) hs.add(Brushes.shade(cv.color, dv));
            Sheet hsSheet = new Sheet(this, "Harmonias da cor");
            hsSheet.add(swatches(hs, c -> { setColor(c, true); wheel.set(c); upd[0].run(); hsSheet.dismiss(); }, null));
            hsSheet.show();
        }));
        s.add(wrapH(acts));
        TextView tip = Ui.text(this, "Segure uma cor da paleta para removê-la. Segure a bolinha de cor na barra para trocar com a 2ª cor.", 11.5f, Ui.MUTE, false);
        tip.setPadding(0, dp(12), 0, 0);
        s.add(tip);
        s.show();
    }

    interface IntL { void on(int c); }

    private View swatches(ArrayList<Integer> cols, IntL tap, IntL hold) {
        LinearLayout box = Ui.col(this);
        LinearLayout row = null;
        int per = 8;
        for (int i = 0; i < cols.size(); i++) {
            if (i % per == 0) { row = Ui.row(this); box.addView(row, gapB(8)); }
            final int c = cols.get(i);
            View v = new View(this);
            v.setBackground(Ui.bgStroke(c, 0x33FFFFFF, dp(10), dp(1)));
            v.setOnClickListener(x -> tap.on(c));
            if (hold != null) v.setOnLongClickListener(x -> { hold.on(c); return true; });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, dp(34), 1);
            if (i % per > 0) l.leftMargin = dp(6);
            row.addView(Ui.pressable(v), l);
        }
        if (row != null && cols.size() % per != 0) for (int k = cols.size() % per; k < per; k++) {
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, 1, 1);
            l.leftMargin = dp(6);
            row.addView(new View(this), l);
        }
        return box;
    }

    private View wrapH(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }

    /* ================================================================ camadas */

    private LinearLayout layersBox;

    private void layersSheet() {
        cv.commitFloating();
        layersSheet = new Pop("Camadas");
        layersSheet.key = "layers";
        layersBox = Ui.col(this);
        layersSheet.add(layersBox);
        fillLayers();
        layersSheet.setOnDismissListener(d -> { layersSheet = null; buildOptions(); });
        layersSheet.show();
    }

    private void fillLayers() {
        layersBox.removeAllViews();
        refreshLayerBar();
        syncDock();
        LinearLayout acts = Ui.row(this);
        acts.addView(chip("+ Nova", false, v -> { cv.addLayer("Camada " + (p.nextLayer)); fillLayers(); }));
        acts.addView(chip("Duplicar", false, v -> { cv.duplicateLayer(cv.active); fillLayers(); }));
        acts.addView(chip("Juntar abaixo", false, v -> { if (cv.active > 0) { cv.mergeDown(cv.active); fillLayers(); } else Ui.toast(this, "Não há camada abaixo"); }));
        acts.addView(chip("Imagem", false, v -> { layersSheet.dismiss(); pickImage(REQ_IMPORT); }));
        layersBox.addView(wrapH(acts), gapB(10));
        TextView cnt = Ui.mono(this, p.layers.size() + " de " + p.maxLayers() + " camadas", 11, Ui.MUTE);
        cnt.setPadding(0, 0, 0, dp(8));
        layersBox.addView(cnt);
        for (int i = p.layers.size() - 1; i >= 0; i--) layersBox.addView(layerRow(i), gapB(6));
        Project.Layer l = cv.layer();
        TextView h = Ui.text(this, "AJUSTES DE \"" + l.name.toUpperCase() + "\"", 11, Ui.MUTE, true);
        h.setPadding(0, dp(12), 0, dp(8));
        layersBox.addView(h);
        layersBox.addView(mini("Opacidade", 100, Math.round(l.opacity / 2.55f), new Ui.Seek() {
            void change(int v) { l.opacity = Math.round(v * 2.55f); cv.invalidate(); }
            void done() { p.save(); }
        }));
        LinearLayout modes = Ui.row(this);
        for (int i = 0; i < Render.BLENDS.length; i++) {
            final String b = Render.BLENDS[i];
            modes.addView(chip(BLEND_NAMES[i], b.equals(l.blend), v -> { l.blend = b; p.save(); cv.invalidate(); fillLayers(); }));
        }
        LinearLayout.LayoutParams ml = gapB(6);
        ml.topMargin = dp(6);
        layersBox.addView(wrapH(modes), ml);
        LinearLayout t = Ui.row(this);
        t.addView(chip(l.clip ? "Recorte ✓" : "Recorte (máscara)", l.clip, v -> { l.clip = !l.clip; p.save(); cv.invalidate(); fillLayers(); }));
        t.addView(chip(l.alpha ? "Trava alfa ✓" : "Trava alfa", l.alpha, v -> { l.alpha = !l.alpha; p.save(); fillLayers(); }));
        t.addView(chip(l.locked ? "Bloqueada ✓" : "Bloquear", l.locked, v -> { l.locked = !l.locked; p.save(); fillLayers(); }));
        t.addView(chip("Renomear", false, v -> renameLayer(l)));
        layersBox.addView(wrapH(t), gapB(6));
        LinearLayout t2 = Ui.row(this);
        t2.addView(chip("⇋ Espelhar", false, v -> cv.flipLayer(true)));
        t2.addView(chip("⇵ Espelhar", false, v -> cv.flipLayer(false)));
        t2.addView(chip("Selecionar desenho", false, v -> { cv.selectLayerContent(); layersSheet.dismiss(); setTool(CanvasView.T_SELECT); }));
        t2.addView(chip("Limpar", false, v -> { cv.clearLayer(cv.active); fillLayers(); }));
        final Button del = chip("Excluir", false, null);
        final boolean[] armed = {false};
        del.setOnClickListener(v -> {
            if (!armed[0]) { armed[0] = true; del.setText("Toque de novo"); Ui.sel(del, true); return; }
            cv.deleteLayer(cv.active);
            fillLayers();
        });
        t2.addView(del);
        layersBox.addView(wrapH(t2));
    }

    private View layerRow(final int idx) {
        final Project.Layer l = p.layers.get(idx);
        boolean on = idx == cv.active;
        LinearLayout r = Ui.row(this);
        r.setPadding(dp(8), dp(6), dp(6), dp(6));
        GradientDrawable g = Ui.bg(on ? HomeActivity.blend(Ui.ACC, Ui.PANEL2, .2f) : Ui.PANEL2, dp(14));
        g.setStroke(dp(on ? 2 : 1), on ? Ui.ACC : Ui.LINE);
        r.setBackground(g);
        ImageView th = new ImageView(this);
        th.setBackground(Ui.bg((p.paper >>> 24) == 0 ? 0xFFE0E2EA : p.paper, dp(6)));
        th.setScaleType(ImageView.ScaleType.FIT_CENTER);
        Bitmap b = cv.bm.get(l.id);
        if (b != null) {
            float k = 96f / Math.max(p.w, p.h);
            th.setImageBitmap(Bitmap.createScaledBitmap(b, Math.max(1, Math.round(p.w * k)), Math.max(1, Math.round(p.h * k)), true));
        }
        if (l.clip) {
            TextView ci = Ui.text(this, "↳", 16, Ui.ACC, true);
            ci.setPadding(0, 0, dp(4), 0);
            r.addView(ci);
        }
        r.addView(th, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout tx = Ui.col(this);
        tx.setPadding(dp(10), 0, dp(4), 0);
        TextView n = Ui.text(this, l.name, 13.5f, Ui.FG, true);
        n.setSingleLine(true);
        n.setEllipsize(TextUtils.TruncateAt.END);
        String info = (l.blend.equals("normal") ? "Normal" : BLEND_NAMES[indexOf(Render.BLENDS, l.blend)]) + " · " + Math.round(l.opacity / 2.55f) + "%"
                + (l.alpha ? " · α" : "") + (l.locked ? " · 🔒" : "");
        TextView sub = Ui.text(this, info, 11, Ui.MUTE, false);
        sub.setPadding(0, dp(3), 0, 0);
        tx.addView(n);
        tx.addView(sub);
        r.addView(tx, Ui.lpw(1));
        ImageView up = smallIcon("up", v -> { cv.moveLayer(idx, idx + 1); fillLayers(); });
        ImageView dn = smallIcon("down", v -> { cv.moveLayer(idx, idx - 1); fillLayers(); });
        ImageView eye = smallIcon("eye", v -> { l.visible = !l.visible; p.save(); cv.invalidate(); fillLayers(); });
        eye.setAlpha(l.visible ? 1f : .3f);
        r.addView(up);
        r.addView(dn);
        r.addView(eye);
        r.setOnClickListener(v -> { cv.active = idx; fillLayers(); buildOptions(); });
        r.setOnLongClickListener(v -> { renameLayer(l); return true; });
        return r;
    }

    private static int indexOf(String[] a, String s) {
        for (int i = 0; i < a.length; i++) if (a[i].equals(s)) return i;
        return 0;
    }

    private ImageView smallIcon(String icon, View.OnClickListener l) {
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(Ui.icon(this, icon, Ui.FG));
        iv.setPadding(dp(7), dp(7), dp(7), dp(7));
        iv.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(34)));
        iv.setOnClickListener(l);
        return iv;
    }

    private void renameLayer(Project.Layer l) {
        final Sheet s = new Sheet(this, "Nome da camada");
        final EditText e = HomeActivity.input(this, "Nome");
        e.setText(l.name);
        s.add(e);
        Button ok = Ui.btn(this, "Salvar");
        Ui.sel(ok, true);
        ok.setOnClickListener(v -> {
            String n = e.getText().toString().trim();
            if (!n.isEmpty()) { l.name = n.length() > 30 ? n.substring(0, 30) : n; p.save(); }
            s.dismiss();
            if (layersSheet != null) fillLayers();
        });
        LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        ol.gravity = Gravity.END;
        ol.topMargin = dp(12);
        s.add(ok, ol);
        s.show();
    }

    /* ================================================================ filtros */

    private void filtersSheet() {
        final Sheet s = new Sheet(this, "Ajustes e filtros");
        TextView h = Ui.text(this, cv.hasSel() ? "Aplicado só dentro da seleção." : "Aplicado na camada \"" + cv.layer().name + "\".", 12, Ui.MUTE, false);
        h.setPadding(0, 0, 0, dp(10));
        s.add(h);
        for (final Filters.F f : Filters.ALL) {
            LinearLayout r = Ui.row(this);
            r.setPadding(dp(14), dp(13), dp(14), dp(13));
            r.setBackground(Ui.bgStroke(Ui.PANEL2, Ui.LINE, dp(14), dp(1)));
            r.addView(Ui.text(this, f.name, 14, Ui.FG, true), Ui.lpw(1));
            r.addView(Ui.iconView(this, "next", Ui.MUTE, 18));
            r.setOnClickListener(v -> { s.dismiss(); filterPanel(f); });
            s.add(Ui.pressable(r), gapB(6));
        }
        s.show();
    }

    private volatile int filterGen;

    private void filterPanel(final Filters.F f) {
        if (!cv.filterBegin()) return;
        final int[] vals = f.def.clone();
        final Pop s = new Pop(f.name);
        s.key = "filter";
        s.modal = true;
        cv.inputLocked = true;
        final Runnable run = () -> {
            final int gen = ++filterGen;
            final int[] v = vals.clone();
            work.execute(() -> {
                if (gen != filterGen) return;
                Bitmap b;
                try { b = cv.filterCompute(f.id, v); } catch (Throwable e) { b = null; }
                final Bitmap fb = b;
                ui.post(() -> {
                    if (gen != filterGen || fb == null) { if (fb != null) fb.recycle(); return; }
                    cv.filterPreview(fb);
                });
            });
        };
        for (int i = 0; i < f.params.length; i++) {
            final int fi = i;
            final TextView lab = Ui.text(this, f.params[i] + ": " + vals[i], 12.5f, Ui.MUTE, true);
            lab.setPadding(0, dp(6), 0, dp(4));
            s.add(lab);
            SeekBar sb = Ui.seek(this, f.max[i] - f.min[i], vals[i] - f.min[i], new Ui.Seek() {
                void change(int v) { vals[fi] = v + f.min[fi]; lab.setText(f.params[fi] + ": " + vals[fi]); }
                void done() { run.run(); }
            });
            s.add(sb);
        }
        if (f.color) {
            TextView c = Ui.text(this, "Usa a cor atual: " + Ui.hex(cv.color), 12, Ui.MUTE, false);
            c.setPadding(0, dp(8), 0, 0);
            s.add(c);
        }
        LinearLayout acts = Ui.row(this);
        acts.setGravity(Gravity.END);
        acts.setPadding(0, dp(14), 0, 0);
        final boolean[] applied = {false};
        Button cancel = Ui.btn(this, "Cancelar");
        cancel.setOnClickListener(v -> s.dismiss());
        Button ok = Ui.btn(this, "✓ Aplicar");
        Ui.sel(ok, true);
        ok.setOnClickListener(v -> { applied[0] = true; s.dismiss(); });
        acts.addView(cancel);
        acts.addView(Ui.gap(this, 8, 1));
        acts.addView(ok);
        s.add(acts);
        s.setOnDismissListener(d -> {
            cv.inputLocked = false;
            if (!applied[0]) filterGen++;
            work.execute(() -> ui.post(() -> {
                cv.filterEnd(applied[0]);
                if (applied[0]) Ui.toast(this, f.name + " aplicado");
            }));
        });
        s.show();
        run.run();
    }

    /* ================================================================ guias e simetria */

    private void guidesSheet() {
        final Pop s = new Pop("Simetria e guias");
        s.key = "guides";
        s.section("Simetria");
        LinearLayout sy = Ui.row(this);
        String[] sm = {"Desligada", "Vertical", "Horizontal", "4 lados", "Radial"};
        final Runnable[] re = new Runnable[1];
        final LinearLayout radial = Ui.col(this);
        re[0] = () -> {
            sy.removeAllViews();
            for (int i = 0; i < sm.length; i++) {
                final int fi = i;
                sy.addView(chip(sm[i], cv.symMode == i, v -> { cv.symMode = fi; cv.invalidate(); re[0].run(); }));
            }
            radial.setVisibility(cv.symMode == 4 ? View.VISIBLE : View.GONE);
        };
        s.add(wrapH(sy));
        final TextView rn = Ui.text(this, "Fatias: " + cv.radialN, 12.5f, Ui.MUTE, true);
        rn.setPadding(0, dp(10), 0, dp(4));
        radial.addView(rn);
        radial.addView(Ui.seek(this, 22, cv.radialN - 2, new Ui.Seek() {
            void change(int v) { cv.radialN = v + 2; rn.setText("Fatias: " + cv.radialN); cv.invalidate(); }
        }));
        LinearLayout mr = Ui.row(this);
        mr.setPadding(0, dp(8), 0, 0);
        final Button mb = chip("Espelhar cada fatia (mandala)", cv.radialMirror, null);
        mb.setOnClickListener(v -> { cv.radialMirror = !cv.radialMirror; Ui.sel(mb, cv.radialMirror); });
        mr.addView(mb);
        radial.addView(mr);
        s.add(radial);
        re[0].run();
        s.section("Guias de desenho");
        LinearLayout gr = Ui.row(this);
        String[] gs = {"Nenhuma", "Grade", "Perspectiva 1 ponto", "Perspectiva 2 pontos", "Isométrica"};
        final Runnable[] rg = new Runnable[1];
        rg[0] = () -> {
            gr.removeAllViews();
            for (int i = 0; i < gs.length; i++) {
                final int fi = i;
                gr.addView(chip(gs[i], cv.guide == i, v -> { cv.guide = fi; cv.invalidate(); rg[0].run(); }));
            }
        };
        rg[0].run();
        s.add(wrapH(gr));
        LinearLayout sn = Ui.row(this);
        sn.setPadding(0, dp(10), 0, 0);
        final Button snb = chip("Régua: travar traço na guia", cv.snapGuide, null);
        snb.setOnClickListener(v -> { cv.snapGuide = !cv.snapGuide; Ui.sel(snb, cv.snapGuide); });
        sn.addView(snb);
        s.add(sn);
        TextView t = Ui.text(this, "Para mover os pontos de fuga, use a ferramenta Guias e arraste na tela.", 11.5f, Ui.MUTE, false);
        t.setPadding(0, dp(10), 0, 0);
        s.add(t);
        s.setOnDismissListener(d -> buildOptions());
        s.show();
    }

    /* ================================================================ texto */

    private void textSheet(final float x, final float y) {
        final Sheet s = new Sheet(this, "Texto");
        final EditText e = HomeActivity.input(this, "Escreva aqui…");
        e.setSingleLine(false);
        e.setMinLines(2);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        s.add(e);
        final String[] fonts = {"Padrão", "Negrito", "Serifa", "Mono", "Manuscrita", "Condensada"};
        final int[] font = {1};
        final int[] size = {Math.max(24, Math.round(Math.min(p.w, p.h) / 14f))};
        final boolean[] outline = {false};
        s.section("Fonte");
        final LinearLayout fr = Ui.row(this);
        final Runnable[] rf = new Runnable[1];
        rf[0] = () -> {
            fr.removeAllViews();
            for (int i = 0; i < fonts.length; i++) {
                final int fi = i;
                Button b = chip(fonts[i], font[0] == i, v -> { font[0] = fi; rf[0].run(); });
                b.setTypeface(face(i));
                fr.addView(b);
            }
        };
        rf[0].run();
        s.add(wrapH(fr));
        final TextView sl = Ui.text(this, "Tamanho: " + size[0] + " px", 12.5f, Ui.MUTE, true);
        sl.setPadding(0, dp(12), 0, dp(4));
        s.add(sl);
        s.add(Ui.seek(this, 400, size[0] - 8, new Ui.Seek() { void change(int v) { size[0] = v + 8; sl.setText("Tamanho: " + size[0] + " px"); } }));
        LinearLayout o = Ui.row(this);
        o.setPadding(0, dp(10), 0, 0);
        final Button ob = chip("Contorno branco", false, null);
        ob.setOnClickListener(v -> { outline[0] = !outline[0]; Ui.sel(ob, outline[0]); });
        o.addView(ob);
        s.add(o);
        Button ok = Ui.btn(this, "Inserir texto");
        Ui.sel(ok, true);
        LinearLayout.LayoutParams okl = new LinearLayout.LayoutParams(Ui.MATCH, dp(46));
        okl.topMargin = dp(14);
        s.add(ok, okl);
        ok.setOnClickListener(v -> {
            String t = e.getText().toString();
            if (t.trim().isEmpty()) { s.dismiss(); return; }
            Bitmap b = renderText(t, face(font[0]), size[0], cv.color, outline[0]);
            s.dismiss();
            if (cv.layer().locked) { Ui.toast(this, "Camada bloqueada"); return; }
            if (cv.addLayer("Texto") == null) return;
            cv.startFloating(b, x, y);
        });
        s.show();
        e.requestFocus();
    }

    private Typeface face(int i) {
        switch (i) {
            case 1: return Typeface.create(Typeface.DEFAULT, Typeface.BOLD);
            case 2: return Typeface.create(Typeface.SERIF, Typeface.BOLD);
            case 3: return Typeface.MONOSPACE;
            case 4: return Typeface.create("casual", Typeface.NORMAL);
            case 5: return Typeface.create("sans-serif-condensed", Typeface.BOLD);
            default: return Typeface.DEFAULT;
        }
    }

    private Bitmap renderText(String text, Typeface tf, int size, int color, boolean outline) {
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(tf);
        tp.setTextSize(size);
        tp.setColor(color);
        String[] lines = text.split("\n");
        float w = 1;
        for (String l : lines) w = Math.max(w, tp.measureText(l));
        Paint.FontMetrics fm = tp.getFontMetrics();
        float lh = (fm.descent - fm.ascent) * 1.1f;
        int pad = outline ? Math.round(size * .12f) + 4 : 4;
        Bitmap b = Bitmap.createBitmap(Math.max(1, Math.round(w) + pad * 2), Math.max(1, Math.round(lh * lines.length) + pad * 2), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        for (int i = 0; i < lines.length; i++) {
            float yy = pad - fm.ascent + i * lh;
            if (outline) {
                Paint op = new Paint(tp);
                op.setStyle(Paint.Style.STROKE);
                op.setStrokeWidth(size * .16f);
                op.setStrokeJoin(Paint.Join.ROUND);
                op.setColor(0xFFFFFFFF);
                c.drawText(lines[i], pad, yy, op);
            }
            c.drawText(lines[i], pad, yy, tp);
        }
        return b;
    }

    /* ================================================================ linha do tempo (como na 5.0) */

    private View buildTimeline() {
        LinearLayout t = Ui.col(this);
        t.setBackgroundColor(Ui.PANEL);
        t.setPadding(dp(8), dp(4), dp(8), dp(6));
        LinearLayout bar = Ui.row(this);
        LinearLayout fps = Ui.row(this);
        fps.setBackground(Ui.bg(Ui.PANEL2, dp(10)));
        TextView dn = Ui.text(this, "−", 18, Ui.MUTE, true);
        dn.setGravity(Gravity.CENTER);
        dn.setOnClickListener(v -> setFps(p.fps - 1));
        fps.addView(dn, new LinearLayout.LayoutParams(dp(28), dp(34)));
        fpsTv = Ui.mono(this, p.fps + " fps", 13, Ui.FG);
        fpsTv.setGravity(Gravity.CENTER);
        fpsTv.setOnClickListener(v -> togglePop("anim", this::animSheet));
        fps.addView(fpsTv, new LinearLayout.LayoutParams(dp(54), dp(34)));
        TextView up = Ui.text(this, "+", 18, Ui.MUTE, true);
        up.setGravity(Gravity.CENTER);
        up.setOnClickListener(v -> setFps(p.fps + 1));
        fps.addView(up, new LinearLayout.LayoutParams(dp(28), dp(34)));
        bar.addView(fps);
        loopB = cap("loop", v -> {
            boolean on = !Prefs.on(this, "loop", true);
            Prefs.set(this, "loop", on);
            loopB.setImageDrawable(Ui.icon(this, "loop", on ? Ui.ACC : Ui.MUTE));
            Ui.toast(this, on ? "Repetir ligado" : "Toca uma vez só");
        });
        loopB.setImageDrawable(Ui.icon(this, "loop", Prefs.on(this, "loop", true) ? Ui.ACC : Ui.MUTE));
        bar.addView(loopB);
        // espaçador: altura fixa, senão ele estica e esconde a tela de desenho
        bar.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        bar.addView(cap("prev", v -> { if (cv.frameIdx > 0) { cv.goFrame(cv.frameIdx - 1); refreshTimeline(); } }));
        bar.addView(cap("next", v -> { if (cv.frameIdx < p.frames.size() - 1) { cv.goFrame(cv.frameIdx + 1); refreshTimeline(); } }));
        bar.addView(cap("copy", v -> { cv.addFrame(true); refreshTimeline(); }));
        final ImageView del = cap("trash", null);
        final boolean[] armed = {false};
        del.setOnClickListener(v -> {
            if (!armed[0]) {
                armed[0] = true;
                del.setBackground(Ui.bg(Ui.ACC, dp(10)));
                del.setImageDrawable(Ui.icon(this, "trash", 0xFFFFFFFF));
                Ui.toast(this, "Toque de novo para apagar o quadro");
                ui.postDelayed(() -> { armed[0] = false; del.setBackground(null); del.setImageDrawable(Ui.icon(this, "trash", Ui.MUTE)); }, 2200);
                return;
            }
            armed[0] = false;
            del.setBackground(null);
            del.setImageDrawable(Ui.icon(this, "trash", Ui.MUTE));
            cv.deleteFrame();
            refreshTimeline();
        });
        bar.addView(del);
        LinearLayout add = Ui.row(this);
        add.setGravity(Gravity.CENTER);
        add.setPadding(dp(10), 0, dp(12), 0);
        add.setBackground(Ui.bg(Ui.ACC, dp(10)));
        add.addView(Ui.iconView(this, "plus", 0xFFFFFFFF, 18));
        TextView at = Ui.text(this, "Novo", 12, 0xFFFFFFFF, true);
        at.setPadding(dp(4), 0, 0, 0);
        add.addView(at);
        add.setOnClickListener(v -> { cv.addFrame(false); refreshTimeline(); });
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(Ui.WRAP, dp(38));
        al.leftMargin = dp(4);
        bar.addView(Ui.pressable(add), al);
        t.addView(bar);
        HorizontalScrollView fs = new HorizontalScrollView(this);
        fs.setHorizontalScrollBarEnabled(false);
        frameRow = Ui.row(this);
        frameRow.setPadding(dp(2), dp(6), dp(2), dp(2));
        fs.addView(frameRow);
        t.addView(fs);
        return t;
    }

    private ImageView cap(String icon, View.OnClickListener l) {
        ImageView b = new ImageView(this);
        b.setImageDrawable(Ui.icon(this, icon, Ui.MUTE));
        b.setPadding(dp(9), dp(9), dp(9), dp(9));
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
        b.setOnClickListener(l);
        return Ui.pressable(b);
    }

    private void setFps(int f) {
        p.fps = Ui.clamp(f, 1, 60);
        p.save();
        if (fpsTv != null) fpsTv.setText(p.fps + " fps");
    }

    void refreshTimeline() {
        updateCounter();
        if (fpsTv != null) fpsTv.setText(p.fps + " fps");
        if (frameRow == null) return;
        frameRow.removeAllViews();
        boolean land = getResources().getDisplayMetrics().widthPixels > getResources().getDisplayMetrics().heightPixels * 1.15f;
        float ar = p.w / (float) p.h;
        int fh = land ? 38 : 47;
        int fw = Math.round(Ui.clampf(fh * ar, 30, 96));
        for (int i = 0; i < p.frames.size(); i++) {
            final int fi = i;
            final int fid = p.frames.get(i);
            FrameLayout f = new FrameLayout(this);
            boolean on = i == cv.frameIdx;
            GradientDrawable g = Ui.bg((p.paper >>> 24) == 0 ? 0xFFE6E8EE : p.paper, dp(6));
            g.setStroke(dp(on ? 2 : 1), on ? Ui.ACC : Ui.LINE);
            f.setBackground(g);
            f.setPadding(dp(on ? 2 : 1), dp(on ? 2 : 1), dp(on ? 2 : 1), dp(on ? 2 : 1));
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_XY);
            Bitmap tb = frameThumbs.get(fid);
            if (tb != null) iv.setImageBitmap(tb);
            else if (!frameThumbs.containsKey(fid)) loadFrameThumb(fid);
            f.addView(iv, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            TextView n = Ui.mono(this, String.valueOf(i + 1), 10, 0xFFFFFFFF);
            n.setPadding(dp(4), 0, dp(4), 0);
            n.setBackground(Ui.bg(0x99000000, dp(4)));
            FrameLayout.LayoutParams nl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.START);
            nl.setMargins(dp(3), 0, 0, dp(2));
            f.addView(n, nl);
            int hold = p.hold(fid);
            if (hold > 1) {
                TextView hv = Ui.mono(this, "×" + hold, 9.5f, 0xFFFFFFFF);
                hv.setPadding(dp(4), 0, dp(4), 0);
                hv.setBackground(Ui.bg(Ui.VIOLET, dp(4)));
                FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP | Gravity.END);
                hl.setMargins(0, dp(2), dp(3), 0);
                f.addView(hv, hl);
            }
            f.setOnClickListener(v -> {
                if (fi == cv.frameIdx) { togglePop("frame", this::frameMenu); return; }
                cv.goFrame(fi);
                refreshTimeline();
            });
            f.setOnLongClickListener(v -> { if (fi != cv.frameIdx) { cv.goFrame(fi); refreshTimeline(); } togglePop("frame", this::frameMenu); return true; });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(dp(fw), dp(fh));
            l.rightMargin = dp(8);
            frameRow.addView(f, l);
        }
        final int cur = cv.frameIdx;
        frameRow.post(() -> {
            if (frameRow.getChildCount() > cur && frameRow.getParent() instanceof HorizontalScrollView) {
                View c = frameRow.getChildAt(cur);
                HorizontalScrollView hs = (HorizontalScrollView) frameRow.getParent();
                int x = c.getLeft() - hs.getWidth() / 2 + c.getWidth() / 2;
                hs.smoothScrollTo(Math.max(0, x), 0);
            }
        });
    }

    private void loadFrameThumb(final int fid) {
        frameThumbs.put(fid, null);
        cv.io.execute(() -> {
            final Bitmap b = p.composite(fid, 140, true);
            ui.post(() -> {
                Bitmap old = frameThumbs.put(fid, b);
                if (old != null && old != b) old.recycle();
                refreshTimeline();
            });
        });
    }

    private void refreshCurrentThumb() {
        if (frameRow == null || cv.frameIdx >= p.frames.size()) return;
        int fid = cv.frameId();
        Bitmap b = cv.renderComposite(140, true);
        Bitmap old = frameThumbs.put(fid, b);
        if (old != null) old.recycle();
        refreshTimeline();
    }

    private void frameMenu() {
        final Pop s = new Pop("Quadro " + (cv.frameIdx + 1) + " de " + p.frames.size());
        s.key = "frame";
        LinearLayout r1 = Ui.row(this);
        r1.addView(chip("◀ Mover", false, v -> { cv.moveFrame(-1); refreshTimeline(); }));
        r1.addView(chip("Mover ▶", false, v -> { cv.moveFrame(1); refreshTimeline(); }));
        r1.addView(chip("Duplicar", false, v -> { cv.addFrame(true); refreshTimeline(); s.dismiss(); }));
        r1.addView(chip("Novo depois", false, v -> { cv.addFrame(false); refreshTimeline(); s.dismiss(); }));
        r1.addView(chip("Limpar camada", false, v -> cv.clearLayer(cv.active)));
        s.add(wrapH(r1), gapB(8));
        s.add(prow("Segurar", 1, 12, p.hold(cv.frameId()), "×", v -> { cv.setHold(v); refreshTimeline(); }));
        s.show();
    }

    /** Painel "Animação" da 5.0: papel de seda, tempo, quadros, guias e simetria. */
    private void animSheet() {
        final Pop s = new Pop("Animação");
        s.key = "anim";
        s.section("Papel de seda (fantasma)");
        s.add(prow("Antes", 0, 4, cv.onionPrev, "", v -> { cv.onionPrev = v; Prefs.put(this, "onPrev", v); cv.refreshOnion(); cv.invalidate(); }));
        s.add(prow("Depois", 0, 4, cv.onionNext, "", v -> { cv.onionNext = v; Prefs.put(this, "onNext", v); cv.refreshOnion(); cv.invalidate(); }));
        s.add(prow("Força", 20, 200, Math.round(cv.onionAlpha / .35f), "%", v -> { cv.onionAlpha = Ui.clamp(Math.round(v * .35f), 5, 95); Prefs.put(this, "onAlpha", cv.onionAlpha); cv.invalidate(); }));
        LinearLayout oc = Ui.row(this);
        final Button cb = chip("Colorido (vermelho/verde)", cv.onionColor, null);
        cb.setOnClickListener(v -> { cv.onionColor = !cv.onionColor; Prefs.set(this, "onColor", cv.onionColor); Ui.sel(cb, cv.onionColor); cv.invalidate(); });
        oc.addView(cb);
        s.add(oc);
        s.section("Tempo");
        s.add(prow("Velocidade", 1, 60, p.fps, " fps", v -> setFps(v)));
        s.add(prow("Segurar quadro", 1, 12, p.hold(cv.frameId()), "×", v -> { cv.setHold(v); refreshTimeline(); }));
        LinearLayout pr = Ui.row(this);
        final Button pb = chip(Prefs.on(this, "pingpong", false) ? "Ida e volta: ligado" : "Ida e volta: desligado", Prefs.on(this, "pingpong", false), null);
        pb.setOnClickListener(v -> { boolean on = !Prefs.on(this, "pingpong", false); Prefs.set(this, "pingpong", on); Ui.sel(pb, on); pb.setText(on ? "Ida e volta: ligado" : "Ida e volta: desligado"); });
        pr.addView(pb);
        s.add(pr);
        s.section("Quadros");
        LinearLayout q1 = Ui.row(this);
        q1.addView(chip("◀ Mover", false, v -> { cv.moveFrame(-1); refreshTimeline(); }));
        q1.addView(chip("Mover ▶", false, v -> { cv.moveFrame(1); refreshTimeline(); }));
        q1.addView(chip("Limpar quadro", false, v -> cv.clearLayer(cv.active)));
        s.add(wrapH(q1), gapB(6));
        LinearLayout q2 = Ui.row(this);
        for (int n : new int[]{5, 12, 24}) q2.addView(chip("+" + n + " quadros", false, v -> { cv.addFrames(n); refreshTimeline(); Ui.toast(this, n + " quadros novos"); }));
        s.add(wrapH(q2));
        s.section("Guias");
        LinearLayout g = Ui.row(this);
        String[] gs = {"Nenhuma", "Grade", "Terços", "Centro", "Perspectiva"};
        int[] gv = {0, 1, 5, 6, 2};
        final ArrayList<Button> gb = new ArrayList<>();
        for (int i = 0; i < gs.length; i++) {
            final int val = gv[i];
            Button b = chip(gs[i], cv.guide == val, null);
            b.setOnClickListener(v -> { cv.guide = val; cv.invalidate(); for (int k = 0; k < gb.size(); k++) Ui.sel(gb.get(k), gv[k] == val); });
            gb.add(b);
            g.addView(b);
        }
        s.add(wrapH(g));
        s.section("Simetria de desenho");
        LinearLayout sy = Ui.row(this);
        String[] ss = {"Espelhar horizontal", "Espelhar vertical", "Quatro lados", "Desligar"};
        int[] sv = {1, 2, 3, 0};
        final ArrayList<Button> sb = new ArrayList<>();
        for (int i = 0; i < ss.length; i++) {
            final int val = sv[i];
            Button b = chip(ss[i], cv.symMode == val, null);
            b.setOnClickListener(v -> { cv.symMode = val; cv.invalidate(); for (int k = 0; k < sb.size(); k++) Ui.sel(sb.get(k), sv[k] == val); buildOptions(); });
            sb.add(b);
            sy.addView(b);
        }
        s.add(wrapH(sy));
        s.show();
    }

    /* ---------------- reprodução ---------------- */

    private ArrayList<Bitmap> playFrames;
    private ArrayList<Integer> playDur;
    private int playPos, playDir = 1;

    private void play() {
        if (!p.anim || playing) return;
        cv.commitFloating();
        cv.saveCurrent();
        playing = true;
        if (playB != null) playB.setImageDrawable(Ui.icon(this, "pause", 0xFFFFFFFF));
        if (pop != null) pop.dismiss();
        Ui.toast(this, "Preparando…");
        final int n = p.frames.size();
        final float k = (float) Math.min(1, Math.sqrt(40e6 / ((double) n * p.w * p.h)));
        final int side = Math.max(64, Math.min(1080, Math.round(Math.max(p.w, p.h) * k)));
        cv.io.execute(() -> {
            final ArrayList<Bitmap> fr = new ArrayList<>();
            final ArrayList<Integer> du = new ArrayList<>();
            for (int i = 0; i < n && playing; i++) {
                int fid = p.frames.get(i);
                fr.add(p.composite(fid, side, true));
                du.add(p.hold(fid));
            }
            ui.post(() -> {
                if (!playing) { for (Bitmap b : fr) b.recycle(); return; }
                playFrames = fr;
                playDur = du;
                playPos = 0;
                playDir = 1;
                playCover = new View(this);
                playCover.setOnClickListener(v -> stopPlay());
                stage.addView(playCover, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
                tick.run();
            });
        });
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!playing || playFrames == null || playFrames.isEmpty()) return;
            cv.playBmp = playFrames.get(playPos);
            cv.invalidate();
            int d = playDur.get(playPos);
            int n = playFrames.size();
            if (counterTv != null) counterTv.setText((playPos + 1) + " / " + n);
            if (Prefs.on(EditorActivity.this, "pingpong", false) && n > 1) {
                if (playPos + playDir >= n || playPos + playDir < 0) playDir = -playDir;
                playPos += playDir;
            } else if (playPos + 1 >= n && !Prefs.on(EditorActivity.this, "loop", true)) {
                ui.postDelayed(EditorActivity.this::stopPlay, Math.max(16, 1000L * d / Math.max(1, p.fps)));
                return;
            } else playPos = (playPos + 1) % n;
            ui.postDelayed(this, Math.max(16, 1000L * d / Math.max(1, p.fps)));
        }
    };

    private void stopPlay() {
        if (!playing) return;
        playing = false;
        ui.removeCallbacks(tick);
        cv.playBmp = null;
        if (playFrames != null) for (Bitmap b : playFrames) b.recycle();
        playFrames = null;
        if (playCover != null) { if (playCover.getParent() != null) ((android.view.ViewGroup) playCover.getParent()).removeView(playCover); playCover = null; }
        updateCounter();
        if (playB != null) playB.setImageDrawable(Ui.icon(this, "play", 0xFFFFFFFF));
        cv.invalidate();
    }

    /* ================================================================ menu "Projeto" (exportar, papel, fundos) */

    private void menuSheet() {
        cv.commitFloating();
        if (pop != null) pop.dismiss();
        final Sheet s = new Sheet(this, p.anim ? "Exportar animação" : "Exportar desenho");
        TextView inf = Ui.mono(this, "Exporta em " + p.w + "×" + p.h + " px" + (p.anim ? " · " + p.frames.size() + " quadros · " + p.fps + " fps" : ""), 11.5f, Ui.MUTE);
        s.add(inf);
        if (p.anim) {
            s.section("Animação");
            LinearLayout a1 = Ui.row(this);
            a1.addView(chip("Vídeo MP4", true, v -> { s.dismiss(); exportVideo(720); }));
            a1.addView(chip("MP4 1080p", false, v -> { s.dismiss(); exportVideo(1080); }));
            a1.addView(chip("GIF animado", false, v -> { s.dismiss(); exportGif(480, false); }));
            a1.addView(chip("GIF grande", false, v -> { s.dismiss(); exportGif(720, false); }));
            a1.addView(chip("GIF transparente", false, v -> { s.dismiss(); exportGif(480, true); }));
            s.add(wrapH(a1), gapB(6));
            LinearLayout a2 = Ui.row(this);
            a2.addView(chip("Sequência PNG (.zip)", false, v -> { s.dismiss(); exportSequence(); }));
            a2.addView(chip("Folha de sprites", false, v -> { s.dismiss(); exportSprites(); }));
            s.add(wrapH(a2));
        }
        s.section(p.anim ? "Quadro atual" : "Imagem");
        LinearLayout r1 = Ui.row(this);
        r1.addView(chip("PNG", !p.anim, v -> { s.dismiss(); exportImage("png", 1, false); }));
        r1.addView(chip("JPG", false, v -> { s.dismiss(); exportImage("jpg", 1, false); }));
        r1.addView(chip("PNG transparente", false, v -> { s.dismiss(); exportImage("pngT", 1, false); }));
        r1.addView(chip("PNG 2×", false, v -> { s.dismiss(); exportImage("png", 2, false); }));
        r1.addView(chip("Camadas (.zip)", false, v -> { s.dismiss(); exportLayers(); }));
        s.add(wrapH(r1), gapB(6));
        LinearLayout r2 = Ui.row(this);
        r2.addView(chip("Compartilhar", false, v -> { s.dismiss(); exportImage("png", 1, true); }));
        r2.addView(chip("Vídeo time-lapse", false, v -> { s.dismiss(); exportTimelapse(); }));
        s.add(wrapH(r2));

        s.section("Papel");
        ArrayList<Integer> cols = new ArrayList<>();
        for (int c : HomeActivity.PAPERS) cols.add(c);
        s.add(swatches(cols, c -> { p.paper = c; p.save(); cv.invalidate(); frameThumbs.clear(); refreshTimeline(); }, null));
        LinearLayout pr = Ui.row(this);
        pr.addView(chip("Transparente", (p.paper >>> 24) == 0, v -> { p.paper = 0; p.save(); cv.invalidate(); s.dismiss(); }));
        pr.addView(chip("Cor atual", false, v -> { p.paper = cv.color; p.save(); cv.invalidate(); s.dismiss(); }));
        s.add(wrapH(pr));

        s.section("Fundos de estúdio · " + Backgrounds.NAMES.length + " cenários");
        final LinearLayout grid = Ui.col(this);
        s.add(grid);
        final int per = 5;
        final float ar = p.w / (float) p.h;
        final int tw = 120, th = Math.max(40, Math.min(200, Math.round(tw / ar)));
        final ArrayList<ImageView> cells = new ArrayList<>();
        LinearLayout row = null;
        for (int i = 0; i < Backgrounds.NAMES.length; i++) {
            if (i % per == 0) { row = Ui.row(this); grid.addView(row, gapB(6)); }
            final int fi = i;
            LinearLayout cell = Ui.col(this);
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(Ui.bg(Ui.PANEL2, dp(8)));
            iv.setClipToOutline(true);
            cell.addView(iv, new LinearLayout.LayoutParams(Ui.MATCH, dp(46)));
            TextView n = Ui.text(this, Backgrounds.NAMES[i], 9, Ui.MUTE, false);
            n.setSingleLine(true);
            n.setEllipsize(TextUtils.TruncateAt.END);
            n.setPadding(0, dp(2), 0, 0);
            cell.addView(n);
            cell.setOnClickListener(v -> applyStudio(fi));
            cells.add(iv);
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, Ui.WRAP, 1);
            if (i % per > 0) l.leftMargin = dp(6);
            row.addView(Ui.pressable(cell), l);
        }
        work.execute(() -> {
            for (int i = 0; i < cells.size(); i++) {
                final Bitmap b = Backgrounds.make(i, tw, th);
                final ImageView iv = cells.get(i);
                ui.post(() -> iv.setImageBitmap(b));
            }
        });
        LinearLayout bgr = Ui.row(this);
        bgr.setPadding(0, dp(4), 0, 0);
        bgr.addView(chip("Imagem de fundo…", false, v -> { s.dismiss(); pickImage(REQ_BG); }));
        bgr.addView(chip("Remover imagem", false, v -> { cv.setBgImage(null); frameThumbs.clear(); refreshTimeline(); Ui.toast(this, "Fundo removido"); }));
        s.add(wrapH(bgr));

        s.section("Preferências");
        s.add(toggleRow("twoUndo", true, "2 dedos desfaz · 3 dedos refaz"), gapB(6));
        s.add(toggleRow("longPick", true, "Segurar o dedo pega a cor"), gapB(6));
        s.add(toggleRow("rotate", true, "Girar a tela com 2 dedos"), gapB(6));
        s.add(toggleRow("tlapse", true, "Gravar time-lapse"), gapB(6));
        LinearLayout r5 = Ui.row(this);
        r5.setPadding(0, dp(8), 0, 0);
        r5.addView(chip("Renomear projeto", false, v -> { s.dismiss(); renameProject(); }));
        r5.addView(chip("Ver dicas de novo", false, v -> { s.dismiss(); tips(); }));
        r5.addView(chip("Quadrinhos (HQ)", false, v -> { s.dismiss(); comicSheet(); }));
        s.add(wrapH(r5));
        final Button wipe = chip("Apagar todos os desenhos", false, null);
        final boolean[] armed = {false};
        wipe.setOnClickListener(v -> {
            if (!armed[0]) { armed[0] = true; wipe.setText("Toque de novo: apaga tudo"); Ui.sel(wipe, true); return; }
            s.dismiss();
            wipeAll();
        });
        LinearLayout r6 = Ui.row(this);
        r6.setPadding(0, dp(10), 0, 0);
        r6.addView(wipe);
        s.add(r6);
        Button close = Ui.btn(this, "Fechar");
        close.setBackground(null);
        close.setTextColor(Ui.MUTE);
        close.setOnClickListener(v -> s.dismiss());
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        cl.gravity = Gravity.END;
        s.add(close, cl);
        s.show();
    }

    private void applyStudio(final int i) {
        Ui.toast(this, "Aplicando \"" + Backgrounds.NAMES[i] + "\"…");
        work.execute(() -> {
            Bitmap b = Backgrounds.make(i, p.w, p.h);
            p.setBg(b);
            ui.post(() -> { cv.bgBmp = p.bg(); cv.invalidate(); frameThumbs.clear(); refreshTimeline(); });
        });
    }

    /** Ajusta a imagem escolhida ao tamanho da tela (preencher, inteira ou esticar). */
    private Bitmap fitBg(Bitmap src, int mode) {
        Bitmap out = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        float sx = p.w / (float) src.getWidth(), sy = p.h / (float) src.getHeight();
        android.graphics.RectF d;
        if (mode == 2) d = new android.graphics.RectF(0, 0, p.w, p.h);
        else {
            float k = mode == 0 ? Math.max(sx, sy) : Math.min(sx, sy);
            float w = src.getWidth() * k, h = src.getHeight() * k;
            d = new android.graphics.RectF((p.w - w) / 2, (p.h - h) / 2, (p.w + w) / 2, (p.h + h) / 2);
            if (mode == 1) c.drawColor((p.paper >>> 24) == 0 ? 0xFFFFFFFF : p.paper);
        }
        c.drawBitmap(src, null, d, new Paint(Paint.FILTER_BITMAP_FLAG));
        return out;
    }

    private void wipeAll() {
        cv.commitFloating();
        cv.flush();
        for (int f : p.frames) for (Project.Layer l : p.layers) p.layerFile(f, l.id).delete();
        for (Bitmap b : cv.bm.values()) if (b != null) b.eraseColor(0);
        cv.clearHistory();
        cv.clearOnionCache();
        for (Bitmap b : frameThumbs.values()) if (b != null) b.recycle();
        frameThumbs.clear();
        cv.saveCurrent();
        cv.invalidate();
        refreshTimeline();
        Ui.toast(this, "Todos os desenhos foram apagados");
    }

    private void pickVideo() {
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.setType("video/*");
        it.addCategory(Intent.CATEGORY_OPENABLE);
        try { startActivityForResult(Intent.createChooser(it, "Escolher vídeo"), REQ_VID); }
        catch (Exception e) { Ui.toast(this, "Não há app de vídeos"); }
    }

    /** Rotoscopia: separa o vídeo em quadros numa camada "Vídeo" (embaixo, meio transparente). */
    private void importVideo(final Uri u) {
        if (busy) return;
        cv.commitFloating();
        cv.saveCurrent();
        busy("Lendo vídeo…");
        final int fps = p.fps;
        work.execute(() -> {
            android.media.MediaMetadataRetriever mr = new android.media.MediaMetadataRetriever();
            try {
                mr.setDataSource(this, u);
                String ds = mr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION);
                long dur = ds == null ? 0 : Long.parseLong(ds);
                final int n = (int) Math.max(1, Math.min(120, dur * fps / 1000));
                final int[] lid = new int[1];
                final int start = cv.frameIdx;
                final Object lock = new Object();
                final boolean[] ready = {false};
                ui.post(() -> {
                    if (p.layers.size() >= p.maxLayers()) { lid[0] = -1; }
                    else {
                        Project.Layer l = new Project.Layer();
                        l.id = p.nextLayer++;
                        l.name = "Vídeo";
                        l.opacity = 150;
                        l.locked = true;
                        p.layers.add(0, l);
                        cv.active++;
                        lid[0] = l.id;
                        while (p.frames.size() < start + n) p.frames.add(p.nextFrame++);
                        p.save();
                    }
                    synchronized (lock) { ready[0] = true; lock.notifyAll(); }
                });
                synchronized (lock) { while (!ready[0]) lock.wait(); }
                if (lid[0] < 0) { fail("Limite de camadas: apague uma camada antes"); return; }
                for (int i = 0; i < n; i++) {
                    step("Separando quadros… " + (i + 1) + "/" + n);
                    Bitmap fr = mr.getFrameAtTime(i * 1_000_000L / fps, android.media.MediaMetadataRetriever.OPTION_CLOSEST);
                    if (fr == null) continue;
                    Bitmap fit = fitBg(fr, 1);
                    fr.recycle();
                    Project.writePng(fit, p.layerFile(p.frames.get(start + i), lid[0]));
                    fit.recycle();
                }
                ui.post(() -> {
                    busy = false;
                    if (progress != null) { root.removeView(progress); progress = null; }
                    cv.loadFrame(cv.frameIdx);
                    for (Bitmap b : frameThumbs.values()) if (b != null) b.recycle();
                    frameThumbs.clear();
                    refreshTimeline();
                    refreshLayerBar();
                    Ui.toast(this, n + " quadros importados na camada \"Vídeo\" (bloqueada)");
                });
            } catch (Throwable e) {
                fail("Não consegui ler esse vídeo");
            } finally {
                try { mr.release(); } catch (Exception ignored) { }
            }
        });
    }

    private View toggleRow(final String key, boolean def, String title) {
        LinearLayout r = Ui.row(this);
        r.setPadding(dp(12), dp(8), dp(8), dp(8));
        r.setBackground(Ui.bgStroke(Ui.PANEL2, Ui.LINE, dp(12), dp(1)));
        r.addView(Ui.text(this, title, 13, Ui.FG, true), Ui.lpw(1));
        final android.widget.Switch sw = new android.widget.Switch(this);
        sw.setChecked(Prefs.on(this, key, def));
        sw.setOnCheckedChangeListener((b, on) -> Prefs.set(this, key, on));
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        return r;
    }

    private void renameProject() {
        final Sheet s = new Sheet(this, "Nome do projeto");
        final EditText e = HomeActivity.input(this, "Nome");
        e.setText(p.name);
        s.add(e);
        Button ok = Ui.btn(this, "Salvar");
        Ui.sel(ok, true);
        ok.setOnClickListener(v -> {
            String n = e.getText().toString().trim();
            if (!n.isEmpty()) { p.name = n.length() > 40 ? n.substring(0, 40) : n; p.save(); }
            s.dismiss();
        });
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        l.gravity = Gravity.END;
        l.topMargin = dp(12);
        s.add(ok, l);
        s.show();
    }

    private void paperSheet() {
        final Sheet s = new Sheet(this, "Fundo (papel)");
        ArrayList<Integer> cols = new ArrayList<>();
        for (int c : HomeActivity.PAPERS) cols.add(c);
        s.add(swatches(cols, c -> { p.paper = c; p.save(); cv.invalidate(); }, null));
        LinearLayout r = Ui.row(this);
        r.setPadding(0, dp(10), 0, 0);
        r.addView(chip("Transparente", (p.paper >>> 24) == 0, v -> { p.paper = 0; p.save(); cv.invalidate(); s.dismiss(); }));
        r.addView(chip("Usar a cor atual", false, v -> { p.paper = cv.color; p.save(); cv.invalidate(); s.dismiss(); }));
        s.add(r);
        s.show();
    }

    private void comicSheet() {
        final Sheet s = new Sheet(this, "Quadros de HQ");
        String[] names = {"2 faixas", "3 faixas", "4 quadros", "1 + 2", "5 quadros", "6 quadros"};
        LinearLayout r = Ui.row(this);
        for (int i = 0; i < names.length; i++) {
            final int fi = i;
            r.addView(chip(names[i], false, v -> { s.dismiss(); cv.comicPanels(fi, .025f, Math.max(3, Math.min(p.w, p.h) / 220f)); Ui.toast(this, "Camada de quadros criada"); }));
        }
        s.add(wrapH(r));
        TextView t = Ui.text(this, "Os contornos ficam numa camada própria. Use o balde em \"Todas as camadas\" para pintar cada quadro.", 11.5f, Ui.MUTE, false);
        t.setPadding(0, dp(10), 0, 0);
        s.add(t);
        s.show();
    }

    private void tips() {
        Prefs.set(this, "tipSeen", true);
        final Sheet s = new Sheet(this, "Dicas rápidas");
        String[] tips = {
                "✌️  Toque com 2 dedos para desfazer, 3 dedos para refazer.",
                "🤏  Pinça para zoom; gire com 2 dedos (ímã a cada 90°).",
                "🎯  Segure o dedo parado para pegar a cor (conta-gotas).",
                "⭕  Segure no fim do traço: vira reta, círculo, retângulo… (QuickShape).",
                "🖌️  Toque de novo no pincel para abrir a biblioteca com +60 pincéis.",
                "🎨  Segure a bolinha de cor para trocar com a 2ª cor.",
                "🧲  Guias: grade, perspectiva e isométrica, com régua que trava o traço.",
                "🪞  Simetria vertical, horizontal, 4 lados e radial (mandala).",
                "📼  Tudo vira time-lapse: Menu › Time-lapse.",
        };
        for (String t : tips) {
            TextView v = Ui.text(this, t, 13.5f, Ui.FG, false);
            v.setPadding(0, dp(6), 0, dp(6));
            v.setLineSpacing(0, 1.2f);
            s.add(v);
        }
        Button ok = Ui.btn(this, "Entendi");
        Ui.sel(ok, true);
        ok.setOnClickListener(v -> s.dismiss());
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        l.gravity = Gravity.END;
        l.topMargin = dp(10);
        s.add(ok, l);
        s.show();
    }

    /* ================================================================ imagens (importar e referência) */

    private void pickImage(int req) {
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.setType("image/*");
        it.addCategory(Intent.CATEGORY_OPENABLE);
        try { startActivityForResult(Intent.createChooser(it, "Escolher imagem"), req); }
        catch (Exception e) { Ui.toast(this, "Não há app de galeria"); }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        if (req == REQ_VID) { importVideo(data.getData()); return; }
        try {
            Bitmap b = decode(data.getData(), req == REQ_REF ? 1600 : Project.MAX_SIDE);
            if (b == null) { Ui.toast(this, "Não consegui ler a imagem"); return; }
            if (!b.isMutable()) { Bitmap m = b.copy(Bitmap.Config.ARGB_8888, true); b.recycle(); b = m; }
            if (req == REQ_IMPORT) { cv.importImage(b); onHistory(); refreshLayerBar(); }
            else if (req == REQ_BG) {
                Bitmap fit = fitBg(b, Prefs.num(this, "bgFit", 0));
                b.recycle();
                cv.setBgImage(fit);
                frameThumbs.clear();
                refreshTimeline();
                Ui.toast(this, "Fundo da tela aplicado");
            }
            else if (req == REQ_REF) showReference(b);
        } catch (Throwable e) {
            Ui.toast(this, "Não consegui abrir a imagem");
        }
    }

    private Bitmap decode(Uri uri, int maxSide) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream in = getContentResolver().openInputStream(uri);
        BitmapFactory.decodeStream(in, null, o);
        if (in != null) in.close();
        int ss = 1;
        while (Math.max(o.outWidth, o.outHeight) / (ss * 2) >= maxSide) ss *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = ss;
        o2.inPreferredConfig = Bitmap.Config.ARGB_8888;
        in = getContentResolver().openInputStream(uri);
        Bitmap b = BitmapFactory.decodeStream(in, null, o2);
        if (in != null) in.close();
        return b;
    }

    /** Janela de referência flutuante: arraste pela barra, toque na imagem para pegar a cor. */
    private void showReference(Bitmap b) {
        if (refWin != null) { stage.removeView(refWin); if (refBmp != null) refBmp.recycle(); }
        refBmp = b;
        refWin = new FrameLayout(this);
        refWin.setBackground(Ui.bgStroke(Ui.PANEL, Ui.LINE, dp(14), dp(1)));
        refWin.setElevation(dp(12));
        refWin.setPadding(dp(4), dp(4), dp(4), dp(4));
        LinearLayout col = Ui.col(this);
        LinearLayout bar = Ui.row(this);
        bar.setPadding(dp(8), 0, 0, 0);
        TextView t = Ui.text(this, "Referência", 12, Ui.MUTE, true);
        bar.addView(t, Ui.lpw(1));
        final int[] wdp = {200};
        bar.addView(smallIcon("down", v -> resizeRef(wdp, -40)));
        bar.addView(smallIcon("up", v -> resizeRef(wdp, 40)));
        bar.addView(smallIcon("trash", v -> { stage.removeView(refWin); refWin = null; if (refBmp != null) { refBmp.recycle(); refBmp = null; } }));
        col.addView(bar);
        final ImageView iv = new ImageView(this);
        iv.setImageBitmap(b);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setAdjustViewBounds(true);
        iv.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
            float vw = v.getWidth(), vh = v.getHeight();
            float k = Math.min(vw / b.getWidth(), vh / b.getHeight());
            float ox = (vw - b.getWidth() * k) / 2, oy = (vh - b.getHeight() * k) / 2;
            int x = (int) ((e.getX() - ox) / k), y = (int) ((e.getY() - oy) / k);
            if (x >= 0 && y >= 0 && x < b.getWidth() && y < b.getHeight()) {
                int c = b.getPixel(x, y);
                if ((c >>> 24) > 0) { setColor(c, true); Ui.toast(this, "Cor " + Ui.hex(c)); }
            }
            return true;
        });
        col.addView(iv, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        refWin.addView(col);
        FrameLayout.LayoutParams l = new FrameLayout.LayoutParams(dp(wdp[0]), Ui.WRAP, Gravity.TOP | Gravity.END);
        l.setMargins(0, dp(52), dp(12), 0);
        stage.addView(refWin, l);
        final float[] d = new float[2];
        bar.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { d[0] = e.getRawX() - refWin.getTranslationX(); d[1] = e.getRawY() - refWin.getTranslationY(); }
            else if (e.getActionMasked() == MotionEvent.ACTION_MOVE) { refWin.setTranslationX(e.getRawX() - d[0]); refWin.setTranslationY(e.getRawY() - d[1]); }
            return true;
        });
    }

    private void resizeRef(int[] wdp, int delta) {
        if (refWin == null) return;
        wdp[0] = Ui.clamp(wdp[0] + delta, 120, 420);
        ViewGroup.LayoutParams l = refWin.getLayoutParams();
        l.width = dp(wdp[0]);
        refWin.setLayoutParams(l);
    }

    /* ================================================================ exportar */

    private void exportSheet() { menuSheet(); }

    private boolean needPerm(Runnable r) {
        if (Build.VERSION.SDK_INT >= 29) return false;
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) return false;
        pendingPerm = r;
        requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_PERM);
        return true;
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_PERM && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && pendingPerm != null) pendingPerm.run();
        else if (req == REQ_PERM) Ui.toast(this, "Sem permissão para salvar");
        pendingPerm = null;
    }

    private String baseName() {
        String n = p.name.replaceAll("[^A-Za-z0-9À-ÿ _-]", "").trim().replace(' ', '_');
        if (n.isEmpty()) n = "DarkMonia";
        return n + "_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }

    private File tmp(String name) {
        File d = new File(getCacheDir(), "export");
        d.mkdirs();
        return new File(d, name);
    }

    private TextView progress;

    private void busy(String text) {
        busy = true;
        if (progress == null) {
            progress = Ui.text(this, text, 14, 0xFFFFFFFF, true);
            progress.setPadding(dp(22), dp(16), dp(22), dp(16));
            progress.setBackground(Ui.bgStroke(Ui.PANEL, Ui.LINE, dp(16), dp(1)));
            progress.setElevation(dp(20));
            progress.setClickable(true);
            root.addView(progress, new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER));
        }
        progress.setText(text);
    }

    private void step(final String text) { ui.post(() -> { if (progress != null) progress.setText(text); }); }

    /** Chamado na thread de trabalho: publica o arquivo e mostra o resultado. */
    private void done(final File f, final String name, final boolean share) {
        Uri pub = null;
        String err = null;
        if (f != null) {
            try { pub = Media.publish(this, f, name); } catch (Exception e) { err = e.getMessage(); }
            f.delete();
        }
        final Uri u = pub;
        final String error = f == null ? "Não consegui exportar" : err;
        ui.post(() -> {
            busy = false;
            if (progress != null) { root.removeView(progress); progress = null; }
            if (error != null) { Ui.toast(this, "Erro ao salvar: " + error); return; }
            if (share) { Media.share(this, u, Media.mime(name)); return; }
            final Sheet s = new Sheet(this, "Salvo ✓");
            TextView t = Ui.text(this, name + "\n" + Media.where(name), 13, Ui.MUTE, false);
            t.setLineSpacing(0, 1.25f);
            s.add(t);
            LinearLayout r = Ui.row(this);
            r.setPadding(0, dp(14), 0, 0);
            if (u != null) r.addView(chip("Compartilhar", true, v -> { s.dismiss(); Media.share(this, u, Media.mime(name)); }));
            r.addView(chip("Fechar", false, v -> s.dismiss()));
            s.add(r);
            s.show();
        });
    }

    private void fail(final String why) {
        ui.post(() -> {
            busy = false;
            if (progress != null) { root.removeView(progress); progress = null; }
            Ui.toast(this, why);
        });
    }

    private void exportImage(final String kind, final int scale, final boolean share) {
        if (busy || needPerm(() -> exportImage(kind, scale, share))) return;
        boolean transparent = kind.equals("pngT");
        final boolean jpg = kind.equals("jpg");
        Bitmap b = cv.renderComposite(Math.max(p.w, p.h), !transparent || jpg);
        if (jpg && (p.paper >>> 24) == 0) {
            Bitmap w = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(w);
            c.drawColor(0xFFFFFFFF);
            c.drawBitmap(b, 0, 0, null);
            b.recycle();
            b = w;
        }
        if (scale > 1) {
            Bitmap s = Bitmap.createScaledBitmap(b, b.getWidth() * scale, b.getHeight() * scale, true);
            b.recycle();
            b = s;
        }
        final Bitmap fb = b;
        final String name = baseName() + (jpg ? ".jpg" : ".png");
        busy("Salvando imagem…");
        work.execute(() -> {
            File f = tmp(name);
            try {
                FileOutputStream out = new FileOutputStream(f);
                fb.compress(jpg ? Bitmap.CompressFormat.JPEG : Bitmap.CompressFormat.PNG, jpg ? 95 : 100, out);
                out.close();
                fb.recycle();
                done(f, name, share);
            } catch (Exception e) { fail("Não consegui salvar"); }
        });
    }

    private void exportLayers() {
        if (busy || needPerm(this::exportLayers)) return;
        cv.saveCurrent();
        final String name = baseName() + "_camadas.zip";
        final int fid = cv.frameId();
        busy("Juntando camadas…");
        cv.io.execute(() -> {
            File f = tmp(name);
            try {
                ZipOutputStream z = new ZipOutputStream(new FileOutputStream(f));
                int i = 1;
                for (Project.Layer l : p.layers) {
                    File lf = p.layerFile(fid, l.id);
                    String safe = l.name.replaceAll("[^A-Za-z0-9À-ÿ _-]", "_");
                    z.putNextEntry(new ZipEntry(String.format(Locale.US, "%02d_%s.png", i++, safe)));
                    if (lf.exists()) {
                        java.io.FileInputStream in = new java.io.FileInputStream(lf);
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) z.write(buf, 0, n);
                        in.close();
                    } else {
                        Bitmap e = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
                        e.compress(Bitmap.CompressFormat.PNG, 100, z);
                        e.recycle();
                    }
                    z.closeEntry();
                }
                Bitmap all = p.composite(fid, Math.max(p.w, p.h), true);
                z.putNextEntry(new ZipEntry("final.png"));
                all.compress(Bitmap.CompressFormat.PNG, 100, z);
                z.closeEntry();
                all.recycle();
                z.close();
                done(f, name, false);
            } catch (Exception e) { fail("Não consegui exportar as camadas"); }
        });
    }

    /** Lista de quadros já com as durações (exposição) e o modo vai-e-volta. */
    private ArrayList<int[]> sequence() {
        ArrayList<int[]> seq = new ArrayList<>();
        for (int i = 0; i < p.frames.size(); i++) seq.add(new int[]{i, p.hold(p.frames.get(i))});
        if (Prefs.on(this, "pingpong", false) && seq.size() > 2)
            for (int i = p.frames.size() - 2; i >= 1; i--) seq.add(new int[]{i, p.hold(p.frames.get(i))});
        return seq;
    }

    private void exportGif(final int side, final boolean transparent) {
        if (busy || needPerm(() -> exportGif(side, transparent))) return;
        cv.saveCurrent();
        final String name = baseName() + ".gif";
        final ArrayList<int[]> seq = sequence();
        busy("Criando GIF…");
        cv.io.execute(() -> {
            File f = tmp(name);
            try {
                FileOutputStream out = new FileOutputStream(f);
                float k = Math.min(1f, side / (float) Math.max(p.w, p.h));
                int w = Math.max(1, Math.round(p.w * k)), h = Math.max(1, Math.round(p.h * k));
                GifEncoder g = new GifEncoder(new java.io.BufferedOutputStream(out, 1 << 16), w, h, 0);
                int[] px = new int[w * h];
                for (int i = 0; i < seq.size(); i++) {
                    step("Criando GIF… " + (i + 1) + "/" + seq.size());
                    int[] e = seq.get(i);
                    Bitmap b = p.composite(p.frames.get(e[0]), side, !transparent);
                    Bitmap s = b.getWidth() == w && b.getHeight() == h ? b : Bitmap.createScaledBitmap(b, w, h, true);
                    s.getPixels(px, 0, w, 0, 0, w, h);
                    if (s != b) s.recycle();
                    b.recycle();
                    g.addFrame(px, Math.round(100f * e[1] / Math.max(1, p.fps)));
                }
                g.finish();
                out.close();
                done(f, name, false);
            } catch (Throwable e) { fail("Não consegui criar o GIF"); }
        });
    }

    private void exportVideo(final int side) {
        if (busy || needPerm(() -> exportVideo(side))) return;
        cv.saveCurrent();
        final String name = baseName() + ".mp4";
        final ArrayList<int[]> seq = sequence();
        busy("Criando vídeo…");
        cv.io.execute(() -> {
            File f = tmp(name);
            VideoEncoder ve = null;
            try {
                int[] sz = VideoEncoder.size(p.w, p.h, side);
                ve = new VideoEncoder(f, sz[0], sz[1], p.fps);
                Bitmap frame = Bitmap.createBitmap(sz[0], sz[1], Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(frame);
                Paint fp = new Paint(Paint.FILTER_BITMAP_FLAG);
                android.graphics.RectF dst = new android.graphics.RectF(0, 0, sz[0], sz[1]);
                int total = 0;
                for (int[] e : seq) total += e[1];
                int done = 0;
                // vídeos muito curtos somem em alguns players: repete até ~1 s
                int reps = Math.max(1, (int) Math.ceil(p.fps / (float) Math.max(1, total)));
                for (int r = 0; r < reps; r++)
                    for (int[] e : seq) {
                        Bitmap b = p.composite(p.frames.get(e[0]), Math.max(sz[0], sz[1]), true);
                        c.drawColor((p.paper >>> 24) == 0 ? 0xFFFFFFFF : p.paper);
                        c.drawBitmap(b, null, dst, fp);
                        b.recycle();
                        for (int k = 0; k < e[1]; k++) ve.add(frame);
                        done += e[1];
                        step("Criando vídeo… " + Math.min(100, done * 100 / Math.max(1, total * reps)) + "%");
                    }
                ve.finish();
                ve = null;
                frame.recycle();
                done(f, name, false);
            } catch (Throwable e) {
                if (ve != null) ve.abort();
                fail("Este aparelho não conseguiu criar o MP4. Tente o GIF.");
            }
        });
    }

    private void exportSequence() {
        if (busy || needPerm(this::exportSequence)) return;
        cv.saveCurrent();
        final String name = baseName() + "_quadros.zip";
        busy("Juntando quadros…");
        cv.io.execute(() -> {
            File f = tmp(name);
            try {
                ZipOutputStream z = new ZipOutputStream(new FileOutputStream(f));
                for (int i = 0; i < p.frames.size(); i++) {
                    step("Quadro " + (i + 1) + "/" + p.frames.size());
                    Bitmap b = p.composite(p.frames.get(i), Math.max(p.w, p.h), true);
                    z.putNextEntry(new ZipEntry(String.format(Locale.US, "quadro_%04d.png", i + 1)));
                    b.compress(Bitmap.CompressFormat.PNG, 100, z);
                    z.closeEntry();
                    b.recycle();
                }
                z.close();
                done(f, name, false);
            } catch (Throwable e) { fail("Não consegui exportar"); }
        });
    }

    private void exportSprites() {
        if (busy || needPerm(this::exportSprites)) return;
        cv.saveCurrent();
        final String name = baseName() + "_sprites.png";
        busy("Montando folha de sprites…");
        cv.io.execute(() -> {
            File f = tmp(name);
            try {
                int n = p.frames.size();
                int cols = (int) Math.ceil(Math.sqrt(n)), rows = (int) Math.ceil(n / (float) cols);
                int cell = Math.min(512, Math.max(p.w, p.h));
                float k = cell / (float) Math.max(p.w, p.h);
                int cw = Math.max(1, Math.round(p.w * k)), ch = Math.max(1, Math.round(p.h * k));
                Bitmap sheet = Bitmap.createBitmap(cw * cols, ch * rows, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(sheet);
                for (int i = 0; i < n; i++) {
                    Bitmap b = p.composite(p.frames.get(i), cell, false);
                    c.drawBitmap(b, null, new android.graphics.RectF((i % cols) * cw, (i / cols) * ch, (i % cols + 1) * cw, (i / cols + 1) * ch), new Paint(Paint.FILTER_BITMAP_FLAG));
                    b.recycle();
                }
                FileOutputStream out = new FileOutputStream(f);
                sheet.compress(Bitmap.CompressFormat.PNG, 100, out);
                out.close();
                sheet.recycle();
                done(f, name, false);
            } catch (Throwable e) { fail("Não consegui montar a folha"); }
        });
    }

    private void exportTimelapse() {
        if (busy || needPerm(this::exportTimelapse)) return;
        cv.saveCurrent();
        if (p.tl < 2) { Ui.toast(this, "Ainda não há passos gravados. Desenhe um pouco!"); return; }
        final String name = baseName() + "_timelapse.mp4";
        busy("Criando time-lapse…");
        cv.io.execute(() -> {
            File f = tmp(name);
            VideoEncoder ve = null;
            try {
                int[] sz = VideoEncoder.size(p.w, p.h, 720);
                ve = new VideoEncoder(f, sz[0], sz[1], 30);
                Bitmap frame = Bitmap.createBitmap(sz[0], sz[1], Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(frame);
                Paint fp = new Paint(Paint.FILTER_BITMAP_FLAG);
                android.graphics.RectF dst = new android.graphics.RectF(0, 0, sz[0], sz[1]);
                int n = p.tl;
                // no máximo ~40 s: pula passos se tiver muitos
                int stepN = Math.max(1, n / 1200);
                for (int i = 0; i < n; i += stepN) {
                    File tf = p.tlFile(i);
                    if (!tf.exists()) continue;
                    Bitmap b = BitmapFactory.decodeFile(tf.getPath());
                    if (b == null) continue;
                    c.drawColor(0xFFFFFFFF);
                    c.drawBitmap(b, null, dst, fp);
                    b.recycle();
                    ve.add(frame);
                    if (i % 30 == 0) step("Time-lapse… " + (i * 100 / n) + "%");
                }
                Bitmap last = p.composite(cv.frameId(), Math.max(sz[0], sz[1]), true);
                c.drawColor(0xFFFFFFFF);
                c.drawBitmap(last, null, dst, fp);
                last.recycle();
                for (int k = 0; k < 60; k++) ve.add(frame);
                ve.finish();
                ve = null;
                frame.recycle();
                done(f, name, false);
            } catch (Throwable e) {
                if (ve != null) ve.abort();
                fail("Não consegui criar o time-lapse neste aparelho");
            }
        });
    }

    /* ================================================================ peças visuais */

    /** Bolinha da cor atual. */
    static class ColorDot extends View {
        private int c;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), r = new Paint(Paint.ANTI_ALIAS_FLAG);
        ColorDot(android.content.Context ctx) {
            super(ctx);
            r.setStyle(Paint.Style.STROKE);
            r.setStrokeWidth(Ui.dp(ctx, 3));
            r.setColor(0xFFFFFFFF);
        }
        void set(int col) { c = col; invalidate(); }
        @Override protected void onDraw(Canvas cv) {
            float rr = Math.min(getWidth(), getHeight()) / 2f - Ui.dp(getContext(), 3);
            p.setColor(c);
            cv.drawCircle(getWidth() / 2f, getHeight() / 2f, rr, p);
            cv.drawCircle(getWidth() / 2f, getHeight() / 2f, rr, r);
        }
    }

    /** Controle deslizante vertical (tamanho / opacidade), como na lateral do Procreate. */
    static class VSlider extends View {
        interface L { void on(float v, boolean done); }
        L l;
        private float v = .3f;
        private final String label;
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG), knob = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        VSlider(android.content.Context c, String label) {
            super(c);
            this.label = label;
            track.setColor(0xFF2A2E44);
            knob.setColor(0xFFFFFFFF);
            txt.setColor(Ui.MUTE);
            txt.setTextSize(Ui.dp(c, 8.5f));
            txt.setTextAlign(Paint.Align.CENTER);
        }
        void set(float x) { v = Ui.clampf(x, 0, 1); invalidate(); }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), pad = Ui.dp(getContext(), 6), tw = Ui.dp(getContext(), 8);
            float top = pad, bot = h - pad - Ui.dp(getContext(), 12);
            float cx = w / 2;
            c.drawRoundRect(cx - tw / 2, top, cx + tw / 2, bot, tw / 2, tw / 2, track);
            float y = bot - (bot - top) * v;
            fill.setColor(Ui.ACC);
            c.drawRoundRect(cx - tw / 2, y, cx + tw / 2, bot, tw / 2, tw / 2, fill);
            c.drawRoundRect(cx - w / 2 + 2, y - Ui.dp(getContext(), 5), cx + w / 2 - 2, y + Ui.dp(getContext(), 5), Ui.dp(getContext(), 5), Ui.dp(getContext(), 5), knob);
            c.drawText(label, cx, h - Ui.dp(getContext(), 2), txt);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            float pad = Ui.dp(getContext(), 6);
            float top = pad, bot = getHeight() - pad - Ui.dp(getContext(), 12);
            v = Ui.clampf((bot - e.getY()) / (bot - top), 0, 1);
            int a = e.getActionMasked();
            boolean done = a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL;
            if (l != null) l.on(v, done);
            invalidate();
            return true;
        }
    }
}
