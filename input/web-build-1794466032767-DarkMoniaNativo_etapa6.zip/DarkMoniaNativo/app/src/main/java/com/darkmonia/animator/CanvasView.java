package com.darkmonia.animator;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** A tela de desenho: camadas, pincéis, seleção, transformação, preenchimento, liquidificar, gestos. */
public class CanvasView extends View {
    static final int T_BRUSH = 0, T_ERASER = 1, T_FILL = 2, T_PICK = 3, T_HAND = 4, T_SELECT = 5, T_TRANSFORM = 6,
            T_SHAPE = 7, T_GRADIENT = 8, T_TEXT = 9, T_LIQUIFY = 10, T_CLONE = 11, T_RECOLOR = 12, T_LASSOFILL = 13,
            T_LASSOERASE = 14, T_GUIDES = 15;

    interface Listener {
        void onColorPicked(int c);
        void onChanged();
        void onSelection(boolean has);
        void onTransform(boolean on);
        void onMessage(String s);
        void onTextAt(float x, float y);
        void onHistory();
    }

    Project p;
    Listener listener;
    int frameIdx = 0, active = 0;

    /* ---- ajustes das ferramentas ---- */
    int tool = T_BRUSH;
    String brushId = "gpen";
    float brushSize = 10, eraserSize = 30;
    int opacity = 100, eraserOpacity = 100, color = 0xFF16161D, color2 = 0xFFFFFFFF;
    String eraserType = "e_round";
    int stabilizer = 15;
    int symMode = 0, radialN = 6;
    boolean radialMirror = false;
    int selMode = 0, selOp = 0;
    int shapeType = 0, polySides = 5;
    boolean shapeFill = false;
    int fillTol = 30, fillGap = 0, fillExpand = 1;
    boolean fillAll = true;
    int gradType = 0;
    boolean gradTwo = false;
    int liqMode = 0, liqStrength = 50;
    float liqSize = 80;
    int recolorTol = 60;
    int guide = 0, gridSize = 64;
    boolean snapGuide = false;
    float vp1x, vp1y, vp2x, vp2y;
    boolean onion = true, onionColor = true;
    int onionPrev = 1, onionNext = 1, onionAlpha = 35;
    Bitmap playBmp;
    boolean drawOnly;

    /* ---- dados ---- */
    final HashMap<Integer, Bitmap> bm = new HashMap<>();
    private final java.util.HashSet<Integer> dirty = new java.util.HashSet<>();
    private Bitmap strokeBmp;
    private Canvas strokeCv;
    final Render.Live live = new Render.Live();
    private final Paint strokePaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Brushes.Engine eng = new Brushes.Engine();
    final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler h = new Handler(Looper.getMainLooper());
    private final HashMap<Integer, Bitmap> onionCache = new HashMap<>();

    /* ---- seleção ---- */
    Bitmap selMask;
    Path selPath;
    private final Path drawPath = new Path();
    private final ArrayList<float[]> polyPts = new ArrayList<>();
    Bitmap clipboard;

    /* ---- transformação ---- */
    Bitmap flt;
    private Bitmap liftBackup;
    private int liftLayer = -1;
    final float[] fsrc = new float[8], fdst = new float[8];
    private final float[] fdst0 = new float[8];
    final Matrix fm = new Matrix();
    int tfMode = 0;
    private int tfHandle = -1;

    /* ---- desfazer ---- */
    private static final class Undo {
        int frameId, layerId;
        Rect r;
        Bitmap before, after;
        long bytes() {
            long b = 0;
            if (before != null) b += (long) before.getWidth() * before.getHeight() * 4;
            if (after != null) b += (long) after.getWidth() * after.getHeight() * 4;
            return b;
        }
    }
    private final ArrayList<Undo> undo = new ArrayList<>(), redo = new ArrayList<>();
    private final long budget = Math.min(Runtime.getRuntime().maxMemory() / 5, 220L * 1024 * 1024);

    /* ---- vista ---- */
    final Matrix m = new Matrix();
    private final Matrix inv = new Matrix(), m0 = new Matrix();
    private final RectF full = new RectF();
    private final float[] tmp = new float[2];

    /* ---- pinturas ---- */
    private final Paint bgShadow = new Paint(Paint.ANTI_ALIAS_FLAG), paperP = new Paint(), checkP = new Paint();
    private final Paint onionP = new Paint(Paint.FILTER_BITMAP_FLAG), plain = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint antsW = new Paint(Paint.ANTI_ALIAS_FLAG), antsB = new Paint(Paint.ANTI_ALIAS_FLAG), selTint = new Paint();
    private final Paint guideP = new Paint(Paint.ANTI_ALIAS_FLAG), handleP = new Paint(Paint.ANTI_ALIAS_FLAG), handleS = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cursorP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint softMaskP = new Paint(Paint.FILTER_BITMAP_FLAG);

    public CanvasView(Context c) {
        super(c);
        bgShadow.setColor(0x66000000);
        antsW.setStyle(Paint.Style.STROKE);
        antsW.setColor(0xFFFFFFFF);
        antsB.setStyle(Paint.Style.STROKE);
        antsB.setColor(0xFF111111);
        guideP.setStyle(Paint.Style.STROKE);
        handleP.setColor(0xFFFFFFFF);
        handleS.setStyle(Paint.Style.STROKE);
        handleS.setStrokeWidth(Ui.dp(c, 2));
        cursorP.setStyle(Paint.Style.STROKE);
        cursorP.setStrokeWidth(Ui.dp(c, 1.2f));
        Bitmap ck = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888);
        ck.setPixel(0, 0, 0xFFFFFFFF); ck.setPixel(1, 1, 0xFFFFFFFF);
        ck.setPixel(1, 0, 0xFFD5D8E0); ck.setPixel(0, 1, 0xFFD5D8E0);
        BitmapShader cs = new BitmapShader(ck, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        Matrix cm = new Matrix();
        cm.setScale(Ui.dp(c, 9), Ui.dp(c, 9));
        cs.setLocalMatrix(cm);
        checkP.setShader(cs);
    }

    /* ================================================================ projeto e quadros */

    void setProject(Project pr) {
        p = pr;
        full.set(0, 0, p.w, p.h);
        strokeBmp = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
        strokeCv = new Canvas(strokeBmp);
        vp1x = p.w / 2f; vp1y = p.h * .42f;
        vp2x = p.w * 1.15f; vp2y = p.h * .42f;
        active = Math.max(0, p.layers.size() - 1);
        loadFrame(0);
        post(this::fitView);
    }

    int frameId() { return p.frames.get(frameIdx); }

    Project.Layer layer() { return p.layers.get(Ui.clamp(active, 0, p.layers.size() - 1)); }

    void loadFrame(int idx) {
        frameIdx = Ui.clamp(idx, 0, p.frames.size() - 1);
        for (Bitmap b : bm.values()) if (b != null) b.recycle();
        bm.clear();
        dirty.clear();
        int fid = frameId();
        for (Project.Layer l : p.layers) {
            Bitmap b = p.loadLayer(fid, l.id);
            if (b != null) bm.put(l.id, b);
        }
        refreshOnion();
        invalidate();
    }

    void goFrame(int idx) {
        if (idx == frameIdx) return;
        commitFloating();
        saveCurrent();
        loadFrame(idx);
    }

    /** Grava as camadas alteradas em segundo plano. */
    void saveCurrent() {
        if (p == null) return;
        final int fid = frameId();
        for (int id : dirty) {
            Bitmap b = bm.get(id);
            final java.io.File f = p.layerFile(fid, id);
            if (b == null) { io.execute(f::delete); continue; }
            final Bitmap copy = b.copy(Bitmap.Config.ARGB_8888, false);
            io.execute(() -> { Project.writePng(copy, f); copy.recycle(); });
        }
        boolean changed = !dirty.isEmpty();
        dirty.clear();
        if (changed) {
            onionCache.remove(fid);
            p.updated = System.currentTimeMillis();
        }
        final Bitmap th = renderComposite(320, true);
        final java.io.File tf = p.thumbFile();
        io.execute(() -> { Project.writePng(th, tf); th.recycle(); });
        p.save();
    }

    /** Espera tudo ser gravado no disco. */
    void flush() {
        try {
            Future<?> f = io.submit(() -> { });
            f.get();
        } catch (Exception ignored) { }
    }

    Bitmap renderComposite(int maxSide, boolean withPaper) {
        float k = Math.min(1f, maxSide / (float) Math.max(p.w, p.h));
        int w = Math.max(1, Math.round(p.w * k)), hh = Math.max(1, Math.round(p.h * k));
        Bitmap out = Bitmap.createBitmap(w, hh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        if (withPaper && (p.paper >>> 24) != 0) c.drawColor(p.paper);
        c.scale(k, k);
        Render.stack(c, p, bm, flt != null ? live : null);
        return out;
    }

    /** Imagem de qualquer quadro (o atual vem da memória). */
    Bitmap frameImage(int idx, int maxSide, boolean withPaper) {
        if (idx == frameIdx) return renderComposite(maxSide, withPaper);
        flush();
        return p.composite(p.frames.get(idx), maxSide, withPaper);
    }

    void refreshOnion() {
        if (p == null || !p.anim) return;
        final ArrayList<Integer> want = new ArrayList<>();
        for (int k = 1; k <= 3; k++) {
            if (frameIdx - k >= 0) want.add(p.frames.get(frameIdx - k));
            if (frameIdx + k < p.frames.size()) want.add(p.frames.get(frameIdx + k));
        }
        ArrayList<Integer> drop = new ArrayList<>();
        for (int id : onionCache.keySet()) if (!want.contains(id)) drop.add(id);
        for (int id : drop) { Bitmap b = onionCache.remove(id); if (b != null) b.recycle(); }
        for (final int id : want) {
            if (onionCache.containsKey(id)) continue;
            onionCache.put(id, null);
            io.execute(() -> {
                final Bitmap b = p.composite(id, 1024, false);
                h.post(() -> {
                    if (onionCache.containsKey(id)) { onionCache.put(id, b); invalidate(); }
                    else b.recycle();
                });
            });
        }
    }

    void clearOnionCache() {
        for (Bitmap b : onionCache.values()) if (b != null) b.recycle();
        onionCache.clear();
        refreshOnion();
    }

    void markDirty(int layerId) {
        dirty.add(layerId);
        if (listener != null) listener.onChanged();
    }

    Bitmap ensure(int layerId) {
        Bitmap b = bm.get(layerId);
        if (b == null) {
            b = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
            bm.put(layerId, b);
        }
        return b;
    }

    boolean activeLocked() {
        Project.Layer l = layer();
        if (l.locked) { msg("Camada bloqueada 🔒"); return true; }
        if (!l.visible) { msg("Camada escondida — mostre para desenhar"); return true; }
        return false;
    }

    private void msg(String s) { if (listener != null) listener.onMessage(s); }

    /* ================================================================ desfazer / refazer */

    private Rect clampRect(float l, float t, float r, float b) {
        Rect rc = new Rect((int) Math.floor(l), (int) Math.floor(t), (int) Math.ceil(r), (int) Math.ceil(b));
        if (!rc.intersect(0, 0, p.w, p.h)) return null;
        return rc;
    }

    private static Bitmap crop(Bitmap src, Rect r) {
        if (src == null) return null;
        return Bitmap.createBitmap(src, r.left, r.top, r.width(), r.height());
    }

    /** Guarda a região antes de mudar (chame ANTES de desenhar na camada). */
    void record(int layerId, Rect r) {
        if (r == null || r.isEmpty()) return;
        Undo u = new Undo();
        u.frameId = frameId();
        u.layerId = layerId;
        u.r = new Rect(r);
        u.before = crop(bm.get(layerId), r);
        push(u);
    }

    void recordFull(int layerId) { record(layerId, new Rect(0, 0, p.w, p.h)); }

    private void recordFrom(int layerId, Bitmap backup, Rect r) {
        if (r == null || r.isEmpty()) return;
        Undo u = new Undo();
        u.frameId = frameId();
        u.layerId = layerId;
        u.r = new Rect(r);
        u.before = crop(backup, r);
        push(u);
    }

    private void push(Undo u) {
        undo.add(u);
        for (Undo x : redo) recycle(x);
        redo.clear();
        trim();
        if (listener != null) listener.onHistory();
    }

    private void recycle(Undo u) {
        if (u.before != null) u.before.recycle();
        if (u.after != null) u.after.recycle();
    }

    private void trim() {
        long total = 0;
        for (Undo u : undo) total += u.bytes();
        for (Undo u : redo) total += u.bytes();
        while ((total > budget && undo.size() > 2) || undo.size() > 80) {
            Undo u = undo.remove(0);
            total -= u.bytes();
            recycle(u);
        }
    }

    boolean canUndo() { return !undo.isEmpty(); }
    boolean canRedo() { return !redo.isEmpty(); }

    void clearHistory() {
        for (Undo u : undo) recycle(u);
        for (Undo u : redo) recycle(u);
        undo.clear();
        redo.clear();
        if (listener != null) listener.onHistory();
    }

    private boolean swap(ArrayList<Undo> from, ArrayList<Undo> to) {
        while (!from.isEmpty()) {
            Undo u = from.remove(from.size() - 1);
            int fi = p.frames.indexOf(u.frameId);
            boolean hasLayer = false;
            for (Project.Layer l : p.layers) if (l.id == u.layerId) hasLayer = true;
            if (fi < 0 || !hasLayer) { recycle(u); continue; }
            if (fi != frameIdx) goFrame(fi);
            Bitmap cur = bm.get(u.layerId);
            Bitmap now = crop(cur, u.r);
            Bitmap target = ensure(u.layerId);
            Canvas c = new Canvas(target);
            c.save();
            c.clipRect(u.r);
            c.drawColor(0, PorterDuff.Mode.CLEAR);
            if (u.before != null) c.drawBitmap(u.before, u.r.left, u.r.top, null);
            c.restore();
            Bitmap restore = u.before;
            u.before = now;
            u.after = null;
            if (restore != null) restore.recycle();
            to.add(u);
            markDirty(u.layerId);
            invalidate();
            if (listener != null) listener.onHistory();
            return true;
        }
        if (listener != null) listener.onHistory();
        return false;
    }

    boolean undo() {
        if (flt != null) { cancelFloating(); return true; }
        return swap(undo, redo);
    }

    boolean redo() { return swap(redo, undo); }

    /* ================================================================ vista */

    void fitView() {
        if (p == null || getWidth() == 0) return;
        float pad = Ui.dp(getContext(), 20);
        float k = Math.min((getWidth() - pad * 2) / p.w, (getHeight() - pad * 2) / p.h);
        m.reset();
        m.postScale(k, k);
        m.postTranslate((getWidth() - p.w * k) / 2f, (getHeight() - p.h * k) / 2f);
        invalidate();
    }

    void zoom100() {
        if (p == null) return;
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float s = scale();
        m.postScale(1f / s, 1f / s, cx, cy);
        invalidate();
    }

    void flipView() {
        m.postScale(-1, 1, getWidth() / 2f, getHeight() / 2f);
        invalidate();
    }

    float scale() {
        float[] v = {1, 0};
        m.mapVectors(v);
        return (float) Math.hypot(v[0], v[1]);
    }

    float rotation() {
        float[] v = {1, 0};
        m.mapVectors(v);
        return (float) Math.toDegrees(Math.atan2(v[1], v[0]));
    }

    private float[] toCanvas(float x, float y) {
        m.invert(inv);
        float[] q = {x, y};
        inv.mapPoints(q);
        return q;
    }

    private float[] toView(float x, float y) {
        float[] q = {x, y};
        m.mapPoints(q);
        return q;
    }

    /* ================================================================ desenho na tela */

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (ow == 0 || oh == 0) fitView();
        else { m.postTranslate((w - ow) / 2f, (h - oh) / 2f); invalidate(); }
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(Ui.BG);
        if (p == null) return;
        float s = scale();
        c.save();
        c.concat(m);
        float sh = Ui.dp(getContext(), 6) / s;
        c.drawRect(sh * .3f, sh, p.w + sh * .3f, p.h + sh, bgShadow);
        if ((p.paper >>> 24) == 0) {
            c.save();
            c.clipRect(full);
            c.drawPaint(checkP);
            c.restore();
        } else {
            paperP.setColor(p.paper);
            c.drawRect(full, paperP);
        }
        c.save();
        c.clipRect(full);
        if (playBmp != null) {
            c.drawBitmap(playBmp, null, full, plain);
        } else {
            if (p.anim && onion) drawOnion(c);
            live.layerId = flt != null ? liftLayer : live.replace != null ? filterLayer : layer().id;
            live.mask = selMask;
            if (live.stroke == null && live.floating == null && live.replace == null) Render.stack(c, p, bm, null);
            else Render.stack(c, p, bm, live);
        }
        c.restore();
        if (playBmp == null) {
            drawSelection(c, s);
            drawGuides(c, s);
            drawSymmetry(c, s);
            drawToolPreview(c, s);
        }
        c.restore();
        if (playBmp == null && flt != null) drawHandles(c);
        if (hoverX >= 0 && (tool == T_BRUSH || tool == T_ERASER || tool == T_LIQUIFY || tool == T_CLONE || tool == T_RECOLOR)) {
            float r = (tool == T_ERASER ? eraserSize : tool == T_LIQUIFY ? liqSize : brushSize) * s / 2;
            cursorP.setColor(0xCCFFFFFF);
            c.drawCircle(hoverX, hoverY, Math.max(2, r), cursorP);
            cursorP.setColor(0x88000000);
            c.drawCircle(hoverX, hoverY, Math.max(2, r) + 1.2f, cursorP);
        }
        if (cloneSet && tool == T_CLONE) {
            float[] v = toView(cloneX, cloneY);
            cursorP.setColor(0xFF22C3A6);
            c.drawCircle(v[0], v[1], Ui.dp(getContext(), 10), cursorP);
            c.drawLine(v[0] - Ui.dp(getContext(), 15), v[1], v[0] + Ui.dp(getContext(), 15), v[1], cursorP);
            c.drawLine(v[0], v[1] - Ui.dp(getContext(), 15), v[0], v[1] + Ui.dp(getContext(), 15), cursorP);
        }
        if (picking) {
            float r = Ui.dp(getContext(), 34);
            float y = Math.max(r + 8, pickVY - Ui.dp(getContext(), 70));
            handleP.setColor(pickColor);
            c.drawCircle(pickVX, y, r, handleP);
            handleS.setColor(0xFFFFFFFF);
            c.drawCircle(pickVX, y, r, handleS);
            handleP.setColor(0xFFFFFFFF);
        }
    }

    private void drawOnion(Canvas c) {
        for (int k = Math.max(onionPrev, onionNext); k >= 1; k--) {
            float a = onionAlpha / 100f * (1f - (k - 1) * .3f);
            if (k <= onionPrev && frameIdx - k >= 0) onionLayer(c, p.frames.get(frameIdx - k), 0xFFE5476B, a);
            if (k <= onionNext && frameIdx + k < p.frames.size()) onionLayer(c, p.frames.get(frameIdx + k), 0xFF22C3A6, a);
        }
    }

    private void onionLayer(Canvas c, int fid, int tint, float a) {
        Bitmap b = onionCache.get(fid);
        if (b == null) return;
        onionP.setColorFilter(onionColor ? new PorterDuffColorFilter(tint, PorterDuff.Mode.SRC_IN) : null);
        onionP.setAlpha(Math.round(Ui.clampf(a, 0, 1) * 255));
        c.drawBitmap(b, null, full, onionP);
    }

    private void drawSelection(Canvas c, float s) {
        if (selMask != null && flt == null) {
            selTint.setColor((Ui.ACC & 0xFFFFFF) | 0x2E000000);
            c.drawBitmap(selMask, 0, 0, selTint);
        }
        Path outline = flt != null ? null : selPath;
        if (outline != null) ants(c, outline, s);
        if (!drawPath.isEmpty()) ants(c, drawPath, s);
        if (!polyPts.isEmpty()) {
            Path pp = new Path();
            for (int i = 0; i < polyPts.size(); i++) {
                float[] q = polyPts.get(i);
                if (i == 0) pp.moveTo(q[0], q[1]); else pp.lineTo(q[0], q[1]);
            }
            ants(c, pp, s);
            handleP.setColor(Ui.ACC);
            for (float[] q : polyPts) c.drawCircle(q[0], q[1], Ui.dp(getContext(), 4) / s, handleP);
            handleP.setColor(0xFFFFFFFF);
        }
    }

    private void ants(Canvas c, Path path, float s) {
        float w = Ui.dp(getContext(), 1.3f) / s, d = Ui.dp(getContext(), 5) / s;
        antsB.setStrokeWidth(w);
        antsB.setPathEffect(null);
        c.drawPath(path, antsB);
        antsW.setStrokeWidth(w);
        antsW.setPathEffect(new DashPathEffect(new float[]{d, d}, 0));
        c.drawPath(path, antsW);
    }

    private void drawGuides(Canvas c, float s) {
        if (guide == 0) return;
        guideP.setStrokeWidth(Ui.dp(getContext(), 1) / s);
        guideP.setColor(0x664D8DFF);
        c.save();
        c.clipRect(full);
        if (guide == 1) {
            float g = Math.max(4, gridSize);
            for (float x = g; x < p.w; x += g) c.drawLine(x, 0, x, p.h, guideP);
            for (float y = g; y < p.h; y += g) c.drawLine(0, y, p.w, y, guideP);
        } else if (guide == 2 || guide == 3) {
            c.drawLine(-p.w, vp1y, p.w * 2, vp1y, guideP);
            rays(c, vp1x, vp1y);
            if (guide == 3) rays(c, vp2x, vp2y);
        } else if (guide == 4) {
            float g = Math.max(8, gridSize);
            float t = (float) Math.tan(Math.toRadians(30));
            float L = p.w + p.h;
            for (float x = -L; x < L * 2; x += g / t) {
                c.drawLine(x, 0, x + p.h / t, p.h, guideP);
                c.drawLine(x, 0, x - p.h / t, p.h, guideP);
            }
        }
        c.restore();
        if (guide >= 2 && guide <= 3) {
            handleP.setColor(0xFF4D8DFF);
            c.drawCircle(vp1x, vp1y, Ui.dp(getContext(), 7) / s, handleP);
            if (guide == 3) c.drawCircle(vp2x, vp2y, Ui.dp(getContext(), 7) / s, handleP);
            handleP.setColor(0xFFFFFFFF);
        }
    }

    private void rays(Canvas c, float x, float y) {
        float L = (p.w + p.h) * 3;
        for (int a = 0; a < 360; a += 10) {
            double r = Math.toRadians(a);
            c.drawLine(x, y, x + (float) Math.cos(r) * L, y + (float) Math.sin(r) * L, guideP);
        }
    }

    private void drawSymmetry(Canvas c, float s) {
        if (symMode == 0 || !(tool == T_BRUSH || tool == T_ERASER || tool == T_SHAPE || tool == T_LASSOFILL || tool == T_LASSOERASE)) return;
        guideP.setStrokeWidth(Ui.dp(getContext(), 1.4f) / s);
        guideP.setColor(0xAA8D7AFF);
        float cx = p.w / 2f, cy = p.h / 2f;
        if (symMode == 1 || symMode == 3) c.drawLine(cx, 0, cx, p.h, guideP);
        if (symMode == 2 || symMode == 3) c.drawLine(0, cy, p.w, cy, guideP);
        if (symMode == 4) {
            float L = Math.max(p.w, p.h);
            for (int i = 0; i < radialN; i++) {
                double a = Math.PI * 2 * i / radialN - Math.PI / 2;
                c.drawLine(cx, cy, cx + (float) Math.cos(a) * L, cy + (float) Math.sin(a) * L, guideP);
            }
        }
    }

    private void drawToolPreview(Canvas c, float s) {
        if (tool == T_GRADIENT && gradActive) {
            guideP.setColor(0xFFFFFFFF);
            guideP.setStrokeWidth(Ui.dp(getContext(), 1.5f) / s);
            c.drawLine(gx0, gy0, gx1, gy1, guideP);
            handleP.setColor(color);
            c.drawCircle(gx0, gy0, Ui.dp(getContext(), 6) / s, handleP);
            handleP.setColor(0xFFFFFFFF);
            c.drawCircle(gx1, gy1, Ui.dp(getContext(), 6) / s, handleP);
        }
    }

    private void drawHandles(Canvas c) {
        float[] v = fdst.clone();
        m.mapPoints(v);
        Path bx = new Path();
        bx.moveTo(v[0], v[1]); bx.lineTo(v[2], v[3]); bx.lineTo(v[4], v[5]); bx.lineTo(v[6], v[7]); bx.close();
        antsB.setStrokeWidth(Ui.dp(getContext(), 1.5f));
        antsB.setPathEffect(null);
        c.drawPath(bx, antsB);
        antsW.setStrokeWidth(Ui.dp(getContext(), 1.5f));
        antsW.setPathEffect(new DashPathEffect(new float[]{Ui.dp(getContext(), 6), Ui.dp(getContext(), 4)}, 0));
        c.drawPath(bx, antsW);
        float hr = Ui.dp(getContext(), 9);
        handleS.setColor(Ui.ACC);
        for (int i = 0; i < 4; i++) {
            c.drawCircle(v[i * 2], v[i * 2 + 1], hr, handleP);
            c.drawCircle(v[i * 2], v[i * 2 + 1], hr, handleS);
        }
        float[] rh = rotHandle(v);
        c.drawLine((v[0] + v[2]) / 2, (v[1] + v[3]) / 2, rh[0], rh[1], antsW);
        handleP.setColor(Ui.ACC);
        c.drawCircle(rh[0], rh[1], hr, handleP);
        handleP.setColor(0xFFFFFFFF);
        c.drawCircle(rh[0], rh[1], hr * .4f, handleP);
    }

    private float[] rotHandle(float[] v) {
        float mx = (v[0] + v[2]) / 2, my = (v[1] + v[3]) / 2;
        float cx = (v[0] + v[2] + v[4] + v[6]) / 4, cy = (v[1] + v[3] + v[5] + v[7]) / 4;
        float dx = mx - cx, dy = my - cy, d = (float) Math.hypot(dx, dy);
        if (d < 1) { dx = 0; dy = -1; d = 1; }
        float L = Ui.dp(getContext(), 34);
        return new float[]{mx + dx / d * L, my + dy / d * L};
    }

    /* ================================================================ toque */

    private int mode;
    private static final int M_NONE = 0, M_TOOL = 1, M_GESTURE = 2, M_PAN1 = 3, M_PICK = 4, M_DONE = 5;
    private int maxPtr;
    private long downT;
    private float dvx, dvy, lvx, lvy;
    private boolean moved;
    private float g0x, g0y, g1x, g1y, gRot0;
    private boolean picking;
    private float pickVX, pickVY;
    private int pickColor;
    float hoverX = -1, hoverY = -1;
    private final Runnable longPress = this::startPick;
    private final Runnable holdShape = this::quickShape;

    @Override public boolean onHoverEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_HOVER_EXIT) hoverX = -1;
        else { hoverX = e.getX(); hoverY = e.getY(); }
        invalidate();
        return true;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (p == null || playBmp != null) return true;
        int a = e.getActionMasked();
        int n = e.getPointerCount();
        switch (a) {
            case MotionEvent.ACTION_DOWN: {
                maxPtr = 1;
                downT = e.getEventTime();
                dvx = lvx = e.getX();
                dvy = lvy = e.getY();
                moved = false;
                hoverX = -1;
                boolean finger = e.getToolType(0) == MotionEvent.TOOL_TYPE_FINGER;
                if (tool == T_HAND || (finger && Prefs.on(getContext(), "stylusOnly", false) && tool != T_TRANSFORM)) {
                    mode = M_PAN1;
                    return true;
                }
                mode = M_TOOL;
                if ((tool == T_BRUSH || tool == T_ERASER) && Prefs.on(getContext(), "longPick", true)) h.postDelayed(longPress, 480);
                toolDown(e.getX(), e.getY(), pressure(e, 0));
                return true;
            }
            case MotionEvent.ACTION_POINTER_DOWN: {
                maxPtr = Math.max(maxPtr, n);
                h.removeCallbacks(longPress);
                h.removeCallbacks(holdShape);
                if (mode == M_TOOL) {
                    boolean early = e.getEventTime() - downT < 260 || !moved;
                    if (tool == T_TRANSFORM && flt != null) { /* gesto no objeto */ }
                    else if (early) toolCancel();
                    else { toolUp(lvx, lvy); }
                }
                if (mode == M_PICK) { picking = false; }
                if (n >= 2) {
                    mode = M_GESTURE;
                    beginGesture(e);
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (mode == M_PAN1) {
                    m.postTranslate(e.getX() - lvx, e.getY() - lvy);
                    lvx = e.getX(); lvy = e.getY();
                    invalidate();
                    return true;
                }
                if (mode == M_GESTURE && n >= 2) {
                    doGesture(e);
                    if (Math.hypot(e.getX(0) - g0x, e.getY(0) - g0y) > Ui.dp(getContext(), 14)) moved = true;
                    return true;
                }
                if (mode == M_PICK) {
                    pickAt(e.getX(), e.getY());
                    return true;
                }
                if (mode == M_TOOL) {
                    if (!moved && Math.hypot(e.getX() - dvx, e.getY() - dvy) > Ui.dp(getContext(), 6)) {
                        moved = true;
                        h.removeCallbacks(longPress);
                    }
                    int hs = e.getHistorySize();
                    for (int i = 0; i < hs; i++)
                        toolMove(e.getHistoricalX(0, i), e.getHistoricalY(0, i), pressureH(e, i));
                    toolMove(e.getX(), e.getY(), pressure(e, 0));
                    lvx = e.getX(); lvy = e.getY();
                }
                return true;
            }
            case MotionEvent.ACTION_POINTER_UP: {
                if (mode == M_GESTURE && n - 1 >= 2) beginGestureExcept(e, e.getActionIndex());
                else if (mode == M_GESTURE) mode = M_DONE;
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                h.removeCallbacks(longPress);
                h.removeCallbacks(holdShape);
                long dt = e.getEventTime() - downT;
                if (mode == M_TOOL) {
                    if (a == MotionEvent.ACTION_CANCEL) toolCancel(); else toolUp(e.getX(), e.getY());
                } else if (mode == M_PICK) {
                    picking = false;
                    if (listener != null) listener.onColorPicked(pickColor);
                    invalidate();
                } else if ((mode == M_GESTURE || mode == M_DONE) && dt < 380 && !moved && a == MotionEvent.ACTION_UP) {
                    if (maxPtr == 2 && Prefs.on(getContext(), "twoUndo", true)) { if (undo()) msg("Desfeito"); }
                    else if (maxPtr >= 3 && Prefs.on(getContext(), "twoUndo", true)) { if (redo()) msg("Refeito"); }
                }
                if (mode == M_GESTURE || mode == M_DONE) gestureEnd();
                mode = M_NONE;
                return true;
            }
        }
        return true;
    }

    private float pressure(MotionEvent e, int i) {
        int tt = e.getToolType(i);
        if (tt == MotionEvent.TOOL_TYPE_STYLUS || tt == MotionEvent.TOOL_TYPE_ERASER) {
            if (!Prefs.on(getContext(), "pressure", true)) return 1f;
            return Ui.clampf(e.getPressure(i) * 1.15f, 0.05f, 1f);
        }
        return 1f;
    }

    private float pressureH(MotionEvent e, int pos) {
        int tt = e.getToolType(0);
        if (tt == MotionEvent.TOOL_TYPE_STYLUS || tt == MotionEvent.TOOL_TYPE_ERASER) {
            if (!Prefs.on(getContext(), "pressure", true)) return 1f;
            return Ui.clampf(e.getHistoricalPressure(0, pos) * 1.15f, 0.05f, 1f);
        }
        return 1f;
    }

    /* ---- gestos de 2 dedos: zoom, mover, girar (ou transformar o objeto flutuante) ---- */

    private final float[] gStart = new float[8];
    private boolean gOnFloat;

    private void beginGesture(MotionEvent e) { beginGestureExcept(e, -1); }

    private void beginGestureExcept(MotionEvent e, int skip) {
        int i0 = -1, i1 = -1;
        for (int i = 0; i < e.getPointerCount(); i++) {
            if (i == skip) continue;
            if (i0 < 0) i0 = i; else if (i1 < 0) i1 = i;
        }
        if (i1 < 0) return;
        g0x = e.getX(i0); g0y = e.getY(i0); g1x = e.getX(i1); g1y = e.getY(i1);
        gid0 = e.getPointerId(i0); gid1 = e.getPointerId(i1);
        m0.set(m);
        gRot0 = rotation();
        moved = false;
        gOnFloat = tool == T_TRANSFORM && flt != null;
        if (gOnFloat) System.arraycopy(fdst, 0, gStart, 0, 8);
    }

    private int gid0, gid1;

    private void doGesture(MotionEvent e) {
        int i0 = e.findPointerIndex(gid0), i1 = e.findPointerIndex(gid1);
        if (i0 < 0 || i1 < 0) return;
        float ax = e.getX(i0), ay = e.getY(i0), bx = e.getX(i1), by = e.getY(i1);
        float mx0 = (g0x + g1x) / 2, my0 = (g0y + g1y) / 2, mx1 = (ax + bx) / 2, my1 = (ay + by) / 2;
        float d0 = (float) Math.hypot(g1x - g0x, g1y - g0y), d1 = (float) Math.hypot(bx - ax, by - ay);
        float k = d0 > 1 ? d1 / d0 : 1;
        float ang = (float) Math.toDegrees(Math.atan2(by - ay, bx - ax) - Math.atan2(g1y - g0y, g1x - g0x));
        if (gOnFloat) {
            float[] c0 = toCanvasWith(m, mx0, my0), c1 = toCanvasWith(m, mx1, my1);
            Matrix t = new Matrix();
            t.postTranslate(-c0[0], -c0[1]);
            t.postScale(k, k);
            t.postRotate(ang);
            t.postTranslate(c1[0], c1[1]);
            System.arraycopy(gStart, 0, fdst, 0, 8);
            t.mapPoints(fdst);
            updateFloat();
            return;
        }
        if (!Prefs.on(getContext(), "rotate", true)) ang = 0;
        else {
            float abs = gRot0 + ang;
            float snap = Math.round(abs / 90f) * 90f;
            if (Math.abs(abs - snap) < 6) ang = snap - gRot0;
        }
        float s0 = scaleOf(m0);
        k = Ui.clampf(s0 * k, 0.03f, 64f) / s0;
        m.set(m0);
        m.postTranslate(-mx0, -my0);
        m.postScale(k, k);
        m.postRotate(ang);
        m.postTranslate(mx1, my1);
        invalidate();
    }

    private static float scaleOf(Matrix mm) {
        float[] v = {1, 0};
        mm.mapVectors(v);
        return (float) Math.hypot(v[0], v[1]);
    }

    private float[] toCanvasWith(Matrix mm, float x, float y) {
        Matrix i = new Matrix();
        mm.invert(i);
        float[] q = {x, y};
        i.mapPoints(q);
        return q;
    }

    private void gestureEnd() {
        if (Math.abs(scale() - 1) < 0.04f) { /* nada */ }
        invalidate();
    }

    /* ---- conta-gotas por toque longo ---- */

    private void startPick() {
        if (mode != M_TOOL || moved) return;
        toolCancel();
        mode = M_PICK;
        picking = true;
        pickAt(lvx, lvy);
    }

    private void pickAt(float vx, float vy) {
        pickVX = vx; pickVY = vy;
        float[] q = toCanvas(vx, vy);
        pickColor = sample(q[0], q[1]);
        invalidate();
    }

    int sample(float x, float y) {
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y);
        if (ix < 0 || iy < 0 || ix >= p.w || iy >= p.h) return color;
        Bitmap one = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(one);
        c.translate(-ix, -iy);
        if ((p.paper >>> 24) != 0) c.drawColor(p.paper);
        Render.stack(c, p, bm, null);
        int col = one.getPixel(0, 0);
        one.recycle();
        if ((col >>> 24) == 0) return 0xFFFFFFFF;
        return col | 0xFF000000;
    }

    /* ================================================================ ferramentas */

    private boolean stroking, shaped, gradActive, direct, lassoing, cloneSet;
    private float sx, sy, ox, oy, gx0, gy0, gx1, gy1, cloneX, cloneY, cloneDX, cloneDY;
    private float snapAng = Float.NaN, snapX, snapY, qsX, qsY;
    private final ArrayList<float[]> raw = new ArrayList<>();
    private Bitmap backup;
    private ShapeDetect.Result shapeRes;
    private float shapeEndX, shapeEndY;

    private void toolDown(float vx, float vy, float pr) {
        float[] q = toCanvas(vx, vy);
        float x = q[0], y = q[1];
        ox = x; oy = y;
        switch (tool) {
            case T_BRUSH:
            case T_ERASER:
            case T_CLONE:
            case T_RECOLOR:
                if (tool == T_CLONE && !cloneSet) {
                    cloneX = x; cloneY = y; cloneSet = true;
                    msg("Origem marcada. Agora pinte onde quer copiar.");
                    invalidate();
                    mode = M_DONE;
                    return;
                }
                beginStroke(x, y, pr);
                return;
            case T_LIQUIFY:
                beginStroke(x, y, pr);
                return;
            case T_PICK:
                pickAt(vx, vy);
                picking = true;
                mode = M_PICK;
                return;
            case T_SHAPE:
            case T_GRADIENT:
                if (activeLocked()) { mode = M_DONE; return; }
                gx0 = gx1 = x; gy0 = gy1 = y;
                gradActive = tool == T_GRADIENT;
                prepareLive(false);
                return;
            case T_SELECT:
                if (selMode == 3) { return; }
                if (selMode >= 4) return;
                gx0 = gx1 = x; gy0 = gy1 = y;
                drawPath.reset();
                if (selMode == 2) drawPath.moveTo(x, y);
                lassoing = true;
                return;
            case T_LASSOFILL:
            case T_LASSOERASE:
                if (activeLocked()) { mode = M_DONE; return; }
                drawPath.reset();
                drawPath.moveTo(x, y);
                lassoing = true;
                return;
            case T_TRANSFORM:
                if (flt == null) { liftFloating(); if (flt == null) { mode = M_DONE; return; } }
                tfHandle = hitHandle(vx, vy);
                System.arraycopy(fdst, 0, fdst0, 0, 8);
                gx0 = x; gy0 = y;
                return;
            case T_GUIDES: {
                float d1 = (float) Math.hypot(x - vp1x, y - vp1y), d2 = (float) Math.hypot(x - vp2x, y - vp2y);
                tfHandle = guide == 3 && d2 < d1 ? 2 : 1;
                return;
            }
            default:
                break;
        }
    }

    private void toolMove(float vx, float vy, float pr) {
        float[] q = toCanvas(vx, vy);
        float x = q[0], y = q[1];
        switch (tool) {
            case T_BRUSH:
            case T_ERASER:
            case T_CLONE:
            case T_RECOLOR:
            case T_LIQUIFY:
                if (!stroking) return;
                if (shaped) { reshape(x, y); return; }
                strokeTo(x, y, pr);
                if ((tool == T_BRUSH || tool == T_ERASER) && moved && Prefs.on(getContext(), "qshape", true)
                        && Math.hypot(vx - qsX, vy - qsY) > Ui.dp(getContext(), 4)) {
                    qsX = vx; qsY = vy;
                    h.removeCallbacks(holdShape);
                    h.postDelayed(holdShape, 650);
                }
                return;
            case T_SHAPE:
            case T_GRADIENT:
                if (strokeCv == null || mode != M_TOOL) return;
                gx1 = x; gy1 = y;
                strokeBmp.eraseColor(0);
                if (tool == T_SHAPE) drawShape(gx0, gy0, gx1, gy1);
                else drawGradient();
                invalidate();
                return;
            case T_SELECT:
                if (!lassoing) return;
                gx1 = x; gy1 = y;
                drawPath.reset();
                if (selMode == 0) drawPath.addRect(Math.min(gx0, x), Math.min(gy0, y), Math.max(gx0, x), Math.max(gy0, y), Path.Direction.CW);
                else if (selMode == 1) drawPath.addOval(new RectF(Math.min(gx0, x), Math.min(gy0, y), Math.max(gx0, x), Math.max(gy0, y)), Path.Direction.CW);
                else if (selMode == 2) { lassoPts.add(new float[]{x, y}); rebuildLasso(); }
                invalidate();
                return;
            case T_LASSOFILL:
            case T_LASSOERASE:
                if (!lassoing) return;
                lassoPts.add(new float[]{x, y});
                rebuildLasso();
                invalidate();
                return;
            case T_TRANSFORM:
                if (flt == null) return;
                dragTransform(x, y);
                return;
            case T_GUIDES:
                if (tfHandle == 2) { vp2x = x; vp2y = y; } else { vp1x = x; vp1y = y; if (guide == 3) vp2y = y; }
                invalidate();
                return;
            default:
                break;
        }
    }

    private void toolUp(float vx, float vy) {
        float[] q = toCanvas(vx, vy);
        float x = q[0], y = q[1];
        switch (tool) {
            case T_BRUSH:
            case T_ERASER:
            case T_CLONE:
            case T_RECOLOR:
            case T_LIQUIFY:
                if (stroking) endStroke();
                return;
            case T_FILL:
                if (!moved) fillAt(x, y);
                return;
            case T_TEXT:
                if (!moved && listener != null) listener.onTextAt(x, y);
                return;
            case T_SHAPE:
            case T_GRADIENT:
                if (strokeBmp == null) return;
                if (Math.hypot(gx1 - gx0, gy1 - gy0) < 2) { strokeBmp.eraseColor(0); live.stroke = null; gradActive = false; invalidate(); return; }
                commitLive(boundsAll());
                gradActive = false;
                return;
            case T_SELECT:
                if (selMode == 3) { polyTap(x, y); return; }
                if (selMode == 4 || selMode == 5) { if (!moved) wandAt(x, y, selMode == 5); return; }
                if (!lassoing) return;
                lassoing = false;
                if (!moved) { clearSelection(); drawPath.reset(); lassoPts.clear(); return; }
                if (selMode == 2) drawPath.close();
                applySelection(new Path(drawPath));
                drawPath.reset();
                lassoPts.clear();
                return;
            case T_LASSOFILL:
            case T_LASSOERASE: {
                if (!lassoing) return;
                lassoing = false;
                drawPath.close();
                if (moved) lassoPaint(new Path(drawPath), tool == T_LASSOERASE);
                drawPath.reset();
                lassoPts.clear();
                invalidate();
                return;
            }
            case T_TRANSFORM:
                tfHandle = -1;
                return;
            default:
                break;
        }
    }

    private void toolCancel() {
        h.removeCallbacks(holdShape);
        if (stroking) {
            stroking = false;
            if (direct && backup != null) {
                Bitmap b = bm.get(layer().id);
                if (b != null) new Canvas(b).drawBitmap(backup, 0, 0, srcPaint());
            }
            freeBackup();
            if (strokeBmp != null) strokeBmp.eraseColor(0);
            live.stroke = null;
        }
        if (tool == T_SHAPE || tool == T_GRADIENT) { strokeBmp.eraseColor(0); live.stroke = null; gradActive = false; }
        lassoing = false;
        drawPath.reset();
        lassoPts.clear();
        invalidate();
    }

    private Paint srcPaint() {
        Paint pp = new Paint();
        pp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
        return pp;
    }

    private void freeBackup() {
        if (backup != null) { backup.recycle(); backup = null; }
    }

    /* ---- simetria ---- */

    Matrix[] symMatrices() {
        float cx = p.w / 2f, cy = p.h / 2f;
        ArrayList<Matrix> out = new ArrayList<>();
        out.add(new Matrix());
        if (symMode == 1 || symMode == 3) { Matrix a = new Matrix(); a.setScale(-1, 1, cx, cy); out.add(a); }
        if (symMode == 2 || symMode == 3) { Matrix a = new Matrix(); a.setScale(1, -1, cx, cy); out.add(a); }
        if (symMode == 3) { Matrix a = new Matrix(); a.setScale(-1, -1, cx, cy); out.add(a); }
        if (symMode == 4) {
            out.clear();
            for (int i = 0; i < radialN; i++) {
                Matrix a = new Matrix();
                a.setRotate(360f * i / radialN, cx, cy);
                out.add(a);
                if (radialMirror) {
                    Matrix b = new Matrix();
                    b.setScale(-1, 1, cx, cy);
                    b.postRotate(360f * i / radialN, cx, cy);
                    out.add(b);
                }
            }
        }
        return out.toArray(new Matrix[0]);
    }

    /* ---- traço ---- */

    private void prepareLive(boolean eraser) {
        strokeBmp.eraseColor(0);
        strokePaint.reset();
        strokePaint.setFilterBitmap(true);
        Project.Layer l = layer();
        float a;
        if (eraser) {
            strokePaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
            a = eraserOpacity / 100f;
        } else {
            a = opacity / 100f * (tool == T_BRUSH ? Brushes.get(brushId).alpha : 1f);
            if (l.alpha) strokePaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
        }
        strokePaint.setAlpha(Math.round(Ui.clampf(a, 0, 1) * 255));
        live.stroke = strokeBmp;
        live.strokePaint = strokePaint;
    }

    private void beginStroke(float x, float y, float pr) {
        if (activeLocked()) { mode = M_DONE; return; }
        stroking = true;
        shaped = false;
        raw.clear();
        snapAng = Float.NaN;
        snapX = x; snapY = y;
        sx = x; sy = y;
        Bitmap lb = ensure(layer().id);
        direct = false;
        boolean er = tool == T_ERASER;
        Brushes.B b = er ? Brushes.get("monoline") : Brushes.get(brushId);
        if (er) b = eraserType.equals("e_soft") ? Brushes.ERASE_SOFT : eraserType.equals("e_grain") ? Brushes.ERASE_GRAIN : Brushes.ERASE_ROUND;
        eng.sink = null;
        if (tool == T_LIQUIFY || tool == T_RECOLOR || (tool == T_BRUSH && b.direct())) {
            direct = true;
            backup = lb.copy(Bitmap.Config.ARGB_8888, false);
            live.stroke = null;
            final Bitmap layerB = lb;
            if (tool == T_LIQUIFY) {
                eng.sink = (dx, dy, w, ang, p2) -> liquifyDab(layerB, dx, dy);
                b = Brushes.get("monoline");
            } else if (tool == T_RECOLOR) {
                recolorTarget = backup.getPixel(Ui.clamp((int) x, 0, p.w - 1), Ui.clamp((int) y, 0, p.h - 1));
                eng.sink = (dx, dy, w, ang, p2) -> recolorDab(layerB, dx, dy, w);
            } else {
                final boolean blur = b.kind == Brushes.BLUR;
                smudgeInit = false;
                eng.sink = (dx, dy, w, ang, p2) -> mixDab(layerB, dx, dy, w, blur);
            }
            float sz = tool == T_LIQUIFY ? liqSize : brushSize;
            eng.begin(b, color, sz, strokeCv, System.nanoTime());
            liqLastX = x; liqLastY = y;
            eng.minX = eng.minY = Float.MAX_VALUE;
        } else {
            prepareLive(er);
            if (tool == T_CLONE) {
                cloneDX = cloneX - x; cloneDY = cloneY - y;
                backup = lb.copy(Bitmap.Config.ARGB_8888, false);
                final BitmapShader bs = new BitmapShader(backup, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                Matrix lm = new Matrix();
                lm.setTranslate(-cloneDX, -cloneDY);
                bs.setLocalMatrix(lm);
                final Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                cp.setShader(bs);
                eng.sink = (dx, dy, w, ang, p2) -> strokeCv.drawCircle(dx, dy, w / 2, cp);
                b = Brushes.get("monoline");
            }
            if (selMask != null) live.mask = selMask;
            eng.sym = tool == T_CLONE ? new Matrix[]{new Matrix()} : symMatrices();
            eng.begin(b, er ? 0xFF000000 : color, er ? eraserSize : brushSize, strokeCv, System.nanoTime());
        }
        raw.add(new float[]{x, y, pr});
        eng.to(x, y, pr);
        invalidate();
    }

    private void strokeTo(float x, float y, float pr) {
        // régua das guias
        if (snapGuide && guide > 0 && (tool == T_BRUSH || tool == T_ERASER)) {
            if (Float.isNaN(snapAng)) {
                if (Math.hypot(x - snapX, y - snapY) > Math.max(8, 14 / scale())) snapAng = chooseSnap(snapX, snapY, x, y);
                else return;
            }
            float dx = (float) Math.cos(snapAng), dy = (float) Math.sin(snapAng);
            float t = (x - snapX) * dx + (y - snapY) * dy;
            x = snapX + dx * t; y = snapY + dy * t;
        }
        // estabilizador (StreamLine)
        float k = stabilizer / 100f;
        float wgt = 1f - 0.93f * (float) Math.sqrt(k);
        sx += (x - sx) * wgt;
        sy += (y - sy) * wgt;
        raw.add(new float[]{sx, sy, pr});
        eng.to(sx, sy, pr);
        if (tool == T_LIQUIFY) { liqLastX = sx; liqLastY = sy; }
        invalidate();
    }

    private float chooseSnap(float x0, float y0, float x1, float y1) {
        float a = (float) Math.atan2(y1 - y0, x1 - x0);
        ArrayList<Float> c = new ArrayList<>();
        if (guide == 1) { c.add(0f); c.add((float) (Math.PI / 2)); }
        else if (guide == 4) { c.add((float) Math.toRadians(30)); c.add((float) Math.toRadians(150)); c.add((float) (Math.PI / 2)); }
        else {
            c.add((float) Math.atan2(vp1y - y0, vp1x - x0));
            if (guide == 3) c.add((float) Math.atan2(vp2y - y0, vp2x - x0));
            else c.add(0f);
            c.add((float) (Math.PI / 2));
        }
        float best = a, bd = Float.MAX_VALUE;
        for (float v : c) {
            for (float s : new float[]{v, v + (float) Math.PI}) {
                float d = Math.abs((float) Math.atan2(Math.sin(a - s), Math.cos(a - s)));
                if (d < bd) { bd = d; best = s; }
            }
        }
        return best;
    }

    private void endStroke() {
        stroking = false;
        h.removeCallbacks(holdShape);
        if (!shaped) {
            // alcança o dedo (o estabilizador fica para trás)
            float[] last = raw.isEmpty() ? null : raw.get(raw.size() - 1);
            if (last != null && stabilizer > 0 && tool != T_LIQUIFY) {
                for (int i = 1; i <= 4; i++) {
                    float t = i / 4f;
                    float x = sx + (lvxC() - sx) * t, y = sy + (lvyC() - sy) * t;
                    if (snapGuide && guide > 0 && !Float.isNaN(snapAng)) break;
                    eng.to(x, y, last[2]);
                }
            }
            eng.end();
            if (!direct && eng.sink == null && eng.b.taper > 0 && raw.size() > 2) {
                float len = eng.dist;
                strokeBmp.eraseColor(0);
                eng.redraw(len);
            }
        }
        if (direct) {
            Rect r = symOrBounds();
            recordFrom(layer().id, backup, r);
            freeBackup();
            markDirty(layer().id);
            timelapse();
            invalidate();
            return;
        }
        if (tool == T_CLONE) {
            commitLive(symOrBounds());
            freeBackup();
            return;
        }
        commitLive(symOrBounds());
    }

    private float lvxC() { return toCanvas(lvx, lvy)[0]; }
    private float lvyC() { return toCanvas(lvx, lvy)[1]; }

    private Rect symOrBounds() {
        if (symMode != 0 && !direct && tool != T_CLONE) return new Rect(0, 0, p.w, p.h);
        if (eng.minX > eng.maxX) return null;
        return clampRect(eng.minX, eng.minY, eng.maxX, eng.maxY);
    }

    private Rect boundsAll() { return new Rect(0, 0, p.w, p.h); }

    /** Junta o traço ao vivo à camada (com máscara de seleção, trava de transparência, borracha). */
    private void commitLive(Rect r) {
        int id = layer().id;
        if (r != null) {
            record(id, r);
            Bitmap lb = ensure(id);
            Canvas c = new Canvas(lb);
            if (selMask != null) {
                Canvas sc = new Canvas(strokeBmp);
                Paint dp = new Paint();
                dp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
                sc.drawBitmap(selMask, 0, 0, dp);
            }
            c.drawBitmap(strokeBmp, 0, 0, strokePaint);
            markDirty(id);
            timelapse();
        }
        strokeBmp.eraseColor(0);
        live.stroke = null;
        invalidate();
    }

    /* ---- QuickShape ---- */

    private void quickShape() {
        if (!stroking || shaped || direct || raw.size() < 6) return;
        ShapeDetect.Result res = ShapeDetect.detect(raw);
        if (res == null) return;
        shaped = true;
        shapeRes = res;
        shapeEndX = raw.get(raw.size() - 1)[0];
        shapeEndY = raw.get(raw.size() - 1)[1];
        renderShapeStroke(res.path);
        msg(res.name + " ✓");
    }

    private void renderShapeStroke(Path path) {
        strokeBmp.eraseColor(0);
        Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
        sp.setStyle(Paint.Style.STROKE);
        sp.setStrokeCap(Paint.Cap.ROUND);
        sp.setStrokeJoin(Paint.Join.ROUND);
        sp.setStrokeWidth(tool == T_ERASER ? eraserSize : brushSize);
        sp.setColor(tool == T_ERASER ? 0xFF000000 : (eng.b.fixed != 0 ? eng.b.fixed : color));
        for (Matrix mm : symMatrices()) {
            strokeCv.save();
            strokeCv.concat(mm);
            strokeCv.drawPath(path, sp);
            strokeCv.restore();
        }
        eng.minX = 0; eng.minY = 0; eng.maxX = p.w; eng.maxY = p.h;
        invalidate();
    }

    private void reshape(float x, float y) {
        if (shapeRes == null) return;
        if (shapeRes.line) {
            Path pp = new Path();
            pp.moveTo(shapeRes.x0, shapeRes.y0);
            pp.lineTo(x, y);
            renderShapeStroke(pp);
        } else {
            // aumenta/diminui a forma em volta do centro
            RectF b = new RectF();
            shapeRes.path.computeBounds(b, true);
            float cx = b.centerX(), cy = b.centerY();
            float d0 = (float) Math.hypot(shapeEndX - cx, shapeEndY - cy), d1 = (float) Math.hypot(x - cx, y - cy);
            float a = (float) Math.toDegrees(Math.atan2(y - cy, x - cx) - Math.atan2(shapeEndY - cy, shapeEndX - cx));
            Path pp = new Path(shapeRes.path);
            Matrix mm = new Matrix();
            if (d0 > 4) mm.setScale(d1 / d0, d1 / d0, cx, cy);
            mm.postRotate(a, cx, cy);
            pp.transform(mm);
            renderShapeStroke(pp);
        }
    }

    /* ---- liquidificar / recolorir / borrar / desfocar (mexem direto na camada) ---- */

    private float liqLastX, liqLastY;
    private int recolorTarget;
    private boolean smudgeInit;
    private Bitmap smBuf, smTmp;
    private float smLastX, smLastY;

    private void liquifyDab(Bitmap layerB, float x, float y) {
        float r = liqSize / 2;
        float dx = x - liqLastX, dy = y - liqLastY;
        liqLastX = x; liqLastY = y;
        int x0 = (int) Math.floor(x - r), y0 = (int) Math.floor(y - r);
        int sz = (int) Math.ceil(r * 2);
        Rect rc = new Rect(x0, y0, x0 + sz, y0 + sz);
        if (!rc.intersect(0, 0, p.w, p.h) || rc.width() < 4 || rc.height() < 4) return;
        eng.minX = Math.min(eng.minX, rc.left); eng.minY = Math.min(eng.minY, rc.top);
        eng.maxX = Math.max(eng.maxX, rc.right); eng.maxY = Math.max(eng.maxY, rc.bottom);
        Bitmap sub = Bitmap.createBitmap(layerB, rc.left, rc.top, rc.width(), rc.height());
        int G = 14;
        float[] v = new float[(G + 1) * (G + 1) * 2];
        float st = liqStrength / 100f;
        int k = 0;
        for (int j = 0; j <= G; j++)
            for (int i = 0; i <= G; i++) {
                float vx = rc.left + rc.width() * i / (float) G, vy = rc.top + rc.height() * j / (float) G;
                boolean edge = i == 0 || j == 0 || i == G || j == G;
                float ddx = vx - x, ddy = vy - y;
                float d = (float) Math.hypot(ddx, ddy) / r;
                float f = edge || d >= 1 ? 0 : (1 - d * d) * (1 - d * d);
                float nx = vx, ny = vy;
                switch (liqMode) {
                    case 1: { float a = f * st * 0.25f; float co = (float) Math.cos(a), si = (float) Math.sin(a);
                        nx = x + ddx * co - ddy * si; ny = y + ddx * si + ddy * co; break; }
                    case 2: nx = vx - ddx * f * st * .12f; ny = vy - ddy * f * st * .12f; break;
                    case 3: nx = vx + ddx * f * st * .12f; ny = vy + ddy * f * st * .12f; break;
                    default: {
                        float lim = r * .35f;
                        float mdx = Ui.clampf(dx, -lim, lim), mdy = Ui.clampf(dy, -lim, lim);
                        nx = vx + mdx * f * (0.4f + st);
                        ny = vy + mdy * f * (0.4f + st);
                    }
                }
                v[k++] = nx;
                v[k++] = ny;
            }
        Canvas c = new Canvas(layerB);
        c.save();
        c.clipRect(rc);
        c.drawColor(0, PorterDuff.Mode.CLEAR);
        c.drawBitmapMesh(sub, G, G, v, 0, null, 0, plain);
        c.restore();
        sub.recycle();
    }

    private void recolorDab(Bitmap layerB, float x, float y, float w) {
        float r = w / 2;
        Rect rc = clampRect(x - r, y - r, x + r, y + r);
        if (rc == null || rc.isEmpty()) return;
        eng.minX = Math.min(eng.minX, rc.left); eng.minY = Math.min(eng.minY, rc.top);
        eng.maxX = Math.max(eng.maxX, rc.right); eng.maxY = Math.max(eng.maxY, rc.bottom);
        int ww = rc.width(), hh = rc.height();
        int[] px = new int[ww * hh];
        layerB.getPixels(px, 0, ww, rc.left, rc.top, ww, hh);
        int tr = (recolorTarget >> 16) & 255, tg = (recolorTarget >> 8) & 255, tb = recolorTarget & 255;
        int rgb = color & 0xFFFFFF;
        for (int j = 0; j < hh; j++)
            for (int i = 0; i < ww; i++) {
                float ddx = rc.left + i + .5f - x, ddy = rc.top + j + .5f - y;
                if (ddx * ddx + ddy * ddy > r * r) continue;
                int c = px[j * ww + i];
                if ((c >>> 24) == 0) continue;
                int d = Math.max(Math.abs(((c >> 16) & 255) - tr), Math.max(Math.abs(((c >> 8) & 255) - tg), Math.abs((c & 255) - tb)));
                if (d > recolorTol) continue;
                px[j * ww + i] = (c & 0xFF000000) | rgb;
            }
        layerB.setPixels(px, 0, ww, rc.left, rc.top, ww, hh);
    }

    /** Dedo (borrar) e desfocar: mistura suave dentro de um círculo. */
    private void mixDab(Bitmap layerB, float x, float y, float w, boolean blur) {
        float r = w / 2;
        int sz = Math.max(4, (int) Math.ceil(w));
        int x0 = Math.round(x - r), y0 = Math.round(y - r);
        Rect rc = new Rect(x0, y0, x0 + sz, y0 + sz);
        if (!Rect.intersects(rc, new Rect(0, 0, p.w, p.h))) return;
        eng.minX = Math.min(eng.minX, x0); eng.minY = Math.min(eng.minY, y0);
        eng.maxX = Math.max(eng.maxX, x0 + sz); eng.maxY = Math.max(eng.maxY, y0 + sz);
        if (smBuf == null || smBuf.getWidth() != sz) {
            if (smBuf != null) smBuf.recycle();
            if (smTmp != null) smTmp.recycle();
            smBuf = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
            smTmp = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
            smudgeInit = false;
        }
        Paint src = srcPaint();
        Canvas tc = new Canvas(smTmp);
        if (blur) {
            tc.drawColor(0, PorterDuff.Mode.CLEAR);
            tc.drawBitmap(layerB, -x0, -y0, src);
            Bitmap bl = Filters.blur(smTmp, Math.max(2, sz / 6));
            tc.drawBitmap(bl, 0, 0, src);
            bl.recycle();
        } else {
            if (!smudgeInit) {
                new Canvas(smBuf).drawBitmap(layerB, -x0, -y0, src);
                smudgeInit = true;
                smLastX = x0; smLastY = y0;
                return;
            }
            tc.drawBitmap(smBuf, 0, 0, src);
        }
        RectF dst = new RectF(0, 0, sz, sz);
        softMaskP.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        softMaskP.setAlpha(blur ? 200 : 150);
        tc.drawBitmap(Brushes.soft(), null, dst, softMaskP);
        Canvas lc = new Canvas(layerB);
        RectF ld = new RectF(x0, y0, x0 + sz, y0 + sz);
        softMaskP.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        lc.drawBitmap(Brushes.soft(), null, ld, softMaskP);
        Paint add = new Paint();
        add.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
        lc.drawBitmap(smTmp, x0, y0, add);
        if (!blur) {
            // o "dedo" pega um pouco da tinta nova
            Paint mix = new Paint();
            mix.setAlpha(110);
            Canvas bc = new Canvas(smBuf);
            bc.drawBitmap(layerB, -x0, -y0, mix);
        }
    }

    /* ---- formas e degradê ---- */

    private void drawShape(float x0, float y0, float x1, float y1) {
        Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
        sp.setColor(color);
        sp.setStyle(shapeFill && shapeType != 0 ? Paint.Style.FILL : Paint.Style.STROKE);
        sp.setStrokeWidth(brushSize);
        sp.setStrokeCap(Paint.Cap.ROUND);
        sp.setStrokeJoin(Paint.Join.ROUND);
        Path path = shapePath(x0, y0, x1, y1);
        for (Matrix mm : symMatrices()) {
            strokeCv.save();
            strokeCv.concat(mm);
            strokeCv.drawPath(path, sp);
            if (shapeType == 5) {
                Paint hp = new Paint(sp);
                hp.setStyle(Paint.Style.FILL);
                strokeCv.drawPath(arrowHead(x0, y0, x1, y1), hp);
            }
            strokeCv.restore();
        }
    }

    Path shapePath(float x0, float y0, float x1, float y1) {
        Path path = new Path();
        RectF r = new RectF(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1), Math.max(y0, y1));
        switch (shapeType) {
            case 1: path.addRect(r, Path.Direction.CW); break;
            case 2: path.addOval(r, Path.Direction.CW); break;
            case 3:
            case 4: {
                boolean star = shapeType == 3;
                int nn = star ? Math.max(3, polySides) * 2 : Math.max(3, polySides);
                float cx = r.centerX(), cy = r.centerY(), rx = r.width() / 2, ry = r.height() / 2;
                for (int i = 0; i < nn; i++) {
                    double a = -Math.PI / 2 + i * Math.PI * 2 / nn;
                    float k = star && i % 2 == 1 ? .45f : 1f;
                    float px = cx + (float) Math.cos(a) * rx * k, py = cy + (float) Math.sin(a) * ry * k;
                    if (i == 0) path.moveTo(px, py); else path.lineTo(px, py);
                }
                path.close();
                break;
            }
            case 5: {
                float a = (float) Math.atan2(y1 - y0, x1 - x0), L = brushSize * 3 + 6;
                path.moveTo(x0, y0);
                path.lineTo(x1 - (float) Math.cos(a) * L * .8f, y1 - (float) Math.sin(a) * L * .8f);
                break;
            }
            default:
                path.moveTo(x0, y0);
                path.lineTo(x1, y1);
        }
        return path;
    }

    private Path arrowHead(float x0, float y0, float x1, float y1) {
        float a = (float) Math.atan2(y1 - y0, x1 - x0), L = brushSize * 3 + 6;
        Path h = new Path();
        h.moveTo(x1, y1);
        h.lineTo(x1 - (float) Math.cos(a - .45f) * L, y1 - (float) Math.sin(a - .45f) * L);
        h.lineTo(x1 - (float) Math.cos(a + .45f) * L, y1 - (float) Math.sin(a + .45f) * L);
        h.close();
        return h;
    }

    private void drawGradient() {
        Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG);
        int c2 = gradTwo ? color2 : (color & 0xFFFFFF);
        float L = (float) Math.hypot(gx1 - gx0, gy1 - gy0);
        if (gradType == 1) gp.setShader(new RadialGradient(gx0, gy0, Math.max(1, L), color, c2, Shader.TileMode.CLAMP));
        else gp.setShader(new LinearGradient(gx0, gy0, gx1, gy1, color, c2, Shader.TileMode.CLAMP));
        strokeCv.drawRect(full, gp);
    }

    /* ---- laço que preenche / apaga ---- */

    private final ArrayList<float[]> lassoPts = new ArrayList<>();

    private void rebuildLasso() {
        drawPath.reset();
        for (int i = 0; i < lassoPts.size(); i++) {
            float[] q = lassoPts.get(i);
            if (i == 0) drawPath.moveTo(ox, oy);
            drawPath.lineTo(q[0], q[1]);
        }
    }

    private void lassoPaint(Path path, boolean erase) {
        prepareLive(erase);
        Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
        fp.setColor(erase ? 0xFF000000 : color);
        for (Matrix mm : symMatrices()) {
            strokeCv.save();
            strokeCv.concat(mm);
            strokeCv.drawPath(path, fp);
            strokeCv.restore();
        }
        RectF b = new RectF();
        path.computeBounds(b, true);
        commitLive(symMode != 0 ? boundsAll() : clampRect(b.left - 2, b.top - 2, b.right + 2, b.bottom + 2));
    }

    /* ---- balde ---- */

    private void fillAt(float x, float y) {
        if (activeLocked()) return;
        int ix = (int) x, iy = (int) y;
        if (ix < 0 || iy < 0 || ix >= p.w || iy >= p.h) return;
        Project.Layer l = layer();
        int w = p.w, hh = p.h;
        int[] px = new int[w * hh];
        if (fillAll) {
            Bitmap comp = Bitmap.createBitmap(w, hh, Bitmap.Config.ARGB_8888);
            Render.stack(new Canvas(comp), p, bm, null);
            comp.getPixels(px, 0, w, 0, 0, w, hh);
            comp.recycle();
        } else {
            Bitmap lb = bm.get(l.id);
            if (lb != null) lb.getPixels(px, 0, w, 0, 0, w, hh);
        }
        Rect rb = new Rect();
        boolean[] area = Fill.region(px, w, hh, ix, iy, fillTol, fillGap, fillExpand, rb);
        if (rb.isEmpty()) return;
        int rw = rb.width(), rh = rb.height();
        int[] out = new int[rw * rh];
        int col = color;
        for (int j = 0; j < rh; j++) {
            int srow = (rb.top + j) * w + rb.left;
            for (int i = 0; i < rw; i++) if (area[srow + i]) out[j * rw + i] = col;
        }
        Bitmap patch = Bitmap.createBitmap(out, rw, rh, Bitmap.Config.ARGB_8888);
        record(l.id, rb);
        Bitmap lb = ensure(l.id);
        Canvas c = new Canvas(lb);
        Paint fp = new Paint();
        fp.setAlpha(Math.round(opacity * 2.55f));
        if (selMask != null) {
            Canvas pc = new Canvas(patch);
            Paint dp = new Paint();
            dp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            pc.drawBitmap(selMask, -rb.left, -rb.top, dp);
        }
        if (l.alpha) fp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
        c.drawBitmap(patch, rb.left, rb.top, fp);
        patch.recycle();
        markDirty(l.id);
        timelapse();
        invalidate();
    }

    /* ================================================================ seleção */

    private void applySelection(Path path) {
        Bitmap mk = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ALPHA_8);
        Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
        fp.setColor(0xFF000000);
        new Canvas(mk).drawPath(path, fp);
        combine(mk, path);
    }

    private void combine(Bitmap mk, Path outline) {
        if (selOp == 0 || selMask == null) {
            if (selMask != null) selMask.recycle();
            selMask = mk;
            selPath = outline;
        } else {
            Paint pp = new Paint();
            pp.setXfermode(new PorterDuffXfermode(selOp == 1 ? PorterDuff.Mode.SRC_OVER : PorterDuff.Mode.DST_OUT));
            new Canvas(selMask).drawBitmap(mk, 0, 0, pp);
            mk.recycle();
            if (selPath != null && outline != null) {
                Path np = new Path(selPath);
                np.op(outline, selOp == 1 ? Path.Op.UNION : Path.Op.DIFFERENCE);
                selPath = np;
            } else selPath = null;
        }
        if (listener != null) listener.onSelection(true);
        invalidate();
    }

    private void polyTap(float x, float y) {
        if (moved) return;
        if (polyPts.size() >= 3) {
            float[] f = polyPts.get(0);
            if (Math.hypot(x - f[0], y - f[1]) * scale() < Ui.dp(getContext(), 22)) { closePoly(); return; }
        }
        polyPts.add(new float[]{x, y});
        invalidate();
    }

    void closePoly() {
        if (polyPts.size() < 3) { polyPts.clear(); invalidate(); return; }
        Path pp = new Path();
        for (int i = 0; i < polyPts.size(); i++) {
            float[] q = polyPts.get(i);
            if (i == 0) pp.moveTo(q[0], q[1]); else pp.lineTo(q[0], q[1]);
        }
        pp.close();
        polyPts.clear();
        applySelection(pp);
    }

    boolean polyOpen() { return !polyPts.isEmpty(); }

    private void wandAt(float x, float y, boolean global) {
        int ix = (int) x, iy = (int) y;
        if (ix < 0 || iy < 0 || ix >= p.w || iy >= p.h) return;
        int w = p.w, hh = p.h;
        int[] px = new int[w * hh];
        if (fillAll) {
            Bitmap comp = Bitmap.createBitmap(w, hh, Bitmap.Config.ARGB_8888);
            Render.stack(new Canvas(comp), p, bm, null);
            comp.getPixels(px, 0, w, 0, 0, w, hh);
            comp.recycle();
        } else {
            Bitmap lb = bm.get(layer().id);
            if (lb != null) lb.getPixels(px, 0, w, 0, 0, w, hh);
        }
        boolean[] area = global ? Fill.similar(px, px[iy * w + ix], fillTol) : Fill.region(px, w, hh, ix, iy, fillTol, 0, 0, null);
        int[] out = new int[w * hh];
        for (int i = 0; i < out.length; i++) if (area[i]) out[i] = 0xFF000000;
        Bitmap argb = Bitmap.createBitmap(out, w, hh, Bitmap.Config.ARGB_8888);
        Bitmap mk = argb.extractAlpha();
        argb.recycle();
        combine(mk, null);
    }

    void selectAll() {
        Path pp = new Path();
        pp.addRect(full, Path.Direction.CW);
        int op = selOp;
        selOp = 0;
        applySelection(pp);
        selOp = op;
    }

    /** Seleciona tudo que tem desenho na camada (como Ctrl+clique no Krita). */
    void selectLayerContent() {
        Bitmap lb = bm.get(layer().id);
        if (lb == null) { msg("Camada vazia"); return; }
        Bitmap mk = lb.extractAlpha();
        int op = selOp;
        selOp = 0;
        combine(mk, null);
        selOp = op;
    }

    void invertSelection() {
        if (selMask == null) { selectAll(); return; }
        Bitmap mk = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ALPHA_8);
        Canvas c = new Canvas(mk);
        c.drawColor(0xFF000000);
        Paint pp = new Paint();
        pp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        c.drawBitmap(selMask, 0, 0, pp);
        selMask.recycle();
        selMask = mk;
        if (selPath != null) {
            Path np = new Path();
            np.addRect(full, Path.Direction.CW);
            np.op(selPath, Path.Op.DIFFERENCE);
            selPath = np;
        }
        invalidate();
    }

    void clearSelection() {
        if (selMask != null) selMask.recycle();
        selMask = null;
        selPath = null;
        polyPts.clear();
        live.mask = null;
        if (listener != null) listener.onSelection(false);
        invalidate();
    }

    boolean hasSel() { return selMask != null; }

    private Rect maskBounds() {
        if (selMask == null) return new Rect(0, 0, p.w, p.h);
        if (selPath != null) {
            RectF b = new RectF();
            selPath.computeBounds(b, true);
            Rect r = clampRect(b.left - 2, b.top - 2, b.right + 2, b.bottom + 2);
            return r == null ? new Rect(0, 0, p.w, p.h) : r;
        }
        return new Rect(0, 0, p.w, p.h);
    }

    /** Pixels da camada dentro da seleção (ou a camada toda). */
    Bitmap selectedPixels(boolean cut) {
        Project.Layer l = layer();
        Bitmap lb = bm.get(l.id);
        if (lb == null) return null;
        Rect r = maskBounds();
        Bitmap out = Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawBitmap(lb, -r.left, -r.top, null);
        if (selMask != null) {
            Paint dp = new Paint();
            dp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            c.drawBitmap(selMask, -r.left, -r.top, dp);
        }
        if (cut) {
            record(l.id, r);
            clearInSelection(lb);
            markDirty(l.id);
        }
        return out;
    }

    private void clearInSelection(Bitmap lb) {
        Canvas c = new Canvas(lb);
        if (selMask == null) { c.drawColor(0, PorterDuff.Mode.CLEAR); return; }
        Paint dp = new Paint();
        dp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        c.drawBitmap(selMask, 0, 0, dp);
    }

    void copySel() {
        if (clipboard != null) clipboard.recycle();
        clipboard = selectedPixels(false);
        msg(clipboard == null ? "Nada para copiar" : "Copiado");
    }

    void cutSel() {
        if (activeLocked()) return;
        if (clipboard != null) clipboard.recycle();
        clipboard = selectedPixels(true);
        clipOrigin = maskBounds();
        invalidate();
        msg(clipboard == null ? "Nada para recortar" : "Recortado");
    }

    private Rect clipOrigin;

    void pasteSel() {
        if (clipboard == null) { msg("A área de transferência está vazia"); return; }
        if (activeLocked()) return;
        Rect r = maskBounds();
        startFloating(clipboard.copy(Bitmap.Config.ARGB_8888, true), r.centerX(), r.centerY());
    }

    void deleteSel() {
        if (activeLocked()) return;
        Bitmap lb = bm.get(layer().id);
        if (lb == null) return;
        record(layer().id, maskBounds());
        clearInSelection(lb);
        markDirty(layer().id);
        invalidate();
    }

    void fillSel() {
        if (activeLocked()) return;
        Bitmap lb = ensure(layer().id);
        record(layer().id, maskBounds());
        Canvas c = new Canvas(lb);
        Paint fp = new Paint();
        if (layer().alpha) fp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
        fp.setAlpha(Math.round(opacity * 2.55f));
        if (selMask == null) { Paint cp = new Paint(fp); cp.setColor(color); cp.setAlpha(fp.getAlpha()); c.drawRect(full, cp); }
        else {
            Paint tp = new Paint(fp);
            tp.setColor(color);
            tp.setAlpha(fp.getAlpha());
            c.drawBitmap(selMask, 0, 0, tp);
        }
        markDirty(layer().id);
        timelapse();
        invalidate();
    }

    /** Copia a seleção para uma nova camada logo acima. */
    boolean selToLayer(boolean cut) {
        if (p.layers.size() >= p.maxLayers()) { msg("Limite de camadas"); return false; }
        Bitmap px = selectedPixels(cut && !layer().locked);
        if (px == null) { msg("Nada selecionado nesta camada"); return false; }
        Rect r = maskBounds();
        Project.Layer nl = new Project.Layer();
        nl.id = p.nextLayer++;
        nl.name = cut ? "Recorte" : "Cópia";
        p.layers.add(active + 1, nl);
        active++;
        Bitmap b = ensure(nl.id);
        new Canvas(b).drawBitmap(px, r.left, r.top, null);
        px.recycle();
        markDirty(nl.id);
        invalidate();
        return true;
    }

    /* ================================================================ transformar */

    void liftFloating() {
        if (flt != null) return;
        if (activeLocked()) return;
        Project.Layer l = layer();
        Bitmap lb = bm.get(l.id);
        if (lb == null) { msg("Camada vazia"); return; }
        Rect r = selMask != null ? maskBounds() : contentBounds(lb);
        if (r == null || r.isEmpty()) { msg("Nada para transformar"); return; }
        liftBackup = lb.copy(Bitmap.Config.ARGB_8888, false);
        liftLayer = l.id;
        Bitmap f = Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(f);
        c.drawBitmap(lb, -r.left, -r.top, null);
        if (selMask != null) {
            Paint dp = new Paint();
            dp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            c.drawBitmap(selMask, -r.left, -r.top, dp);
        }
        clearInSelection(lb);
        setFloat(f, r.left, r.top);
    }

    /** Coloca uma imagem flutuando (colar, texto, importar) para mover/girar/escalar. */
    void startFloating(Bitmap b, float cx, float cy) {
        commitFloating();
        Project.Layer l = layer();
        Bitmap lb = ensure(l.id);
        liftBackup = lb.copy(Bitmap.Config.ARGB_8888, false);
        liftLayer = l.id;
        float k = Math.min(1f, Math.min(p.w * .9f / b.getWidth(), p.h * .9f / b.getHeight()));
        setFloat(b, 0, 0);
        Matrix t = new Matrix();
        t.setScale(k, k);
        t.postTranslate(cx - b.getWidth() * k / 2, cy - b.getHeight() * k / 2);
        System.arraycopy(fsrc, 0, fdst, 0, 8);
        t.mapPoints(fdst);
        updateFloat();
        tool = T_TRANSFORM;
        if (listener != null) listener.onTransform(true);
    }

    private void setFloat(Bitmap f, float x, float y) {
        flt = f;
        float w = f.getWidth(), hh = f.getHeight();
        fsrc[0] = 0; fsrc[1] = 0; fsrc[2] = w; fsrc[3] = 0; fsrc[4] = w; fsrc[5] = hh; fsrc[6] = 0; fsrc[7] = hh;
        for (int i = 0; i < 4; i++) { fdst[i * 2] = fsrc[i * 2] + x; fdst[i * 2 + 1] = fsrc[i * 2 + 1] + y; }
        updateFloat();
        if (listener != null) listener.onTransform(true);
    }

    private void updateFloat() {
        fm.setPolyToPoly(fsrc, 0, fdst, 0, 4);
        live.floating = flt;
        live.floatMatrix = fm;
        live.layerId = liftLayer;
        invalidate();
    }

    private Rect contentBounds(Bitmap b) {
        int w = b.getWidth(), hh = b.getHeight();
        Bitmap small = Bitmap.createScaledBitmap(b, Math.max(1, w / 4), Math.max(1, hh / 4), false);
        int sw = small.getWidth(), sh = small.getHeight();
        int[] px = new int[sw * sh];
        small.getPixels(px, 0, sw, 0, 0, sw, sh);
        small.recycle();
        int minX = sw, minY = sh, maxX = -1, maxY = -1;
        for (int y = 0; y < sh; y++) for (int x = 0; x < sw; x++) if ((px[y * sw + x] >>> 24) != 0) {
            minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y);
        }
        if (maxX < 0) return null;
        return clampRect(minX * 4 - 6, minY * 4 - 6, (maxX + 1) * 4 + 6, (maxY + 1) * 4 + 6);
    }

    private int hitHandle(float vx, float vy) {
        float[] v = fdst.clone();
        m.mapPoints(v);
        float R = Ui.dp(getContext(), 26);
        float[] rh = rotHandle(v);
        if (Math.hypot(vx - rh[0], vy - rh[1]) < R) return 4;
        for (int i = 0; i < 4; i++) if (Math.hypot(vx - v[i * 2], vy - v[i * 2 + 1]) < R) return i;
        return -1;
    }

    private void dragTransform(float x, float y) {
        float cx = (fdst0[0] + fdst0[2] + fdst0[4] + fdst0[6]) / 4, cy = (fdst0[1] + fdst0[3] + fdst0[5] + fdst0[7]) / 4;
        System.arraycopy(fdst0, 0, fdst, 0, 8);
        if (tfHandle == 4) {
            float a = (float) Math.toDegrees(Math.atan2(y - cy, x - cx) - Math.atan2(gy0 - cy, gx0 - cx));
            float snap = Math.round(a / 45f) * 45f;
            if (Math.abs(a - snap) < 4) a = snap;
            Matrix t = new Matrix();
            t.setRotate(a, cx, cy);
            t.mapPoints(fdst);
        } else if (tfHandle >= 0) {
            if (tfMode == 1) {
                fdst[tfHandle * 2] = fdst0[tfHandle * 2] + (x - gx0);
                fdst[tfHandle * 2 + 1] = fdst0[tfHandle * 2 + 1] + (y - gy0);
            } else {
                int opp = (tfHandle + 2) % 4;
                float axx = fdst0[opp * 2], ayy = fdst0[opp * 2 + 1];
                float d0 = (float) Math.hypot(fdst0[tfHandle * 2] - axx, fdst0[tfHandle * 2 + 1] - ayy);
                float d1 = (float) Math.hypot(x - axx, y - ayy);
                float k = d0 > 1 ? d1 / d0 : 1;
                Matrix t = new Matrix();
                t.setScale(k, k, axx, ayy);
                t.mapPoints(fdst);
            }
        } else {
            for (int i = 0; i < 4; i++) { fdst[i * 2] += x - gx0; fdst[i * 2 + 1] += y - gy0; }
        }
        updateFloat();
    }

    void flipFloat(boolean horizontal) {
        if (flt == null) liftFloating();
        if (flt == null) return;
        float[] d = fdst.clone();
        if (horizontal) {
            fdst[0] = d[2]; fdst[1] = d[3]; fdst[2] = d[0]; fdst[3] = d[1];
            fdst[4] = d[6]; fdst[5] = d[7]; fdst[6] = d[4]; fdst[7] = d[5];
        } else {
            fdst[0] = d[6]; fdst[1] = d[7]; fdst[6] = d[0]; fdst[7] = d[1];
            fdst[2] = d[4]; fdst[3] = d[5]; fdst[4] = d[2]; fdst[5] = d[3];
        }
        updateFloat();
    }

    void rotateFloat(float deg) {
        if (flt == null) liftFloating();
        if (flt == null) return;
        float cx = (fdst[0] + fdst[2] + fdst[4] + fdst[6]) / 4, cy = (fdst[1] + fdst[3] + fdst[5] + fdst[7]) / 4;
        Matrix t = new Matrix();
        t.setRotate(deg, cx, cy);
        t.mapPoints(fdst);
        updateFloat();
    }

    /** Ajusta o objeto para caber na tela inteira. */
    void fitFloat() {
        if (flt == null) return;
        float k = Math.min(p.w / (float) flt.getWidth(), p.h / (float) flt.getHeight());
        Matrix t = new Matrix();
        t.setScale(k, k);
        t.postTranslate((p.w - flt.getWidth() * k) / 2, (p.h - flt.getHeight() * k) / 2);
        System.arraycopy(fsrc, 0, fdst, 0, 8);
        t.mapPoints(fdst);
        updateFloat();
    }

    void commitFloating() {
        if (flt == null) return;
        Bitmap lb = ensure(liftLayer);
        Canvas c = new Canvas(lb);
        c.drawBitmap(flt, fm, plain);
        recordFrom(liftLayer, liftBackup, new Rect(0, 0, p.w, p.h));
        endFloat();
        markDirty(liftLayer);
        timelapse();
    }

    void cancelFloating() {
        if (flt == null) return;
        Bitmap lb = bm.get(liftLayer);
        if (lb != null && liftBackup != null) new Canvas(lb).drawBitmap(liftBackup, 0, 0, srcPaint());
        endFloat();
    }

    private void endFloat() {
        if (flt != null) flt.recycle();
        flt = null;
        if (liftBackup != null) liftBackup.recycle();
        liftBackup = null;
        live.floating = null;
        live.floatMatrix = null;
        if (listener != null) listener.onTransform(false);
        invalidate();
    }

    /* ================================================================ filtros */

    private Bitmap filterSrc;
    private int filterLayer = -1;

    /** Começa a prévia de filtro na camada atual. */
    boolean filterBegin() {
        if (activeLocked()) return false;
        Bitmap lb = bm.get(layer().id);
        if (lb == null) { msg("Camada vazia"); return false; }
        commitFloating();
        filterSrc = lb;
        filterLayer = layer().id;
        return true;
    }

    /** Monta o resultado (respeitando a seleção) — pode rodar fora da thread principal. */
    Bitmap filterCompute(String id, int[] v) {
        Bitmap src = filterSrc;
        if (src == null) return null;
        Bitmap f = Filters.apply(src, id, v, color);
        if (selMask != null) {
            Bitmap res = src.copy(Bitmap.Config.ARGB_8888, true);
            Canvas rc = new Canvas(res);
            Paint dp = new Paint();
            dp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
            rc.drawBitmap(selMask, 0, 0, dp);
            Canvas fc = new Canvas(f);
            Paint ip = new Paint();
            ip.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            fc.drawBitmap(selMask, 0, 0, ip);
            rc.drawBitmap(f, 0, 0, null);
            f.recycle();
            return res;
        }
        return f;
    }

    void filterPreview(Bitmap b) {
        if (live.replace != null && live.replace != b) live.replace.recycle();
        live.replace = b;
        live.layerId = filterLayer;
        invalidate();
    }

    void filterEnd(boolean apply) {
        Bitmap r = live.replace;
        live.replace = null;
        if (apply && r != null && filterSrc != null) {
            record(filterLayer, new Rect(0, 0, p.w, p.h));
            new Canvas(filterSrc).drawBitmap(r, 0, 0, srcPaint());
            markDirty(filterLayer);
            timelapse();
        }
        if (r != null) r.recycle();
        filterSrc = null;
        filterLayer = -1;
        invalidate();
    }

    /* ================================================================ camadas */

    Project.Layer addLayer(String name) {
        commitFloating();
        if (p.layers.size() >= p.maxLayers()) { msg("Limite de " + p.maxLayers() + " camadas para este tamanho"); return null; }
        Project.Layer l = new Project.Layer();
        l.id = p.nextLayer++;
        l.name = name;
        p.layers.add(active + 1, l);
        active++;
        p.save();
        invalidate();
        return l;
    }

    void deleteLayer(int idx) {
        commitFloating();
        if (p.layers.size() <= 1) { clearLayer(idx); return; }
        Project.Layer l = p.layers.remove(idx);
        Bitmap b = bm.remove(l.id);
        if (b != null) b.recycle();
        dirty.remove(l.id);
        final Project pp = p;
        final int lid = l.id;
        final ArrayList<Integer> frames = new ArrayList<>(p.frames);
        io.execute(() -> { for (int f : frames) pp.layerFile(f, lid).delete(); });
        active = Ui.clamp(active >= idx ? active - 1 : active, 0, p.layers.size() - 1);
        p.save();
        clearOnionCache();
        invalidate();
    }

    void clearLayer(int idx) {
        Project.Layer l = p.layers.get(idx);
        Bitmap b = bm.get(l.id);
        if (b == null) return;
        record(l.id, new Rect(0, 0, p.w, p.h));
        b.eraseColor(0);
        markDirty(l.id);
        invalidate();
    }

    void duplicateLayer(int idx) {
        commitFloating();
        if (p.layers.size() >= p.maxLayers()) { msg("Limite de camadas"); return; }
        saveCurrent();
        flush();
        Project.Layer s = p.layers.get(idx);
        Project.Layer l = new Project.Layer();
        l.id = p.nextLayer++;
        l.name = s.name + " cópia";
        l.blend = s.blend; l.opacity = s.opacity; l.clip = s.clip; l.alpha = s.alpha;
        p.layers.add(idx + 1, l);
        for (int f : p.frames) Project.copyFile(p.layerFile(f, s.id), p.layerFile(f, l.id));
        Bitmap b = bm.get(s.id);
        if (b != null) bm.put(l.id, b.copy(Bitmap.Config.ARGB_8888, true));
        active = idx + 1;
        p.save();
        invalidate();
    }

    void moveLayer(int from, int to) {
        if (to < 0 || to >= p.layers.size() || from == to) return;
        Project.Layer l = p.layers.remove(from);
        p.layers.add(to, l);
        if (active == from) active = to;
        else if (from < active && to >= active) active--;
        else if (from > active && to <= active) active++;
        p.save();
        clearOnionCache();
        invalidate();
    }

    /** Junta a camada com a de baixo, em todos os quadros. */
    void mergeDown(int idx) {
        if (idx <= 0) return;
        commitFloating();
        saveCurrent();
        flush();
        Project.Layer up = p.layers.get(idx), dn = p.layers.get(idx - 1);
        Paint lp = Render.layerPaint(new Paint(), up);
        for (int f : p.frames) {
            if (f == frameId()) continue;
            Bitmap a = p.loadLayer(f, up.id);
            if (a == null) continue;
            Bitmap b = p.loadLayer(f, dn.id);
            if (b == null) b = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            if (up.clip) {
                Bitmap t = a.copy(Bitmap.Config.ARGB_8888, true);
                Paint dp = new Paint();
                dp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
                new Canvas(t).drawBitmap(b, 0, 0, dp);
                c.drawBitmap(t, 0, 0, lp);
                t.recycle();
            } else c.drawBitmap(a, 0, 0, lp);
            Project.writePng(b, p.layerFile(f, dn.id));
            a.recycle();
            b.recycle();
            p.layerFile(f, up.id).delete();
        }
        Bitmap a = bm.remove(up.id);
        if (a != null) {
            Bitmap b = ensure(dn.id);
            if (up.clip) {
                Bitmap t = a.copy(Bitmap.Config.ARGB_8888, true);
                Paint dp = new Paint();
                dp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
                new Canvas(t).drawBitmap(b, 0, 0, dp);
                new Canvas(b).drawBitmap(t, 0, 0, lp);
                t.recycle();
            } else new Canvas(b).drawBitmap(a, 0, 0, lp);
            a.recycle();
            markDirty(dn.id);
        }
        p.layerFile(frameId(), up.id).delete();
        dirty.remove(up.id);
        p.layers.remove(idx);
        active = idx - 1;
        clearHistory();
        p.save();
        clearOnionCache();
        invalidate();
    }

    void flipLayer(boolean horizontal) {
        if (activeLocked()) return;
        Bitmap b = bm.get(layer().id);
        if (b == null) return;
        record(layer().id, new Rect(0, 0, p.w, p.h));
        Bitmap c = b.copy(Bitmap.Config.ARGB_8888, false);
        Canvas cv = new Canvas(b);
        cv.drawColor(0, PorterDuff.Mode.CLEAR);
        Matrix mm = new Matrix();
        if (horizontal) mm.setScale(-1, 1, p.w / 2f, 0); else mm.setScale(1, -1, 0, p.h / 2f);
        cv.drawBitmap(c, mm, null);
        c.recycle();
        markDirty(layer().id);
        invalidate();
    }

    /** Cria uma camada com uma imagem (ex.: importar foto) já em modo de transformação. */
    void importImage(Bitmap img) {
        if (addLayer("Imagem") == null) return;
        startFloating(img, p.w / 2f, p.h / 2f);
    }

    /** Quadrinhos: desenha as bordas dos painéis numa camada nova. */
    void comicPanels(int layout, float gutterPct, float border) {
        Project.Layer l = addLayer("Quadros HQ");
        if (l == null) return;
        Bitmap b = ensure(l.id);
        Canvas c = new Canvas(b);
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeWidth(border);
        bp.setColor(0xFF111111);
        float g = Math.min(p.w, p.h) * gutterPct, m0 = g * 1.2f;
        float W = p.w - m0 * 2, H = p.h - m0 * 2;
        float[][] cells;
        switch (layout) {
            case 0: cells = new float[][]{{0, 0, 1, .5f}, {0, .5f, 1, .5f}}; break;
            case 1: cells = new float[][]{{0, 0, 1, .34f}, {0, .34f, 1, .33f}, {0, .67f, 1, .33f}}; break;
            case 2: cells = new float[][]{{0, 0, .5f, .5f}, {.5f, 0, .5f, .5f}, {0, .5f, .5f, .5f}, {.5f, .5f, .5f, .5f}}; break;
            case 3: cells = new float[][]{{0, 0, 1, .4f}, {0, .4f, .5f, .6f}, {.5f, .4f, .5f, .6f}}; break;
            case 4: cells = new float[][]{{0, 0, .6f, .33f}, {.6f, 0, .4f, .33f}, {0, .33f, 1, .34f}, {0, .67f, .4f, .33f}, {.4f, .67f, .6f, .33f}}; break;
            default: cells = new float[][]{{0, 0, .5f, .33f}, {.5f, 0, .5f, .33f}, {0, .33f, .5f, .34f}, {.5f, .33f, .5f, .34f}, {0, .67f, .5f, .33f}, {.5f, .67f, .5f, .33f}};
        }
        for (float[] cl : cells) {
            float x = m0 + cl[0] * W + g / 2, y = m0 + cl[1] * H + g / 2;
            c.drawRect(x, y, x + cl[2] * W - g, y + cl[3] * H - g, bp);
        }
        markDirty(l.id);
        invalidate();
    }

    /* ================================================================ quadros */

    void addFrame(boolean copy) {
        commitFloating();
        saveCurrent();
        flush();
        int nid = p.nextFrame++;
        if (copy) p.copyFrameFiles(frameId(), nid);
        p.frames.add(frameIdx + 1, nid);
        p.save();
        loadFrame(frameIdx + 1);
    }

    void deleteFrame() {
        commitFloating();
        if (p.frames.size() <= 1) { for (Project.Layer l : p.layers) clearLayer(p.layers.indexOf(l)); return; }
        int fid = frameId();
        dirty.clear();
        flush();
        p.deleteFrameFiles(fid);
        p.frames.remove(frameIdx);
        onionCache.remove(fid);
        p.save();
        loadFrame(Math.min(frameIdx, p.frames.size() - 1));
    }

    void moveFrame(int dir) {
        int to = frameIdx + dir;
        if (to < 0 || to >= p.frames.size()) return;
        int id = p.frames.remove(frameIdx);
        p.frames.add(to, id);
        frameIdx = to;
        p.save();
        clearOnionCache();
        invalidate();
    }

    void setHold(int v) {
        int fid = frameId();
        v = Ui.clamp(v, 1, 24);
        if (v == 1) p.holds.remove(fid); else p.holds.put(fid, v);
        p.save();
    }

    /* ================================================================ time-lapse */

    private int tlCount;

    void timelapse() {
        if (p == null || !Prefs.on(getContext(), "tlapse", true)) return;
        tlCount++;
        if (p.tl > 2500 && tlCount % 2 == 1) return;
        final Bitmap b = renderComposite(720, true);
        final java.io.File f = p.tlFile(p.tl++);
        io.execute(() -> {
            try {
                FileOutputStream out = new FileOutputStream(f);
                b.compress(Bitmap.CompressFormat.JPEG, 82, out);
                out.close();
            } catch (Exception ignored) { }
            b.recycle();
        });
    }

    void resetClone() { cloneSet = false; invalidate(); }

    void release() {
        for (Bitmap b : bm.values()) if (b != null) b.recycle();
        bm.clear();
        for (Bitmap b : onionCache.values()) if (b != null) b.recycle();
        onionCache.clear();
        clearHistory();
    }
}
