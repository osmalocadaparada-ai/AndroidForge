package com.darkmonia.animator;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/** Projeto (desenho ou animação) salvo na pasta interna do app. */
public class Project {
    public static class Layer {
        int id;
        String name;
        boolean visible = true;
        boolean locked = false;
        /** bloquear transparência: só pinta onde já tem desenho */
        boolean alpha = false;
        /** máscara de recorte: só aparece onde a camada de baixo tem desenho */
        boolean clip = false;
        String blend = "normal";
        int opacity = 255;
    }

    File dir;
    String name = "Projeto";
    int w = 1080, h = 1080, fps = 12;
    /** Cor do papel; 0 = transparente. */
    int paper = 0xFFFFFFFF;
    boolean anim;
    long updated, created;
    int nextLayer = 1, nextFrame = 1;
    int tl = 0;
    final ArrayList<Layer> layers = new ArrayList<>();
    final ArrayList<Integer> frames = new ArrayList<>();
    final HashMap<Integer, Integer> holds = new HashMap<>();

    /** Lado máximo de trabalho (memória do celular). */
    static final int MAX_SIDE = 2048;

    static File root(Context c) {
        File f = new File(c.getFilesDir(), "projects");
        f.mkdirs();
        return f;
    }

    static ArrayList<Project> list(Context c) {
        ArrayList<Project> out = new ArrayList<>();
        File[] ds = root(c).listFiles();
        if (ds != null) for (File d : ds) {
            Project p = load(d);
            if (p != null) out.add(p);
        }
        Collections.sort(out, (a, b) -> Long.compare(b.updated, a.updated));
        return out;
    }

    static int[] fit(int w, int h) {
        float k = Math.min(1f, MAX_SIDE / (float) Math.max(w, h));
        return new int[]{Math.max(16, Math.round(w * k)), Math.max(16, Math.round(h * k))};
    }

    static Project create(Context c, String name, int w, int h, boolean anim) {
        Project p = new Project();
        p.dir = new File(root(c), "p" + System.currentTimeMillis());
        p.dir.mkdirs();
        int[] s = fit(w, h);
        p.name = name;
        p.w = s[0];
        p.h = s[1];
        p.anim = anim;
        p.addLayer("Desenho");
        p.frames.add(p.nextFrame++);
        p.created = p.updated = System.currentTimeMillis();
        p.save();
        return p;
    }

    Layer addLayer(String n) {
        Layer l = new Layer();
        l.id = nextLayer++;
        l.name = n;
        layers.add(l);
        return l;
    }

    int hold(int frameId) {
        Integer v = holds.get(frameId);
        return v == null ? 1 : v;
    }

    int maxLayers() {
        long px = (long) w * h;
        return px > 2_500_000 ? 10 : px > 1_500_000 ? 16 : 24;
    }

    static Project load(File d) {
        try {
            File mf = new File(d, "meta.json");
            if (!mf.exists()) return null;
            byte[] buf = new byte[(int) mf.length()];
            FileInputStream in = new FileInputStream(mf);
            int n = 0;
            while (n < buf.length) {
                int r = in.read(buf, n, buf.length - n);
                if (r < 0) break;
                n += r;
            }
            in.close();
            JSONObject o = new JSONObject(new String(buf, 0, n, "UTF-8"));
            Project p = new Project();
            p.dir = d;
            p.name = o.optString("name", "Projeto");
            p.w = o.getInt("w");
            p.h = o.getInt("h");
            p.fps = o.optInt("fps", 12);
            p.paper = o.optInt("paper", 0xFFFFFFFF);
            p.anim = o.optBoolean("anim", false);
            p.updated = o.optLong("updated", 0);
            p.created = o.optLong("created", p.updated);
            p.nextLayer = o.optInt("nextLayer", 1);
            p.nextFrame = o.optInt("nextFrame", 1);
            p.tl = o.optInt("tl", 0);
            JSONArray ls = o.getJSONArray("layers");
            for (int i = 0; i < ls.length(); i++) {
                JSONObject j = ls.getJSONObject(i);
                Layer l = new Layer();
                l.id = j.getInt("id");
                l.name = j.optString("name", "Camada");
                l.visible = j.optBoolean("visible", true);
                l.locked = j.optBoolean("locked", false);
                l.alpha = j.optBoolean("alpha", false);
                l.clip = j.optBoolean("clip", false);
                l.blend = j.optString("blend", "normal");
                l.opacity = j.optInt("opacity", 255);
                p.layers.add(l);
            }
            JSONArray fs = o.getJSONArray("frames");
            for (int i = 0; i < fs.length(); i++) p.frames.add(fs.getInt(i));
            JSONObject hs = o.optJSONObject("holds");
            if (hs != null) {
                JSONArray names = hs.names();
                if (names != null) for (int i = 0; i < names.length(); i++) {
                    String k = names.getString(i);
                    p.holds.put(Integer.parseInt(k), hs.getInt(k));
                }
            }
            if (p.layers.isEmpty() || p.frames.isEmpty()) return null;
            return p;
        } catch (Exception e) {
            return null;
        }
    }

    void save() {
        try {
            JSONObject o = new JSONObject();
            o.put("name", name);
            o.put("w", w);
            o.put("h", h);
            o.put("fps", fps);
            o.put("paper", paper);
            o.put("anim", anim);
            o.put("updated", updated);
            o.put("created", created);
            o.put("nextLayer", nextLayer);
            o.put("nextFrame", nextFrame);
            o.put("tl", tl);
            JSONArray ls = new JSONArray();
            for (Layer l : layers) {
                JSONObject j = new JSONObject();
                j.put("id", l.id);
                j.put("name", l.name);
                j.put("visible", l.visible);
                j.put("locked", l.locked);
                j.put("alpha", l.alpha);
                j.put("clip", l.clip);
                j.put("blend", l.blend);
                j.put("opacity", l.opacity);
                ls.put(j);
            }
            o.put("layers", ls);
            JSONArray fs = new JSONArray();
            for (int f : frames) fs.put(f);
            o.put("frames", fs);
            JSONObject hs = new JSONObject();
            for (int f : frames) if (hold(f) > 1) hs.put(String.valueOf(f), hold(f));
            o.put("holds", hs);
            FileOutputStream out = new FileOutputStream(new File(dir, "meta.json"));
            out.write(o.toString().getBytes("UTF-8"));
            out.close();
        } catch (Exception e) { /* melhor esforço */ }
    }

    File layerFile(int frameId, int layerId) {
        return new File(dir, "f" + frameId + "_l" + layerId + ".png");
    }

    File thumbFile() {
        return new File(dir, "thumb.png");
    }

    File tlFile(int i) {
        File d = new File(dir, "timelapse");
        d.mkdirs();
        return new File(d, i + ".jpg");
    }

    Bitmap loadLayer(int frameId, int layerId) {
        File f = layerFile(frameId, layerId);
        if (!f.exists()) return null;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inMutable = true;
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap b = BitmapFactory.decodeFile(f.getPath(), o);
        if (b != null && (b.getWidth() != w || b.getHeight() != h)) {
            Bitmap s = Bitmap.createScaledBitmap(b, w, h, true);
            if (s != b) b.recycle();
            return s.isMutable() ? s : s.copy(Bitmap.Config.ARGB_8888, true);
        }
        return b;
    }

    static void writePng(Bitmap b, File f) {
        try {
            FileOutputStream out = new FileOutputStream(f);
            b.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();
        } catch (Exception e) { /* melhor esforço */ }
    }

    static void copyFile(File src, File dst) {
        if (!src.exists()) { dst.delete(); return; }
        try {
            FileInputStream in = new FileInputStream(src);
            FileOutputStream out = new FileOutputStream(dst);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            out.close();
        } catch (Exception e) { /* melhor esforço */ }
    }

    /** Copia todos os arquivos de um quadro para outro. */
    void copyFrameFiles(int fromId, int toId) {
        for (Layer l : layers) copyFile(layerFile(fromId, l.id), layerFile(toId, l.id));
        holds.put(toId, hold(fromId));
    }

    /** Imagem final de um quadro (lida do disco), com no máximo maxSide de lado. */
    Bitmap composite(int frameId, int maxSide, boolean withPaper) {
        float k = Math.min(1f, maxSide / (float) Math.max(w, h));
        int cw = Math.max(1, Math.round(w * k)), ch = Math.max(1, Math.round(h * k));
        Bitmap out = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        if (withPaper && (paper >>> 24) != 0) c.drawColor(paper);
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inSampleSize = Math.max(1, Integer.highestOneBit(Math.max(1, (int) (1f / k))));
        HashMap<Integer, Bitmap> bm = new HashMap<>();
        for (Layer l : layers) {
            if (!l.visible) continue;
            File f = layerFile(frameId, l.id);
            if (!f.exists()) continue;
            Bitmap b = BitmapFactory.decodeFile(f.getPath(), o);
            if (b != null) bm.put(l.id, b);
        }
        c.scale(k, k);
        Render.stack(c, this, bm, null);
        for (Bitmap b : bm.values()) b.recycle();
        return out;
    }

    void deleteFrameFiles(int frameId) {
        for (Layer l : layers) layerFile(frameId, l.id).delete();
        holds.remove(frameId);
    }

    static void deleteDir(File d) {
        File[] fs = d.listFiles();
        if (fs != null) for (File f : fs) { if (f.isDirectory()) deleteDir(f); else f.delete(); }
        d.delete();
    }

    void deleteAll() { deleteDir(dir); }

    /** Cópia completa do projeto (todos os arquivos). */
    Project duplicate(Context c) {
        File nd = new File(root(c), "p" + System.currentTimeMillis());
        nd.mkdirs();
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) if (f.isFile()) copyFile(f, new File(nd, f.getName()));
        Project p = load(nd);
        if (p == null) return null;
        p.name = (name + " (cópia)");
        if (p.name.length() > 40) p.name = p.name.substring(0, 40);
        p.created = p.updated = System.currentTimeMillis();
        p.tl = 0;
        p.save();
        return p;
    }
}
