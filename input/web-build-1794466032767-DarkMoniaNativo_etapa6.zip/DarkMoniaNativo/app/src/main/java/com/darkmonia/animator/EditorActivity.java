package com.darkmonia.animator;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Editor nativo: pincéis, camadas, cores, seleção, filtros, guias, animação e exportação. */
public class EditorActivity extends Activity implements CanvasView.Listener {
    private static final int REQ_IMPORT = 7, REQ_REF = 8, REQ_PERM = 9;

    static final Object[][] TOOLS = {
            {CanvasView.T_BRUSH, "brush", "Pincel"}, {CanvasView.T_ERASER, "eraser", "Borracha"},
            {CanvasView.T_FILL, "bucket", "Balde"}, {CanvasView.T_PICK, "pipette", "Conta-gotas"},
            {CanvasView.T_SELECT, "lasso", "Seleção"}, {CanvasView.T_TRANSFORM, "transform", "Transformar"},
            {CanvasView.T_SHAPE, "rect", "Formas"}, {CanvasView.T_GRADIENT, "gradient", "Degradê"},
            {CanvasView.T_TEXT, "text", "Texto"}, {CanvasView.T_LIQUIFY, "liquify", "Liquidificar"},
            {CanvasView.T_CLONE, "clone", "Carimbo"}, {CanvasView.T_RECOLOR, "recolor", "Recolorir"},
            {CanvasView.T_LASSOFILL, "lassofill", "Laço de tinta"}, {CanvasView.T_LASSOERASE, "lassoerase", "Laço borracha"},
            {CanvasView.T_GUIDES, "assist", "Guias"}, {CanvasView.T_HAND, "hand", "Mover tela"},
    };
    static final int[] PALETTE = {0xFF16161D, 0xFFFFFFFF, 0xFF6B6F80, 0xFFC9CCD6, 0xFFE5476B, 0xFFFF6B8F, 0xFFFF8A3D, 0xFFF2C94C,
            0xFFFFE27A, 0xFF22C3A6, 0xFF2BB673, 0xFF1B7F4B, 0xFF4D8DFF, 0xFF1B2A8A, 0xFF8D7AFF, 0xFFB44DFF,
            0xFF7A4A2A, 0xFFC68B59, 0xFFF6D2B8, 0xFFFFC7A8, 0xFF9E2B25, 0xFF2B2A28, 0xFF6FD3FF, 0xFFFFB3D9};
    static final String[] BLEND_NAMES = {"Normal", "Multiplicar", "Tela", "Sobrepor", "Luz suave", "Luz forte", "Escurecer", "Clarear",
            "Subexpor cor", "Superexpor cor", "Adição", "Diferença", "Exclusão", "Matiz", "Saturação", "Cor", "Luminosidade"};

    private Project p;
    private CanvasView cv;
    private FrameLayout root;
    private LinearLayout toolRow, optRow, frameRow;
    private View timeline, optWrap;
    private ImageView undoB, redoB, playB;
    private ColorDot colorDot;
    private VSlider sizeS, opS;
    private TextView bubble;
    private final HashMap<Integer, View> toolBtns = new HashMap<>();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private final ArrayList<Integer> recent = new ArrayList<>();
    private final HashMap<Integer, Bitmap> frameThumbs = new HashMap<>();
    private Sheet layersSheet;
    private boolean playing, busy;
    private Runnable pendingPerm;
    private FrameLayout refWin;
    private Bitmap refBmp;
    private View playCover;
    private final Runnable autosave = () -> { if (cv != null && !playing) cv.saveCurrent(); };
    private final Runnable thumbRefresh = this::refreshCurrentThumb;

    private int dp(float v) { return Ui.dp(this, v); }

    /* ================================================================ ciclo de vida */

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        Prefs.init(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        String dir = getIntent().getStringExtra("dir");
        p = dir == null ? null : Project.load(new File(dir));
        if (p == null) { Ui.toast(this, "Não consegui abrir o projeto"); finish(); return; }
        build();
        loadToolPrefs();
        cv.setProject(p);
        setTool(CanvasView.T_BRUSH);
        refreshTimeline();
        String action = getIntent().getStringExtra("action");
        if ("play".equals(action)) ui.postDelayed(this::play, 400);
        else if ("export".equals(action)) ui.postDelayed(this::exportSheet, 300);
        else if (!Prefs.on(this, "tipSeen", false)) ui.postDelayed(this::tips, 500);
    }

    private void loadToolPrefs() {
        cv.brushId = Prefs.get(this).getString("brush", "gpen");
        cv.brushSize = Prefs.get(this).getFloat("bsize", Brushes.get(cv.brushId).defSize);
        cv.eraserSize = Prefs.get(this).getFloat("esize", 30);
        cv.opacity = Prefs.num(this, "bop", 100);
        cv.color = Prefs.num(this, "color", 0xFF16161D);
        cv.color2 = Prefs.num(this, "color2", 0xFFFFFFFF);
        cv.stabilizer = Prefs.num(this, "stab", 15);
        cv.eraserType = Prefs.get(this).getString("etype", "e_round");
        cv.onionPrev = Prefs.num(this, "onPrev", 1);
        cv.onionNext = Prefs.num(this, "onNext", 1);
        cv.onionAlpha = Prefs.num(this, "onAlpha", 35);
        cv.onion = Prefs.on(this, "onion", true);
        cv.onionColor = Prefs.on(this, "onColor", true);
        recent.addAll(Prefs.colors(this, "recent", new int[]{}));
        colorDot.set(cv.color);
    }

    private void saveToolPrefs() {
        Prefs.get(this).edit().putString("brush", cv.brushId).putFloat("bsize", cv.brushSize).putFloat("esize", cv.eraserSize)
                .putString("etype", cv.eraserType).apply();
        Prefs.put(this, "bop", cv.opacity);
        Prefs.put(this, "color", cv.color);
        Prefs.put(this, "color2", cv.color2);
        Prefs.put(this, "stab", cv.stabilizer);
        Prefs.colors(this, "recent", recent);
    }

    @Override protected void onPause() {
        super.onPause();
        if (cv == null) return;
        stopPlay();
        cv.commitFloating();
        cv.saveCurrent();
        saveToolPrefs();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (cv != null) {
            cv.flush();
            cv.release();
            cv.io.shutdown();
        }
        work.shutdown();
    }

    @Override public void onBackPressed() {
        if (playing) { stopPlay(); return; }
        if (cv.flt != null) { cv.commitFloating(); setTool(CanvasView.T_BRUSH); return; }
        cv.saveCurrent();
        cv.flush();
        finish();
    }

    /* ================================================================ interface */

    private void build() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        cv = new CanvasView(this);
        cv.listener = this;
        cv.drawOnly = !p.anim;
        root.addView(cv, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        /* barra de cima */
        LinearLayout top = Ui.row(this);
        top.setPadding(dp(8), dp(6), dp(8), dp(6));
        top.setBackground(Ui.bgStroke(0xF0171925, Ui.LINE, dp(18), dp(1)));
        top.setElevation(dp(6));
        top.addView(iconBtn("prev", v -> onBackPressed()));
        undoB = iconBtn("undo", v -> { if (!cv.undo()) Ui.toast(this, "Nada para desfazer"); });
        redoB = iconBtn("redo", v -> { if (!cv.redo()) Ui.toast(this, "Nada para refazer"); });
        top.addView(undoB);
        top.addView(redoB);
        TextView title = Ui.text(this, p.name, 13, Ui.MUTE, true);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setPadding(dp(8), 0, dp(8), 0);
        title.setGravity(Gravity.CENTER);
        top.addView(title, Ui.lpw(1));
        top.addView(iconBtn("act_ref", v -> pickImage(REQ_REF)));
        top.addView(iconBtn("adjust", v -> filtersSheet()));
        top.addView(iconBtn("layers", v -> layersSheet()));
        top.addView(iconBtn("menu", v -> menuSheet()));
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.TOP);
        tl.setMargins(dp(8), dp(8), dp(8), 0);
        root.addView(top, tl);

        /* controles laterais (tamanho e opacidade) */
        LinearLayout side = Ui.col(this);
        side.setGravity(Gravity.CENTER_HORIZONTAL);
        side.setPadding(dp(5), dp(8), dp(5), dp(8));
        side.setBackground(Ui.bgStroke(0xE6171925, Ui.LINE, dp(16), dp(1)));
        sizeS = new VSlider(this, "Tam.");
        opS = new VSlider(this, "Opac.");
        side.addView(sizeS, new LinearLayout.LayoutParams(dp(30), dp(150)));
        side.addView(Ui.gap(this, 1, 12));
        side.addView(opS, new LinearLayout.LayoutParams(dp(30), dp(110)));
        FrameLayout.LayoutParams sl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.START | Gravity.CENTER_VERTICAL);
        sl.leftMargin = dp(6);
        root.addView(side, sl);
        sizeS.l = (v, done) -> {
            float max = maxSize();
            float sz = 1 + (max - 1) * v * v;
            setSize(sz);
            showBubble(Math.round(sz) + " px", done);
        };
        opS.l = (v, done) -> {
            int o = Math.max(1, Math.round(v * 100));
            if (cv.tool == CanvasView.T_ERASER) cv.eraserOpacity = o; else cv.opacity = o;
            showBubble("Opacidade " + o + "%", done);
        };

        bubble = Ui.text(this, "", 14, 0xFFFFFFFF, true);
        bubble.setPadding(dp(14), dp(8), dp(14), dp(8));
        bubble.setBackground(Ui.bg(0xE6222537, dp(999)));
        bubble.setVisibility(View.GONE);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        bl.topMargin = dp(70);
        root.addView(bubble, bl);

        /* parte de baixo: opções da ferramenta, linha do tempo e doca */
        LinearLayout bottom = Ui.col(this);
        bottom.setPadding(dp(8), 0, dp(8), dp(8));

        HorizontalScrollView os = new HorizontalScrollView(this);
        os.setHorizontalScrollBarEnabled(false);
        optRow = Ui.row(this);
        optRow.setPadding(dp(8), dp(6), dp(8), dp(6));
        os.addView(optRow);
        os.setBackground(Ui.bgStroke(0xE6171925, Ui.LINE, dp(16), dp(1)));
        optWrap = os;
        LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        ol.gravity = Gravity.CENTER_HORIZONTAL;
        ol.bottomMargin = dp(6);
        bottom.addView(os, ol);

        if (p.anim) {
            timeline = buildTimeline();
            LinearLayout.LayoutParams tll = new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP);
            tll.bottomMargin = dp(6);
            bottom.addView(timeline, tll);
        }

        LinearLayout dock = Ui.row(this);
        dock.setPadding(dp(6), dp(6), dp(6), dp(6));
        dock.setBackground(Ui.bgStroke(0xF0171925, Ui.LINE, dp(20), dp(1)));
        dock.setElevation(dp(8));
        HorizontalScrollView ts = new HorizontalScrollView(this);
        ts.setHorizontalScrollBarEnabled(false);
        toolRow = Ui.row(this);
        for (Object[] t : TOOLS) {
            final int id = (Integer) t[0];
            View b = toolBtn((String) t[1], (String) t[2]);
            b.setOnClickListener(v -> {
                if (cv.tool == id && id == CanvasView.T_BRUSH) brushSheet();
                else if (cv.tool == id && id == CanvasView.T_GUIDES) guidesSheet();
                else setTool(id);
            });
            if (id == CanvasView.T_BRUSH) b.setOnLongClickListener(v -> { brushSheet(); return true; });
            toolBtns.put(id, b);
            toolRow.addView(b);
        }
        ts.addView(toolRow);
        dock.addView(ts, Ui.lpw(1));
        colorDot = new ColorDot(this);
        colorDot.setOnClickListener(v -> colorSheet());
        colorDot.setOnLongClickListener(v -> {
            int t = cv.color; setColor(cv.color2, false); cv.color2 = t;
            Ui.toast(this, "Cores trocadas");
            return true;
        });
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(dp(46), dp(46));
        cl.leftMargin = dp(6);
        dock.addView(colorDot, cl);
        bottom.addView(dock, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        root.addView(bottom, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM));
        Ui.padInsets(root, true);
        setContentView(root);
    }

    private float maxSize() {
        return cv.tool == CanvasView.T_ERASER ? 500 : cv.tool == CanvasView.T_LIQUIFY ? 600 : 400;
    }

    private void setSize(float sz) {
        if (cv.tool == CanvasView.T_ERASER) cv.eraserSize = sz;
        else if (cv.tool == CanvasView.T_LIQUIFY) cv.liqSize = sz;
        else cv.brushSize = sz;
    }

    private float curSize() {
        return cv.tool == CanvasView.T_ERASER ? cv.eraserSize : cv.tool == CanvasView.T_LIQUIFY ? cv.liqSize : cv.brushSize;
    }

    private void syncSliders() {
        float max = maxSize();
        sizeS.set((float) Math.sqrt(Math.max(0, (curSize() - 1) / (max - 1))));
        opS.set((cv.tool == CanvasView.T_ERASER ? cv.eraserOpacity : cv.opacity) / 100f);
    }

    private void showBubble(String s, boolean done) {
        bubble.setText(s);
        bubble.setVisibility(View.VISIBLE);
        ui.removeCallbacks(hideBubble);
        if (done) ui.postDelayed(hideBubble, 700);
    }

    private final Runnable hideBubble = () -> bubble.setVisibility(View.GONE);

    private ImageView iconBtn(String icon, View.OnClickListener l) {
        ImageView b = new ImageView(this);
        b.setImageDrawable(Ui.icon(this, icon, Ui.FG));
        b.setPadding(dp(9), dp(9), dp(9), dp(9));
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(42), dp(42)));
        b.setBackground(Ui.bg(0, dp(12)));
        b.setOnClickListener(l);
        return Ui.pressable(b);
    }

    private View toolBtn(String icon, String name) {
        FrameLayout f = new FrameLayout(this);
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(Ui.icon(this, icon, Ui.FG));
        iv.setTag("icon");
        f.addView(iv, new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
        f.setContentDescription(name);
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(46), dp(46)));
        return Ui.pressable(f);
    }

    private void paintToolBtn(int id, boolean on) {
        View b = toolBtns.get(id);
        if (b == null) return;
        b.setBackground(on ? Ui.bg(Ui.ACC, dp(14)) : null);
        ImageView iv = (ImageView) ((FrameLayout) b).getChildAt(0);
        String icon = null;
        for (Object[] t : TOOLS) if ((Integer) t[0] == id) icon = (String) t[1];
        if (id == CanvasView.T_BRUSH) {
            icon = Ui.icon(this, cv.brushId, 0) != null ? cv.brushId : "brush";
        }
        iv.setImageDrawable(Ui.icon(this, icon, on ? 0xFFFFFFFF : Ui.FG));
    }

    void setTool(int t) {
        if (cv.tool == CanvasView.T_TRANSFORM && t != CanvasView.T_TRANSFORM && cv.flt != null) cv.commitFloating();
        if (cv.tool == CanvasView.T_SELECT && cv.polyOpen() && t != CanvasView.T_SELECT) cv.closePoly();
        cv.tool = t;
        for (Object[] o : TOOLS) paintToolBtn((Integer) o[0], (Integer) o[0] == t);
        if (t == CanvasView.T_TRANSFORM && cv.flt == null) cv.liftFloating();
        buildOptions();
        syncSliders();
        cv.invalidate();
    }

    /* ---------------- barra de opções de cada ferramenta ---------------- */

    private Button chip(String t, boolean on, View.OnClickListener l) {
        Button b = Ui.btn(this, t);
        Ui.sel(b, on);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.WRAP, dp(34));
        lp.rightMargin = dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    private View mini(String label, int max, int value, Ui.Seek s) {
        LinearLayout r = Ui.row(this);
        TextView t = Ui.text(this, label, 11.5f, Ui.MUTE, true);
        r.addView(t);
        SeekBar sb = Ui.seek(this, max, value, s);
        r.addView(sb, new LinearLayout.LayoutParams(dp(120), Ui.WRAP));
        r.setPadding(0, 0, dp(6), 0);
        return r;
    }

    private void hint(String s) {
        TextView t = Ui.text(this, s, 12, Ui.MUTE, false);
        t.setPadding(dp(4), 0, dp(8), 0);
        optRow.addView(t);
    }

    private void buildOptions() {
        optRow.removeAllViews();
        int t = cv.tool;
        switch (t) {
            case CanvasView.T_BRUSH: {
                Brushes.B b = Brushes.get(cv.brushId);
                Button nb = chip("✎ " + b.name, true, v -> brushSheet());
                optRow.addView(nb);
                optRow.addView(mini("Estabilizar", 100, cv.stabilizer, new Ui.Seek() { void change(int v) { cv.stabilizer = v; } }));
                optRow.addView(chip(cv.symMode == 0 ? "Simetria" : "Simetria ✓", cv.symMode != 0, v -> guidesSheet()));
                optRow.addView(chip(cv.layer().alpha ? "Trava alfa ✓" : "Trava alfa", cv.layer().alpha, v -> { cv.layer().alpha = !cv.layer().alpha; p.save(); buildOptions(); }));
                break;
            }
            case CanvasView.T_ERASER:
                optRow.addView(chip("Dura", cv.eraserType.equals("e_round"), v -> { cv.eraserType = "e_round"; buildOptions(); }));
                optRow.addView(chip("Suave", cv.eraserType.equals("e_soft"), v -> { cv.eraserType = "e_soft"; buildOptions(); }));
                optRow.addView(chip("Lápis", cv.eraserType.equals("e_grain"), v -> { cv.eraserType = "e_grain"; buildOptions(); }));
                optRow.addView(mini("Estabilizar", 100, cv.stabilizer, new Ui.Seek() { void change(int v) { cv.stabilizer = v; } }));
                break;
            case CanvasView.T_FILL:
                optRow.addView(mini("Tolerância", 255, cv.fillTol, new Ui.Seek() { void change(int v) { cv.fillTol = v; } }));
                optRow.addView(mini("Fechar falhas", 12, cv.fillGap, new Ui.Seek() { void change(int v) { cv.fillGap = v; } }));
                optRow.addView(mini("Expandir", 6, cv.fillExpand, new Ui.Seek() { void change(int v) { cv.fillExpand = v; } }));
                optRow.addView(chip("Todas as camadas", cv.fillAll, v -> { cv.fillAll = !cv.fillAll; buildOptions(); }));
                break;
            case CanvasView.T_PICK:
                hint("Toque ou arraste para pegar a cor. Dica: segure o dedo com o pincel.");
                break;
            case CanvasView.T_SELECT: {
                String[] modes = {"Retângulo", "Elipse", "Laço", "Polígono", "Varinha", "Por cor"};
                for (int i = 0; i < modes.length; i++) {
                    final int fi = i;
                    optRow.addView(chip(modes[i], cv.selMode == i, v -> { cv.selMode = fi; buildOptions(); }));
                }
                String[] ops = {"Nova", "Somar", "Tirar"};
                for (int i = 0; i < 3; i++) {
                    final int fi = i;
                    optRow.addView(chip(ops[i], cv.selOp == i, v -> { cv.selOp = fi; buildOptions(); }));
                }
                if (cv.selMode == 3) optRow.addView(chip("Fechar polígono", false, v -> cv.closePoly()));
                if (cv.selMode >= 4) optRow.addView(mini("Tolerância", 255, cv.fillTol, new Ui.Seek() { void change(int v) { cv.fillTol = v; } }));
                optRow.addView(chip("Tudo", false, v -> cv.selectAll()));
                optRow.addView(chip("Do desenho", false, v -> cv.selectLayerContent()));
                optRow.addView(chip("Inverter", false, v -> cv.invertSelection()));
                optRow.addView(chip("Limpar", false, v -> cv.clearSelection()));
                optRow.addView(chip("Copiar", false, v -> cv.copySel()));
                optRow.addView(chip("Recortar", false, v -> cv.cutSel()));
                optRow.addView(chip("Colar", false, v -> cv.pasteSel()));
                optRow.addView(chip("Apagar", false, v -> cv.deleteSel()));
                optRow.addView(chip("Preencher", false, v -> cv.fillSel()));
                optRow.addView(chip("→ Nova camada", false, v -> { if (cv.selToLayer(false)) Ui.toast(this, "Copiado para nova camada"); }));
                optRow.addView(chip("Transformar", false, v -> setTool(CanvasView.T_TRANSFORM)));
                break;
            }
            case CanvasView.T_TRANSFORM:
                optRow.addView(chip("Uniforme", cv.tfMode == 0, v -> { cv.tfMode = 0; buildOptions(); }));
                optRow.addView(chip("Distorcer", cv.tfMode == 1, v -> { cv.tfMode = 1; buildOptions(); }));
                optRow.addView(chip("⇋ Espelhar", false, v -> cv.flipFloat(true)));
                optRow.addView(chip("⇵ Espelhar", false, v -> cv.flipFloat(false)));
                optRow.addView(chip("↻ 90°", false, v -> cv.rotateFloat(90)));
                optRow.addView(chip("Ajustar à tela", false, v -> cv.fitFloat()));
                optRow.addView(chip("Cancelar", false, v -> { cv.cancelFloating(); setTool(CanvasView.T_BRUSH); }));
                Button ok = chip("✓ Aplicar", true, v -> { cv.commitFloating(); setTool(CanvasView.T_BRUSH); });
                optRow.addView(ok);
                break;
            case CanvasView.T_SHAPE: {
                String[] sh = {"Reta", "Retângulo", "Elipse", "Estrela", "Polígono", "Seta"};
                for (int i = 0; i < sh.length; i++) {
                    final int fi = i;
                    optRow.addView(chip(sh[i], cv.shapeType == i, v -> { cv.shapeType = fi; buildOptions(); }));
                }
                optRow.addView(chip("Preenchida", cv.shapeFill, v -> { cv.shapeFill = !cv.shapeFill; buildOptions(); }));
                if (cv.shapeType == 3 || cv.shapeType == 4)
                    optRow.addView(mini("Pontas", 12, cv.polySides, new Ui.Seek() { void change(int v) { cv.polySides = Math.max(3, v); } }));
                break;
            }
            case CanvasView.T_GRADIENT:
                optRow.addView(chip("Linear", cv.gradType == 0, v -> { cv.gradType = 0; buildOptions(); }));
                optRow.addView(chip("Radial", cv.gradType == 1, v -> { cv.gradType = 1; buildOptions(); }));
                optRow.addView(chip("Cor → transparente", !cv.gradTwo, v -> { cv.gradTwo = false; buildOptions(); }));
                optRow.addView(chip("Cor → 2ª cor", cv.gradTwo, v -> { cv.gradTwo = true; buildOptions(); }));
                hint("Arraste na tela. Segure a bolinha de cor para trocar as cores.");
                break;
            case CanvasView.T_TEXT:
                hint("Toque na tela onde o texto deve ficar.");
                break;
            case CanvasView.T_LIQUIFY: {
                String[] lm = {"Empurrar", "Girar", "Contrair", "Inflar"};
                for (int i = 0; i < lm.length; i++) {
                    final int fi = i;
                    optRow.addView(chip(lm[i], cv.liqMode == i, v -> { cv.liqMode = fi; buildOptions(); }));
                }
                optRow.addView(mini("Força", 100, cv.liqStrength, new Ui.Seek() { void change(int v) { cv.liqStrength = Math.max(1, v); } }));
                break;
            }
            case CanvasView.T_CLONE:
                optRow.addView(chip("Marcar nova origem", false, v -> { cv.resetClone(); Ui.toast(this, "Toque no ponto que quer copiar"); }));
                hint("1º toque marca a origem; depois pinte.");
                break;
            case CanvasView.T_RECOLOR:
                optRow.addView(mini("Tolerância", 255, cv.recolorTol, new Ui.Seek() { void change(int v) { cv.recolorTol = v; } }));
                hint("Pinte por cima: troca a cor tocada pela cor atual.");
                break;
            case CanvasView.T_LASSOFILL:
                hint("Contorne uma área para preenchê-la com a cor atual.");
                break;
            case CanvasView.T_LASSOERASE:
                hint("Contorne uma área para apagá-la.");
                break;
            case CanvasView.T_GUIDES:
                guideOptions();
                break;
            case CanvasView.T_HAND:
                optRow.addView(chip("Ajustar", false, v -> cv.fitView()));
                optRow.addView(chip("100%", false, v -> cv.zoom100()));
                optRow.addView(chip("Espelhar visão", false, v -> cv.flipView()));
                break;
            default:
                break;
        }
        optWrap.setVisibility(optRow.getChildCount() == 0 ? View.GONE : View.VISIBLE);
    }

    private void guideOptions() {
        String[] g = {"Sem guia", "Grade", "Perspectiva 1", "Perspectiva 2", "Isométrica"};
        for (int i = 0; i < g.length; i++) {
            final int fi = i;
            optRow.addView(chip(g[i], cv.guide == i, v -> { cv.guide = fi; cv.invalidate(); buildOptions(); }));
        }
        optRow.addView(chip("Régua (travar traço)", cv.snapGuide, v -> { cv.snapGuide = !cv.snapGuide; buildOptions(); }));
        optRow.addView(mini("Grade", 256, cv.gridSize, new Ui.Seek() { void change(int v) { cv.gridSize = Math.max(8, v); cv.invalidate(); } }));
        hint("Arraste para mover o ponto de fuga.");
    }

    /* ================================================================ eventos da tela */

    @Override public void onColorPicked(int c) { setColor(c, true); }

    @Override public void onChanged() {
        ui.removeCallbacks(autosave);
        ui.postDelayed(autosave, 20000);
        if (p.anim) { ui.removeCallbacks(thumbRefresh); ui.postDelayed(thumbRefresh, 500); }
        if (layersSheet != null && layersSheet.isShowing()) { ui.removeCallbacks(layersRefresh); ui.postDelayed(layersRefresh, 300); }
    }

    private final Runnable layersRefresh = () -> { if (layersSheet != null && layersSheet.isShowing()) fillLayers(); };

    @Override public void onSelection(boolean has) { if (cv.tool == CanvasView.T_SELECT) buildOptions(); }

    @Override public void onTransform(boolean on) {
        if (on && cv.tool != CanvasView.T_TRANSFORM) { cv.tool = CanvasView.T_TRANSFORM; for (Object[] o : TOOLS) paintToolBtn((Integer) o[0], (Integer) o[0] == cv.tool); buildOptions(); }
    }

    @Override public void onMessage(String s) { Ui.toast(this, s); }

    @Override public void onTextAt(float x, float y) { textSheet(x, y); }

    @Override public void onHistory() {
        undoB.setAlpha(cv.canUndo() || cv.flt != null ? 1f : .4f);
        redoB.setAlpha(cv.canRedo() ? 1f : .4f);
    }

    void setColor(int c, boolean remember) {
        cv.color = c | 0xFF000000;
        colorDot.set(cv.color);
        if (remember) addRecent(cv.color);
    }

    private void addRecent(int c) {
        recent.remove((Integer) c);
        recent.add(0, c);
        while (recent.size() > 14) recent.remove(recent.size() - 1);
    }

    /* ================================================================ pincéis */

    private void brushSheet() {
        final Sheet s = new Sheet(this, "Pincéis");
        for (String cat : Brushes.CATS) {
            s.section(cat);
            LinearLayout grid = Ui.col(this);
            LinearLayout row = null;
            int i = 0;
            for (final Brushes.B b : Brushes.ALL) {
                if (!b.cat.equals(cat)) continue;
                if (i % 2 == 0) { row = Ui.row(this); grid.addView(row, gapB(8)); }
                LinearLayout card = Ui.row(this);
                card.setPadding(dp(10), dp(10), dp(10), dp(10));
                boolean on = b.id.equals(cv.brushId);
                GradientDrawable g = Ui.bg(on ? HomeActivity.blend(Ui.ACC, Ui.PANEL2, .18f) : Ui.PANEL2, dp(14));
                g.setStroke(dp(on ? 2 : 1), on ? Ui.ACC : Ui.LINE);
                card.setBackground(g);
                ImageView iv = new ImageView(this);
                android.graphics.drawable.Drawable d = Ui.icon(this, b.id, on ? Ui.ACC : Ui.FG);
                iv.setImageDrawable(d != null ? d : Ui.icon(this, "brush", on ? Ui.ACC : Ui.FG));
                card.addView(iv, new LinearLayout.LayoutParams(dp(30), dp(30)));
                LinearLayout tx = Ui.col(this);
                tx.setPadding(dp(10), 0, 0, 0);
                TextView n = Ui.text(this, b.name, 13, Ui.FG, true);
                n.setSingleLine(true);
                n.setEllipsize(TextUtils.TruncateAt.END);
                TextView hn = Ui.text(this, b.hint, 10.5f, Ui.MUTE, false);
                hn.setMaxLines(2);
                hn.setPadding(0, dp(2), 0, 0);
                tx.addView(n);
                tx.addView(hn);
                card.addView(tx, Ui.lpw(1));
                card.setOnClickListener(v -> {
                    cv.brushId = b.id;
                    if (!Prefs.get(this).contains("bsize_" + b.id)) cv.brushSize = b.defSize;
                    else cv.brushSize = Prefs.get(this).getFloat("bsize_" + b.id, b.defSize);
                    s.dismiss();
                    setTool(CanvasView.T_BRUSH);
                });
                LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, Ui.WRAP, 1);
                if (i % 2 == 1) l.leftMargin = dp(8);
                row.addView(Ui.pressable(card), l);
                i++;
            }
            if (i % 2 == 1) {
                LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, 1, 1);
                l.leftMargin = dp(8);
                row.addView(new View(this), l);
            }
            s.add(grid);
        }
        final String prev = cv.brushId;
        final float prevSize = cv.brushSize;
        s.setOnDismissListener(d -> Prefs.get(this).edit().putFloat("bsize_" + prev, prevSize).apply());
        s.show();
    }

    private LinearLayout.LayoutParams gapB(int d) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP);
        l.bottomMargin = dp(d);
        return l;
    }

    /* ================================================================ cores */

    private void colorSheet() {
        final Sheet s = new Sheet(this, "Cor");
        final ColorWheel wheel = new ColorWheel(this);
        wheel.set(cv.color);
        s.add(wheel, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        LinearLayout info = Ui.row(this);
        info.setPadding(0, dp(12), 0, 0);
        final View now = new View(this);
        now.setBackground(Ui.bg(cv.color, dp(10)));
        info.addView(now, new LinearLayout.LayoutParams(dp(44), dp(36)));
        final View sec = new View(this);
        sec.setBackground(Ui.bgStroke(cv.color2, Ui.LINE, dp(10), dp(1)));
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(dp(30), dp(26));
        sl.leftMargin = dp(6);
        info.addView(sec, sl);
        final EditText hex = HomeActivity.input(this, "#RRGGBB");
        hex.setText(Ui.hex(cv.color));
        hex.setTypeface(Typeface.MONOSPACE);
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(0, Ui.WRAP, 1);
        hl.leftMargin = dp(10);
        info.addView(hex, hl);
        Button ok = Ui.btn(this, "OK");
        LinearLayout.LayoutParams okl = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        okl.leftMargin = dp(6);
        info.addView(ok, okl);
        s.add(info);
        final Runnable[] upd = new Runnable[1];
        upd[0] = () -> {
            now.setBackground(Ui.bg(cv.color, dp(10)));
            sec.setBackground(Ui.bgStroke(cv.color2, Ui.LINE, dp(10), dp(1)));
            if (!hex.hasFocus()) hex.setText(Ui.hex(cv.color));
        };
        wheel.listener = (c, done) -> { setColor(c, done); upd[0].run(); };
        ok.setOnClickListener(v -> {
            try {
                String t = hex.getText().toString().trim();
                if (!t.startsWith("#")) t = "#" + t;
                int c = Color.parseColor(t);
                setColor(c, true);
                wheel.set(cv.color);
                upd[0].run();
            } catch (Exception e) { Ui.toast(this, "Cor inválida"); }
        });
        sec.setOnClickListener(v -> {
            int t = cv.color; setColor(cv.color2, true); cv.color2 = t;
            wheel.set(cv.color);
            upd[0].run();
        });
        if (!recent.isEmpty()) {
            s.section("Recentes");
            s.add(swatches(recent, c -> { setColor(c, true); wheel.set(c); upd[0].run(); }, null));
        }
        s.section("Paleta");
        final ArrayList<Integer> pal = Prefs.colors(this, "palette", PALETTE);
        final LinearLayout[] palBox = new LinearLayout[1];
        final Runnable[] drawPal = new Runnable[1];
        palBox[0] = Ui.col(this);
        drawPal[0] = () -> {
            palBox[0].removeAllViews();
            palBox[0].addView(swatches(pal, c -> { setColor(c, true); wheel.set(c); upd[0].run(); }, c -> {
                pal.remove((Integer) c);
                Prefs.colors(this, "palette", pal);
                drawPal[0].run();
                Ui.toast(this, "Cor removida da paleta");
            }));
        };
        drawPal[0].run();
        s.add(palBox[0]);
        LinearLayout acts = Ui.row(this);
        acts.setPadding(0, dp(10), 0, 0);
        acts.addView(chip("+ Salvar cor na paleta", false, v -> {
            if (!pal.contains(cv.color)) { pal.add(cv.color); Prefs.colors(this, "palette", pal); drawPal[0].run(); }
        }));
        acts.addView(chip("Harmonias", false, v -> {
            ArrayList<Integer> hs = new ArrayList<>();
            for (float d : new float[]{0, 30, -30, 180, 150, 210, 120, 240}) hs.add(Brushes.hueShift(cv.color, d, 0));
            for (float dv : new float[]{-.3f, -.15f, .15f, .3f}) hs.add(Brushes.shade(cv.color, dv));
            Sheet hsSheet = new Sheet(this, "Harmonias da cor");
            hsSheet.add(swatches(hs, c -> { setColor(c, true); wheel.set(c); upd[0].run(); hsSheet.dismiss(); }, null));
            hsSheet.show();
        }));
        s.add(wrapH(acts));
        TextView tip = Ui.text(this, "Segure uma cor da paleta para removê-la. Segure a bolinha de cor na barra para trocar com a 2ª cor.", 11.5f, Ui.MUTE, false);
        tip.setPadding(0, dp(12), 0, 0);
        s.add(tip);
        s.show();
    }

    interface IntL { void on(int c); }

    private View swatches(ArrayList<Integer> cols, IntL tap, IntL hold) {
        LinearLayout box = Ui.col(this);
        LinearLayout row = null;
        int per = 8;
        for (int i = 0; i < cols.size(); i++) {
            if (i % per == 0) { row = Ui.row(this); box.addView(row, gapB(8)); }
            final int c = cols.get(i);
            View v = new View(this);
            v.setBackground(Ui.bgStroke(c, 0x33FFFFFF, dp(10), dp(1)));
            v.setOnClickListener(x -> tap.on(c));
            if (hold != null) v.setOnLongClickListener(x -> { hold.on(c); return true; });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, dp(34), 1);
            if (i % per > 0) l.leftMargin = dp(6);
            row.addView(Ui.pressable(v), l);
        }
        if (row != null && cols.size() % per != 0) for (int k = cols.size() % per; k < per; k++) {
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, 1, 1);
            l.leftMargin = dp(6);
            row.addView(new View(this), l);
        }
        return box;
    }

    private View wrapH(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }

    /* ================================================================ camadas */

    private LinearLayout layersBox;

    private void layersSheet() {
        cv.commitFloating();
        layersSheet = new Sheet(this, "Camadas");
        layersBox = Ui.col(this);
        layersSheet.add(layersBox);
        fillLayers();
        layersSheet.setOnDismissListener(d -> { layersSheet = null; buildOptions(); });
        layersSheet.show();
    }

    private void fillLayers() {
        layersBox.removeAllViews();
        LinearLayout acts = Ui.row(this);
        acts.addView(chip("+ Nova", false, v -> { cv.addLayer("Camada " + (p.nextLayer)); fillLayers(); }));
        acts.addView(chip("Duplicar", false, v -> { cv.duplicateLayer(cv.active); fillLayers(); }));
        acts.addView(chip("Juntar abaixo", false, v -> { if (cv.active > 0) { cv.mergeDown(cv.active); fillLayers(); } else Ui.toast(this, "Não há camada abaixo"); }));
        acts.addView(chip("Imagem", false, v -> { layersSheet.dismiss(); pickImage(REQ_IMPORT); }));
        layersBox.addView(wrapH(acts), gapB(10));
        TextView cnt = Ui.mono(this, p.layers.size() + " de " + p.maxLayers() + " camadas", 11, Ui.MUTE);
        cnt.setPadding(0, 0, 0, dp(8));
        layersBox.addView(cnt);
        for (int i = p.layers.size() - 1; i >= 0; i--) layersBox.addView(layerRow(i), gapB(6));
        Project.Layer l = cv.layer();
        TextView h = Ui.text(this, "AJUSTES DE \"" + l.name.toUpperCase() + "\"", 11, Ui.MUTE, true);
        h.setPadding(0, dp(12), 0, dp(8));
        layersBox.addView(h);
        layersBox.addView(mini("Opacidade", 100, Math.round(l.opacity / 2.55f), new Ui.Seek() {
            void change(int v) { l.opacity = Math.round(v * 2.55f); cv.invalidate(); }
            void done() { p.save(); }
        }));
        LinearLayout modes = Ui.row(this);
        for (int i = 0; i < Render.BLENDS.length; i++) {
            final String b = Render.BLENDS[i];
            modes.addView(chip(BLEND_NAMES[i], b.equals(l.blend), v -> { l.blend = b; p.save(); cv.invalidate(); fillLayers(); }));
        }
        LinearLayout.LayoutParams ml = gapB(6);
        ml.topMargin = dp(6);
        layersBox.addView(wrapH(modes), ml);
        LinearLayout t = Ui.row(this);
        t.addView(chip(l.clip ? "Recorte ✓" : "Recorte (máscara)", l.clip, v -> { l.clip = !l.clip; p.save(); cv.invalidate(); fillLayers(); }));
        t.addView(chip(l.alpha ? "Trava alfa ✓" : "Trava alfa", l.alpha, v -> { l.alpha = !l.alpha; p.save(); fillLayers(); }));
        t.addView(chip(l.locked ? "Bloqueada ✓" : "Bloquear", l.locked, v -> { l.locked = !l.locked; p.save(); fillLayers(); }));
        t.addView(chip("Renomear", false, v -> renameLayer(l)));
        layersBox.addView(wrapH(t), gapB(6));
        LinearLayout t2 = Ui.row(this);
        t2.addView(chip("⇋ Espelhar", false, v -> cv.flipLayer(true)));
        t2.addView(chip("⇵ Espelhar", false, v -> cv.flipLayer(false)));
        t2.addView(chip("Selecionar desenho", false, v -> { cv.selectLayerContent(); layersSheet.dismiss(); setTool(CanvasView.T_SELECT); }));
        t2.addView(chip("Limpar", false, v -> { cv.clearLayer(cv.active); fillLayers(); }));
        final Button del = chip("Excluir", false, null);
        final boolean[] armed = {false};
        del.setOnClickListener(v -> {
            if (!armed[0]) { armed[0] = true; del.setText("Toque de novo"); Ui.sel(del, true); return; }
            cv.deleteLayer(cv.active);
            fillLayers();
        });
        t2.addView(del);
        layersBox.addView(wrapH(t2));
    }

    private View layerRow(final int idx) {
        final Project.Layer l = p.layers.get(idx);
        boolean on = idx == cv.active;
        LinearLayout r = Ui.row(this);
        r.setPadding(dp(8), dp(6), dp(6), dp(6));
        GradientDrawable g = Ui.bg(on ? HomeActivity.blend(Ui.ACC, Ui.PANEL2, .2f) : Ui.PANEL2, dp(14));
        g.setStroke(dp(on ? 2 : 1), on ? Ui.ACC : Ui.LINE);
        r.setBackground(g);
        ImageView th = new ImageView(this);
        th.setBackground(Ui.bg((p.paper >>> 24) == 0 ? 0xFFE0E2EA : p.paper, dp(6)));
        th.setScaleType(ImageView.ScaleType.FIT_CENTER);
        Bitmap b = cv.bm.get(l.id);
        if (b != null) {
            float k = 96f / Math.max(p.w, p.h);
            th.setImageBitmap(Bitmap.createScaledBitmap(b, Math.max(1, Math.round(p.w * k)), Math.max(1, Math.round(p.h * k)), true));
        }
        if (l.clip) {
            TextView ci = Ui.text(this, "↳", 16, Ui.ACC, true);
            ci.setPadding(0, 0, dp(4), 0);
            r.addView(ci);
        }
        r.addView(th, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout tx = Ui.col(this);
        tx.setPadding(dp(10), 0, dp(4), 0);
        TextView n = Ui.text(this, l.name, 13.5f, Ui.FG, true);
        n.setSingleLine(true);
        n.setEllipsize(TextUtils.TruncateAt.END);
        String info = (l.blend.equals("normal") ? "Normal" : BLEND_NAMES[indexOf(Render.BLENDS, l.blend)]) + " · " + Math.round(l.opacity / 2.55f) + "%"
                + (l.alpha ? " · α" : "") + (l.locked ? " · 🔒" : "");
        TextView sub = Ui.text(this, info, 11, Ui.MUTE, false);
        sub.setPadding(0, dp(3), 0, 0);
        tx.addView(n);
        tx.addView(sub);
        r.addView(tx, Ui.lpw(1));
        ImageView up = smallIcon("up", v -> { cv.moveLayer(idx, idx + 1); fillLayers(); });
        ImageView dn = smallIcon("down", v -> { cv.moveLayer(idx, idx - 1); fillLayers(); });
        ImageView eye = smallIcon("eye", v -> { l.visible = !l.visible; p.save(); cv.invalidate(); fillLayers(); });
        eye.setAlpha(l.visible ? 1f : .3f);
        r.addView(up);
        r.addView(dn);
        r.addView(eye);
        r.setOnClickListener(v -> { cv.active = idx; fillLayers(); buildOptions(); });
        r.setOnLongClickListener(v -> { renameLayer(l); return true; });
        return r;
    }

    private static int indexOf(String[] a, String s) {
        for (int i = 0; i < a.length; i++) if (a[i].equals(s)) return i;
        return 0;
    }

    private ImageView smallIcon(String icon, View.OnClickListener l) {
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(Ui.icon(this, icon, Ui.FG));
        iv.setPadding(dp(7), dp(7), dp(7), dp(7));
        iv.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(34)));
        iv.setOnClickListener(l);
        return iv;
    }

    private void renameLayer(Project.Layer l) {
        final Sheet s = new Sheet(this, "Nome da camada");
        final EditText e = HomeActivity.input(this, "Nome");
        e.setText(l.name);
        s.add(e);
        Button ok = Ui.btn(this, "Salvar");
        Ui.sel(ok, true);
        ok.setOnClickListener(v -> {
            String n = e.getText().toString().trim();
            if (!n.isEmpty()) { l.name = n.length() > 30 ? n.substring(0, 30) : n; p.save(); }
            s.dismiss();
            if (layersSheet != null) fillLayers();
        });
        LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        ol.gravity = Gravity.END;
        ol.topMargin = dp(12);
        s.add(ok, ol);
        s.show();
    }

    /* ================================================================ filtros */

    private void filtersSheet() {
        final Sheet s = new Sheet(this, "Ajustes e filtros");
        TextView h = Ui.text(this, cv.hasSel() ? "Aplicado só dentro da seleção." : "Aplicado na camada \"" + cv.layer().name + "\".", 12, Ui.MUTE, false);
        h.setPadding(0, 0, 0, dp(10));
        s.add(h);
        for (final Filters.F f : Filters.ALL) {
            LinearLayout r = Ui.row(this);
            r.setPadding(dp(14), dp(13), dp(14), dp(13));
            r.setBackground(Ui.bgStroke(Ui.PANEL2, Ui.LINE, dp(14), dp(1)));
            r.addView(Ui.text(this, f.name, 14, Ui.FG, true), Ui.lpw(1));
            r.addView(Ui.iconView(this, "next", Ui.MUTE, 18));
            r.setOnClickListener(v -> { s.dismiss(); filterPanel(f); });
            s.add(Ui.pressable(r), gapB(6));
        }
        s.show();
    }

    private volatile int filterGen;

    private void filterPanel(final Filters.F f) {
        if (!cv.filterBegin()) return;
        final int[] vals = f.def.clone();
        final Sheet s = new Sheet(this, f.name);
        if (s.getWindow() != null) s.getWindow().setDimAmount(0f);
        s.setCanceledOnTouchOutside(false);
        final Runnable run = () -> {
            final int gen = ++filterGen;
            final int[] v = vals.clone();
            work.execute(() -> {
                if (gen != filterGen) return;
                Bitmap b;
                try { b = cv.filterCompute(f.id, v); } catch (Throwable e) { b = null; }
                final Bitmap fb = b;
                ui.post(() -> {
                    if (gen != filterGen || fb == null) { if (fb != null) fb.recycle(); return; }
                    cv.filterPreview(fb);
                });
            });
        };
        for (int i = 0; i < f.params.length; i++) {
            final int fi = i;
            final TextView lab = Ui.text(this, f.params[i] + ": " + vals[i], 12.5f, Ui.MUTE, true);
            lab.setPadding(0, dp(6), 0, dp(4));
            s.add(lab);
            SeekBar sb = Ui.seek(this, f.max[i] - f.min[i], vals[i] - f.min[i], new Ui.Seek() {
                void change(int v) { vals[fi] = v + f.min[fi]; lab.setText(f.params[fi] + ": " + vals[fi]); }
                void done() { run.run(); }
            });
            s.add(sb);
        }
        if (f.color) {
            TextView c = Ui.text(this, "Usa a cor atual: " + Ui.hex(cv.color), 12, Ui.MUTE, false);
            c.setPadding(0, dp(8), 0, 0);
            s.add(c);
        }
        LinearLayout acts = Ui.row(this);
        acts.setGravity(Gravity.END);
        acts.setPadding(0, dp(14), 0, 0);
        final boolean[] applied = {false};
        Button cancel = Ui.btn(this, "Cancelar");
        cancel.setOnClickListener(v -> s.dismiss());
        Button ok = Ui.btn(this, "✓ Aplicar");
        Ui.sel(ok, true);
        ok.setOnClickListener(v -> { applied[0] = true; s.dismiss(); });
        acts.addView(cancel);
        acts.addView(Ui.gap(this, 8, 1));
        acts.addView(ok);
        s.add(acts);
        s.setOnDismissListener(d -> {
            if (!applied[0]) filterGen++;
            work.execute(() -> ui.post(() -> {
                cv.filterEnd(applied[0]);
                if (applied[0]) Ui.toast(this, f.name + " aplicado");
            }));
        });
        s.show();
        run.run();
    }

    /* ================================================================ guias e simetria */

    private void guidesSheet() {
        final Sheet s = new Sheet(this, "Simetria e guias");
        s.section("Simetria");
        LinearLayout sy = Ui.row(this);
        String[] sm = {"Desligada", "Vertical", "Horizontal", "4 lados", "Radial"};
        final Runnable[] re = new Runnable[1];
        final LinearLayout radial = Ui.col(this);
        re[0] = () -> {
            sy.removeAllViews();
            for (int i = 0; i < sm.length; i++) {
                final int fi = i;
                sy.addView(chip(sm[i], cv.symMode == i, v -> { cv.symMode = fi; cv.invalidate(); re[0].run(); }));
            }
            radial.setVisibility(cv.symMode == 4 ? View.VISIBLE : View.GONE);
        };
        s.add(wrapH(sy));
        final TextView rn = Ui.text(this, "Fatias: " + cv.radialN, 12.5f, Ui.MUTE, true);
        rn.setPadding(0, dp(10), 0, dp(4));
        radial.addView(rn);
        radial.addView(Ui.seek(this, 22, cv.radialN - 2, new Ui.Seek() {
            void change(int v) { cv.radialN = v + 2; rn.setText("Fatias: " + cv.radialN); cv.invalidate(); }
        }));
        LinearLayout mr = Ui.row(this);
        mr.setPadding(0, dp(8), 0, 0);
        final Button mb = chip("Espelhar cada fatia (mandala)", cv.radialMirror, null);
        mb.setOnClickListener(v -> { cv.radialMirror = !cv.radialMirror; Ui.sel(mb, cv.radialMirror); });
        mr.addView(mb);
        radial.addView(mr);
        s.add(radial);
        re[0].run();
        s.section("Guias de desenho");
        LinearLayout gr = Ui.row(this);
        String[] gs = {"Nenhuma", "Grade", "Perspectiva 1 ponto", "Perspectiva 2 pontos", "Isométrica"};
        final Runnable[] rg = new Runnable[1];
        rg[0] = () -> {
            gr.removeAllViews();
            for (int i = 0; i < gs.length; i++) {
                final int fi = i;
                gr.addView(chip(gs[i], cv.guide == i, v -> { cv.guide = fi; cv.invalidate(); rg[0].run(); }));
            }
        };
        rg[0].run();
        s.add(wrapH(gr));
        LinearLayout sn = Ui.row(this);
        sn.setPadding(0, dp(10), 0, 0);
        final Button snb = chip("Régua: travar traço na guia", cv.snapGuide, null);
        snb.setOnClickListener(v -> { cv.snapGuide = !cv.snapGuide; Ui.sel(snb, cv.snapGuide); });
        sn.addView(snb);
        s.add(sn);
        TextView t = Ui.text(this, "Para mover os pontos de fuga, use a ferramenta Guias e arraste na tela.", 11.5f, Ui.MUTE, false);
        t.setPadding(0, dp(10), 0, 0);
        s.add(t);
        s.setOnDismissListener(d -> buildOptions());
        s.show();
    }

    /* ================================================================ texto */

    private void textSheet(final float x, final float y) {
        final Sheet s = new Sheet(this, "Texto");
        final EditText e = HomeActivity.input(this, "Escreva aqui…");
        e.setSingleLine(false);
        e.setMinLines(2);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        s.add(e);
        final String[] fonts = {"Padrão", "Negrito", "Serifa", "Mono", "Manuscrita", "Condensada"};
        final int[] font = {1};
        final int[] size = {Math.max(24, Math.round(Math.min(p.w, p.h) / 14f))};
        final boolean[] outline = {false};
        s.section("Fonte");
        final LinearLayout fr = Ui.row(this);
        final Runnable[] rf = new Runnable[1];
        rf[0] = () -> {
            fr.removeAllViews();
            for (int i = 0; i < fonts.length; i++) {
                final int fi = i;
                Button b = chip(fonts[i], font[0] == i, v -> { font[0] = fi; rf[0].run(); });
                b.setTypeface(face(i));
                fr.addView(b);
            }
        };
        rf[0].run();
        s.add(wrapH(fr));
        final TextView sl = Ui.text(this, "Tamanho: " + size[0] + " px", 12.5f, Ui.MUTE, true);
        sl.setPadding(0, dp(12), 0, dp(4));
        s.add(sl);
        s.add(Ui.seek(this, 400, size[0] - 8, new Ui.Seek() { void change(int v) { size[0] = v + 8; sl.setText("Tamanho: " + size[0] + " px"); } }));
        LinearLayout o = Ui.row(this);
        o.setPadding(0, dp(10), 0, 0);
        final Button ob = chip("Contorno branco", false, null);
        ob.setOnClickListener(v -> { outline[0] = !outline[0]; Ui.sel(ob, outline[0]); });
        o.addView(ob);
        s.add(o);
        Button ok = Ui.btn(this, "Inserir texto");
        Ui.sel(ok, true);
        LinearLayout.LayoutParams okl = new LinearLayout.LayoutParams(Ui.MATCH, dp(46));
        okl.topMargin = dp(14);
        s.add(ok, okl);
        ok.setOnClickListener(v -> {
            String t = e.getText().toString();
            if (t.trim().isEmpty()) { s.dismiss(); return; }
            Bitmap b = renderText(t, face(font[0]), size[0], cv.color, outline[0]);
            s.dismiss();
            if (cv.layer().locked) { Ui.toast(this, "Camada bloqueada"); return; }
            if (cv.addLayer("Texto") == null) return;
            cv.startFloating(b, x, y);
        });
        s.show();
        e.requestFocus();
    }

    private Typeface face(int i) {
        switch (i) {
            case 1: return Typeface.create(Typeface.DEFAULT, Typeface.BOLD);
            case 2: return Typeface.create(Typeface.SERIF, Typeface.BOLD);
            case 3: return Typeface.MONOSPACE;
            case 4: return Typeface.create("casual", Typeface.NORMAL);
            case 5: return Typeface.create("sans-serif-condensed", Typeface.BOLD);
            default: return Typeface.DEFAULT;
        }
    }

    private Bitmap renderText(String text, Typeface tf, int size, int color, boolean outline) {
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(tf);
        tp.setTextSize(size);
        tp.setColor(color);
        String[] lines = text.split("\n");
        float w = 1;
        for (String l : lines) w = Math.max(w, tp.measureText(l));
        Paint.FontMetrics fm = tp.getFontMetrics();
        float lh = (fm.descent - fm.ascent) * 1.1f;
        int pad = outline ? Math.round(size * .12f) + 4 : 4;
        Bitmap b = Bitmap.createBitmap(Math.max(1, Math.round(w) + pad * 2), Math.max(1, Math.round(lh * lines.length) + pad * 2), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        for (int i = 0; i < lines.length; i++) {
            float yy = pad - fm.ascent + i * lh;
            if (outline) {
                Paint op = new Paint(tp);
                op.setStyle(Paint.Style.STROKE);
                op.setStrokeWidth(size * .16f);
                op.setStrokeJoin(Paint.Join.ROUND);
                op.setColor(0xFFFFFFFF);
                c.drawText(lines[i], pad, yy, op);
            }
            c.drawText(lines[i], pad, yy, tp);
        }
        return b;
    }

    /* ================================================================ linha do tempo */

    private View buildTimeline() {
        LinearLayout t = Ui.row(this);
        t.setPadding(dp(6), dp(6), dp(6), dp(6));
        t.setBackground(Ui.bgStroke(0xF0171925, Ui.LINE, dp(18), dp(1)));
        playB = iconBtn("play", v -> { if (playing) stopPlay(); else play(); });
        t.addView(playB);
        ImageView on = iconBtn("onion", null);
        on.setOnClickListener(v -> {
            cv.onion = !cv.onion;
            Prefs.set(this, "onion", cv.onion);
            on.setAlpha(cv.onion ? 1f : .4f);
            cv.invalidate();
        });
        on.setOnLongClickListener(v -> { animSheet(); return true; });
        on.setAlpha(cv.onion ? 1f : .4f);
        t.addView(on);
        HorizontalScrollView fs = new HorizontalScrollView(this);
        fs.setHorizontalScrollBarEnabled(false);
        frameRow = Ui.row(this);
        fs.addView(frameRow);
        t.addView(fs, Ui.lpw(1));
        t.addView(iconBtn("plus", v -> { cv.addFrame(false); refreshTimeline(); }));
        ImageView cp = iconBtn("copy", v -> { cv.addFrame(true); refreshTimeline(); });
        t.addView(cp);
        t.addView(iconBtn("film", v -> animSheet()));
        return t;
    }

    void refreshTimeline() {
        if (frameRow == null) return;
        frameRow.removeAllViews();
        for (int i = 0; i < p.frames.size(); i++) {
            final int fi = i;
            final int fid = p.frames.get(i);
            FrameLayout f = new FrameLayout(this);
            boolean on = i == cv.frameIdx;
            GradientDrawable g = Ui.bg(0xFF0C0E18, dp(10));
            g.setStroke(dp(on ? 2.5f : 1), on ? Ui.ACC : Ui.LINE);
            f.setBackground(g);
            f.setPadding(dp(3), dp(3), dp(3), dp(3));
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            Bitmap tb = frameThumbs.get(fid);
            if (tb != null) iv.setImageBitmap(tb);
            else if (!frameThumbs.containsKey(fid)) loadFrameThumb(fid);
            f.addView(iv, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
            TextView n = Ui.mono(this, String.valueOf(i + 1), 9.5f, 0xFFFFFFFF);
            n.setPadding(dp(4), dp(1), dp(4), dp(1));
            n.setBackground(Ui.bg(on ? Ui.ACC : 0xB3090A12, dp(6)));
            f.addView(n, new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP | Gravity.START));
            int hold = p.hold(fid);
            if (hold > 1) {
                TextView hv = Ui.mono(this, "×" + hold, 9.5f, 0xFFFFFFFF);
                hv.setPadding(dp(4), dp(1), dp(4), dp(1));
                hv.setBackground(Ui.bg(0xFF8D7AFF, dp(6)));
                f.addView(hv, new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.END));
            }
            f.setOnClickListener(v -> {
                if (fi == cv.frameIdx) { frameMenu(); return; }
                cv.goFrame(fi);
                refreshTimeline();
            });
            f.setOnLongClickListener(v -> { if (fi != cv.frameIdx) { cv.goFrame(fi); refreshTimeline(); } frameMenu(); return true; });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(dp(56), dp(46));
            l.rightMargin = dp(5);
            frameRow.addView(f, l);
        }
    }

    private void loadFrameThumb(final int fid) {
        frameThumbs.put(fid, null);
        cv.io.execute(() -> {
            final Bitmap b = p.composite(fid, 112, true);
            ui.post(() -> {
                Bitmap old = frameThumbs.put(fid, b);
                if (old != null && old != b) old.recycle();
                refreshTimeline();
            });
        });
    }

    private void refreshCurrentThumb() {
        if (frameRow == null || cv.frameIdx >= p.frames.size()) return;
        int fid = cv.frameId();
        Bitmap b = cv.renderComposite(112, true);
        Bitmap old = frameThumbs.put(fid, b);
        if (old != null) old.recycle();
        refreshTimeline();
    }

    private void frameMenu() {
        final Sheet s = new Sheet(this, "Quadro " + (cv.frameIdx + 1));
        LinearLayout r1 = Ui.row(this);
        r1.addView(chip("◀ Mover", false, v -> { cv.moveFrame(-1); refreshTimeline(); }));
        r1.addView(chip("Mover ▶", false, v -> { cv.moveFrame(1); refreshTimeline(); }));
        r1.addView(chip("Duplicar", false, v -> { cv.addFrame(true); refreshTimeline(); s.dismiss(); }));
        r1.addView(chip("Novo depois", false, v -> { cv.addFrame(false); refreshTimeline(); s.dismiss(); }));
        s.add(wrapH(r1), gapB(8));
        final TextView hl = Ui.text(this, "Duração (exposição): " + p.hold(cv.frameId()) + "×", 12.5f, Ui.MUTE, true);
        hl.setPadding(0, dp(8), 0, dp(4));
        s.add(hl);
        s.add(Ui.seek(this, 11, p.hold(cv.frameId()) - 1, new Ui.Seek() {
            void change(int v) { cv.setHold(v + 1); hl.setText("Duração (exposição): " + (v + 1) + "×"); }
            void done() { refreshTimeline(); }
        }));
        final Button del = chip("Excluir quadro", false, null);
        final boolean[] armed = {false};
        del.setOnClickListener(v -> {
            if (!armed[0]) { armed[0] = true; del.setText("Toque de novo para excluir"); Ui.sel(del, true); return; }
            cv.deleteFrame();
            refreshTimeline();
            s.dismiss();
        });
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        dl.topMargin = dp(14);
        s.add(del, dl);
        s.show();
    }

    private void animSheet() {
        final Sheet s = new Sheet(this, "Animação");
        final TextView fl = Ui.text(this, "Velocidade: " + p.fps + " fps", 12.5f, Ui.MUTE, true);
        fl.setPadding(0, 0, 0, dp(4));
        s.add(fl);
        s.add(Ui.seek(this, 59, p.fps - 1, new Ui.Seek() {
            void change(int v) { p.fps = v + 1; fl.setText("Velocidade: " + p.fps + " fps"); }
            void done() { p.save(); }
        }));
        s.section("Papel vegetal (onion skin)");
        final TextView pl = Ui.text(this, "Quadros antes: " + cv.onionPrev + "   ·   depois: " + cv.onionNext, 12.5f, Ui.MUTE, true);
        s.add(pl);
        s.add(Ui.seek(this, 3, cv.onionPrev, new Ui.Seek() { void change(int v) { cv.onionPrev = v; Prefs.put(EditorActivity.this, "onPrev", v); pl.setText("Quadros antes: " + cv.onionPrev + "   ·   depois: " + cv.onionNext); cv.invalidate(); } }));
        s.add(Ui.seek(this, 3, cv.onionNext, new Ui.Seek() { void change(int v) { cv.onionNext = v; Prefs.put(EditorActivity.this, "onNext", v); pl.setText("Quadros antes: " + cv.onionPrev + "   ·   depois: " + cv.onionNext); cv.invalidate(); } }));
        final TextView al = Ui.text(this, "Transparência: " + cv.onionAlpha + "%", 12.5f, Ui.MUTE, true);
        al.setPadding(0, dp(8), 0, 0);
        s.add(al);
        s.add(Ui.seek(this, 90, cv.onionAlpha - 5, new Ui.Seek() { void change(int v) { cv.onionAlpha = v + 5; Prefs.put(EditorActivity.this, "onAlpha", cv.onionAlpha); al.setText("Transparência: " + cv.onionAlpha + "%"); cv.invalidate(); } }));
        LinearLayout r = Ui.row(this);
        r.setPadding(0, dp(10), 0, 0);
        final Button cb = chip("Colorido (vermelho/verde)", cv.onionColor, null);
        cb.setOnClickListener(v -> { cv.onionColor = !cv.onionColor; Prefs.set(this, "onColor", cv.onionColor); Ui.sel(cb, cv.onionColor); cv.invalidate(); });
        r.addView(cb);
        s.add(r);
        s.section("Reprodução");
        LinearLayout pr = Ui.row(this);
        final boolean[] ping = {Prefs.on(this, "pingpong", false)};
        final Button lb = chip("Repetir", !ping[0], null), pb = chip("Vai e volta", ping[0], null);
        lb.setOnClickListener(v -> { ping[0] = false; Prefs.set(this, "pingpong", false); Ui.sel(lb, true); Ui.sel(pb, false); });
        pb.setOnClickListener(v -> { ping[0] = true; Prefs.set(this, "pingpong", true); Ui.sel(lb, false); Ui.sel(pb, true); });
        pr.addView(lb);
        pr.addView(pb);
        s.add(pr);
        s.show();
    }

    /* ---------------- reprodução ---------------- */

    private ArrayList<Bitmap> playFrames;
    private ArrayList<Integer> playDur;
    private int playPos, playDir = 1;

    private void play() {
        if (!p.anim || playing) return;
        cv.commitFloating();
        cv.saveCurrent();
        playing = true;
        playB.setImageDrawable(Ui.icon(this, "pause", Ui.FG));
        Ui.toast(this, "Preparando…");
        final int n = p.frames.size();
        final float k = (float) Math.min(1, Math.sqrt(40e6 / ((double) n * p.w * p.h)));
        final int side = Math.max(64, Math.min(1080, Math.round(Math.max(p.w, p.h) * k)));
        cv.io.execute(() -> {
            final ArrayList<Bitmap> fr = new ArrayList<>();
            final ArrayList<Integer> du = new ArrayList<>();
            for (int i = 0; i < n && playing; i++) {
                int fid = p.frames.get(i);
                fr.add(p.composite(fid, side, true));
                du.add(p.hold(fid));
            }
            ui.post(() -> {
                if (!playing) { for (Bitmap b : fr) b.recycle(); return; }
                playFrames = fr;
                playDur = du;
                playPos = 0;
                playDir = 1;
                playCover = new View(this);
                playCover.setOnClickListener(v -> stopPlay());
                root.addView(playCover, 1, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
                tick.run();
            });
        });
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!playing || playFrames == null || playFrames.isEmpty()) return;
            cv.playBmp = playFrames.get(playPos);
            cv.invalidate();
            int d = playDur.get(playPos);
            int n = playFrames.size();
            if (Prefs.on(EditorActivity.this, "pingpong", false) && n > 1) {
                if (playPos + playDir >= n || playPos + playDir < 0) playDir = -playDir;
                playPos += playDir;
            } else playPos = (playPos + 1) % n;
            ui.postDelayed(this, Math.max(16, 1000L * d / Math.max(1, p.fps)));
        }
    };

    private void stopPlay() {
        if (!playing) return;
        playing = false;
        ui.removeCallbacks(tick);
        cv.playBmp = null;
        if (playFrames != null) for (Bitmap b : playFrames) b.recycle();
        playFrames = null;
        if (playCover != null) { root.removeView(playCover); playCover = null; }
        if (playB != null) playB.setImageDrawable(Ui.icon(this, "play", Ui.FG));
        cv.invalidate();
    }

    /* ================================================================ menu */

    private void menuSheet() {
        cv.commitFloating();
        final Sheet s = new Sheet(this, p.name);
        s.section("Salvar e compartilhar");
        LinearLayout r1 = Ui.row(this);
        r1.addView(chip("Exportar…", true, v -> { s.dismiss(); exportSheet(); }));
        r1.addView(chip("Compartilhar imagem", false, v -> { s.dismiss(); exportImage("png", 1, true); }));
        r1.addView(chip("Time-lapse", false, v -> { s.dismiss(); exportTimelapse(); }));
        s.add(wrapH(r1));
        s.section("Tela");
        LinearLayout r2 = Ui.row(this);
        r2.addView(chip("Ajustar", false, v -> cv.fitView()));
        r2.addView(chip("100%", false, v -> cv.zoom100()));
        r2.addView(chip("Espelhar visão", false, v -> cv.flipView()));
        r2.addView(chip("Fundo…", false, v -> { s.dismiss(); paperSheet(); }));
        s.add(wrapH(r2));
        s.section("Ações");
        LinearLayout r3 = Ui.row(this);
        r3.addView(chip("Importar imagem", false, v -> { s.dismiss(); pickImage(REQ_IMPORT); }));
        r3.addView(chip("Referência", false, v -> { s.dismiss(); pickImage(REQ_REF); }));
        r3.addView(chip("Quadrinhos (HQ)", false, v -> { s.dismiss(); comicSheet(); }));
        r3.addView(chip("Simetria e guias", false, v -> { s.dismiss(); guidesSheet(); }));
        s.add(wrapH(r3));
        if (p.anim) {
            LinearLayout r4 = Ui.row(this);
            r4.setPadding(0, dp(6), 0, 0);
            r4.addView(chip("Animação e onion skin", false, v -> { s.dismiss(); animSheet(); }));
            s.add(wrapH(r4));
        }
        s.section("Gestos e preferências");
        s.add(toggleRow("twoUndo", true, "2 dedos desfaz · 3 dedos refaz"), gapB(6));
        s.add(toggleRow("longPick", true, "Segurar o dedo pega a cor"), gapB(6));
        s.add(toggleRow("qshape", true, "QuickShape (segure no fim do traço)"), gapB(6));
        s.add(toggleRow("rotate", true, "Girar a tela com 2 dedos"), gapB(6));
        s.add(toggleRow("pressure", true, "Pressão da caneta"), gapB(6));
        s.add(toggleRow("stylusOnly", false, "Só a caneta desenha (dedo move a tela)"), gapB(6));
        s.add(toggleRow("tlapse", true, "Gravar time-lapse"), gapB(6));
        LinearLayout r5 = Ui.row(this);
        r5.setPadding(0, dp(8), 0, 0);
        r5.addView(chip("Renomear projeto", false, v -> { s.dismiss(); renameProject(); }));
        r5.addView(chip("Dicas", false, v -> { s.dismiss(); tips(); }));
        s.add(wrapH(r5));
        TextView info = Ui.mono(this, p.w + "×" + p.h + " px · " + p.layers.size() + " camadas" + (p.anim ? " · " + p.frames.size() + " quadros" : ""), 11.5f, Ui.MUTE);
        info.setPadding(0, dp(14), 0, 0);
        s.add(info);
        s.show();
    }

    private View toggleRow(final String key, boolean def, String title) {
        LinearLayout r = Ui.row(this);
        r.setPadding(dp(12), dp(8), dp(8), dp(8));
        r.setBackground(Ui.bgStroke(Ui.PANEL2, Ui.LINE, dp(12), dp(1)));
        r.addView(Ui.text(this, title, 13, Ui.FG, true), Ui.lpw(1));
        final android.widget.Switch sw = new android.widget.Switch(this);
        sw.setChecked(Prefs.on(this, key, def));
        sw.setOnCheckedChangeListener((b, on) -> Prefs.set(this, key, on));
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        return r;
    }

    private void renameProject() {
        final Sheet s = new Sheet(this, "Nome do projeto");
        final EditText e = HomeActivity.input(this, "Nome");
        e.setText(p.name);
        s.add(e);
        Button ok = Ui.btn(this, "Salvar");
        Ui.sel(ok, true);
        ok.setOnClickListener(v -> {
            String n = e.getText().toString().trim();
            if (!n.isEmpty()) { p.name = n.length() > 40 ? n.substring(0, 40) : n; p.save(); }
            s.dismiss();
        });
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        l.gravity = Gravity.END;
        l.topMargin = dp(12);
        s.add(ok, l);
        s.show();
    }

    private void paperSheet() {
        final Sheet s = new Sheet(this, "Fundo (papel)");
        ArrayList<Integer> cols = new ArrayList<>();
        for (int c : HomeActivity.PAPERS) cols.add(c);
        s.add(swatches(cols, c -> { p.paper = c; p.save(); cv.invalidate(); }, null));
        LinearLayout r = Ui.row(this);
        r.setPadding(0, dp(10), 0, 0);
        r.addView(chip("Transparente", (p.paper >>> 24) == 0, v -> { p.paper = 0; p.save(); cv.invalidate(); s.dismiss(); }));
        r.addView(chip("Usar a cor atual", false, v -> { p.paper = cv.color; p.save(); cv.invalidate(); s.dismiss(); }));
        s.add(r);
        s.show();
    }

    private void comicSheet() {
        final Sheet s = new Sheet(this, "Quadros de HQ");
        String[] names = {"2 faixas", "3 faixas", "4 quadros", "1 + 2", "5 quadros", "6 quadros"};
        LinearLayout r = Ui.row(this);
        for (int i = 0; i < names.length; i++) {
            final int fi = i;
            r.addView(chip(names[i], false, v -> { s.dismiss(); cv.comicPanels(fi, .025f, Math.max(3, Math.min(p.w, p.h) / 220f)); Ui.toast(this, "Camada de quadros criada"); }));
        }
        s.add(wrapH(r));
        TextView t = Ui.text(this, "Os contornos ficam numa camada própria. Use o balde em \"Todas as camadas\" para pintar cada quadro.", 11.5f, Ui.MUTE, false);
        t.setPadding(0, dp(10), 0, 0);
        s.add(t);
        s.show();
    }

    private void tips() {
        Prefs.set(this, "tipSeen", true);
        final Sheet s = new Sheet(this, "Dicas rápidas");
        String[] tips = {
                "✌️  Toque com 2 dedos para desfazer, 3 dedos para refazer.",
                "🤏  Pinça para zoom; gire com 2 dedos (ímã a cada 90°).",
                "🎯  Segure o dedo parado para pegar a cor (conta-gotas).",
                "⭕  Segure no fim do traço: vira reta, círculo, retângulo… (QuickShape).",
                "🖌️  Toque de novo no pincel para abrir a biblioteca com +60 pincéis.",
                "🎨  Segure a bolinha de cor para trocar com a 2ª cor.",
                "🧲  Guias: grade, perspectiva e isométrica, com régua que trava o traço.",
                "🪞  Simetria vertical, horizontal, 4 lados e radial (mandala).",
                "📼  Tudo vira time-lapse: Menu › Time-lapse.",
        };
        for (String t : tips) {
            TextView v = Ui.text(this, t, 13.5f, Ui.FG, false);
            v.setPadding(0, dp(6), 0, dp(6));
            v.setLineSpacing(0, 1.2f);
            s.add(v);
        }
        Button ok = Ui.btn(this, "Entendi");
        Ui.sel(ok, true);
        ok.setOnClickListener(v -> s.dismiss());
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        l.gravity = Gravity.END;
        l.topMargin = dp(10);
        s.add(ok, l);
        s.show();
    }

    /* ================================================================ imagens (importar e referência) */

    private void pickImage(int req) {
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.setType("image/*");
        it.addCategory(Intent.CATEGORY_OPENABLE);
        try { startActivityForResult(Intent.createChooser(it, "Escolher imagem"), req); }
        catch (Exception e) { Ui.toast(this, "Não há app de galeria"); }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        try {
            Bitmap b = decode(data.getData(), req == REQ_REF ? 1600 : Project.MAX_SIDE);
            if (b == null) { Ui.toast(this, "Não consegui ler a imagem"); return; }
            if (!b.isMutable()) { Bitmap m = b.copy(Bitmap.Config.ARGB_8888, true); b.recycle(); b = m; }
            if (req == REQ_IMPORT) { cv.importImage(b); onHistory(); }
            else if (req == REQ_REF) showReference(b);
        } catch (Throwable e) {
            Ui.toast(this, "Não consegui abrir a imagem");
        }
    }

    private Bitmap decode(Uri uri, int maxSide) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream in = getContentResolver().openInputStream(uri);
        BitmapFactory.decodeStream(in, null, o);
        if (in != null) in.close();
        int ss = 1;
        while (Math.max(o.outWidth, o.outHeight) / (ss * 2) >= maxSide) ss *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = ss;
        o2.inPreferredConfig = Bitmap.Config.ARGB_8888;
        in = getContentResolver().openInputStream(uri);
        Bitmap b = BitmapFactory.decodeStream(in, null, o2);
        if (in != null) in.close();
        return b;
    }

    /** Janela de referência flutuante: arraste pela barra, toque na imagem para pegar a cor. */
    private void showReference(Bitmap b) {
        if (refWin != null) { root.removeView(refWin); if (refBmp != null) refBmp.recycle(); }
        refBmp = b;
        refWin = new FrameLayout(this);
        refWin.setBackground(Ui.bgStroke(Ui.PANEL, Ui.LINE, dp(14), dp(1)));
        refWin.setElevation(dp(12));
        refWin.setPadding(dp(4), dp(4), dp(4), dp(4));
        LinearLayout col = Ui.col(this);
        LinearLayout bar = Ui.row(this);
        bar.setPadding(dp(8), 0, 0, 0);
        TextView t = Ui.text(this, "Referência", 12, Ui.MUTE, true);
        bar.addView(t, Ui.lpw(1));
        final int[] wdp = {200};
        bar.addView(smallIcon("down", v -> resizeRef(wdp, -40)));
        bar.addView(smallIcon("up", v -> resizeRef(wdp, 40)));
        bar.addView(smallIcon("trash", v -> { root.removeView(refWin); refWin = null; if (refBmp != null) { refBmp.recycle(); refBmp = null; } }));
        col.addView(bar);
        final ImageView iv = new ImageView(this);
        iv.setImageBitmap(b);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setAdjustViewBounds(true);
        iv.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
            float vw = v.getWidth(), vh = v.getHeight();
            float k = Math.min(vw / b.getWidth(), vh / b.getHeight());
            float ox = (vw - b.getWidth() * k) / 2, oy = (vh - b.getHeight() * k) / 2;
            int x = (int) ((e.getX() - ox) / k), y = (int) ((e.getY() - oy) / k);
            if (x >= 0 && y >= 0 && x < b.getWidth() && y < b.getHeight()) {
                int c = b.getPixel(x, y);
                if ((c >>> 24) > 0) { setColor(c, true); Ui.toast(this, "Cor " + Ui.hex(c)); }
            }
            return true;
        });
        col.addView(iv, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        refWin.addView(col);
        FrameLayout.LayoutParams l = new FrameLayout.LayoutParams(dp(wdp[0]), Ui.WRAP, Gravity.TOP | Gravity.END);
        l.setMargins(0, dp(70), dp(12), 0);
        root.addView(refWin, l);
        final float[] d = new float[2];
        bar.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { d[0] = e.getRawX() - refWin.getTranslationX(); d[1] = e.getRawY() - refWin.getTranslationY(); }
            else if (e.getActionMasked() == MotionEvent.ACTION_MOVE) { refWin.setTranslationX(e.getRawX() - d[0]); refWin.setTranslationY(e.getRawY() - d[1]); }
            return true;
        });
    }

    private void resizeRef(int[] wdp, int delta) {
        if (refWin == null) return;
        wdp[0] = Ui.clamp(wdp[0] + delta, 120, 420);
        ViewGroup.LayoutParams l = refWin.getLayoutParams();
        l.width = dp(wdp[0]);
        refWin.setLayoutParams(l);
    }

    /* ================================================================ exportar */

    private void exportSheet() {
        cv.commitFloating();
        final Sheet s = new Sheet(this, "Exportar");
        s.section("Imagem");
        LinearLayout r1 = Ui.row(this);
        r1.addView(chip("PNG", true, v -> { s.dismiss(); exportImage("png", 1, false); }));
        r1.addView(chip("JPG", false, v -> { s.dismiss(); exportImage("jpg", 1, false); }));
        r1.addView(chip("PNG transparente", false, v -> { s.dismiss(); exportImage("pngT", 1, false); }));
        r1.addView(chip("PNG 2× maior", false, v -> { s.dismiss(); exportImage("png", 2, false); }));
        s.add(wrapH(r1));
        LinearLayout r2 = Ui.row(this);
        r2.setPadding(0, dp(6), 0, 0);
        r2.addView(chip("Camadas separadas (.zip)", false, v -> { s.dismiss(); exportLayers(); }));
        s.add(wrapH(r2));
        if (p.anim) {
            s.section("Animação");
            LinearLayout r3 = Ui.row(this);
            r3.addView(chip("Vídeo MP4 720p", true, v -> { s.dismiss(); exportVideo(720); }));
            r3.addView(chip("MP4 1080p", false, v -> { s.dismiss(); exportVideo(1080); }));
            r3.addView(chip("GIF", false, v -> { s.dismiss(); exportGif(480, false); }));
            r3.addView(chip("GIF grande", false, v -> { s.dismiss(); exportGif(720, false); }));
            r3.addView(chip("GIF transparente", false, v -> { s.dismiss(); exportGif(480, true); }));
            s.add(wrapH(r3));
            LinearLayout r4 = Ui.row(this);
            r4.setPadding(0, dp(6), 0, 0);
            r4.addView(chip("Sequência PNG (.zip)", false, v -> { s.dismiss(); exportSequence(); }));
            r4.addView(chip("Folha de sprites", false, v -> { s.dismiss(); exportSprites(); }));
            s.add(wrapH(r4));
        }
        s.section("Processo");
        LinearLayout r5 = Ui.row(this);
        r5.addView(chip("Vídeo time-lapse", false, v -> { s.dismiss(); exportTimelapse(); }));
        s.add(wrapH(r5));
        TextView t = Ui.text(this, "Imagens vão para Galeria › Pictures/DarkMonia, vídeos para Movies/DarkMonia e .zip para Downloads/DarkMonia.", 11.5f, Ui.MUTE, false);
        t.setPadding(0, dp(12), 0, 0);
        s.add(t);
        s.show();
    }

    private boolean needPerm(Runnable r) {
        if (Build.VERSION.SDK_INT >= 29) return false;
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) return false;
        pendingPerm = r;
        requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_PERM);
        return true;
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_PERM && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && pendingPerm != null) pendingPerm.run();
        else if (req == REQ_PERM) Ui.toast(this, "Sem permissão para salvar");
        pendingPerm = null;
    }

    private String baseName() {
        String n = p.name.replaceAll("[^A-Za-z0-9À-ÿ _-]", "").trim().replace(' ', '_');
        if (n.isEmpty()) n = "DarkMonia";
        return n + "_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }

    private File tmp(String name) {
        File d = new File(getCacheDir(), "export");
        d.mkdirs();
        return new File(d, name);
    }

    private TextView progress;

    private void busy(String text) {
        busy = true;
        if (progress == null) {
            progress = Ui.text(this, text, 14, 0xFFFFFFFF, true);
            progress.setPadding(dp(22), dp(16), dp(22), dp(16));
            progress.setBackground(Ui.bgStroke(Ui.PANEL, Ui.LINE, dp(16), dp(1)));
            progress.setElevation(dp(20));
            progress.setClickable(true);
            root.addView(progress, new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER));
        }
        progress.setText(text);
    }

    private void step(final String text) { ui.post(() -> { if (progress != null) progress.setText(text); }); }

    /** Chamado na thread de trabalho: publica o arquivo e mostra o resultado. */
    private void done(final File f, final String name, final boolean share) {
        Uri pub = null;
        String err = null;
        if (f != null) {
            try { pub = Media.publish(this, f, name); } catch (Exception e) { err = e.getMessage(); }
            f.delete();
        }
        final Uri u = pub;
        final String error = f == null ? "Não consegui exportar" : err;
        ui.post(() -> {
            busy = false;
            if (progress != null) { root.removeView(progress); progress = null; }
            if (error != null) { Ui.toast(this, "Erro ao salvar: " + error); return; }
            if (share) { Media.share(this, u, Media.mime(name)); return; }
            final Sheet s = new Sheet(this, "Salvo ✓");
            TextView t = Ui.text(this, name + "\n" + Media.where(name), 13, Ui.MUTE, false);
            t.setLineSpacing(0, 1.25f);
            s.add(t);
            LinearLayout r = Ui.row(this);
            r.setPadding(0, dp(14), 0, 0);
            if (u != null) r.addView(chip("Compartilhar", true, v -> { s.dismiss(); Media.share(this, u, Media.mime(name)); }));
            r.addView(chip("Fechar", false, v -> s.dismiss()));
            s.add(r);
            s.show();
        });
    }

    private void fail(final String why) {
        ui.post(() -> {
            busy = false;
            if (progress != null) { root.removeView(progress); progress = null; }
            Ui.toast(this, why);
        });
    }

    private void exportImage(final String kind, final int scale, final boolean share) {
        if (busy || needPerm(() -> exportImage(kind, scale, share))) return;
        boolean transparent = kind.equals("pngT");
        final boolean jpg = kind.equals("jpg");
        Bitmap b = cv.renderComposite(Math.max(p.w, p.h), !transparent || jpg);
        if (jpg && (p.paper >>> 24) == 0) {
            Bitmap w = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(w);
            c.drawColor(0xFFFFFFFF);
            c.drawBitmap(b, 0, 0, null);
            b.recycle();
            b = w;
        }
        if (scale > 1) {
            Bitmap s = Bitmap.createScaledBitmap(b, b.getWidth() * scale, b.getHeight() * scale, true);
            b.recycle();
            b = s;
        }
        final Bitmap fb = b;
        final String name = baseName() + (jpg ? ".jpg" : ".png");
        busy("Salvando imagem…");
        work.execute(() -> {
            File f = tmp(name);
            try {
                FileOutputStream out = new FileOutputStream(f);
                fb.compress(jpg ? Bitmap.CompressFormat.JPEG : Bitmap.CompressFormat.PNG, jpg ? 95 : 100, out);
                out.close();
                fb.recycle();
                done(f, name, share);
            } catch (Exception e) { fail("Não consegui salvar"); }
        });
    }

    private void exportLayers() {
        if (busy || needPerm(this::exportLayers)) return;
        cv.saveCurrent();
        final String name = baseName() + "_camadas.zip";
        final int fid = cv.frameId();
        busy("Juntando camadas…");
        cv.io.execute(() -> {
            File f = tmp(name);
            try {
                ZipOutputStream z = new ZipOutputStream(new FileOutputStream(f));
                int i = 1;
                for (Project.Layer l : p.layers) {
                    File lf = p.layerFile(fid, l.id);
                    String safe = l.name.replaceAll("[^A-Za-z0-9À-ÿ _-]", "_");
                    z.putNextEntry(new ZipEntry(String.format(Locale.US, "%02d_%s.png", i++, safe)));
                    if (lf.exists()) {
                        java.io.FileInputStream in = new java.io.FileInputStream(lf);
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) z.write(buf, 0, n);
                        in.close();
                    } else {
                        Bitmap e = Bitmap.createBitmap(p.w, p.h, Bitmap.Config.ARGB_8888);
                        e.compress(Bitmap.CompressFormat.PNG, 100, z);
                        e.recycle();
                    }
                    z.closeEntry();
                }
                Bitmap all = p.composite(fid, Math.max(p.w, p.h), true);
                z.putNextEntry(new ZipEntry("final.png"));
                all.compress(Bitmap.CompressFormat.PNG, 100, z);
                z.closeEntry();
                all.recycle();
                z.close();
                done(f, name, false);
            } catch (Exception e) { fail("Não consegui exportar as camadas"); }
        });
    }

    /** Lista de quadros já com as durações (exposição) e o modo vai-e-volta. */
    private ArrayList<int[]> sequence() {
        ArrayList<int[]> seq = new ArrayList<>();
        for (int i = 0; i < p.frames.size(); i++) seq.add(new int[]{i, p.hold(p.frames.get(i))});
        if (Prefs.on(this, "pingpong", false) && seq.size() > 2)
            for (int i = p.frames.size() - 2; i >= 1; i--) seq.add(new int[]{i, p.hold(p.frames.get(i))});
        return seq;
    }

    private void exportGif(final int side, final boolean transparent) {
        if (busy || needPerm(() -> exportGif(side, transparent))) return;
        cv.saveCurrent();
        final String name = baseName() + ".gif";
        final ArrayList<int[]> seq = sequence();
        busy("Criando GIF…");
        cv.io.execute(() -> {
            File f = tmp(name);
            try {
                FileOutputStream out = new FileOutputStream(f);
                float k = Math.min(1f, side / (float) Math.max(p.w, p.h));
                int w = Math.max(1, Math.round(p.w * k)), h = Math.max(1, Math.round(p.h * k));
                GifEncoder g = new GifEncoder(new java.io.BufferedOutputStream(out, 1 << 16), w, h, 0);
                int[] px = new int[w * h];
                for (int i = 0; i < seq.size(); i++) {
                    step("Criando GIF… " + (i + 1) + "/" + seq.size());
                    int[] e = seq.get(i);
                    Bitmap b = p.composite(p.frames.get(e[0]), side, !transparent);
                    Bitmap s = b.getWidth() == w && b.getHeight() == h ? b : Bitmap.createScaledBitmap(b, w, h, true);
                    s.getPixels(px, 0, w, 0, 0, w, h);
                    if (s != b) s.recycle();
                    b.recycle();
                    g.addFrame(px, Math.round(100f * e[1] / Math.max(1, p.fps)));
                }
                g.finish();
                out.close();
                done(f, name, false);
            } catch (Throwable e) { fail("Não consegui criar o GIF"); }
        });
    }

    private void exportVideo(final int side) {
        if (busy || needPerm(() -> exportVideo(side))) return;
        cv.saveCurrent();
        final String name = baseName() + ".mp4";
        final ArrayList<int[]> seq = sequence();
        busy("Criando vídeo…");
        cv.io.execute(() -> {
            File f = tmp(name);
            VideoEncoder ve = null;
            try {
                int[] sz = VideoEncoder.size(p.w, p.h, side);
                ve = new VideoEncoder(f, sz[0], sz[1], p.fps);
                Bitmap frame = Bitmap.createBitmap(sz[0], sz[1], Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(frame);
                Paint fp = new Paint(Paint.FILTER_BITMAP_FLAG);
                android.graphics.RectF dst = new android.graphics.RectF(0, 0, sz[0], sz[1]);
                int total = 0;
                for (int[] e : seq) total += e[1];
                int done = 0;
                // vídeos muito curtos somem em alguns players: repete até ~1 s
                int reps = Math.max(1, (int) Math.ceil(p.fps / (float) Math.max(1, total)));
                for (int r = 0; r < reps; r++)
                    for (int[] e : seq) {
                        Bitmap b = p.composite(p.frames.get(e[0]), Math.max(sz[0], sz[1]), true);
                        c.drawColor((p.paper >>> 24) == 0 ? 0xFFFFFFFF : p.paper);
                        c.drawBitmap(b, null, dst, fp);
                        b.recycle();
                        for (int k = 0; k < e[1]; k++) ve.add(frame);
                        done += e[1];
                        step("Criando vídeo… " + Math.min(100, done * 100 / Math.max(1, total * reps)) + "%");
                    }
                ve.finish();
                ve = null;
                frame.recycle();
                done(f, name, false);
            } catch (Throwable e) {
                if (ve != null) ve.abort();
                fail("Este aparelho não conseguiu criar o MP4. Tente o GIF.");
            }
        });
    }

    private void exportSequence() {
        if (busy || needPerm(this::exportSequence)) return;
        cv.saveCurrent();
        final String name = baseName() + "_quadros.zip";
        busy("Juntando quadros…");
        cv.io.execute(() -> {
            File f = tmp(name);
            try {
                ZipOutputStream z = new ZipOutputStream(new FileOutputStream(f));
                for (int i = 0; i < p.frames.size(); i++) {
                    step("Quadro " + (i + 1) + "/" + p.frames.size());
                    Bitmap b = p.composite(p.frames.get(i), Math.max(p.w, p.h), true);
                    z.putNextEntry(new ZipEntry(String.format(Locale.US, "quadro_%04d.png", i + 1)));
                    b.compress(Bitmap.CompressFormat.PNG, 100, z);
                    z.closeEntry();
                    b.recycle();
                }
                z.close();
                done(f, name, false);
            } catch (Throwable e) { fail("Não consegui exportar"); }
        });
    }

    private void exportSprites() {
        if (busy || needPerm(this::exportSprites)) return;
        cv.saveCurrent();
        final String name = baseName() + "_sprites.png";
        busy("Montando folha de sprites…");
        cv.io.execute(() -> {
            File f = tmp(name);
            try {
                int n = p.frames.size();
                int cols = (int) Math.ceil(Math.sqrt(n)), rows = (int) Math.ceil(n / (float) cols);
                int cell = Math.min(512, Math.max(p.w, p.h));
                float k = cell / (float) Math.max(p.w, p.h);
                int cw = Math.max(1, Math.round(p.w * k)), ch = Math.max(1, Math.round(p.h * k));
                Bitmap sheet = Bitmap.createBitmap(cw * cols, ch * rows, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(sheet);
                for (int i = 0; i < n; i++) {
                    Bitmap b = p.composite(p.frames.get(i), cell, false);
                    c.drawBitmap(b, null, new android.graphics.RectF((i % cols) * cw, (i / cols) * ch, (i % cols + 1) * cw, (i / cols + 1) * ch), new Paint(Paint.FILTER_BITMAP_FLAG));
                    b.recycle();
                }
                FileOutputStream out = new FileOutputStream(f);
                sheet.compress(Bitmap.CompressFormat.PNG, 100, out);
                out.close();
                sheet.recycle();
                done(f, name, false);
            } catch (Throwable e) { fail("Não consegui montar a folha"); }
        });
    }

    private void exportTimelapse() {
        if (busy || needPerm(this::exportTimelapse)) return;
        cv.saveCurrent();
        if (p.tl < 2) { Ui.toast(this, "Ainda não há passos gravados. Desenhe um pouco!"); return; }
        final String name = baseName() + "_timelapse.mp4";
        busy("Criando time-lapse…");
        cv.io.execute(() -> {
            File f = tmp(name);
            VideoEncoder ve = null;
            try {
                int[] sz = VideoEncoder.size(p.w, p.h, 720);
                ve = new VideoEncoder(f, sz[0], sz[1], 30);
                Bitmap frame = Bitmap.createBitmap(sz[0], sz[1], Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(frame);
                Paint fp = new Paint(Paint.FILTER_BITMAP_FLAG);
                android.graphics.RectF dst = new android.graphics.RectF(0, 0, sz[0], sz[1]);
                int n = p.tl;
                // no máximo ~40 s: pula passos se tiver muitos
                int stepN = Math.max(1, n / 1200);
                for (int i = 0; i < n; i += stepN) {
                    File tf = p.tlFile(i);
                    if (!tf.exists()) continue;
                    Bitmap b = BitmapFactory.decodeFile(tf.getPath());
                    if (b == null) continue;
                    c.drawColor(0xFFFFFFFF);
                    c.drawBitmap(b, null, dst, fp);
                    b.recycle();
                    ve.add(frame);
                    if (i % 30 == 0) step("Time-lapse… " + (i * 100 / n) + "%");
                }
                Bitmap last = p.composite(cv.frameId(), Math.max(sz[0], sz[1]), true);
                c.drawColor(0xFFFFFFFF);
                c.drawBitmap(last, null, dst, fp);
                last.recycle();
                for (int k = 0; k < 60; k++) ve.add(frame);
                ve.finish();
                ve = null;
                frame.recycle();
                done(f, name, false);
            } catch (Throwable e) {
                if (ve != null) ve.abort();
                fail("Não consegui criar o time-lapse neste aparelho");
            }
        });
    }

    /* ================================================================ peças visuais */

    /** Bolinha da cor atual. */
    static class ColorDot extends View {
        private int c;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), r = new Paint(Paint.ANTI_ALIAS_FLAG);
        ColorDot(android.content.Context ctx) {
            super(ctx);
            r.setStyle(Paint.Style.STROKE);
            r.setStrokeWidth(Ui.dp(ctx, 3));
            r.setColor(0xFFFFFFFF);
        }
        void set(int col) { c = col; invalidate(); }
        @Override protected void onDraw(Canvas cv) {
            float rr = Math.min(getWidth(), getHeight()) / 2f - Ui.dp(getContext(), 3);
            p.setColor(c);
            cv.drawCircle(getWidth() / 2f, getHeight() / 2f, rr, p);
            cv.drawCircle(getWidth() / 2f, getHeight() / 2f, rr, r);
        }
    }

    /** Controle deslizante vertical (tamanho / opacidade), como na lateral do Procreate. */
    static class VSlider extends View {
        interface L { void on(float v, boolean done); }
        L l;
        private float v = .3f;
        private final String label;
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG), knob = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        VSlider(android.content.Context c, String label) {
            super(c);
            this.label = label;
            track.setColor(0xFF2A2E44);
            knob.setColor(0xFFFFFFFF);
            txt.setColor(Ui.MUTE);
            txt.setTextSize(Ui.dp(c, 8.5f));
            txt.setTextAlign(Paint.Align.CENTER);
        }
        void set(float x) { v = Ui.clampf(x, 0, 1); invalidate(); }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), pad = Ui.dp(getContext(), 6), tw = Ui.dp(getContext(), 8);
            float top = pad, bot = h - pad - Ui.dp(getContext(), 12);
            float cx = w / 2;
            c.drawRoundRect(cx - tw / 2, top, cx + tw / 2, bot, tw / 2, tw / 2, track);
            float y = bot - (bot - top) * v;
            fill.setColor(Ui.ACC);
            c.drawRoundRect(cx - tw / 2, y, cx + tw / 2, bot, tw / 2, tw / 2, fill);
            c.drawRoundRect(cx - w / 2 + 2, y - Ui.dp(getContext(), 5), cx + w / 2 - 2, y + Ui.dp(getContext(), 5), Ui.dp(getContext(), 5), Ui.dp(getContext(), 5), knob);
            c.drawText(label, cx, h - Ui.dp(getContext(), 2), txt);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            float pad = Ui.dp(getContext(), 6);
            float top = pad, bot = getHeight() - pad - Ui.dp(getContext(), 12);
            v = Ui.clampf((bot - e.getY()) / (bot - top), 0, 1);
            int a = e.getActionMasked();
            boolean done = a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL;
            if (l != null) l.on(v, done);
            invalidate();
            return true;
        }
    }
}
