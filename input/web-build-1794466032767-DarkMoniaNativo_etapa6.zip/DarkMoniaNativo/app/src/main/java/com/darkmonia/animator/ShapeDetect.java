package com.darkmonia.animator;

import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;

import java.util.ArrayList;

/** QuickShape: reconhece reta, curva, círculo, elipse, triângulo, retângulo e polígono no fim do traço. */
final class ShapeDetect {
    static final class Result {
        String name;
        final Path path = new Path();
        boolean closed;
        float x0, y0, x1, y1;
        boolean line;
    }

    private static double len(ArrayList<float[]> p) {
        double L = 0;
        for (int i = 1; i < p.size(); i++) L += Math.hypot(p.get(i)[0] - p.get(i - 1)[0], p.get(i)[1] - p.get(i - 1)[1]);
        return L;
    }

    private static double segDist(float[] q, float[] a, float[] b) {
        double dx = b[0] - a[0], dy = b[1] - a[1];
        double l2 = dx * dx + dy * dy;
        if (l2 < 1e-6) return Math.hypot(q[0] - a[0], q[1] - a[1]);
        double t = Math.max(0, Math.min(1, ((q[0] - a[0]) * dx + (q[1] - a[1]) * dy) / l2));
        return Math.hypot(q[0] - (a[0] + t * dx), q[1] - (a[1] + t * dy));
    }

    private static void rdp(ArrayList<float[]> p, int s, int e, double eps, ArrayList<Integer> keep) {
        double md = 0;
        int mi = -1;
        for (int i = s + 1; i < e; i++) {
            double d = segDist(p.get(i), p.get(s), p.get(e));
            if (d > md) { md = d; mi = i; }
        }
        if (md > eps && mi > 0) {
            rdp(p, s, mi, eps, keep);
            keep.add(mi);
            rdp(p, mi, e, eps, keep);
        }
    }

    static Result detect(ArrayList<float[]> in) {
        if (in.size() < 4) return null;
        ArrayList<float[]> p = new ArrayList<>(in);
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        for (float[] q : p) {
            minX = Math.min(minX, q[0]); maxX = Math.max(maxX, q[0]);
            minY = Math.min(minY, q[1]); maxY = Math.max(maxY, q[1]);
        }
        double diag = Math.hypot(maxX - minX, maxY - minY);
        if (diag < 12) return null;
        double L = len(p);
        float[] a = p.get(0), b = p.get(p.size() - 1);
        double ends = Math.hypot(b[0] - a[0], b[1] - a[1]);
        Result r = new Result();
        if (ends / L > 0.93) {
            r.name = "Reta";
            r.line = true;
            r.x0 = a[0]; r.y0 = a[1]; r.x1 = b[0]; r.y1 = b[1];
            r.path.moveTo(a[0], a[1]);
            r.path.lineTo(b[0], b[1]);
            return r;
        }
        boolean closed = ends < Math.max(diag * 0.22, L * 0.1);
        double eps = diag * 0.075;
        if (!closed) {
            ArrayList<Integer> keep = new ArrayList<>();
            keep.add(0);
            rdp(p, 0, p.size() - 1, eps, keep);
            keep.add(p.size() - 1);
            if (keep.size() <= 3 && keep.size() >= 3) {
                // curva suave: passa pelo ponto do meio do traço
                float[] m = p.get(p.size() / 2);
                float cx = 2 * m[0] - (a[0] + b[0]) / 2, cy = 2 * m[1] - (a[1] + b[1]) / 2;
                double dev = segDist(m, a, b);
                if (dev > diag * 0.12) {
                    r.name = "Curva";
                    r.path.moveTo(a[0], a[1]);
                    r.path.quadTo(cx, cy, b[0], b[1]);
                    return r;
                }
            }
            if (keep.size() <= 6) {
                r.name = "Linha poligonal";
                for (int i = 0; i < keep.size(); i++) {
                    float[] q = p.get(keep.get(i));
                    if (i == 0) r.path.moveTo(q[0], q[1]); else r.path.lineTo(q[0], q[1]);
                }
                return r;
            }
            float[] m = p.get(p.size() / 2);
            r.name = "Curva";
            r.path.moveTo(a[0], a[1]);
            r.path.quadTo(2 * m[0] - (a[0] + b[0]) / 2, 2 * m[1] - (a[1] + b[1]) / 2, b[0], b[1]);
            return r;
        }
        r.closed = true;
        // elipse por componentes principais
        double cx = 0, cy = 0;
        for (float[] q : p) { cx += q[0]; cy += q[1]; }
        cx /= p.size(); cy /= p.size();
        double sxx = 0, syy = 0, sxy = 0;
        for (float[] q : p) {
            double dx = q[0] - cx, dy = q[1] - cy;
            sxx += dx * dx; syy += dy * dy; sxy += dx * dy;
        }
        sxx /= p.size(); syy /= p.size(); sxy /= p.size();
        double tr = sxx + syy, det = sxx * syy - sxy * sxy;
        double disc = Math.sqrt(Math.max(0, tr * tr / 4 - det));
        double l1 = tr / 2 + disc, l2 = Math.max(1e-6, tr / 2 - disc);
        double rot = 0.5 * Math.atan2(2 * sxy, sxx - syy);
        double ra = Math.sqrt(2 * l1), rb = Math.sqrt(2 * l2);
        double err = 0;
        double co = Math.cos(-rot), si = Math.sin(-rot);
        for (float[] q : p) {
            double dx = q[0] - cx, dy = q[1] - cy;
            double u = dx * co - dy * si, v = dx * si + dy * co;
            double rr = Math.sqrt(u * u / (ra * ra) + v * v / (rb * rb));
            err += Math.abs(rr - 1);
        }
        err /= p.size();
        // polígono
        ArrayList<Integer> keep = new ArrayList<>();
        // começa no ponto mais distante do centro para não cortar um canto
        int far = 0;
        double fd = 0;
        for (int i = 0; i < p.size(); i++) {
            double d = Math.hypot(p.get(i)[0] - cx, p.get(i)[1] - cy);
            if (d > fd) { fd = d; far = i; }
        }
        ArrayList<float[]> ring = new ArrayList<>();
        for (int i = 0; i < p.size(); i++) ring.add(p.get((far + i) % p.size()));
        ring.add(ring.get(0));
        keep.add(0);
        rdp(ring, 0, ring.size() - 1, diag * 0.09, keep);
        int corners = keep.size();
        double perr = 0;
        for (int i = 0; i < ring.size(); i++) {
            double md = Double.MAX_VALUE;
            for (int k = 0; k < keep.size(); k++) {
                float[] s = ring.get(keep.get(k)), e = ring.get(k + 1 < keep.size() ? keep.get(k + 1) : 0);
                md = Math.min(md, segDist(ring.get(i), s, e));
            }
            perr += md;
        }
        perr = perr / ring.size() / Math.max(1, (ra + rb) / 2);
        if ((corners == 3 || corners == 4) && perr < err) {
            if (corners == 4 && isRect(ring, keep)) {
                r.name = "Retângulo";
                // retângulo alinhado à própria rotação
                float[] p0 = ring.get(keep.get(0)), p1 = ring.get(keep.get(1)), p2 = ring.get(keep.get(2)), p3 = ring.get(keep.get(3));
                double ang = Math.atan2(p1[1] - p0[1], p1[0] - p0[0]);
                double snap = Math.round(ang / (Math.PI / 2)) * (Math.PI / 2);
                if (Math.abs(ang - snap) < 0.12) ang = snap;
                double w = (Math.hypot(p1[0] - p0[0], p1[1] - p0[1]) + Math.hypot(p2[0] - p3[0], p2[1] - p3[1])) / 2;
                double h = (Math.hypot(p3[0] - p0[0], p3[1] - p0[1]) + Math.hypot(p2[0] - p1[0], p2[1] - p1[1])) / 2;
                float mx = (p0[0] + p1[0] + p2[0] + p3[0]) / 4, my = (p0[1] + p1[1] + p2[1] + p3[1]) / 4;
                r.path.addRect(new RectF((float) (mx - w / 2), (float) (my - h / 2), (float) (mx + w / 2), (float) (my + h / 2)), Path.Direction.CW);
                Matrix m = new Matrix();
                m.setRotate((float) Math.toDegrees(ang), mx, my);
                r.path.transform(m);
                return r;
            }
            r.name = corners == 3 ? "Triângulo" : "Quadrilátero";
            for (int i = 0; i < corners; i++) {
                float[] q = ring.get(keep.get(i));
                if (i == 0) r.path.moveTo(q[0], q[1]); else r.path.lineTo(q[0], q[1]);
            }
            r.path.close();
            return r;
        }
        if (err < 0.16) {
            if (ra / rb < 1.18) {
                float rr = (float) ((ra + rb) / 2);
                r.name = "Círculo";
                r.path.addCircle((float) cx, (float) cy, rr, Path.Direction.CW);
            } else {
                r.name = "Elipse";
                double deg = Math.toDegrees(rot);
                double snap = Math.round(deg / 90) * 90;
                if (Math.abs(deg - snap) < 7) deg = snap;
                r.path.addOval(new RectF((float) (cx - ra), (float) (cy - rb), (float) (cx + ra), (float) (cy + rb)), Path.Direction.CW);
                Matrix m = new Matrix();
                m.setRotate((float) deg, (float) cx, (float) cy);
                r.path.transform(m);
            }
            return r;
        }
        if (corners >= 3 && corners <= 8) {
            r.name = "Polígono";
            for (int i = 0; i < corners; i++) {
                float[] q = ring.get(keep.get(i));
                if (i == 0) r.path.moveTo(q[0], q[1]); else r.path.lineTo(q[0], q[1]);
            }
            r.path.close();
            return r;
        }
        return null;
    }

    private static boolean isRect(ArrayList<float[]> ring, ArrayList<Integer> keep) {
        for (int i = 0; i < 4; i++) {
            float[] a = ring.get(keep.get((i + 3) % 4)), b = ring.get(keep.get(i)), c = ring.get(keep.get((i + 1) % 4));
            double ux = a[0] - b[0], uy = a[1] - b[1], vx = c[0] - b[0], vy = c[1] - b[1];
            double cos = (ux * vx + uy * vy) / (Math.hypot(ux, uy) * Math.hypot(vx, vy) + 1e-6);
            if (Math.abs(cos) > 0.3) return false;
        }
        return true;
    }
}
