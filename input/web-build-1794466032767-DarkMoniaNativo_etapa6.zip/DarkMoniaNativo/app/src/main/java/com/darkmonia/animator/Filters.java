package com.darkmonia.animator;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;

import java.util.Random;

/** Filtros e ajustes de camada (como no Ibis Paint / Krita). */
final class Filters {
    static final class F {
        final String id, name;
        final String[] params;
        final int[] min, max, def;
        boolean color;
        F(String id, String name, String[] params, int[] min, int[] max, int[] def) {
            this.id = id; this.name = name; this.params = params; this.min = min; this.max = max; this.def = def;
        }
        F col() { color = true; return this; }
    }

    private static final String[] N = {};
    private static final int[] Z = {};
    static final F[] ALL = {
            new F("hsb", "Matiz · Saturação · Brilho", new String[]{"Matiz", "Saturação", "Brilho"}, new int[]{-180, -100, -100}, new int[]{180, 100, 100}, new int[]{0, 0, 0}),
            new F("contrast", "Contraste", new String[]{"Contraste", "Exposição"}, new int[]{-100, -100}, new int[]{100, 100}, new int[]{20, 0}),
            new F("blur", "Desfoque gaussiano", new String[]{"Raio"}, new int[]{1}, new int[]{60}, new int[]{6}),
            new F("sharpen", "Nitidez", new String[]{"Intensidade"}, new int[]{0}, new int[]{200}, new int[]{70}),
            new F("noise", "Ruído", new String[]{"Quantidade"}, new int[]{0}, new int[]{100}, new int[]{25}),
            new F("lineart", "Extrair traço", new String[]{"Limite"}, new int[]{0}, new int[]{100}, new int[]{60}).col(),
            new F("colorize", "Colorir com a cor atual", new String[]{"Intensidade"}, new int[]{0}, new int[]{100}, new int[]{100}).col(),
            new F("glow", "Brilho (bloom)", new String[]{"Raio", "Intensidade"}, new int[]{1, 0}, new int[]{60, 200}, new int[]{12, 90}),
            new F("outline", "Contorno externo", new String[]{"Espessura"}, new int[]{1}, new int[]{40}, new int[]{6}).col(),
            new F("shadow", "Sombra projetada", new String[]{"Distância", "Desfoque", "Opacidade"}, new int[]{0, 0, 0}, new int[]{80, 40, 100}, new int[]{14, 8, 55}),
            new F("chroma", "Aberração cromática", new String[]{"Deslocamento"}, new int[]{1}, new int[]{40}, new int[]{6}),
            new F("posterize", "Posterizar", new String[]{"Níveis"}, new int[]{2}, new int[]{16}, new int[]{5}),
            new F("threshold", "Limiar (P&B)", new String[]{"Limite"}, new int[]{0}, new int[]{255}, new int[]{128}),
            new F("pixelate", "Pixelizar", new String[]{"Tamanho"}, new int[]{2}, new int[]{64}, new int[]{10}),
            new F("gray", "Preto e branco", N, Z, Z, Z),
            new F("sepia", "Sépia", new String[]{"Intensidade"}, new int[]{0}, new int[]{100}, new int[]{100}),
            new F("invert", "Inverter cores", N, Z, Z, Z),
    };

    static Bitmap apply(Bitmap src, String id, int[] v, int color) {
        int w = src.getWidth(), h = src.getHeight();
        switch (id) {
            case "hsb": {
                ColorMatrix m = new ColorMatrix();
                ColorMatrix s = new ColorMatrix();
                s.setSaturation(1 + v[1] / 100f);
                m.postConcat(s);
                m.postConcat(hue(v[0]));
                float br = v[2] * 1.6f;
                m.postConcat(new ColorMatrix(new float[]{1, 0, 0, 0, br, 0, 1, 0, 0, br, 0, 0, 1, 0, br, 0, 0, 0, 1, 0}));
                return matrix(src, m);
            }
            case "contrast": {
                float c = 1 + v[0] / 100f * (v[0] > 0 ? 1.5f : 1f), t = 128 * (1 - c) + v[1] * 1.6f;
                return matrix(src, new ColorMatrix(new float[]{c, 0, 0, 0, t, 0, c, 0, 0, t, 0, 0, c, 0, t, 0, 0, 0, 1, 0}));
            }
            case "gray": {
                ColorMatrix m = new ColorMatrix();
                m.setSaturation(0);
                return matrix(src, m);
            }
            case "sepia": {
                float k = v[0] / 100f;
                float[] s = {.393f, .769f, .189f, .349f, .686f, .168f, .272f, .534f, .131f};
                float[] id3 = {1, 0, 0, 0, 1, 0, 0, 0, 1};
                float[] m = new float[20];
                for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) m[r * 5 + c] = id3[r * 3 + c] * (1 - k) + s[r * 3 + c] * k;
                m[18] = 1;
                return matrix(src, new ColorMatrix(m));
            }
            case "invert":
                return matrix(src, new ColorMatrix(new float[]{-1, 0, 0, 0, 255, 0, -1, 0, 0, 255, 0, 0, -1, 0, 255, 0, 0, 0, 1, 0}));
            case "pixelate": {
                int s = Math.max(2, v[0]);
                Bitmap small = Bitmap.createScaledBitmap(src, Math.max(1, w / s), Math.max(1, h / s), true);
                Bitmap out = Bitmap.createScaledBitmap(small, w, h, false);
                small.recycle();
                return out;
            }
            case "blur":
                return blur(src, v[0]);
            case "glow": {
                Bitmap b = blur(src, v[0]);
                Bitmap out = src.copy(Bitmap.Config.ARGB_8888, true);
                Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
                p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
                Canvas c = new Canvas(out);
                int a = v[1];
                while (a > 0) {
                    p.setAlpha(Math.min(255, Math.round(a * 2.55f)));
                    c.drawBitmap(b, 0, 0, p);
                    a -= 100;
                }
                // o brilho também espalha para fora do desenho
                Paint over = new Paint(Paint.FILTER_BITMAP_FLAG);
                over.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OVER));
                over.setAlpha(Math.min(255, Math.round(v[1] * 2.55f)));
                c.drawBitmap(b, 0, 0, over);
                b.recycle();
                return out;
            }
            case "outline":
            case "shadow": {
                boolean sh = id.equals("shadow");
                int r = sh ? v[1] : v[0];
                Bitmap alpha = src.extractAlpha();
                Bitmap mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                Paint tp = new Paint();
                tp.setColor(0xFF000000);
                new Canvas(mask).drawBitmap(alpha, 0, 0, tp);
                alpha.recycle();
                Bitmap soft = r > 0 ? blur(mask, r) : mask;
                if (soft != mask) mask.recycle();
                int[] px = new int[w * h];
                soft.getPixels(px, 0, w, 0, 0, w, h);
                int rgb = (sh ? 0x000000 : color & 0xFFFFFF);
                float op = sh ? v[2] / 100f : 1f;
                for (int i = 0; i < px.length; i++) {
                    int a = px[i] >>> 24;
                    float k = sh ? a / 255f : Math.min(1f, a / 255f * 3.2f);
                    px[i] = (Math.round(k * op * 255) << 24) | rgb;
                }
                soft.setPixels(px, 0, w, 0, 0, w, h);
                Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(out);
                float d = sh ? v[0] * .7071f : 0;
                c.drawBitmap(soft, d, d, null);
                c.drawBitmap(src, 0, 0, null);
                soft.recycle();
                return out;
            }
            default:
                break;
        }
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        switch (id) {
            case "sharpen": {
                Bitmap b = blur(src, 2);
                int[] bl = new int[w * h];
                b.getPixels(bl, 0, w, 0, 0, w, h);
                b.recycle();
                float k = v[0] / 100f;
                for (int i = 0; i < px.length; i++) {
                    int c = px[i], d = bl[i];
                    if ((c >>> 24) == 0) continue;
                    int r = clamp(((c >> 16) & 255) + Math.round(k * (((c >> 16) & 255) - ((d >> 16) & 255))));
                    int g = clamp(((c >> 8) & 255) + Math.round(k * (((c >> 8) & 255) - ((d >> 8) & 255))));
                    int bb = clamp((c & 255) + Math.round(k * ((c & 255) - (d & 255))));
                    px[i] = (c & 0xFF000000) | (r << 16) | (g << 8) | bb;
                }
                break;
            }
            case "noise": {
                Random rnd = new Random(7);
                int amt = Math.round(v[0] * 1.2f);
                for (int i = 0; i < px.length; i++) {
                    int c = px[i];
                    if ((c >>> 24) == 0) continue;
                    int n = rnd.nextInt(amt * 2 + 1) - amt;
                    px[i] = (c & 0xFF000000) | (clamp(((c >> 16) & 255) + n) << 16) | (clamp(((c >> 8) & 255) + n) << 8) | clamp((c & 255) + n);
                }
                break;
            }
            case "posterize": {
                int lv = Math.max(2, v[0]);
                float st = 255f / (lv - 1);
                for (int i = 0; i < px.length; i++) {
                    int c = px[i];
                    int r = Math.round(Math.round(((c >> 16) & 255) / st) * st);
                    int g = Math.round(Math.round(((c >> 8) & 255) / st) * st);
                    int b = Math.round(Math.round((c & 255) / st) * st);
                    px[i] = (c & 0xFF000000) | (clamp(r) << 16) | (clamp(g) << 8) | clamp(b);
                }
                break;
            }
            case "threshold":
                for (int i = 0; i < px.length; i++) {
                    int c = px[i];
                    int l = lum(c);
                    px[i] = (c & 0xFF000000) | (l >= v[0] ? 0xFFFFFF : 0);
                }
                break;
            case "lineart": {
                float t = 255 * (0.35f + v[0] / 100f * 0.6f);
                int rgb = color & 0xFFFFFF;
                for (int i = 0; i < px.length; i++) {
                    int c = px[i];
                    float l = lum(c);
                    float a = l >= t ? 0 : Math.min(1f, (t - l) / t * 1.4f);
                    a *= (c >>> 24) / 255f;
                    px[i] = (Math.round(a * 255) << 24) | rgb;
                }
                break;
            }
            case "colorize": {
                float k = v[0] / 100f;
                int cr = (color >> 16) & 255, cg = (color >> 8) & 255, cb = color & 255;
                for (int i = 0; i < px.length; i++) {
                    int c = px[i];
                    if ((c >>> 24) == 0) continue;
                    float l = lum(c) / 255f;
                    // tom da cor atual, mantendo luz e sombra do desenho
                    float lo = l < .5f ? l * 2 : 1, hi = l < .5f ? 0 : (l - .5f) * 2;
                    int r = Math.round(cr * lo + (255 - cr) * hi), g = Math.round(cg * lo + (255 - cg) * hi), b = Math.round(cb * lo + (255 - cb) * hi);
                    r = Math.round(((c >> 16) & 255) * (1 - k) + r * k);
                    g = Math.round(((c >> 8) & 255) * (1 - k) + g * k);
                    b = Math.round((c & 255) * (1 - k) + b * k);
                    px[i] = (c & 0xFF000000) | (clamp(r) << 16) | (clamp(g) << 8) | clamp(b);
                }
                break;
            }
            case "chroma": {
                int s = v[0];
                int[] out = new int[px.length];
                for (int y = 0; y < h; y++) {
                    int row = y * w;
                    for (int x = 0; x < w; x++) {
                        int cr = px[row + Math.min(w - 1, x + s)], cg = px[row + x], cb = px[row + Math.max(0, x - s)];
                        int a = Math.max(cr >>> 24, Math.max(cg >>> 24, cb >>> 24));
                        int r = (cr >> 16) & 255, g = (cg >> 8) & 255, b = cb & 255;
                        if ((cr >>> 24) == 0) r = 0;
                        if ((cg >>> 24) == 0) g = 0;
                        if ((cb >>> 24) == 0) b = 0;
                        out[row + x] = (a << 24) | (r << 16) | (g << 8) | b;
                    }
                }
                px = out;
                break;
            }
            default:
                break;
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(px, 0, w, 0, 0, w, h);
        return out;
    }

    static int lum(int c) {
        return (((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000;
    }

    private static int clamp(int v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

    private static Bitmap matrix(Bitmap src, ColorMatrix m) {
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Paint p = new Paint();
        p.setColorFilter(new ColorMatrixColorFilter(m));
        new Canvas(out).drawBitmap(src, 0, 0, p);
        return out;
    }

    private static ColorMatrix hue(float deg) {
        float a = (float) Math.toRadians(deg);
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        float lr = .213f, lg = .715f, lb = .072f;
        return new ColorMatrix(new float[]{
                lr + c * (1 - lr) + s * (-lr), lg + c * (-lg) + s * (-lg), lb + c * (-lb) + s * (1 - lb), 0, 0,
                lr + c * (-lr) + s * .143f, lg + c * (1 - lg) + s * .14f, lb + c * (-lb) + s * (-.283f), 0, 0,
                lr + c * (-lr) + s * (-(1 - lr)), lg + c * (-lg) + s * lg, lb + c * (1 - lb) + s * lb, 0, 0,
                0, 0, 0, 1, 0});
    }

    /** Desfoque rápido (3 caixas ≈ gaussiano) em cores pré-multiplicadas, sem bordas escuras. */
    static Bitmap blur(Bitmap src, int radius) {
        int w = src.getWidth(), h = src.getHeight();
        int scale = 1;
        while (radius / scale > 10 && Math.min(w, h) / (scale * 2) > 16) scale *= 2;
        Bitmap work = scale > 1 ? Bitmap.createScaledBitmap(src, Math.max(1, w / scale), Math.max(1, h / scale), true) : src;
        int ww = work.getWidth(), hh = work.getHeight();
        int r = Math.max(1, Math.round(radius / (float) scale * 0.6f));
        int[] px = new int[ww * hh];
        work.getPixels(px, 0, ww, 0, 0, ww, hh);
        if (work != src) work.recycle();
        int n = px.length;
        int[] a = new int[n], rr = new int[n], gg = new int[n], bb = new int[n];
        for (int i = 0; i < n; i++) {
            int c = px[i], al = c >>> 24;
            a[i] = al;
            rr[i] = ((c >> 16) & 255) * al / 255;
            gg[i] = ((c >> 8) & 255) * al / 255;
            bb[i] = (c & 255) * al / 255;
        }
        int[] t = new int[n];
        for (int pass = 0; pass < 3; pass++) {
            for (int[] ch : new int[][]{a, rr, gg, bb}) {
                box(ch, t, ww, hh, r, true);
                box(t, ch, ww, hh, r, false);
            }
        }
        for (int i = 0; i < n; i++) {
            int al = a[i];
            if (al <= 0) { px[i] = 0; continue; }
            px[i] = (Math.min(255, al) << 24) | (clamp(rr[i] * 255 / al) << 16) | (clamp(gg[i] * 255 / al) << 8) | clamp(bb[i] * 255 / al);
        }
        Bitmap out = Bitmap.createBitmap(ww, hh, Bitmap.Config.ARGB_8888);
        out.setPixels(px, 0, ww, 0, 0, ww, hh);
        if (scale > 1) {
            Bitmap up = Bitmap.createScaledBitmap(out, w, h, true);
            out.recycle();
            return up;
        }
        return out;
    }

    private static void box(int[] in, int[] out, int w, int h, int r, boolean horiz) {
        int len = horiz ? w : h, lines = horiz ? h : w;
        int d = r * 2 + 1;
        for (int l = 0; l < lines; l++) {
            int base = horiz ? l * w : l, step = horiz ? 1 : w;
            int sum = 0;
            for (int i = -r; i <= r; i++) sum += in[base + Math.min(len - 1, Math.max(0, i)) * step];
            for (int i = 0; i < len; i++) {
                out[base + i * step] = sum / d;
                int add = Math.min(len - 1, i + r + 1), rem = Math.max(0, i - r);
                sum += in[base + add * step] - in[base + rem * step];
            }
        }
    }
}
