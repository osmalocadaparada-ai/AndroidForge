# Dark Monia — nativo etapa 4

**Java puro**, sem WebView. `applicationId` = `com.darkmonia.animator` (substitui a versão HTML).

## Tela cheia
- Canvas ocupa **100%** da tela (FrameLayout)
- Barras flutuantes semi-transparentes (topo + base)
- Modo imersivo (esconde status/navigation bar)
- Botão ⛶ ou segurar o título: esconde/mostra a UI

## Ferramentas (próximo da v5.0)
| Grupo | Itens |
|-------|--------|
| Pincéis | Lápis, G-Pen (pressão), Marcador, Aerógrafo, Borracha |
| Preencher | Balde (tolerância), Conta-gotas |
| Visão | Mão (pan), pinça zoom, 2 dedos desfaz, 3 dedos refaz |
| Seleção | Retângulo, **Laço**, mover pixels, apagar/preencher/recortar/copiar/colar |
| Formas | Reta, Retângulo, Elipse (+ opção **Preench.**) |
| Texto | Ferramenta Texto |
| Simetria | SymH / SymV ao desenhar |
| Camadas | até 16, bloquear, mesclar, espelhar H/V, opacidade |
| Animação | timeline, onion, copiar/colar quadro, fps, play |
| Export | PNG com/sem fundo, sequência de quadros |

## Ainda não (HTML v5)
Liquidificar, clone, filtros, blend modes, máscara de recorte, varinha mágica completa,
transformar com alças/rotação, QuickShape, girar tela livre, áudio, GIF/vídeo, time-lapse.

## Compilar
Android Studio / AndroidIDE → Build APK  
ou GitHub Action em `.github/workflows`
