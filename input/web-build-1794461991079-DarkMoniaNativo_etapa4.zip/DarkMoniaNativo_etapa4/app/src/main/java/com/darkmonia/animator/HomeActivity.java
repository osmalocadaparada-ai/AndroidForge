package com.darkmonia.animator;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;

/** Tela inicial: criar desenho/animação e galeria com filtros. */
public class HomeActivity extends Activity {
    private LinearLayout grid;
    private TextView empty;
    private int filter = 0; // 0 all, 1 drawings, 2 anims
    private final Button[] filterBtns = new Button[3];

    private static final String[] SIZE_NAMES = {
            "Quadrado 1080×1080", "Retrato 1080×1350", "Story 1080×1920", "Paisagem 1920×1080",
            "HD 1280×720", "A4 2480×3508", "A5 1748×2480", "4K 3840×2160",
            "Ícone 512×512", "Pixel art 256×256", "Leve 854×480", "Papel de parede 1080×2340"
    };
    private static final int[][] SIZES = {
            {1080, 1080}, {1080, 1350}, {1080, 1920}, {1920, 1080},
            {1280, 720}, {2480, 3508}, {1748, 2480}, {3840, 2160},
            {512, 512}, {256, 256}, {854, 480}, {1080, 2340}
    };

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        int pad = Ui.dp(this, 16);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(pad, pad, pad, 0);

        TextView title = new TextView(this);
        title.setText("Dark Monia");
        title.setTextColor(Ui.FG);
        title.setTextSize(30);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Estúdio Java nativo · etapa 4");
        sub.setTextColor(Ui.MUTE);
        sub.setTextSize(12);
        root.addView(sub);

        LinearLayout acts = new LinearLayout(this);
        acts.setPadding(0, pad, 0, pad);
        Button d = bigBtn("Novo desenho", 0xFFD94C8F);
        Button a = bigBtn("Nova animação", 0xFF2F8FD9);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, Ui.dp(this, 88), 1);
        lp1.setMargins(0, 0, Ui.dp(this, 6), 0);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, Ui.dp(this, 88), 1);
        lp2.setMargins(Ui.dp(this, 6), 0, 0, 0);
        acts.addView(d, lp1);
        acts.addView(a, lp2);
        root.addView(acts);
        d.setOnClickListener(v -> newProject(false));
        a.setOnClickListener(v -> newProject(true));

        TextView gal = new TextView(this);
        gal.setText("Minha galeria");
        gal.setTextColor(Ui.FG);
        gal.setTextSize(17);
        gal.setTypeface(null, android.graphics.Typeface.BOLD);
        gal.setPadding(0, 0, 0, Ui.dp(this, 8));
        root.addView(gal);

        LinearLayout filters = new LinearLayout(this);
        filters.setPadding(0, 0, 0, Ui.dp(this, 8));
        String[] labels = {"Tudo", "Desenhos", "Animações"};
        for (int i = 0; i < 3; i++) {
            final int fi = i;
            filterBtns[i] = Ui.btn(this, labels[i]);
            filterBtns[i].setOnClickListener(v -> {
                filter = fi;
                updateFilterBtns();
                refresh();
            });
            LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
            flp.setMargins(i == 0 ? 0 : Ui.dp(this, 4), 0, 0, 0);
            filters.addView(filterBtns[i], flp);
        }
        root.addView(filters);
        updateFilterBtns();

        ScrollView sv = new ScrollView(this);
        grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        empty = new TextView(this);
        empty.setTextColor(Ui.MUTE);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(0, Ui.dp(this, 40), 0, 0);
        empty.setVisibility(View.GONE);
        grid.addView(empty);
        sv.addView(grid);
        root.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);
    }

    private void updateFilterBtns() {
        for (int i = 0; i < 3; i++) Ui.selAlt(filterBtns[i], i == filter, Ui.ACC2);
    }

    private Button bigBtn(String t, int col) {
        Button b = Ui.btn(this, t);
        b.setTextSize(16);
        b.setBackground(Ui.bg(col, Ui.dp(this, 18)));
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void newProject(final boolean anim) {
        new AlertDialog.Builder(this)
                .setTitle(anim ? "Tamanho da animação" : "Tamanho do desenho")
                .setItems(SIZE_NAMES, (dlg, i) -> {
                    int n = Project.list(this).size() + 1;
                    Project p = Project.create(this, (anim ? "Animação " : "Desenho ") + n, SIZES[i][0], SIZES[i][1], anim);
                    open(p);
                })
                .show();
    }

    private void open(Project p) {
        Intent it = new Intent(this, EditorActivity.class);
        it.putExtra("dir", p.dir.getPath());
        startActivity(it);
    }

    private void refresh() {
        // remove cards but keep empty view at index 0
        while (grid.getChildCount() > 1) grid.removeViewAt(1);
        ArrayList<Project> all = Project.list(this);
        ArrayList<Project> list = new ArrayList<>();
        for (Project p : all) {
            if (filter == 1 && p.anim) continue;
            if (filter == 2 && !p.anim) continue;
            list.add(p);
        }
        if (list.isEmpty()) {
            empty.setVisibility(View.VISIBLE);
            empty.setText(filter == 0
                    ? "Nada aqui ainda. Crie um desenho ou uma animação."
                    : "Nenhum projeto neste filtro.");
            return;
        }
        empty.setVisibility(View.GONE);
        int gap = Ui.dp(this, 6);
        LinearLayout row = null;
        for (int i = 0; i < list.size(); i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                grid.addView(row);
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
            lp.setMargins(gap, gap, gap, gap);
            row.addView(card(list.get(i)), lp);
        }
        if (list.size() % 2 == 1) {
            View filler = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1);
            lp.setMargins(gap, gap, gap, gap);
            row.addView(filler, lp);
        }
    }

    private View card(final Project p) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.bg(Ui.CARD, Ui.dp(this, 14)));
        int pad = Ui.dp(this, 8);
        c.setPadding(pad, pad, pad, pad);
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackgroundColor(0xFF0C0D14);
        if (p.thumbFile().exists()) {
            Bitmap b = BitmapFactory.decodeFile(p.thumbFile().getPath());
            if (b != null) iv.setImageBitmap(b);
        }
        c.addView(iv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 130)));
        TextView n = new TextView(this);
        n.setText(p.name);
        n.setTextColor(Ui.FG);
        n.setTextSize(14);
        n.setSingleLine(true);
        n.setPadding(0, pad, 0, 0);
        c.addView(n);
        TextView info = new TextView(this);
        info.setText((p.anim ? p.frames.size() + " quadros · " : "Desenho · ") + p.w + "×" + p.h);
        info.setTextColor(Ui.MUTE);
        info.setTextSize(11);
        c.addView(info);
        c.setOnClickListener(v -> open(p));
        c.setOnLongClickListener(v -> {
            options(p);
            return true;
        });
        return c;
    }

    private void options(final Project p) {
        new AlertDialog.Builder(this)
                .setTitle(p.name)
                .setItems(new String[]{"Abrir", "Renomear", "Excluir"}, (dlg, i) -> {
                    if (i == 0) open(p);
                    else if (i == 1) rename(p);
                    else confirmDelete(p);
                })
                .show();
    }

    private void rename(final Project p) {
        final EditText et = new EditText(this);
        et.setText(p.name);
        new AlertDialog.Builder(this)
                .setTitle("Renomear")
                .setView(et)
                .setPositiveButton("OK", (dlg, w) -> {
                    String s = et.getText().toString().trim();
                    if (s.length() > 0) {
                        p.name = s.length() > 40 ? s.substring(0, 40) : s;
                        p.save();
                        refresh();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void confirmDelete(final Project p) {
        new AlertDialog.Builder(this)
                .setTitle("Excluir “" + p.name + "”?")
                .setMessage("Isso não pode ser desfeito.")
                .setPositiveButton("Excluir", (dlg, w) -> {
                    p.deleteAll();
                    refresh();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}
