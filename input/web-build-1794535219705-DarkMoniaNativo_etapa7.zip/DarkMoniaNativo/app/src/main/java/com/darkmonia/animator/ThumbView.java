package com.darkmonia.animator;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Miniatura do projeto: fundo escuro com brilho no centro e a imagem com cantos arredondados. */
class ThumbView extends View {
    private Bitmap bmp;
    private final Paint bgP = new Paint(), imgP = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG),
            shadowP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Matrix mx = new Matrix();
    float fill = 0.84f;
    float corner;
    boolean square = true;

    ThumbView(Context c) {
        super(c);
        corner = Ui.dp(c, 6);
        shadowP.setColor(0x66000000);
    }

    void setBitmap(Bitmap b) { bmp = b; imgP.setShader(null); invalidate(); }

    @Override protected void onMeasure(int ws, int hs) {
        if (square) {
            int w = MeasureSpec.getSize(ws);
            setMeasuredDimension(w, w);
        } else super.onMeasure(ws, hs);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        bgP.setShader(new RadialGradient(w / 2f, h * 0.38f, Math.max(w, h) * 0.75f,
                new int[]{0xFF1E2236, 0xFF0C0E18}, null, Shader.TileMode.CLAMP));
    }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawRect(0, 0, w, h, bgP);
        if (bmp == null || bmp.isRecycled()) return;
        float k = Math.min(w * fill / bmp.getWidth(), h * fill / bmp.getHeight());
        float bw = bmp.getWidth() * k, bh = bmp.getHeight() * k;
        r.set((w - bw) / 2f, (h - bh) / 2f, (w + bw) / 2f, (h + bh) / 2f);
        BitmapShader sh = new BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        mx.reset();
        mx.setScale(k, k);
        mx.postTranslate(r.left, r.top);
        sh.setLocalMatrix(mx);
        imgP.setShader(sh);
        c.save();
        c.translate(0, Ui.dp(getContext(), 4));
        c.drawRoundRect(r, corner, corner, shadowP);
        c.restore();
        c.drawRoundRect(r, corner, corner, imgP);
    }
}
