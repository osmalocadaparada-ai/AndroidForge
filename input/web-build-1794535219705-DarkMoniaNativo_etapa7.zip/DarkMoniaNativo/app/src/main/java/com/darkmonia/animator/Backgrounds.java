package com.darkmonia.animator;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.util.Random;

/** "Fundos de estúdio": cenários prontos desenhados por código (céus, paisagens, papéis e texturas). */
final class Backgrounds {
    static final String[] NAMES = {"Céu azul", "Pôr do sol", "Noite estrelada", "Aurora", "Oceano", "Campo verde", "Deserto",
            "Montanhas", "Neblina", "Cidade ao entardecer", "Ilhas no céu", "Espaço", "Floresta", "Neve", "Estúdio cinza",
            "Papel kraft", "Caderno pautado", "Quadriculado", "Retícula mangá", "Vinheta escura", "Degradê rosa", "Degradê azul",
            "Cena de luta", "Sala de aula", "Palco", "Grama e céu", "Lava", "Submarino", "Pixel céu", "Papel aquarela"};

    private static void vgrad(Canvas c, int w, int h, int[] cols, float[] pos) {
        Paint p = new Paint();
        p.setShader(new LinearGradient(0, 0, 0, h, cols, pos, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
    }

    private static void hills(Canvas c, int w, int h, float base, float amp, int col, Random r, int bumps) {
        Path p = new Path();
        p.moveTo(0, h);
        p.lineTo(0, base);
        float step = w / (float) bumps;
        for (int i = 0; i < bumps; i++) {
            float x0 = i * step;
            p.quadTo(x0 + step / 2, base - amp * (.4f + r.nextFloat()), x0 + step, base + amp * (r.nextFloat() - .5f) * .3f);
        }
        p.lineTo(w, h);
        p.close();
        Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
        pp.setColor(col);
        c.drawPath(p, pp);
    }

    private static void peaks(Canvas c, int w, int h, float base, float amp, int col, Random r, int n) {
        Path p = new Path();
        p.moveTo(0, h);
        p.lineTo(0, base);
        float step = w / (float) n;
        for (int i = 0; i < n; i++) {
            p.lineTo(i * step + step / 2, base - amp * (.5f + r.nextFloat() * .5f));
            p.lineTo((i + 1) * step, base - amp * r.nextFloat() * .25f);
        }
        p.lineTo(w, h);
        p.close();
        Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
        pp.setColor(col);
        c.drawPath(p, pp);
    }

    private static void stars(Canvas c, int w, int h, int n, Random r, float maxY) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float k = Math.max(w, h) / 1080f;
        for (int i = 0; i < n; i++) {
            p.setColor(((60 + r.nextInt(195)) << 24) | 0xFFFFFF);
            c.drawCircle(r.nextFloat() * w, r.nextFloat() * h * maxY, (.6f + r.nextFloat() * r.nextFloat() * 2.4f) * k, p);
        }
    }

    private static void glow(Canvas c, float x, float y, float r, int col) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(x, y, r, col, col & 0xFFFFFF, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, p);
    }

    private static void clouds(Canvas c, int w, int h, Random r, int n, int col, float maxY) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(col);
        float k = Math.max(w, h) / 1080f;
        for (int i = 0; i < n; i++) {
            float cx = r.nextFloat() * w, cy = h * (.05f + r.nextFloat() * maxY), s = (40 + r.nextFloat() * 70) * k;
            for (int j = 0; j < 5; j++) c.drawCircle(cx + (j - 2) * s * .55f, cy - (j % 2) * s * .25f, s * (.5f + (j == 2 ? .25f : 0)), p);
            c.drawRect(cx - s * 1.3f, cy, cx + s * 1.3f, cy + s * .35f, p);
        }
    }

    static Bitmap make(int i, int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Random r = new Random(1000 + i);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float k = Math.max(w, h) / 1080f;
        switch (i) {
            case 0: vgrad(c, w, h, new int[]{0xFF4A90E2, 0xFF9CCBFF, 0xFFE8F4FF}, new float[]{0, .6f, 1}); clouds(c, w, h, r, 6, 0xF2FFFFFF, .5f); break;
            case 1: vgrad(c, w, h, new int[]{0xFF2B1B4F, 0xFFB4436C, 0xFFF79D5C, 0xFFFFD27A}, new float[]{0, .45f, .75f, 1}); glow(c, w * .5f, h * .78f, h * .35f, 0xCCFFE3A0); hills(c, w, h, h * .82f, h * .08f, 0xFF3A1F3D, r, 4); break;
            case 2: vgrad(c, w, h, new int[]{0xFF070A1C, 0xFF16204A, 0xFF2B2F6B}, new float[]{0, .6f, 1}); stars(c, w, h, (int) (420 * k * k), r, 1f); glow(c, w * .78f, h * .2f, h * .1f, 0xFFF5F1D8); hills(c, w, h, h * .86f, h * .06f, 0xFF0B0E22, r, 5); break;
            case 3: vgrad(c, w, h, new int[]{0xFF04131C, 0xFF0B2E3A, 0xFF10203A}, null); stars(c, w, h, (int) (260 * k * k), r, .7f);
                for (int j = 0; j < 4; j++) glow(c, w * (.2f + j * .2f), h * (.3f + r.nextFloat() * .1f), h * .3f, j % 2 == 0 ? 0x6634F5A0 : 0x5530C8FF);
                peaks(c, w, h, h * .85f, h * .12f, 0xFF061017, r, 7); break;
            case 4: vgrad(c, w, h, new int[]{0xFF7EC8F0, 0xFFCFEFFF, 0xFF2A7FB8, 0xFF0B3D6B}, new float[]{0, .5f, .52f, 1}); p.setColor(0x55FFFFFF);
                for (int j = 0; j < 60; j++) { float y = h * (.55f + r.nextFloat() * .45f); float x = r.nextFloat() * w; c.drawRect(x, y, x + (20 + r.nextFloat() * 60) * k, y + 2 * k, p); } break;
            case 5: vgrad(c, w, h, new int[]{0xFF8FD3FF, 0xFFE6F7FF}, null); clouds(c, w, h, r, 4, 0xEEFFFFFF, .35f); hills(c, w, h, h * .62f, h * .1f, 0xFF7BC86C, r, 3); hills(c, w, h, h * .72f, h * .08f, 0xFF4FA54A, r, 4); break;
            case 6: vgrad(c, w, h, new int[]{0xFFFFC07A, 0xFFFFE4B0}, null); glow(c, w * .7f, h * .3f, h * .12f, 0xFFFFF4D0); hills(c, w, h, h * .7f, h * .1f, 0xFFE8A85A, r, 3); hills(c, w, h, h * .8f, h * .07f, 0xFFD38C40, r, 5); break;
            case 7: vgrad(c, w, h, new int[]{0xFF9FC3E8, 0xFFE9F1FA}, null); peaks(c, w, h, h * .62f, h * .3f, 0xFF8796B8, r, 4); peaks(c, w, h, h * .75f, h * .22f, 0xFF5D6C8F, r, 6); hills(c, w, h, h * .88f, h * .05f, 0xFF3E4A66, r, 5); break;
            case 8: vgrad(c, w, h, new int[]{0xFFB7C0CC, 0xFFE3E7EC}, null); hills(c, w, h, h * .6f, h * .1f, 0xAA8C97A6, r, 3); hills(c, w, h, h * .72f, h * .08f, 0xCC6E7A8C, r, 4); vgrad(c, w, h, new int[]{0x00FFFFFF, 0x99F2F4F7}, null); break;
            case 9: vgrad(c, w, h, new int[]{0xFF3B2A5C, 0xFFE0707A, 0xFFFFB37A}, new float[]{0, .6f, 1});
                for (int j = 0; j < 22; j++) { float bw = (40 + r.nextFloat() * 90) * k, bh = h * (.15f + r.nextFloat() * .4f), x = r.nextFloat() * w;
                    p.setColor(0xFF231A38); c.drawRect(x, h - bh, x + bw, h, p); p.setColor(0x99FFD27A);
                    for (int q = 0; q < 8; q++) { float wx = x + 6 * k + r.nextFloat() * (bw - 16 * k), wy = h - bh + 8 * k + r.nextFloat() * (bh - 16 * k); c.drawRect(wx, wy, wx + 5 * k, wy + 7 * k, p); } } break;
            case 10: vgrad(c, w, h, new int[]{0xFF6CB8FF, 0xFFD8EEFF}, null); clouds(c, w, h, r, 5, 0xCCFFFFFF, .8f);
                for (int j = 0; j < 4; j++) { float cx = w * (.15f + j * .24f), cy = h * (.35f + r.nextFloat() * .35f), s = (80 + r.nextFloat() * 90) * k;
                    Path ip = new Path(); ip.moveTo(cx - s, cy); ip.lineTo(cx + s, cy); ip.lineTo(cx + s * .2f, cy + s * 1.4f); ip.close(); p.setColor(0xFF7A5A43); c.drawPath(ip, p);
                    p.setColor(0xFF5DBB63); c.drawOval(new android.graphics.RectF(cx - s * 1.05f, cy - s * .2f, cx + s * 1.05f, cy + s * .2f), p); } break;
            case 11: c.drawColor(0xFF05060F); stars(c, w, h, (int) (700 * k * k), r, 1f); glow(c, w * .3f, h * .4f, h * .45f, 0x553A2BFF); glow(c, w * .75f, h * .6f, h * .4f, 0x44FF3B8A); break;
            case 12: vgrad(c, w, h, new int[]{0xFF2E5E4A, 0xFF9FD6B0}, null);
                for (int j = 0; j < 40; j++) { float x = r.nextFloat() * w, th = h * (.3f + r.nextFloat() * .5f), tw = (40 + r.nextFloat() * 60) * k;
                    Path t = new Path(); t.moveTo(x, h - th); t.lineTo(x + tw, h); t.lineTo(x - tw, h); t.close(); p.setColor(j < 20 ? 0xFF2F6B4A : 0xFF1D4A33); c.drawPath(t, p); } break;
            case 13: vgrad(c, w, h, new int[]{0xFFB9D3EA, 0xFFF4F8FC}, null); hills(c, w, h, h * .7f, h * .1f, 0xFFFFFFFF, r, 3); p.setColor(0xCCFFFFFF);
                for (int j = 0; j < 300; j++) c.drawCircle(r.nextFloat() * w, r.nextFloat() * h, (1 + r.nextFloat() * 3) * k, p); break;
            case 14: c.drawColor(0xFF8A8F99); glow(c, w * .5f, h * .45f, Math.max(w, h) * .7f, 0xFFD5D8DE); break;
            case 15: c.drawColor(0xFFC9A57A); p.setColor(0x22000000); for (int j = 0; j < 4000; j++) c.drawCircle(r.nextFloat() * w, r.nextFloat() * h, k * (.5f + r.nextFloat()), p); break;
            case 16: { c.drawColor(0xFFFDFCF7); p.setColor(0xFFB8D4F0); p.setStrokeWidth(2 * k); float st = 34 * k; for (float y = st * 3; y < h; y += st) c.drawLine(0, y, w, y, p); p.setColor(0xFFF0A0A0); c.drawLine(70 * k, 0, 70 * k, h, p); break; }
            case 17: { c.drawColor(0xFFFFFFFF); p.setColor(0xFFDDE6F0); p.setStrokeWidth(1.5f * k); float st = 30 * k; for (float x = st; x < w; x += st) c.drawLine(x, 0, x, h, p); for (float y = st; y < h; y += st) c.drawLine(0, y, w, y, p); break; }
            case 18: { c.drawColor(0xFFFFFFFF); p.setColor(0xFFBFC3CC); float st = 12 * k; for (float y = 0; y < h; y += st) for (float x = (y / st) % 2 == 0 ? 0 : st / 2; x < w; x += st) c.drawCircle(x, y, st * .22f * (.4f + y / h), p); break; }
            case 19: c.drawColor(0xFF2A2C36); { Paint v = new Paint(); v.setShader(new RadialGradient(w / 2f, h / 2f, Math.max(w, h) * .7f, 0x00000000, 0xCC000000, Shader.TileMode.CLAMP)); c.drawRect(0, 0, w, h, v); } break;
            case 20: vgrad(c, w, h, new int[]{0xFFFF9AC0, 0xFFFFD6E5, 0xFFFFF3E8}, new float[]{0, .55f, 1}); break;
            case 21: vgrad(c, w, h, new int[]{0xFF1B2A8A, 0xFF4D8DFF, 0xFFBFE3FF}, new float[]{0, .55f, 1}); break;
            case 22: { c.drawColor(0xFFFFF4D8); p.setStrokeWidth(3 * k); for (int j = 0; j < 140; j++) { double a = r.nextDouble() * Math.PI * 2; float r0 = Math.max(w, h) * (.18f + r.nextFloat() * .1f), r1 = Math.max(w, h);
                p.setColor(j % 3 == 0 ? 0xFFFF6A45 : 0xFF222222); c.drawLine(w / 2f + (float) Math.cos(a) * r0, h / 2f + (float) Math.sin(a) * r0, w / 2f + (float) Math.cos(a) * r1, h / 2f + (float) Math.sin(a) * r1, p); } break; }
            case 23: vgrad(c, w, h, new int[]{0xFFF3E6C8, 0xFFE9D7AE}, null); p.setColor(0xFF2F4F3A); c.drawRect(w * .1f, h * .12f, w * .9f, h * .5f, p); p.setColor(0xFF8B5A2B); c.drawRect(w * .08f, h * .5f, w * .92f, h * .53f, p);
                p.setColor(0xFFB98A55); c.drawRect(0, h * .78f, w, h, p); break;
            case 24: vgrad(c, w, h, new int[]{0xFF1A0E14, 0xFF4A1422}, null); glow(c, w * .5f, h * .15f, h * .6f, 0x66FFE3A0); p.setColor(0xFF2B1A12); c.drawRect(0, h * .8f, w, h, p); p.setColor(0xFF8E1B2C);
                c.drawRect(0, 0, w * .12f, h, p); c.drawRect(w * .88f, 0, w, h, p); break;
            case 25: vgrad(c, w, h, new int[]{0xFF5AB4FF, 0xFFD5EEFF}, null); clouds(c, w, h, r, 4, 0xEEFFFFFF, .4f); p.setColor(0xFF59B04F); c.drawRect(0, h * .7f, w, h, p); p.setStrokeWidth(3 * k); p.setColor(0xFF3E8F38);
                for (int j = 0; j < 400; j++) { float x = r.nextFloat() * w, y = h * .7f + r.nextFloat() * h * .3f; c.drawLine(x, y, x + (r.nextFloat() - .5f) * 8 * k, y - (8 + r.nextFloat() * 14) * k, p); } break;
            case 26: vgrad(c, w, h, new int[]{0xFF1A0500, 0xFF5A1200, 0xFFFF5A00}, new float[]{0, .6f, 1}); for (int j = 0; j < 10; j++) glow(c, r.nextFloat() * w, h * (.75f + r.nextFloat() * .25f), h * .15f, 0x99FFB13B); break;
            case 27: vgrad(c, w, h, new int[]{0xFF0F6E8C, 0xFF053047, 0xFF021826}, new float[]{0, .5f, 1}); p.setColor(0x33FFFFFF);
                for (int j = 0; j < 80; j++) { float x = r.nextFloat() * w, y = r.nextFloat() * h; p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f * k); c.drawCircle(x, y, (2 + r.nextFloat() * 8) * k, p); } p.setStyle(Paint.Style.FILL); break;
            case 28: { int s = Math.max(4, Math.round(16 * k)); for (int y = 0; y < h; y += s) { float t = y / (float) h; p.setColor(blend(0xFF3A7BD5, 0xFFB8E1FF, t)); c.drawRect(0, y, w, y + s, p); }
                p.setColor(0xFFFFFFFF); for (int j = 0; j < 5; j++) { int cx = (int) (r.nextFloat() * w) / s * s, cy = (int) (r.nextFloat() * h * .5f) / s * s; c.drawRect(cx, cy, cx + s * 6, cy + s * 2, p); c.drawRect(cx + s, cy - s, cx + s * 4, cy, p); } break; }
            default: c.drawColor(0xFFFBF8F0); p.setColor(0x14000000); for (int j = 0; j < 2500; j++) { float x = r.nextFloat() * w, y = r.nextFloat() * h; c.drawCircle(x, y, k * (1 + r.nextFloat() * 2.5f), p); } break;
        }
        return b;
    }

    static int blend(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | (Math.round(ar + (br - ar) * t) << 16) | (Math.round(ag + (bg - ag) * t) << 8) | Math.round(ab + (bb - ab) * t);
    }
}
