package com.darkmonia.animator;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** Salva arquivos na Galeria / Downloads (pasta DarkMonia) e compartilha. */
final class Media {
    static String mime(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".mp4")) return "video/mp4";
        if (n.endsWith(".zip")) return "application/zip";
        return "application/octet-stream";
    }

    /** Copia o arquivo temporário para a pasta pública certa. Retorna o endereço (para compartilhar). */
    static Uri publish(Context c, File src, String name) throws Exception {
        String mime = mime(name);
        boolean img = mime.startsWith("image/"), vid = mime.startsWith("video/");
        String dir = img ? Environment.DIRECTORY_PICTURES : vid ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_DOWNLOADS;
        ContentResolver cr = c.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        Uri coll;
        if (Build.VERSION.SDK_INT >= 29) {
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, dir + "/DarkMonia");
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            coll = img ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : vid ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            Uri u = cr.insert(coll, v);
            if (u == null) throw new IllegalStateException("sem acesso à galeria");
            OutputStream out = cr.openOutputStream(u);
            copy(new FileInputStream(src), out);
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(u, done, null, null);
            return u;
        }
        File pub = new File(Environment.getExternalStoragePublicDirectory(dir), "DarkMonia");
        pub.mkdirs();
        File dst = new File(pub, name);
        copy(new FileInputStream(src), new java.io.FileOutputStream(dst));
        v.put(MediaStore.MediaColumns.DATA, dst.getAbsolutePath());
        coll = img ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : vid ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                : MediaStore.Files.getContentUri("external");
        Uri u = null;
        try { u = cr.insert(coll, v); } catch (Exception ignored) { }
        return u;
    }

    static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        out.close();
    }

    static void share(Context c, Uri u, String mime) {
        if (u == null) { Ui.toast(c, "Salvo na pasta DarkMonia"); return; }
        Intent it = new Intent(Intent.ACTION_SEND);
        it.setType(mime);
        it.putExtra(Intent.EXTRA_STREAM, u);
        it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { c.startActivity(Intent.createChooser(it, "Compartilhar")); } catch (Exception e) { Ui.toast(c, "Nenhum app para compartilhar"); }
    }

    static String where(String name) {
        String m = mime(name);
        return m.startsWith("image/") ? "Galeria › Pictures/DarkMonia" : m.startsWith("video/") ? "Galeria › Movies/DarkMonia" : "Downloads/DarkMonia";
    }
}
