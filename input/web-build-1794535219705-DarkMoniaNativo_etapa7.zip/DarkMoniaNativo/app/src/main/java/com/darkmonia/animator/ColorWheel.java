package com.darkmonia.animator;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ComposeShader;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.view.MotionEvent;
import android.view.View;

/** Roda de cores: anel de matiz + quadrado de saturação/brilho (como no Krita e no Procreate). */
class ColorWheel extends View {
    interface L { void onColor(int c, boolean done); }

    L listener;
    private final float[] hsv = {0, 0, 0};
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG), sq = new Paint(Paint.ANTI_ALIAS_FLAG), mark = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();
    private float cx, cy, ro, ri;
    private int drag;

    ColorWheel(Context c) {
        super(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        ring.setStyle(Paint.Style.STROKE);
        mark.setStyle(Paint.Style.STROKE);
        mark.setStrokeWidth(Ui.dp(c, 2.5f));
    }

    void set(int c) {
        Color.colorToHSV(c, hsv);
        invalidate();
    }

    int get() { return Color.HSVToColor(hsv); }

    @Override protected void onMeasure(int ws, int hs) {
        int w = MeasureSpec.getSize(ws);
        int s = Math.min(w, Ui.dp(getContext(), 300));
        setMeasuredDimension(w, s);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        cx = w / 2f; cy = h / 2f;
        ro = Math.min(w, h) / 2f - Ui.dp(getContext(), 4);
        float th = Ui.dp(getContext(), 26);
        ri = ro - th;
        ring.setStrokeWidth(th);
        ring.setShader(new SweepGradient(cx, cy, new int[]{0xFFFF0000, 0xFFFFFF00, 0xFF00FF00, 0xFF00FFFF, 0xFF0000FF, 0xFFFF00FF, 0xFFFF0000}, null));
        float half = ri * 0.66f;
        box.set(cx - half, cy - half, cx + half, cy + half);
    }

    @Override protected void onDraw(Canvas c) {
        c.drawCircle(cx, cy, (ro + ri) / 2, ring);
        int pure = Color.HSVToColor(new float[]{hsv[0], 1, 1});
        Shader s1 = new LinearGradient(box.left, 0, box.right, 0, 0xFFFFFFFF, pure, Shader.TileMode.CLAMP);
        Shader s2 = new LinearGradient(0, box.top, 0, box.bottom, 0x00000000, 0xFF000000, Shader.TileMode.CLAMP);
        sq.setShader(new ComposeShader(s1, s2, PorterDuff.Mode.SRC_OVER));
        c.drawRoundRect(box, Ui.dp(getContext(), 6), Ui.dp(getContext(), 6), sq);
        double a = Math.toRadians(hsv[0]);
        float r = (ro + ri) / 2;
        float hx = cx + (float) Math.cos(a) * r, hy = cy + (float) Math.sin(a) * r;
        mark.setColor(0xFFFFFFFF);
        c.drawCircle(hx, hy, Ui.dp(getContext(), 11), mark);
        float px = box.left + hsv[1] * box.width(), py = box.top + (1 - hsv[2]) * box.height();
        mark.setColor(hsv[2] > .5f ? 0xFF111111 : 0xFFFFFFFF);
        c.drawCircle(px, py, Ui.dp(getContext(), 9), mark);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            float d = (float) Math.hypot(x - cx, y - cy);
            drag = d > ri - Ui.dp(getContext(), 8) ? 1 : 2;
            getParent().requestDisallowInterceptTouchEvent(true);
        }
        if (drag == 1) {
            float deg = (float) Math.toDegrees(Math.atan2(y - cy, x - cx));
            hsv[0] = (deg + 360) % 360;
        } else if (drag == 2) {
            hsv[1] = Ui.clampf((x - box.left) / box.width(), 0, 1);
            hsv[2] = Ui.clampf(1 - (y - box.top) / box.height(), 0, 1);
        }
        boolean done = a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL;
        if (listener != null) listener.onColor(get(), done);
        if (done) drag = 0;
        invalidate();
        return true;
    }
}
