package com.darkmonia.animator;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;

/** Preferências do app (guardadas no aparelho). */
final class Prefs {
    private static SharedPreferences sp;

    static SharedPreferences get(Context c) {
        if (sp == null) sp = c.getApplicationContext().getSharedPreferences("darkmonia", Context.MODE_PRIVATE);
        return sp;
    }

    static void init(Context c) {
        Ui.ACC = get(c).getInt("accent", 0xFFE5476B);
    }

    static boolean on(Context c, String k, boolean def) { return get(c).getBoolean(k, def); }

    static void set(Context c, String k, boolean v) { get(c).edit().putBoolean(k, v).apply(); }

    static int num(Context c, String k, int def) { return get(c).getInt(k, def); }

    static void put(Context c, String k, int v) { get(c).edit().putInt(k, v).apply(); }

    static ArrayList<Integer> colors(Context c, String k, int[] def) {
        ArrayList<Integer> out = new ArrayList<>();
        String s = get(c).getString(k, null);
        if (s == null) { for (int v : def) out.add(v); return out; }
        for (String p : s.split(",")) {
            if (p.isEmpty()) continue;
            try { out.add((int) Long.parseLong(p, 16)); } catch (Exception ignored) { }
        }
        return out;
    }

    static void colors(Context c, String k, ArrayList<Integer> v) {
        StringBuilder b = new StringBuilder();
        for (int x : v) { if (b.length() > 0) b.append(','); b.append(Integer.toHexString(x)); }
        get(c).edit().putString(k, b.toString()).apply();
    }

    static ArrayList<String> list(Context c, String k, String def) {
        ArrayList<String> out = new ArrayList<>();
        String s = get(c).getString(k, def);
        if (s != null) for (String p : s.split(",")) if (!p.isEmpty()) out.add(p);
        return out;
    }

    static void list(Context c, String k, ArrayList<String> v) {
        get(c).edit().putString(k, String.join(",", v)).apply();
    }
}
