package com.darkmonia.animator;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Folha que sobe de baixo, igual às do app 5.0 (fundo escuro, cantos arredondados). */
class Sheet extends Dialog {
    final LinearLayout body;
    final TextView title;
    private final Context ctx;

    /** ScrollView com altura máxima. */
    static class MaxScroll extends ScrollView {
        int max;
        MaxScroll(Context c, int max) { super(c); this.max = max; }
        @Override protected void onMeasure(int w, int h) {
            super.onMeasure(w, MeasureSpec.makeMeasureSpec(max, MeasureSpec.AT_MOST));
        }
    }

    Sheet(Context c, String t) {
        super(c);
        ctx = c;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        int pad = Ui.dp(c, 18);
        LinearLayout box = Ui.col(c);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Ui.PANEL);
        float r = Ui.dp(c, 22);
        g.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        g.setStroke(Ui.dp(c, 1), Ui.LINE);
        box.setBackground(g);
        View grip = new View(c);
        grip.setBackground(Ui.bg(0xFF3A3F57, Ui.dp(c, 3)));
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(Ui.dp(c, 40), Ui.dp(c, 5));
        glp.gravity = Gravity.CENTER_HORIZONTAL;
        glp.topMargin = Ui.dp(c, 10);
        box.addView(grip, glp);
        int maxH = (int) (c.getResources().getDisplayMetrics().heightPixels * 0.86f);
        MaxScroll sc = new MaxScroll(c, maxH);
        sc.setFillViewport(false);
        body = Ui.col(c);
        body.setPadding(pad, Ui.dp(c, 12), pad, pad + Ui.dp(c, 8));
        title = Ui.text(c, t == null ? "" : t, 20, Ui.FG, true);
        title.setPadding(0, 0, 0, Ui.dp(c, 14));
        if (t != null) body.addView(title);
        sc.addView(body);
        box.addView(sc);
        Ui.padInsets(box, false);
        setContentView(box);
        Window w = getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0));
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.BOTTOM);
            w.setDimAmount(0.62f);
            w.setWindowAnimations(android.R.style.Animation_InputMethod);
            int maxW = Ui.dp(c, 560);
            if (c.getResources().getDisplayMetrics().widthPixels > maxW)
                w.setLayout(maxW, WindowManager.LayoutParams.WRAP_CONTENT);
        }
        setCanceledOnTouchOutside(true);
    }

    /** Título de seção pequeno (CAIXA ALTA, cinza). */
    TextView section(String s) {
        TextView t = Ui.text(ctx, s.toUpperCase(), 11, Ui.MUTE, true);
        t.setLetterSpacing(0.08f);
        t.setPadding(0, Ui.dp(ctx, 16), 0, Ui.dp(ctx, 8));
        body.addView(t);
        return t;
    }

    void add(View v) { body.addView(v); }

    void add(View v, LinearLayout.LayoutParams lp) { body.addView(v, lp); }
}
