package com.darkmonia.animator;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

import java.util.Random;

/** Fundo da tela inicial: brilhos suaves e partículas que sobem devagar (como na 5.0). */
class HomeBg extends View {
    private final Paint glow1 = new Paint(), glow2 = new Paint(), dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float[] px, py, pr, pv, pt;
    private boolean[] pk;
    private int w, h;
    boolean running = true;

    HomeBg(Context c) { super(c); }

    @Override protected void onSizeChanged(int nw, int nh, int ow, int oh) {
        w = nw; h = nh;
        if (w == 0 || h == 0) return;
        glow1.setShader(new RadialGradient(w * 1.05f, -h * 0.08f, Math.max(w, h) * 0.75f,
                new int[]{(Ui.ACC & 0x00FFFFFF) | 0x42000000, 0x00000000}, null, Shader.TileMode.CLAMP));
        glow2.setShader(new RadialGradient(-w * 0.15f, h * 0.28f, Math.max(w, h) * 0.55f,
                new int[]{0x2B5C70FF, 0x00000000}, null, Shader.TileMode.CLAMP));
        int n = Math.min(90, w * h / 26000 + 20);
        Random r = new Random(7);
        px = new float[n]; py = new float[n]; pr = new float[n]; pv = new float[n]; pt = new float[n]; pk = new boolean[n];
        float d = getResources().getDisplayMetrics().density;
        for (int i = 0; i < n; i++) {
            px[i] = r.nextFloat() * w; py[i] = r.nextFloat() * h;
            pr[i] = (r.nextFloat() * 1.3f + 0.4f) * d; pv[i] = (r.nextFloat() * 0.25f + 0.06f) * d;
            pt[i] = r.nextFloat() * 6.28f; pk[i] = r.nextFloat() < 0.16f;
        }
    }

    void refreshAccent() { onSizeChanged(w, h, w, h); invalidate(); }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(Ui.HOME_BG);
        if (w == 0) return;
        c.drawRect(0, 0, w, h, glow1);
        c.drawRect(0, 0, w, h, glow2);
        if (px == null) return;
        for (int i = 0; i < px.length; i++) {
            py[i] -= pv[i];
            pt[i] += 0.02f;
            px[i] += (float) Math.sin(pt[i]) * 0.15f;
            if (py[i] < -4) { py[i] = h + 4; px[i] = (float) (Math.random() * w); }
            float al = 0.25f + 0.45f * Math.abs((float) Math.sin(pt[i] * 0.8f));
            int a = Math.round(al * (pk[i] ? 255 : 200) * 0.6f);
            dot.setColor(pk[i] ? (a << 24) | 0xE5476B : (a << 24) | 0xBED0FF);
            c.drawCircle(px[i], py[i], pr[i], dot);
        }
        if (running) postInvalidateOnAnimation();
    }
}
