package com.darkmonia.animator;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

/** Catálogo de pincéis e o motor que transforma o traço em "carimbos" (dabs). */
final class Brushes {
    static final int ROUND = 0, GRAIN = 1, SOFT = 2, STAMP = 3, SMUDGE = 4, BLUR = 5, PIXEL = 6;

    static final class B {
        final String id, name, hint, cat;
        final int kind;
        float spacing = 0.12f, alpha = 1f, flow = 1f, minW = 0.18f, taper = 0f, grain = 0f, reach = 1f;
        boolean pressure = true;
        int fixed = 0, defSize = 12;
        B(String id, String name, String hint, String cat, int kind) {
            this.id = id; this.name = name; this.hint = hint; this.cat = cat; this.kind = kind;
        }
        B sp(float v) { spacing = v; return this; }
        B al(float v) { alpha = v; return this; }
        B fl(float v) { flow = v; return this; }
        B mw(float v) { minW = v; return this; }
        B tp(float v) { taper = v; return this; }
        B gr(float v) { grain = v; return this; }
        B rc(float v) { reach = v; return this; }
        B np() { pressure = false; return this; }
        B fx(int c) { fixed = c; return this; }
        B ds(int s) { defSize = s; return this; }
        boolean direct() { return kind == SMUDGE || kind == BLUR; }
    }

    static final ArrayList<B> ALL = new ArrayList<>();
    static final ArrayList<String> CATS = new ArrayList<>();
    private static final HashMap<String, B> BY = new HashMap<>();

    private static B add(B b) {
        ALL.add(b);
        BY.put(b.id, b);
        if (!CATS.contains(b.cat)) CATS.add(b.cat);
        return b;
    }

    static {
        String c = "Lineart";
        add(new B("gpen", "G-Pen", "pressão e variação de espessura", c, ROUND).tp(1.6f).ds(10));
        add(new B("monoline", "Monoline", "espessura constante", c, ROUND).np().ds(8));
        add(new B("taper", "Taper Pen", "pontas afiladas para anime", c, ROUND).tp(5f).mw(.08f).ds(10));
        c = "Esboço";
        add(new B("pencil", "Lápis", "grafite para rascunho", c, GRAIN).gr(.5f).al(.92f).mw(.4f).sp(.1f).ds(6));
        add(new B("sketch", "Esboço azul", "traço solto para construção", c, GRAIN).gr(.35f).al(.7f).fx(0xFF4D8DFF).mw(.45f).ds(6));
        c = "Pincéis artísticos";
        add(new B("watercolor", "Aquarela", "transparente e com bordas suaves", c, STAMP).sp(.14f).al(.6f).mw(.5f).ds(40));
        add(new B("marker", "Marcador translúcido", "camadas de cor semitransparentes", c, ROUND).al(.5f).np().ds(24));
        add(new B("airbrush", "Aerógrafo", "névoa suave para luz e sombra", c, SOFT).fl(.07f).sp(.08f).mw(.6f).ds(80));
        add(new B("charcoal", "Carvão seco", "textura áspera de grafite", c, GRAIN).gr(.82f).mw(.5f).ds(18));
        add(new B("chalk", "Giz", "grão fosco para concept art", c, GRAIN).gr(.9f).al(.9f).mw(.6f).ds(26));
        add(new B("pastel", "Pastel", "pigmento macio em camadas", c, GRAIN).gr(.65f).al(.8f).mw(.6f).ds(30));
        add(new B("drybrush", "Pincel seco", "textura de tinta com cerdas", c, STAMP).sp(.06f).mw(.6f).ds(30));
        add(new B("inkwash", "Lavagem de tinta", "manchas orgânicas controladas", c, STAMP).sp(.18f).al(.45f).mw(.6f).ds(50));
        add(new B("blur", "Desfocar", "suaviza o que já está desenhado", c, BLUR).sp(.25f).np().ds(40));
        add(new B("smudge", "Borrar / dedo", "arrasta e mistura as cores", c, SMUDGE).sp(.12f).np().ds(36));
        c = "Ferramentas novas";
        add(new B("pixel", "Pixel art", "blocos quadrados, sem suavização", c, PIXEL).np().ds(1));
        add(new B("rainbow", "Arco-íris", "cores em ciclo pelo traço", c, ROUND).ds(16));
        add(new B("dashed", "Linha tracejada", "guias e contornos pontilhados", c, ROUND).np().ds(6));
        add(new B("hatch", "Hachura", "sombreamento com linhas", c, STAMP).sp(.35f).rc(1.2f).ds(30));
        add(new B("neon", "Neon duplo", "brilho com núcleo claro", c, STAMP).sp(.1f).rc(2.2f).ds(14));
        add(new B("spray", "Spray de partículas", "pulveriza pontos de tinta", c, STAMP).sp(.25f).np().ds(50));
        add(new B("calligraphy", "Ponta caligráfica", "largo e fino conforme o ângulo", c, STAMP).sp(.04f).ds(20));
        add(new B("ribbon", "Fita dupla", "duas linhas paralelas", c, STAMP).sp(.05f).ds(20));
        add(new B("stipple", "Pontilhismo", "textura feita de pontos", c, STAMP).sp(.5f).np().ds(30));
        c = "Anime e efeitos";
        add(new B("glow", "Brilho", "neon na cor escolhida", c, STAMP).sp(.1f).rc(1.8f).ds(18));
        add(new B("hair", "Cabelo anime", "mechas contínuas", c, STAMP).sp(.05f).tp(4f).mw(.1f).ds(30));
        add(new B("fur", "Pelos", "pelagem", c, STAMP).sp(.12f).rc(1.3f).ds(24));
        add(new B("chain", "Corrente", "elos", c, STAMP).sp(.9f).np().ds(22));
        add(new B("impact", "Impacto", "rachaduras e pedras", c, STAMP).sp(1.2f).rc(1.6f).np().ds(40));
        add(new B("speed", "Velocidade", "linhas de movimento", c, STAMP).sp(.35f).rc(3f).np().ds(30));
        add(new B("spark", "Brilhos", "estrelas", c, STAMP).sp(1.1f).rc(1.2f).np().ds(26));
        add(new B("aura", "Aura", "energia", c, STAMP).sp(.25f).rc(2.2f).np().ds(40));
        add(new B("fire", "Fogo", "chamas", c, STAMP).sp(.35f).rc(2.4f).np().ds(40));
        add(new B("blood", "Sangue", "gotas e respingos", c, STAMP).sp(.45f).rc(2f).ds(16));
        add(new B("cloud", "Nuvem", "estilo anime", c, STAMP).sp(.45f).rc(1.2f).np().ds(60));
        c = "Natureza";
        add(new B("turf", "Grama contínua", "textura natural", c, STAMP).sp(.12f).rc(2.2f).np().ds(26));
        add(new B("soil", "Terra contínua", "solo texturizado", c, STAMP).sp(.2f).np().ds(34));
        add(new B("comb", "Grama fluida", "segue o traço", c, STAMP).sp(.15f).rc(2f).np().ds(24));
        add(new B("grass", "Grama para cima", "tufos", c, STAMP).sp(.5f).rc(2.6f).np().ds(26));
        add(new B("grassdn", "Grama para baixo", "grama pendurada", c, STAMP).sp(.5f).rc(2.6f).np().ds(26));
        add(new B("rock", "Rocha", "pedras", c, STAMP).sp(.7f).rc(1.2f).np().ds(36));
        add(new B("earth", "Terra", "base de ilha flutuante", c, STAMP).sp(.3f).rc(1.4f).np().ds(46));
        c = "Árvore e água";
        add(new B("trunk", "Tronco", "casca contínua", c, STAMP).sp(.08f).ds(46));
        add(new B("branch", "Galho", "afina no fim", c, ROUND).tp(8f).mw(.05f).ds(18));
        add(new B("leaf", "Folhas", "folhas soltas", c, STAMP).sp(.6f).rc(1.6f).np().ds(26));
        add(new B("canopy", "Copa", "massa de folhas", c, STAMP).sp(.3f).rc(1.4f).np().ds(60));
        add(new B("pine", "Pinheiro", "camadas", c, STAMP).sp(.25f).rc(1.6f).np().ds(50));
        add(new B("water", "Água", "textura contínua", c, STAMP).sp(.15f).rc(1.2f).np().ds(40));
        add(new B("wave", "Ondas", "cristas", c, STAMP).sp(.7f).rc(1.3f).np().ds(34));
        c = "Cenários de cinema";
        add(new B("stonework", "Pedra talhada", "faces e fissuras de rocha", c, STAMP).sp(.55f).rc(1.2f).np().ds(44));
        add(new B("cliff", "Penhasco", "paredes rochosas em planos", c, STAMP).sp(.3f).rc(1.3f).np().ds(56));
        add(new B("islandmesa", "Ilha mesa", "topo plano com bordas", c, STAMP).sp(.25f).rc(1.6f).np().ds(56));
        add(new B("islandstrata", "Estratos de terra", "camadas geológicas", c, STAMP).sp(.2f).rc(1.2f).np().ds(50));
        add(new B("islandmoss", "Musgo", "vegetação agarrada à terra", c, STAMP).sp(.25f).rc(1.2f).np().ds(34));
        add(new B("islandcrystal", "Cristais", "formações facetadas", c, STAMP).sp(.9f).rc(2f).np().ds(34));
        add(new B("islanddebris", "Detritos", "pedrinhas e fragmentos", c, STAMP).sp(.5f).rc(1.6f).np().ds(30));
        add(new B("sand", "Areia", "grãos finos", c, STAMP).sp(.25f).np().ds(40));
        add(new B("snow", "Neve", "flocos e acúmulo", c, STAMP).sp(.4f).np().fx(0xFFFFFFFF).ds(40));
        add(new B("dust", "Poeira", "nuvem de partículas", c, STAMP).sp(.3f).rc(1.3f).np().ds(50));
        add(new B("smoke", "Fumaça", "volumes suaves", c, STAMP).sp(.25f).rc(1.5f).np().ds(70));
        add(new B("starfield", "Campo estelar", "estrelas variadas", c, STAMP).sp(.6f).rc(1.2f).np().ds(60));
        add(new B("foliage", "Folhagem", "folhas para cenário", c, STAMP).sp(.35f).rc(1.5f).np().ds(40));
        add(new B("bamboo", "Bambu", "caules segmentados", c, STAMP).sp(.06f).np().ds(20));
        add(new B("roots", "Raízes", "raízes ramificadas", c, STAMP).sp(.1f).rc(2.5f).tp(4f).mw(.15f).ds(16));
        add(new B("magma", "Magma", "fendas incandescentes", c, STAMP).sp(.25f).rc(1.2f).np().ds(40));
    }

    static B get(String id) {
        B b = BY.get(id);
        return b == null ? BY.get("gpen") : b;
    }

    static final B ERASE_ROUND = new B("e_round", "Borracha dura", "", "", ROUND).ds(30);
    static final B ERASE_SOFT = new B("e_soft", "Borracha suave", "", "", SOFT).fl(.12f).sp(.08f).mw(.6f).ds(60);
    static final B ERASE_GRAIN = new B("e_grain", "Borracha lápis", "", "", GRAIN).gr(.6f).ds(20);

    /* ------------------------------------------------------------ */

    private static Bitmap softTex;
    private static final HashMap<String, Bitmap> grainTex = new HashMap<>();

    static Bitmap soft() {
        if (softTex == null) {
            int s = 128;
            softTex = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setShader(new RadialGradient(s / 2f, s / 2f, s / 2f, new int[]{0xFFFFFFFF, 0x99FFFFFF, 0x33FFFFFF, 0x00FFFFFF},
                    new float[]{0f, .35f, .7f, 1f}, Shader.TileMode.CLAMP));
            new Canvas(softTex).drawCircle(s / 2f, s / 2f, s / 2f, p);
        }
        return softTex;
    }

    /** Textura de papel (canal alfa) — fica presa à tela, como grafite em papel de verdade. */
    static Bitmap grain(float strength) {
        String k = String.valueOf(Math.round(strength * 20));
        Bitmap b = grainTex.get(k);
        if (b != null) return b;
        int s = 128;
        Random r = new Random(77);
        int[] px = new int[s * s];
        float[] n = new float[s * s];
        for (int i = 0; i < n.length; i++) n[i] = r.nextFloat();
        for (int pass = 0; pass < 1; pass++) {
            float[] m = new float[n.length];
            for (int y = 0; y < s; y++)
                for (int x = 0; x < s; x++) {
                    float a = n[y * s + x] * 2;
                    a += n[y * s + (x + 1) % s] + n[((y + 1) % s) * s + x];
                    m[y * s + x] = a / 4f;
                }
            for (int i = 0; i < n.length; i++) n[i] = n[i] * .55f + m[i] * .45f;
        }
        for (int i = 0; i < px.length; i++) {
            float v = n[i];
            float t = strength * .7f;
            float a = v < t ? 0 : Math.min(1f, (v - t) / Math.max(.05f, 1f - t) * 1.6f);
            px[i] = ((int) (a * 255) << 24) | 0xFFFFFF;
        }
        Bitmap argb = Bitmap.createBitmap(px, s, s, Bitmap.Config.ARGB_8888);
        b = argb.extractAlpha();
        argb.recycle();
        grainTex.put(k, b);
        return b;
    }

    static int shade(int c, float dv) {
        float[] h = new float[3];
        Color.colorToHSV(c, h);
        h[2] = Ui.clampf(h[2] + dv, 0, 1);
        if (dv > 0) h[1] = Ui.clampf(h[1] - dv * .35f, 0, 1);
        return Color.HSVToColor(Color.alpha(c), h);
    }

    static int hueShift(int c, float dh, float ds) {
        float[] h = new float[3];
        Color.colorToHSV(c, h);
        h[0] = (h[0] + dh + 360) % 360;
        h[1] = Ui.clampf(h[1] + ds, 0, 1);
        return Color.HSVToColor(Color.alpha(c), h);
    }

    static int withA(int c, float a) {
        return (Math.round(Ui.clampf(a, 0, 1) * 255) << 24) | (c & 0xFFFFFF);
    }

    /* ------------------------------------------------------------ */

    /** Recebe pontos do dedo e desenha os carimbos no canvas do traço. */
    static final class Engine {
        interface Sink { void dab(float x, float y, float w, float ang, float pr); }

        B b;
        int color;
        float size;
        Canvas c;
        Matrix[] sym = new Matrix[]{new Matrix()};
        Sink sink;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint tex = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        final Path path = new Path();
        final RectF r = new RectF();
        final ArrayList<float[]> pts = new ArrayList<>();
        float dist, total = -1, nextDab, minX, minY, maxX, maxY;
        /** afinar início e fim (0..1), valem para qualquer pincel */
        float tin, tout;
        private float ax, ay, ap, bx, by, bp, lastAng;
        private int n;
        private long seed;
        Random rnd = new Random();

        void begin(B brush, int col, float sz, Canvas cv, long sd) {
            b = brush;
            color = b.fixed != 0 ? b.fixed : col;
            size = Math.max(1, sz);
            c = cv;
            seed = sd;
            rnd = new Random(seed);
            pts.clear();
            dist = 0;
            nextDab = 0;
            n = 0;
            total = -1;
            minX = minY = Float.MAX_VALUE;
            maxX = maxY = -Float.MAX_VALUE;
            p.setShader(null);
            p.setColorFilter(null);
            p.setStyle(Paint.Style.FILL);
            p.setAntiAlias(b.kind != PIXEL);
            p.setColor(color);
            if (b.kind == GRAIN) {
                p.setShader(new BitmapShader(grain(b.grain), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
            }
            tex.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
        }

        void to(float x, float y, float pr) {
            pts.add(new float[]{x, y, pr});
            if (n == 0) {
                ax = bx = x; ay = by = y; ap = bp = pr;
                n = 1;
                place(x, y, pr, 0, true);
                return;
            }
            // curva suave: de meio(a,b) até meio(b,novo) com controle em b
            float m1x = (ax + bx) / 2, m1y = (ay + by) / 2, m1p = (ap + bp) / 2;
            float m2x = (bx + x) / 2, m2y = (by + y) / 2, m2p = (bp + pr) / 2;
            if (n == 1) { m1x = ax; m1y = ay; m1p = ap; }
            quad(m1x, m1y, m1p, bx, by, m2x, m2y, m2p);
            ax = bx; ay = by; ap = bp;
            bx = x; by = y; bp = pr;
            n++;
        }

        void end() {
            if (n >= 2) {
                float m1x = (ax + bx) / 2, m1y = (ay + by) / 2, m1p = (ap + bp) / 2;
                quad(m1x, m1y, m1p, (m1x + bx) / 2, (m1y + by) / 2, bx, by, bp);
            }
        }

        /** Redesenha tudo sabendo o comprimento total (para afinar a ponta final). */
        void redraw(float totalLen) {
            ArrayList<float[]> copy = new ArrayList<>(pts);
            B bb = b;
            int col = color;
            begin(bb, col, size, c, seed);
            color = col;
            total = totalLen;
            for (float[] q : copy) to(q[0], q[1], q[2]);
            end();
        }

        private void quad(float x0, float y0, float p0, float cx, float cy, float x1, float y1, float p1) {
            float len = (float) (Math.hypot(cx - x0, cy - y0) + Math.hypot(x1 - cx, y1 - cy));
            if (len < 0.01f) return;
            float ang = (float) Math.atan2(y1 - y0, x1 - x0);
            if (len > 0.5f) lastAng = ang;
            int steps = Math.max(1, (int) Math.ceil(len / .5f));
            float px = x0, py = y0;
            for (int i = 1; i <= steps; i++) {
                float t = i / (float) steps, u = 1 - t;
                float x = u * u * x0 + 2 * u * t * cx + t * t * x1;
                float y = u * u * y0 + 2 * u * t * cy + t * t * y1;
                float d = (float) Math.hypot(x - px, y - py);
                dist += d;
                px = x; py = y;
                if (dist >= nextDab) place(x, y, p0 + (p1 - p0) * t, lastAng, false);
            }
        }

        float width(float pr) {
            float w = size;
            if (b.pressure) w *= b.minW + (1 - b.minW) * Ui.clampf(pr, 0, 1);
            float tlS = b.taper > 0 ? Math.max(8, size * b.taper) : 0, tlE = tlS;
            if (tin > 0) tlS = Math.max(tlS, Math.max(8, size * 14 * tin));
            if (tout > 0) tlE = Math.max(tlE, Math.max(8, size * 14 * tout));
            float f = 1f;
            if (tlS > 0) f = Math.min(f, 0.1f + 0.9f * dist / tlS);
            if (total > 0 && tlE > 0) f = Math.min(f, 0.1f + 0.9f * Math.max(0, total - dist) / tlE);
            w *= f;
            return Math.max(0.6f, w);
        }

        private void place(float x, float y, float pr, float ang, boolean first) {
            float w = width(pr);
            float step = b.kind == PIXEL ? Math.max(1, size) * .5f : Math.max(0.5f, w * b.spacing);
            if (b.kind == STAMP && b.spacing > .3f) step = Math.max(step, size * b.spacing);
            nextDab = dist + step;
            float e = w * b.reach * 1.6f + 4;
            minX = Math.min(minX, x - e); minY = Math.min(minY, y - e);
            maxX = Math.max(maxX, x + e); maxY = Math.max(maxY, y + e);
            if (sink != null) { sink.dab(x, y, w, ang, pr); return; }
            for (Matrix m : sym) {
                c.save();
                c.concat(m);
                dab(x, y, w, ang, pr);
                c.restore();
            }
        }

        /* ---------------- carimbos ---------------- */

        private float rf() { return rnd.nextFloat(); }
        private float rs() { return rnd.nextFloat() * 2 - 1; }

        private void circle(float x, float y, float r, int col) {
            p.setColor(col);
            c.drawCircle(x, y, Math.max(.4f, r), p);
        }

        private void softDab(float x, float y, float r, int col, float a) {
            tex.setColorFilter(new PorterDuffColorFilter(col, PorterDuff.Mode.SRC_IN));
            tex.setAlpha(Math.round(Ui.clampf(a, 0, 1) * 255));
            r = Math.max(1, r);
            this.r.set(x - r, y - r, x + r, y + r);
            c.drawBitmap(soft(), null, this.r, tex);
        }

        private void blade(float x, float y, float len, float wid, float ang, int col) {
            float bend = rs() * .35f;
            float ex = x + (float) Math.cos(ang) * len, ey = y + (float) Math.sin(ang) * len;
            float nx = -(float) Math.sin(ang), ny = (float) Math.cos(ang);
            float mx = (x + ex) / 2 + nx * len * bend, my = (y + ey) / 2 + ny * len * bend;
            path.reset();
            path.moveTo(x - nx * wid, y - ny * wid);
            path.quadTo(mx, my, ex, ey);
            path.quadTo(mx, my, x + nx * wid, y + ny * wid);
            path.close();
            p.setColor(col);
            c.drawPath(path, p);
        }

        private void leafShape(float x, float y, float len, float wid, float ang, int col) {
            float ex = x + (float) Math.cos(ang) * len, ey = y + (float) Math.sin(ang) * len;
            float nx = -(float) Math.sin(ang) * wid, ny = (float) Math.cos(ang) * wid;
            float mx = (x + ex) / 2, my = (y + ey) / 2;
            path.reset();
            path.moveTo(x, y);
            path.quadTo(mx + nx, my + ny, ex, ey);
            path.quadTo(mx - nx, my - ny, x, y);
            path.close();
            p.setColor(col);
            c.drawPath(path, p);
        }

        private void poly(float x, float y, float r, int sides, float rot, int col, float jag) {
            path.reset();
            for (int i = 0; i < sides; i++) {
                double a = rot + i * Math.PI * 2 / sides;
                float rr = r * (1 - jag * rf());
                float px = x + (float) Math.cos(a) * rr, py = y + (float) Math.sin(a) * rr;
                if (i == 0) path.moveTo(px, py); else path.lineTo(px, py);
            }
            path.close();
            p.setColor(col);
            c.drawPath(path, p);
        }

        private void star4(float x, float y, float r, int col) {
            path.reset();
            float k = r * .22f;
            path.moveTo(x, y - r);
            path.quadTo(x + k, y - k, x + r, y);
            path.quadTo(x + k, y + k, x, y + r);
            path.quadTo(x - k, y + k, x - r, y);
            path.quadTo(x - k, y - k, x, y - r);
            path.close();
            p.setColor(col);
            c.drawPath(path, p);
        }

        private void line(float x0, float y0, float x1, float y1, float w, int col) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(.6f, w));
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(col);
            c.drawLine(x0, y0, x1, y1, p);
            p.setStyle(Paint.Style.FILL);
        }

        private void dab(float x, float y, float w, float ang, float pr) {
            float r = w / 2;
            int col = color;
            float nx = -(float) Math.sin(ang), ny = (float) Math.cos(ang);
            switch (b.id) {
                case "pixel": {
                    float s = Math.max(1, Math.round(size));
                    float qx = (float) Math.floor(x / s) * s, qy = (float) Math.floor(y / s) * s;
                    p.setColor(col);
                    c.drawRect(qx, qy, qx + s, qy + s, p);
                    return;
                }
                case "rainbow":
                    circle(x, y, r, Color.HSVToColor(new float[]{(dist * .6f) % 360, .85f, 1f}));
                    return;
                case "dashed": {
                    float per = Math.max(6, size * 3.2f);
                    if ((dist % per) < per * .55f) circle(x, y, r, col);
                    return;
                }
                case "watercolor": {
                    float rr = r * (.85f + rf() * .3f);
                    p.setShader(new RadialGradient(x, y, rr, new int[]{withA(col, .16f), withA(col, .22f), withA(col, .5f), withA(col, 0)},
                            new float[]{0, .6f, .92f, 1}, Shader.TileMode.CLAMP));
                    c.drawCircle(x, y, rr, p);
                    p.setShader(null);
                    return;
                }
                case "inkwash":
                    for (int i = 0; i < 3; i++) softDab(x + rs() * r * .3f, y + rs() * r * .3f, r * (.6f + rf() * .5f), col, .22f);
                    return;
                case "drybrush": {
                    int k = Math.max(4, (int) (w / 2.2f));
                    for (int i = 0; i < k; i++) {
                        float o = (i / (float) (k - 1) - .5f) * w;
                        Random br = new Random(seed * 31 + i);
                        float gap = br.nextFloat();
                        if (gap < .18f && rf() < .8f) continue;
                        circle(x + nx * o, y + ny * o, Math.max(.6f, w / k * .55f), withA(col, .55f + br.nextFloat() * .45f));
                    }
                    return;
                }
                case "hatch": {
                    float d = r * 1.1f, a = (float) Math.PI / 4;
                    float dx = (float) Math.cos(a) * d, dy = (float) Math.sin(a) * d;
                    line(x - dx, y + dy, x + dx, y - dy, Math.max(1, size * .06f), col);
                    return;
                }
                case "neon":
                    softDab(x, y, w * 1.6f, col, .1f);
                    circle(x, y, r * .7f, col);
                    circle(x, y, r * .32f, 0xFFFFFFFF);
                    return;
                case "glow":
                    softDab(x, y, w * 1.4f, col, .12f);
                    circle(x, y, r * .5f, shade(col, .25f));
                    return;
                case "spray": {
                    int k = (int) (6 + w * .35f);
                    for (int i = 0; i < k; i++) {
                        double a = rf() * Math.PI * 2;
                        float d = (float) Math.sqrt(rf()) * r;
                        circle(x + (float) Math.cos(a) * d, y + (float) Math.sin(a) * d, Math.max(.6f, size * .025f), col);
                    }
                    return;
                }
                case "stipple": {
                    int k = 3 + (int) (w * .08f);
                    for (int i = 0; i < k; i++) {
                        double a = rf() * Math.PI * 2;
                        float d = (float) Math.sqrt(rf()) * r;
                        circle(x + (float) Math.cos(a) * d, y + (float) Math.sin(a) * d, Math.max(.8f, size * .05f * (.6f + rf())), col);
                    }
                    return;
                }
                case "calligraphy": {
                    c.save();
                    c.rotate(-40, x, y);
                    p.setColor(col);
                    this.r.set(x - r, y - r * .18f, x + r, y + r * .18f);
                    c.drawOval(this.r, p);
                    c.restore();
                    return;
                }
                case "ribbon": {
                    float o = r * .9f;
                    circle(x + nx * o, y + ny * o, Math.max(.7f, w * .07f), col);
                    circle(x - nx * o, y - ny * o, Math.max(.7f, w * .07f), col);
                    return;
                }
                case "hair": {
                    int k = 5;
                    for (int i = 0; i < k; i++) {
                        float o = (i / (float) (k - 1) - .5f) * w;
                        circle(x + nx * o, y + ny * o, Math.max(.5f, w * .045f * (1 - Math.abs(o) / w)), i % 2 == 0 ? col : shade(col, .15f));
                    }
                    return;
                }
                case "fur":
                    for (int i = 0; i < 3; i++) {
                        float a = ang + (float) Math.PI / 2 * (rf() < .5f ? 1 : -1) + rs() * .5f;
                        blade(x + rs() * r * .4f, y + rs() * r * .4f, w * (.5f + rf() * .7f), Math.max(.6f, w * .05f), a, shade(col, rs() * .12f));
                    }
                    return;
                case "chain": {
                    c.save();
                    c.rotate((float) Math.toDegrees(ang), x, y);
                    boolean flat = ((int) (dist / Math.max(1, size * b.spacing))) % 2 == 0;
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(Math.max(1.2f, size * .16f));
                    p.setColor(col);
                    if (flat) this.r.set(x - r * .9f, y - r * .45f, x + r * .9f, y + r * .45f);
                    else this.r.set(x - r * .9f, y - r * .12f, x + r * .9f, y + r * .12f);
                    c.drawRoundRect(this.r, r * .45f, r * .45f, p);
                    p.setStyle(Paint.Style.FILL);
                    c.restore();
                    return;
                }
                case "impact": {
                    int k = 5 + rnd.nextInt(4);
                    for (int i = 0; i < k; i++) {
                        float a = (float) (i * Math.PI * 2 / k + rs() * .4f);
                        float lx = x, ly = y, len = w * (.6f + rf() * .9f);
                        int seg = 3;
                        for (int s = 0; s < seg; s++) {
                            float ex = lx + (float) Math.cos(a + rs() * .5f) * len / seg, ey = ly + (float) Math.sin(a + rs() * .5f) * len / seg;
                            line(lx, ly, ex, ey, Math.max(1, size * .07f * (1 - s / (float) seg)), col);
                            lx = ex; ly = ey;
                        }
                    }
                    for (int i = 0; i < 4; i++) poly(x + rs() * w, y + rs() * w, w * (.06f + rf() * .1f), 5, rf() * 6, shade(col, rs() * .2f), .4f);
                    return;
                }
                case "speed": {
                    float len = w * (1.5f + rf() * 3);
                    float o = rs() * r;
                    float sx = x + nx * o, sy = y + ny * o;
                    float ex = sx - (float) Math.cos(ang) * len, ey = sy - (float) Math.sin(ang) * len;
                    blade(sx, sy, len, Math.max(.6f, size * .04f), ang + (float) Math.PI, col);
                    return;
                }
                case "spark":
                    star4(x + rs() * r * .4f, y + rs() * r * .4f, r * (.5f + rf() * .7f), col);
                    if (rf() < .5f) star4(x + rs() * w, y + rs() * w, r * .25f, shade(col, .3f));
                    return;
                case "aura":
                    softDab(x, y, w * (1.2f + rf() * .6f), col, .1f);
                    if (rf() < .4f) blade(x + rs() * r, y + rs() * r, w * (.8f + rf()), Math.max(.6f, w * .05f), -(float) Math.PI / 2 + rs() * .3f, shade(col, .3f));
                    return;
                case "fire": {
                    int[] fc = {0xFFFF3B1F, 0xFFFF7A1A, 0xFFFFB21F, 0xFFFFE27A};
                    for (int i = 0; i < 4; i++) {
                        float s = w * (1 - i * .22f) * (.7f + rf() * .5f);
                        float fx = x + rs() * r * .3f, fy = y + rs() * r * .2f;
                        path.reset();
                        path.moveTo(fx - s * .45f, fy);
                        path.quadTo(fx - s * .5f, fy - s * .6f, fx + rs() * s * .2f, fy - s * (1.2f + rf() * .6f));
                        path.quadTo(fx + s * .5f, fy - s * .6f, fx + s * .45f, fy);
                        path.quadTo(fx, fy + s * .35f, fx - s * .45f, fy);
                        path.close();
                        p.setColor(withA(fc[i], .85f));
                        c.drawPath(path, p);
                    }
                    return;
                }
                case "blood":
                    circle(x, y, r * (.7f + rf() * .4f), col);
                    if (rf() < .35f) {
                        float dx = rs() * w * 1.5f, dy = rs() * w * 1.5f;
                        circle(x + dx, y + dy, r * (.15f + rf() * .25f), col);
                    }
                    if (rf() < .2f) {
                        float dl = w * (1 + rf() * 1.5f);
                        line(x, y, x, y + dl, r * .35f, col);
                        circle(x, y + dl, r * .32f, col);
                    }
                    return;
                case "cloud": {
                    for (int i = 0; i < 4; i++) {
                        float cx = x + rs() * w * .6f, cy = y + rs() * w * .3f, cr = r * (.5f + rf() * .6f);
                        circle(cx, cy + cr * .18f, cr, shade(col, -.12f));
                        circle(cx - cr * .08f, cy, cr * .94f, col);
                        circle(cx - cr * .3f, cy - cr * .32f, cr * .3f, shade(col, .15f));
                    }
                    return;
                }
                case "turf":
                case "comb":
                case "grass":
                case "grassdn": {
                    int k = b.id.equals("turf") ? 4 : b.id.equals("comb") ? 3 : 7;
                    for (int i = 0; i < k; i++) {
                        float a;
                        if (b.id.equals("comb")) a = ang + (float) Math.PI + rs() * .25f;
                        else if (b.id.equals("grassdn")) a = (float) Math.PI / 2 + rs() * .45f;
                        else a = -(float) Math.PI / 2 + rs() * .45f;
                        float bx = x + rs() * r * (b.id.equals("grass") || b.id.equals("grassdn") ? 1 : .6f), by = y + rs() * r * .2f;
                        blade(bx, by, w * (.8f + rf() * 1.3f), Math.max(.6f, w * .07f), a, shade(col, rs() * .18f));
                    }
                    return;
                }
                case "soil":
                case "earth":
                case "sand": {
                    int k = b.id.equals("sand") ? 18 : 10;
                    for (int i = 0; i < k; i++) {
                        double a = rf() * Math.PI * 2;
                        float d = (float) Math.sqrt(rf()) * r;
                        float rr = b.id.equals("sand") ? Math.max(.5f, size * .02f) : Math.max(.7f, size * (.03f + rf() * .05f));
                        circle(x + (float) Math.cos(a) * d, y + (float) Math.sin(a) * d, rr, shade(col, rs() * .2f));
                    }
                    if (b.id.equals("earth")) {
                        softDab(x, y, r, shade(col, -.15f), .35f);
                        if (rf() < .3f) poly(x + rs() * r, y + rs() * r, r * .25f, 6, rf() * 6, shade(col, -.25f), .35f);
                    }
                    return;
                }
                case "rock":
                case "islanddebris": {
                    float rr = r * (b.id.equals("rock") ? (.6f + rf() * .5f) : (.15f + rf() * .25f));
                    float rx = x + rs() * r * .3f, ry = y + rs() * r * .3f;
                    float rot = rf() * 6;
                    poly(rx, ry + rr * .12f, rr, 7, rot, shade(col, -.25f), .3f);
                    poly(rx, ry, rr * .9f, 7, rot, col, .3f);
                    poly(rx - rr * .2f, ry - rr * .25f, rr * .45f, 5, rot, shade(col, .18f), .2f);
                    if (b.id.equals("islanddebris")) for (int i = 0; i < 3; i++) circle(x + rs() * w, y + rs() * w, rr * .25f, shade(col, rs() * .2f));
                    return;
                }
                case "trunk": {
                    circle(x, y, r, col);
                    int k = 4;
                    for (int i = 0; i < k; i++) {
                        float o = (i / (float) (k - 1) - .5f) * w * .8f;
                        Random br = new Random(seed * 17 + i);
                        if (((int) (dist / (size * .5f + br.nextInt(9))) + i) % 3 == 0) continue;
                        circle(x + nx * o, y + ny * o, Math.max(.6f, w * .045f), shade(col, -.3f));
                    }
                    circle(x + nx * r * .55f, y + ny * r * .55f, r * .18f, shade(col, .12f));
                    return;
                }
                case "leaf":
                case "foliage":
                case "canopy":
                case "islandmoss": {
                    int k = b.id.equals("canopy") ? 6 : b.id.equals("leaf") ? 2 : 4;
                    float ls = b.id.equals("islandmoss") ? .35f : b.id.equals("canopy") ? .55f : .9f;
                    if (b.id.equals("canopy")) softDab(x, y, r * 1.1f, shade(col, -.25f), .5f);
                    for (int i = 0; i < k; i++) {
                        float a = rf() * 6.28f;
                        leafShape(x + rs() * r, y + rs() * r, w * ls * (.6f + rf() * .6f), w * ls * .22f, a, shade(col, rs() * .2f));
                    }
                    return;
                }
                case "pine": {
                    float s = w * (.8f + rf() * .4f);
                    path.reset();
                    path.moveTo(x, y - s);
                    path.lineTo(x + s * .7f, y + s * .3f);
                    path.lineTo(x - s * .7f, y + s * .3f);
                    path.close();
                    p.setColor(shade(col, rs() * .12f));
                    c.drawPath(path, p);
                    return;
                }
                case "water": {
                    softDab(x, y, r, col, .25f);
                    if (rf() < .5f) {
                        float lx = x + rs() * r, ly = y + rs() * r * .5f, len = w * (.3f + rf() * .5f);
                        line(lx - len / 2, ly, lx + len / 2, ly, Math.max(.8f, size * .05f), shade(col, .35f));
                    }
                    return;
                }
                case "wave": {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(Math.max(1.2f, size * .12f));
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setColor(col);
                    this.r.set(x - r, y - r * .6f, x + r, y + r * .6f);
                    c.drawArc(this.r, 180, 200, false, p);
                    p.setColor(shade(col, .4f));
                    this.r.set(x - r * .3f, y - r * .5f, x + r * .5f, y + r * .1f);
                    c.drawArc(this.r, 200, 160, false, p);
                    p.setStyle(Paint.Style.FILL);
                    return;
                }
                case "stonework":
                case "cliff": {
                    boolean cl = b.id.equals("cliff");
                    float rw = cl ? w * .6f : r, rh = cl ? w * 1.2f : r * .7f;
                    float rx = x + rs() * r * .2f, ry = y + rs() * r * .2f;
                    p.setColor(shade(col, rs() * .15f));
                    path.reset();
                    path.moveTo(rx - rw, ry - rh * (.8f + rf() * .3f));
                    path.lineTo(rx + rw * (.8f + rf() * .3f), ry - rh);
                    path.lineTo(rx + rw, ry + rh * (.8f + rf() * .3f));
                    path.lineTo(rx - rw * (.8f + rf() * .3f), ry + rh);
                    path.close();
                    c.drawPath(path, p);
                    line(rx - rw * .9f, ry - rh * .7f, rx + rw * .2f, ry + rs() * rh * .5f, Math.max(.8f, size * .03f), shade(col, -.35f));
                    line(rx - rw, ry - rh, rx + rw, ry - rh, Math.max(.8f, size * .04f), shade(col, .25f));
                    return;
                }
                case "islandmesa": {
                    p.setColor(shade(col, -.2f));
                    path.reset();
                    path.moveTo(x - r, y);
                    path.lineTo(x + r, y);
                    path.lineTo(x + r * .4f, y + w * (.9f + rf() * .7f));
                    path.lineTo(x - r * .5f, y + w * (.5f + rf() * .5f));
                    path.close();
                    c.drawPath(path, p);
                    this.r.set(x - r * 1.05f, y - r * .18f, x + r * 1.05f, y + r * .18f);
                    p.setColor(hueShift(col, 50, 0));
                    c.drawOval(this.r, p);
                    return;
                }
                case "islandstrata": {
                    int k = 4;
                    for (int i = 0; i < k; i++) {
                        float yy = y + (i - k / 2f) * w / k;
                        p.setColor(shade(col, (i % 2 == 0 ? -.12f : .08f) + rs() * .05f));
                        c.drawRect(x - r * .7f, yy, x + r * .7f, yy + w / k * .9f, p);
                    }
                    return;
                }
                case "islandcrystal": {
                    float s = w * (.6f + rf() * .7f);
                    float a = -(float) Math.PI / 2 + rs() * .5f;
                    float tx = x + (float) Math.cos(a) * s, ty = y + (float) Math.sin(a) * s;
                    float qx = -(float) Math.sin(a) * s * .25f, qy = (float) Math.cos(a) * s * .25f;
                    path.reset();
                    path.moveTo(x + qx, y + qy);
                    path.lineTo(tx, ty);
                    path.lineTo(x - qx, y - qy);
                    path.close();
                    p.setColor(col);
                    c.drawPath(path, p);
                    path.reset();
                    path.moveTo(x, y);
                    path.lineTo(tx, ty);
                    path.lineTo(x - qx, y - qy);
                    path.close();
                    p.setColor(shade(col, .3f));
                    c.drawPath(path, p);
                    return;
                }
                case "snow":
                    for (int i = 0; i < 6; i++) circle(x + rs() * r, y + rs() * r, Math.max(.7f, size * (.02f + rf() * .05f)), withA(col, .6f + rf() * .4f));
                    if (rf() < .2f) star4(x + rs() * r, y + rs() * r, size * .1f, col);
                    return;
                case "dust":
                    for (int i = 0; i < 8; i++) circle(x + rs() * w, y + rs() * w, Math.max(.6f, size * (.01f + rf() * .03f)), withA(col, .2f + rf() * .5f));
                    softDab(x, y, r, col, .04f);
                    return;
                case "smoke":
                    softDab(x + rs() * r * .3f, y + rs() * r * .3f, w * (.8f + rf() * .6f), shade(col, rs() * .1f), .07f);
                    return;
                case "starfield": {
                    for (int i = 0; i < 4; i++) {
                        float sx = x + rs() * w, sy = y + rs() * w;
                        float s = size * (.01f + rf() * rf() * .08f);
                        if (s > size * .05f) { softDab(sx, sy, s * 4, col, .25f); star4(sx, sy, s * 2.5f, col); }
                        else circle(sx, sy, Math.max(.5f, s), withA(col, .5f + rf() * .5f));
                    }
                    return;
                }
                case "bamboo": {
                    circle(x, y, r, col);
                    circle(x + nx * r * .45f, y + ny * r * .45f, r * .2f, shade(col, .2f));
                    float seg = Math.max(12, size * 3.5f);
                    if ((dist % seg) < Math.max(1, w * b.spacing) * 1.2f) line(x - nx * r * 1.1f, y - ny * r * 1.1f, x + nx * r * 1.1f, y + ny * r * 1.1f, Math.max(1, size * .14f), shade(col, -.3f));
                    return;
                }
                case "roots": {
                    circle(x, y, r, col);
                    if (rf() < .06f) {
                        float a = ang + (rf() < .5f ? 1 : -1) * (.6f + rf() * .6f);
                        float lx = x, ly = y, wd = r;
                        for (int s = 0; s < 6; s++) {
                            float ex = lx + (float) Math.cos(a) * w * .5f, ey = ly + (float) Math.sin(a) * w * .5f;
                            line(lx, ly, ex, ey, wd, col);
                            lx = ex; ly = ey; wd *= .7f; a += rs() * .4f;
                        }
                    }
                    return;
                }
                case "magma": {
                    circle(x, y, r, shade(col, -.45f));
                    if (rf() < .55f) {
                        float a = rf() * 6.28f, len = w * (.3f + rf() * .4f);
                        float sx = x + rs() * r * .5f, sy = y + rs() * r * .5f;
                        float ex = sx + (float) Math.cos(a) * len, ey = sy + (float) Math.sin(a) * len;
                        softDab((sx + ex) / 2, (sy + ey) / 2, len * .6f, 0xFFFF6A00, .25f);
                        line(sx, sy, ex, ey, Math.max(1, size * .06f), 0xFFFFB13B);
                    }
                    return;
                }
                default:
                    break;
            }
            switch (b.kind) {
                case SOFT:
                    softDab(x, y, r, col, b.flow);
                    return;
                case GRAIN:
                    p.setColor(col);
                    c.drawCircle(x, y, r, p);
                    return;
                default:
                    if (b.id.equals("monoline") || b.id.equals("e_round") || b.id.equals("marker")) {
                        p.setColor(col);
                        c.drawCircle(x, y, r, p);
                        return;
                    }
                    circle(x, y, r, col);
            }
        }
    }
}
