package com.darkmonia.animator;

import android.graphics.Rect;

/** Balde de tinta e varinha mágica: preenchimento por área com tolerância, fechar falhas e expandir. */
final class Fill {
    /** Pixels "parecidos" com a cor do ponto inicial (tolerância 0..255 por canal). */
    static boolean[] similar(int[] px, int target, int tol) {
        boolean[] s = new boolean[px.length];
        int ta = target >>> 24, tr = (target >> 16) & 255, tg = (target >> 8) & 255, tb = target & 255;
        boolean clear = ta < 8;
        for (int i = 0; i < px.length; i++) {
            int c = px[i], a = c >>> 24;
            if (clear) { s[i] = a <= tol + 8; continue; }
            if (Math.abs(a - ta) > tol) continue;
            if (a < 8) { s[i] = ta <= tol + 8; continue; }
            s[i] = Math.abs(((c >> 16) & 255) - tr) <= tol && Math.abs(((c >> 8) & 255) - tg) <= tol && Math.abs((c & 255) - tb) <= tol;
        }
        return s;
    }

    /** Preenchimento por linhas a partir de (sx,sy) dentro das áreas permitidas. */
    static boolean[] flood(boolean[] ok, int w, int h, int sx, int sy, Rect bounds) {
        boolean[] out = new boolean[ok.length];
        int start = sy * w + sx;
        if (!ok[start]) return out;
        int[] stack = new int[Math.max(1024, w * 4)];
        int sp = 0;
        stack[sp++] = start;
        int minX = sx, maxX = sx, minY = sy, maxY = sy;
        while (sp > 0) {
            int i = stack[--sp];
            if (out[i] || !ok[i]) continue;
            int y = i / w, x = i % w;
            int l = x, r = x;
            while (l > 0 && ok[y * w + l - 1] && !out[y * w + l - 1]) l--;
            while (r < w - 1 && ok[y * w + r + 1] && !out[y * w + r + 1]) r++;
            for (int k = l; k <= r; k++) out[y * w + k] = true;
            minX = Math.min(minX, l); maxX = Math.max(maxX, r);
            minY = Math.min(minY, y); maxY = Math.max(maxY, y);
            for (int ny = y - 1; ny <= y + 1; ny += 2) {
                if (ny < 0 || ny >= h) continue;
                boolean run = false;
                for (int k = l; k <= r; k++) {
                    int j = ny * w + k;
                    boolean can = ok[j] && !out[j];
                    if (can && !run) {
                        if (sp >= stack.length) {
                            int[] ns = new int[stack.length * 2];
                            System.arraycopy(stack, 0, ns, 0, sp);
                            stack = ns;
                        }
                        stack[sp++] = j;
                        run = true;
                    } else if (!can) run = false;
                }
            }
        }
        if (bounds != null) bounds.set(minX, minY, maxX + 1, maxY + 1);
        return out;
    }

    /** Engorda a área marcada em r pixels (quadrado separável). */
    static boolean[] dilate(boolean[] in, int w, int h, int r) {
        if (r <= 0) return in;
        boolean[] t = new boolean[in.length], out = new boolean[in.length];
        for (int y = 0; y < h; y++) {
            int row = y * w, last = -100000;
            for (int x = 0; x < w; x++) if (in[row + x]) last = x;
                else if (x - last <= r) t[row + x] = true;
            last = 100000;
            for (int x = w - 1; x >= 0; x--) {
                if (in[row + x]) { last = x; t[row + x] = true; }
                else if (last - x <= r) t[row + x] = true;
            }
        }
        for (int x = 0; x < w; x++) {
            int last = -100000;
            for (int y = 0; y < h; y++) if (t[y * w + x]) last = y;
                else if (y - last <= r) out[y * w + x] = true;
            last = 100000;
            for (int y = h - 1; y >= 0; y--) {
                if (t[y * w + x]) { last = y; out[y * w + x] = true; }
                else if (last - y <= r) out[y * w + x] = true;
            }
        }
        return out;
    }

    /**
     * Área a pintar: tolerância, "fechar falhas" (ignora buracos de até gap px nas linhas)
     * e "expandir" (passa por baixo do contorno serrilhado).
     */
    static boolean[] region(int[] px, int w, int h, int sx, int sy, int tol, int gap, int expand, Rect bounds) {
        boolean[] ok = similar(px, px[sy * w + sx], tol);
        boolean[] area;
        if (gap > 0) {
            boolean[] wall = new boolean[ok.length];
            for (int i = 0; i < ok.length; i++) wall[i] = !ok[i];
            boolean[] thick = dilate(wall, w, h, gap);
            boolean[] ok2 = new boolean[ok.length];
            for (int i = 0; i < ok.length; i++) ok2[i] = !thick[i];
            if (!ok2[sy * w + sx]) ok2 = ok;
            area = flood(ok2, w, h, sx, sy, null);
            // devolve a borda que a falha "comeu", só onde a cor era parecida
            boolean[] grown = dilate(area, w, h, gap + 1);
            for (int i = 0; i < area.length; i++) area[i] = grown[i] && ok[i];
            area = flood(area, w, h, sx, sy, null);
        } else area = flood(ok, w, h, sx, sy, null);
        if (expand > 0) area = dilate(area, w, h, expand);
        if (bounds != null) {
            int minX = w, minY = h, maxX = -1, maxY = -1;
            for (int y = 0; y < h; y++) {
                int row = y * w;
                for (int x = 0; x < w; x++) if (area[row + x]) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    maxY = y;
                }
            }
            if (maxX < 0) bounds.setEmpty(); else bounds.set(minX, minY, maxX + 1, maxY + 1);
        }
        return area;
    }
}
