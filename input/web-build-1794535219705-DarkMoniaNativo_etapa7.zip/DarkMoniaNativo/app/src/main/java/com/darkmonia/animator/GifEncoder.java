package com.darkmonia.animator;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;

/** GIF animado: paleta por quadro (corte pela mediana), pontilhado Floyd–Steinberg e LZW. */
final class GifEncoder {
    private final OutputStream out;
    private final int w, h;
    private boolean first = true;
    boolean dither = true;

    GifEncoder(OutputStream out, int w, int h, int loops) throws IOException {
        this.out = out;
        this.w = w;
        this.h = h;
        out.write("GIF89a".getBytes("US-ASCII"));
        short16(w);
        short16(h);
        out.write(0x70); // sem paleta global, 8 bits
        out.write(0);
        out.write(0);
        // repetir para sempre
        out.write(new byte[]{0x21, (byte) 0xFF, 0x0B});
        out.write("NETSCAPE2.0".getBytes("US-ASCII"));
        out.write(new byte[]{3, 1});
        short16(loops);
        out.write(0);
    }

    private void short16(int v) throws IOException {
        out.write(v & 255);
        out.write((v >> 8) & 255);
    }

    /** px: ARGB w×h; delay em centésimos de segundo. */
    void addFrame(int[] px, int delayCs) throws IOException {
        boolean transparent = false;
        for (int c : px) if ((c >>> 24) < 128) { transparent = true; break; }
        int maxColors = transparent ? 255 : 256;
        int[] pal = palette(px, maxColors);
        int[] lut = new int[32768];
        Arrays.fill(lut, -1);
        byte[] idx = new byte[w * h];
        int off = transparent ? 1 : 0;
        int[] er = null, eg = null, eb = null, nr = null, ng = null, nb = null;
        if (dither) { er = new int[w + 2]; eg = new int[w + 2]; eb = new int[w + 2]; nr = new int[w + 2]; ng = new int[w + 2]; nb = new int[w + 2]; }
        for (int y = 0; y < h; y++) {
            if (dither) {
                int[] t;
                t = er; er = nr; nr = t; Arrays.fill(nr, 0);
                t = eg; eg = ng; ng = t; Arrays.fill(ng, 0);
                t = eb; eb = nb; nb = t; Arrays.fill(nb, 0);
            }
            for (int x = 0; x < w; x++) {
                int c = px[y * w + x];
                if (transparent && (c >>> 24) < 128) { idx[y * w + x] = 0; continue; }
                int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                if (dither) {
                    r = clamp(r + er[x + 1] / 16); g = clamp(g + eg[x + 1] / 16); b = clamp(b + eb[x + 1] / 16);
                }
                int key = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
                int pi = lut[key];
                if (pi < 0) { pi = nearest(pal, r, g, b); lut[key] = pi; }
                idx[y * w + x] = (byte) (pi + off);
                if (dither) {
                    int pc = pal[pi];
                    int dr = r - ((pc >> 16) & 255), dg = g - ((pc >> 8) & 255), db = b - (pc & 255);
                    er[x + 2] += dr * 7; eg[x + 2] += dg * 7; eb[x + 2] += db * 7;
                    nr[x] += dr * 3; ng[x] += dg * 3; nb[x] += db * 3;
                    nr[x + 1] += dr * 5; ng[x + 1] += dg * 5; nb[x + 1] += db * 5;
                    nr[x + 2] += dr; ng[x + 2] += dg; nb[x + 2] += db;
                }
            }
        }
        // controle gráfico
        out.write(new byte[]{0x21, (byte) 0xF9, 4});
        out.write((transparent ? 2 << 2 : 1 << 2) | (transparent ? 1 : 0));
        short16(Math.max(2, delayCs));
        out.write(0);
        out.write(0);
        // descritor da imagem com paleta local de 256 cores
        out.write(0x2C);
        short16(0);
        short16(0);
        short16(w);
        short16(h);
        out.write(0x87);
        byte[] table = new byte[768];
        for (int i = 0; i < 256; i++) {
            int pi = i - off;
            int c = pi >= 0 && pi < pal.length ? pal[pi] : 0;
            table[i * 3] = (byte) ((c >> 16) & 255);
            table[i * 3 + 1] = (byte) ((c >> 8) & 255);
            table[i * 3 + 2] = (byte) (c & 255);
        }
        out.write(table);
        lzw(idx);
        first = false;
    }

    void finish() throws IOException {
        out.write(0x3B);
        out.flush();
    }

    private static int clamp(int v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

    private static int nearest(int[] pal, int r, int g, int b) {
        int best = 0, bd = Integer.MAX_VALUE;
        for (int i = 0; i < pal.length; i++) {
            int c = pal[i];
            int dr = ((c >> 16) & 255) - r, dg = ((c >> 8) & 255) - g, db = (c & 255) - b;
            int d = dr * dr * 3 + dg * dg * 4 + db * db * 2;
            if (d < bd) { bd = d; best = i; }
        }
        return best;
    }

    /* ---------------- corte pela mediana ---------------- */

    private static int[] palette(int[] px, int max) {
        int[] hist = new int[32768];
        for (int c : px) {
            if ((c >>> 24) < 128) continue;
            hist[(((c >> 16) & 255) >> 3) << 10 | (((c >> 8) & 255) >> 3) << 5 | ((c & 255) >> 3)]++;
        }
        int used = 0;
        for (int v : hist) if (v > 0) used++;
        int[] bins = new int[used];
        int k = 0;
        for (int i = 0; i < hist.length; i++) if (hist[i] > 0) bins[k++] = i;
        if (used <= max) {
            int[] pal = new int[Math.max(1, used)];
            for (int i = 0; i < used; i++) pal[i] = binColor(bins[i]);
            return pal;
        }
        ArrayList<int[]> boxes = new ArrayList<>();
        boxes.add(new int[]{0, used});
        while (boxes.size() < max) {
            int bi = -1;
            long bestScore = -1;
            int bestCh = 0;
            for (int i = 0; i < boxes.size(); i++) {
                int[] bx = boxes.get(i);
                if (bx[1] - bx[0] < 2) continue;
                int[] range = range(bins, bx[0], bx[1]);
                int ch = 0, rng = range[0];
                if (range[1] > rng) { ch = 1; rng = range[1]; }
                if (range[2] > rng) { ch = 2; rng = range[2]; }
                long pop = 0;
                for (int j = bx[0]; j < bx[1]; j++) pop += hist[bins[j]];
                long score = (long) rng * (long) Math.sqrt(pop + 1);
                if (score > bestScore) { bestScore = score; bi = i; bestCh = ch; }
            }
            if (bi < 0) break;
            int[] bx = boxes.remove(bi);
            final int ch = bestCh;
            Integer[] sub = new Integer[bx[1] - bx[0]];
            for (int j = 0; j < sub.length; j++) sub[j] = bins[bx[0] + j];
            Arrays.sort(sub, (a, b) -> Integer.compare(chan(a, ch), chan(b, ch)));
            long total = 0;
            for (Integer v : sub) total += hist[v];
            long acc = 0;
            int cut = 1;
            for (int j = 0; j < sub.length - 1; j++) {
                acc += hist[sub[j]];
                if (acc >= total / 2) { cut = j + 1; break; }
                cut = j + 1;
            }
            for (int j = 0; j < sub.length; j++) bins[bx[0] + j] = sub[j];
            boxes.add(new int[]{bx[0], bx[0] + cut});
            boxes.add(new int[]{bx[0] + cut, bx[1]});
        }
        int[] pal = new int[boxes.size()];
        for (int i = 0; i < boxes.size(); i++) {
            int[] bx = boxes.get(i);
            long r = 0, g = 0, b = 0, n = 0;
            for (int j = bx[0]; j < bx[1]; j++) {
                int c = binColor(bins[j]);
                int wt = hist[bins[j]];
                r += (long) ((c >> 16) & 255) * wt; g += (long) ((c >> 8) & 255) * wt; b += (long) (c & 255) * wt; n += wt;
            }
            n = Math.max(1, n);
            pal[i] = (int) ((r / n) << 16 | (g / n) << 8 | (b / n));
        }
        return pal;
    }

    private static int chan(int bin, int ch) { return ch == 0 ? (bin >> 10) & 31 : ch == 1 ? (bin >> 5) & 31 : bin & 31; }

    private static int[] range(int[] bins, int a, int b) {
        int[] mn = {31, 31, 31}, mx = {0, 0, 0};
        for (int j = a; j < b; j++)
            for (int ch = 0; ch < 3; ch++) {
                int v = chan(bins[j], ch);
                if (v < mn[ch]) mn[ch] = v;
                if (v > mx[ch]) mx[ch] = v;
            }
        return new int[]{(mx[0] - mn[0]) * 3, (mx[1] - mn[1]) * 4, (mx[2] - mn[2]) * 2};
    }

    private static int binColor(int bin) {
        int r = ((bin >> 10) & 31) * 255 / 31, g = ((bin >> 5) & 31) * 255 / 31, b = (bin & 31) * 255 / 31;
        return (r << 16) | (g << 8) | b;
    }

    /* ---------------- LZW (variante do "compress") ---------------- */

    private static final int HSIZE = 5003, MAXBITS = 12, MAXMAX = 1 << MAXBITS;
    private final int[] htab = new int[HSIZE], codetab = new int[HSIZE];
    private int nBits, maxcode, freeEnt, clearCode, eofCode, curAccum, curBits;
    private boolean clearFlg;
    private final byte[] accum = new byte[256];
    private int aCount;

    private void lzw(byte[] pixels) throws IOException {
        int initBits = 8;
        out.write(initBits);
        int gInit = initBits + 1;
        nBits = gInit;
        maxcode = (1 << nBits) - 1;
        clearCode = 1 << initBits;
        eofCode = clearCode + 1;
        freeEnt = clearCode + 2;
        clearFlg = false;
        curAccum = 0;
        curBits = 0;
        aCount = 0;
        Arrays.fill(htab, -1);
        int hshift = 0;
        for (int f = HSIZE; f < 65536; f *= 2) hshift++;
        hshift = 8 - hshift;
        int ent = pixels[0] & 255;
        output(clearCode, gInit);
        for (int p = 1; p < pixels.length; p++) {
            int c = pixels[p] & 255;
            int fcode = (c << MAXBITS) + ent;
            int i = (c << hshift) ^ ent;
            if (htab[i] == fcode) { ent = codetab[i]; continue; }
            if (htab[i] >= 0) {
                int disp = HSIZE - i;
                if (i == 0) disp = 1;
                boolean found = false;
                do {
                    if ((i -= disp) < 0) i += HSIZE;
                    if (htab[i] == fcode) { ent = codetab[i]; found = true; break; }
                } while (htab[i] >= 0);
                if (found) continue;
            }
            output(ent, gInit);
            ent = c;
            if (freeEnt < MAXMAX) {
                codetab[i] = freeEnt++;
                htab[i] = fcode;
            } else {
                Arrays.fill(htab, -1);
                freeEnt = clearCode + 2;
                clearFlg = true;
                output(clearCode, gInit);
            }
        }
        output(ent, gInit);
        output(eofCode, gInit);
        out.write(0);
    }

    private void output(int code, int gInit) throws IOException {
        curAccum &= (1 << curBits) - 1;
        if (curBits > 0) curAccum |= (code << curBits);
        else curAccum = code;
        curBits += nBits;
        while (curBits >= 8) {
            charOut((byte) (curAccum & 0xff));
            curAccum >>= 8;
            curBits -= 8;
        }
        if (freeEnt > maxcode || clearFlg) {
            if (clearFlg) {
                nBits = gInit;
                maxcode = (1 << nBits) - 1;
                clearFlg = false;
            } else {
                nBits++;
                maxcode = nBits == MAXBITS ? MAXMAX : (1 << nBits) - 1;
            }
        }
        if (code == eofCode) {
            while (curBits > 0) {
                charOut((byte) (curAccum & 0xff));
                curAccum >>= 8;
                curBits -= 8;
            }
            flushChar();
        }
    }

    private void charOut(byte c) throws IOException {
        accum[aCount++] = c;
        if (aCount >= 254) flushChar();
    }

    private void flushChar() throws IOException {
        if (aCount > 0) {
            out.write(aCount);
            out.write(accum, 0, aCount);
            aCount = 0;
        }
    }
}
