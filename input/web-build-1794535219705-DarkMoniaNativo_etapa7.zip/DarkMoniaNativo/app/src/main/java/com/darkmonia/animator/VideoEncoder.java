package com.darkmonia.animator;

import android.graphics.Bitmap;
import android.media.Image;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;

/** Vídeo MP4 (H.264) feito quadro a quadro com o codificador do próprio aparelho. */
final class VideoEncoder {
    private final MediaCodec codec;
    private final MediaMuxer mux;
    private final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
    private final int w, h, fps;
    private int track = -1;
    private boolean started;
    private long frame;
    private final int[] argb;

    /** Medidas múltiplas de 16 funcionam em praticamente todos os aparelhos. */
    static int[] size(int w, int h, int maxSide) {
        float k = Math.min(1f, maxSide / (float) Math.max(w, h));
        int ww = Math.max(16, Math.round(w * k / 16f) * 16), hh = Math.max(16, Math.round(h * k / 16f) * 16);
        return new int[]{ww, hh};
    }

    VideoEncoder(File out, int w, int h, int fps) throws IOException {
        this.w = w;
        this.h = h;
        this.fps = Math.max(1, fps);
        argb = new int[w * h];
        MediaFormat f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h);
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
        int br = (int) Math.min(20_000_000L, Math.max(2_000_000L, (long) w * h * this.fps / 3));
        f.setInteger(MediaFormat.KEY_BIT_RATE, br);
        f.setInteger(MediaFormat.KEY_FRAME_RATE, this.fps);
        f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
        codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        codec.start();
        mux = new MediaMuxer(out.getPath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
    }

    /** Adiciona um quadro (o bitmap precisa ter exatamente w×h). */
    void add(Bitmap b) {
        b.getPixels(argb, 0, w, 0, 0, w, h);
        int idx;
        int guard = 0;
        while ((idx = codec.dequeueInputBuffer(10_000)) < 0) {
            drain(false);
            if (++guard > 1000) throw new IllegalStateException("codificador travou");
        }
        Image img = codec.getInputImage(idx);
        if (img == null) throw new IllegalStateException("sem imagem de entrada");
        fill(img);
        long pts = frame * 1_000_000L / fps;
        codec.queueInputBuffer(idx, 0, w * h * 3 / 2, pts, 0);
        frame++;
        drain(false);
    }

    private void fill(Image img) {
        Image.Plane[] pl = img.getPlanes();
        ByteBuffer yb = pl[0].getBuffer(), ub = pl[1].getBuffer(), vb = pl[2].getBuffer();
        int yRow = pl[0].getRowStride(), yPix = pl[0].getPixelStride();
        int uRow = pl[1].getRowStride(), uPix = pl[1].getPixelStride();
        int vRow = pl[2].getRowStride(), vPix = pl[2].getPixelStride();
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int c = argb[row + x];
                int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                int Y = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
                yb.put(y * yRow + x * yPix, (byte) Y);
            }
        }
        for (int y = 0; y < h / 2; y++) {
            for (int x = 0; x < w / 2; x++) {
                int r = 0, g = 0, b = 0;
                for (int dy = 0; dy < 2; dy++)
                    for (int dx = 0; dx < 2; dx++) {
                        int c = argb[(y * 2 + dy) * w + x * 2 + dx];
                        r += (c >> 16) & 255; g += (c >> 8) & 255; b += c & 255;
                    }
                r >>= 2; g >>= 2; b >>= 2;
                int U = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                int V = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;
                ub.put(y * uRow + x * uPix, (byte) U);
                vb.put(y * vRow + x * vPix, (byte) V);
            }
        }
    }

    private void drain(boolean end) {
        int waits = 0;
        while (true) {
            int o = codec.dequeueOutputBuffer(info, end ? 10_000 : 0);
            if (o == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!end || ++waits > 300) return;
                continue;
            }
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = mux.addTrack(codec.getOutputFormat());
                mux.start();
                started = true;
                continue;
            }
            if (o < 0) continue;
            ByteBuffer data = codec.getOutputBuffer(o);
            if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
            if (info.size > 0 && started && data != null) {
                data.position(info.offset);
                data.limit(info.offset + info.size);
                mux.writeSampleData(track, data, info);
            }
            codec.releaseOutputBuffer(o, false);
            if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return;
        }
    }

    void finish() {
        try {
            int idx;
            int guard = 0;
            while ((idx = codec.dequeueInputBuffer(10_000)) < 0) { drain(false); if (++guard > 1000) break; }
            if (idx >= 0) codec.queueInputBuffer(idx, 0, 0, frame * 1_000_000L / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            drain(true);
        } finally {
            try { codec.stop(); } catch (Exception ignored) { }
            codec.release();
            try { if (started) mux.stop(); } catch (Exception ignored) { }
            mux.release();
        }
    }

    void abort() {
        try { codec.stop(); } catch (Exception ignored) { }
        try { codec.release(); } catch (Exception ignored) { }
        try { mux.release(); } catch (Exception ignored) { }
    }
}
