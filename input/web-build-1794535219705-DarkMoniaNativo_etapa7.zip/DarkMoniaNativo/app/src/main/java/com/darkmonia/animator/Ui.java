package com.darkmonia.animator;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

/** Ajudantes de interface: cores do tema 5.0, ícones vetoriais, botões e textos. */
final class Ui {
    static final int BG = 0xFF0F1017;
    static final int HOME_BG = 0xFF0A0B12;
    static final int PANEL = 0xFF171925;
    static final int PANEL2 = 0xFF222537;
    static final int CARD = 0xFF131624;
    static final int BTN = 0xFF222537;
    static final int LINE = 0xFF2D3148;
    static final int FG = 0xFFECEEF7;
    static final int MUTE = 0xFF9AA0B8;
    static final int DIM = 0xFF858CA8;
    static final int VIOLET = 0xFF8D7AFF;
    /** Cor de destaque (muda nas configurações). */
    static int ACC = 0xFFE5476B;

    private static final HashMap<String, Integer> ICONS = new HashMap<>();

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable bg(int col, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(col);
        g.setCornerRadius(r);
        return g;
    }

    static GradientDrawable bgStroke(int fill, int stroke, float r, int sw) {
        GradientDrawable g = bg(fill, r);
        g.setStroke(sw, stroke);
        return g;
    }

    static GradientDrawable grad(int c1, int c2, float r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(r);
        return g;
    }

    static GradientDrawable dashed(int stroke, float r, int sw, float dash) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(0);
        g.setCornerRadius(r);
        g.setStroke(sw, stroke, dash, dash * 0.8f);
        return g;
    }

    /** Ícone vetorial (res/drawable/ic_NOME.xml) pintado com a cor pedida. */
    static Drawable icon(Context c, String name, int color) {
        Integer id = ICONS.get(name);
        if (id == null) {
            id = c.getResources().getIdentifier("ic_" + name, "drawable", c.getPackageName());
            ICONS.put(name, id);
        }
        if (id == 0) return null;
        Drawable d = c.getResources().getDrawable(id, null).mutate();
        d.setTint(color);
        return d;
    }

    static Drawable art(Context c, String name) {
        int id = c.getResources().getIdentifier(name, "drawable", c.getPackageName());
        return id == 0 ? null : c.getResources().getDrawable(id, null);
    }

    static ImageView iconView(Context c, String name, int color, int sizeDp) {
        ImageView iv = new ImageView(c);
        Drawable d = icon(c, name, color);
        if (d != null) iv.setImageDrawable(d);
        iv.setLayoutParams(new LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)));
        return iv;
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        t.setIncludeFontPadding(false);
        return t;
    }

    static TextView mono(Context c, String s, float sp, int color) {
        TextView t = text(c, s, sp, color, false);
        t.setTypeface(Typeface.MONOSPACE);
        return t;
    }

    static Button btn(Context c, String t) {
        Button b = new Button(c);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(FG);
        b.setTextSize(12.5f);
        b.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setStateListAnimator(null);
        b.setElevation(0);
        int p = dp(c, 12);
        b.setPadding(p, dp(c, 8), p, dp(c, 8));
        b.setBackground(bgStroke(BTN, LINE, dp(c, 999), dp(c, 1)));
        return b;
    }

    /** Botão "pílula" ligado/desligado no estilo dos chips da 5.0. */
    static void sel(Button b, boolean on) {
        Context c = b.getContext();
        b.setBackground(on ? bg(ACC, dp(c, 999)) : bgStroke(BTN, LINE, dp(c, 999), dp(c, 1)));
        b.setTextColor(on ? 0xFFFFFFFF : FG);
    }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    static LinearLayout.LayoutParams lpw(float weight) {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight);
    }

    static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;
    static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;

    static View gap(Context c, int wDp, int hDp) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(c, wDp), dp(c, hDp)));
        return v;
    }

    /** Leve "afundar" ao tocar (como o :active do app 5.0). */
    @SuppressLint("ClickableViewAccessibility")
    static <T extends View> T pressable(T v) {
        v.setOnTouchListener((view, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                view.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            return false;
        });
        return v;
    }

    static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
    }

    static void tint(SeekBar s) {
        android.content.res.ColorStateList a = android.content.res.ColorStateList.valueOf(ACC);
        s.setProgressTintList(a);
        s.setThumbTintList(a);
        s.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF3A3F57));
    }

    /** Android 15 desenha atrás das barras do sistema: soma o espaço delas ao padding. */
    static void padInsets(final View v, final boolean top) {
        final int l = v.getPaddingLeft(), t = v.getPaddingTop(), r = v.getPaddingRight(), b = v.getPaddingBottom();
        v.setOnApplyWindowInsetsListener((view, in) -> {
            view.setPadding(l + in.getSystemWindowInsetLeft(), t + (top ? in.getSystemWindowInsetTop() : 0),
                    r + in.getSystemWindowInsetRight(), b + in.getSystemWindowInsetBottom());
            return in;
        });
    }

    static int clamp(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }

    static float clampf(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }

    static String hex(int c) { return String.format("#%06X", c & 0xFFFFFF); }

    abstract static class Seek implements SeekBar.OnSeekBarChangeListener {
        abstract void change(int v);

        void done() { }

        @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) { change(v); }

        @Override public void onStartTrackingTouch(SeekBar s) { }

        @Override public void onStopTrackingTouch(SeekBar s) { done(); }
    }

    static SeekBar seek(Context c, int max, int value, Seek l) {
        SeekBar s = new SeekBar(c);
        s.setMax(max);
        s.setProgress(value);
        s.setOnSeekBarChangeListener(l);
        tint(s);
        return s;
    }
}
