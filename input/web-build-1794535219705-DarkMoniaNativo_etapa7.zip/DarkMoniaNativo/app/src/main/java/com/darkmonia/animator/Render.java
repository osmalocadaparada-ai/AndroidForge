package com.darkmonia.animator;

import android.graphics.Bitmap;
import android.graphics.BlendMode;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.os.Build;

import java.util.Map;

/** Junta as camadas respeitando opacidade, modo de mesclagem e máscara de recorte. */
final class Render {
    static final String[] BLENDS = {"normal", "multiply", "screen", "overlay", "soft", "hard", "darken", "lighten",
            "burn", "dodge", "add", "difference", "exclusion", "hue", "saturation", "color", "luminosity"};
    static final String[] BLEND_NAMES = {"Normal", "Multiplicar", "Tela (clarear)", "Sobrepor", "Luz suave", "Luz forte",
            "Escurecer", "Clarear", "Subexpor cor", "Superexpor cor", "Somar (brilho)", "Diferença", "Exclusão",
            "Matiz", "Saturação", "Cor", "Luminosidade"};

    static String blendName(String k) {
        for (int i = 0; i < BLENDS.length; i++) if (BLENDS[i].equals(k)) return BLEND_NAMES[i];
        return "Normal";
    }

    /** O que está sendo desenhado agora na camada ativa (traço ao vivo e seleção flutuante). */
    static class Live {
        int layerId;
        Bitmap stroke;
        Paint strokePaint;
        Bitmap floating;
        Matrix floatMatrix;
        /** substitui o bitmap da camada (ex.: prévia de filtro ou liquidificar) */
        Bitmap replace;
        /** máscara da seleção: o traço só aparece dentro dela */
        Bitmap mask;
    }

    private static final Paint LP = new Paint(Paint.FILTER_BITMAP_FLAG);
    private static final Paint PLAIN = new Paint(Paint.FILTER_BITMAP_FLAG);
    private static final Paint DST_IN = new Paint(Paint.FILTER_BITMAP_FLAG);
    private static final RectF FULL = new RectF();

    static {
        DST_IN.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
    }

    static Paint layerPaint(Paint p, Project.Layer l) {
        p.reset();
        p.setFlags(Paint.FILTER_BITMAP_FLAG);
        p.setAlpha(l.opacity);
        setBlend(p, l.blend);
        return p;
    }

    static void setBlend(Paint p, String b) {
        if (b == null || b.equals("normal")) {
            p.setXfermode(null);
            return;
        }
        if (Build.VERSION.SDK_INT >= 29) {
            Api29.set(p, b);
        } else {
            PorterDuff.Mode m = null;
            switch (b) {
                case "multiply": m = PorterDuff.Mode.MULTIPLY; break;
                case "screen": m = PorterDuff.Mode.SCREEN; break;
                case "overlay": m = PorterDuff.Mode.OVERLAY; break;
                case "darken": case "burn": m = PorterDuff.Mode.DARKEN; break;
                case "lighten": case "dodge": m = PorterDuff.Mode.LIGHTEN; break;
                case "add": m = PorterDuff.Mode.ADD; break;
                default: break;
            }
            p.setXfermode(m == null ? null : new PorterDuffXfermode(m));
        }
    }

    /** Só é carregada no Android 10+ (BlendMode não existe antes). */
    static final class Api29 {
        static void set(Paint p, String b) {
            BlendMode m;
            switch (b) {
                case "multiply": m = BlendMode.MULTIPLY; break;
                case "screen": m = BlendMode.SCREEN; break;
                case "overlay": m = BlendMode.OVERLAY; break;
                case "soft": m = BlendMode.SOFT_LIGHT; break;
                case "hard": m = BlendMode.HARD_LIGHT; break;
                case "darken": m = BlendMode.DARKEN; break;
                case "lighten": m = BlendMode.LIGHTEN; break;
                case "burn": m = BlendMode.COLOR_BURN; break;
                case "dodge": m = BlendMode.COLOR_DODGE; break;
                case "add": m = BlendMode.PLUS; break;
                case "difference": m = BlendMode.DIFFERENCE; break;
                case "exclusion": m = BlendMode.EXCLUSION; break;
                case "hue": m = BlendMode.HUE; break;
                case "saturation": m = BlendMode.SATURATION; break;
                case "color": m = BlendMode.COLOR; break;
                case "luminosity": m = BlendMode.LUMINOSITY; break;
                default: m = BlendMode.SRC_OVER; break;
            }
            p.setBlendMode(m);
        }
    }

    /** Camada-base de uma camada com recorte: a primeira abaixo que não é recorte. */
    static Project.Layer clipBase(Project p, int idx) {
        for (int j = idx - 1; j >= 0; j--) if (!p.layers.get(j).clip) return p.layers.get(j);
        return null;
    }

    /**
     * Desenha todas as camadas visíveis em c (coordenadas do projeto).
     * Cada bitmap é esticado para 0..w × 0..h, então miniaturas de baixa resolução também funcionam.
     */
    static void stack(Canvas c, Project p, Map<Integer, Bitmap> bm, Live live) {
        FULL.set(0, 0, p.w, p.h);
        for (int i = 0; i < p.layers.size(); i++) {
            Project.Layer l = p.layers.get(i);
            if (!l.visible) continue;
            boolean isLive = live != null && live.layerId == l.id;
            Bitmap b = isLive && live.replace != null ? live.replace : bm.get(l.id);
            boolean hasLive = isLive && (live.stroke != null || live.floating != null);
            Bitmap base = null;
            if (l.clip) {
                Project.Layer bl = clipBase(p, i);
                if (bl == null || !bl.visible) continue;
                base = live != null && live.layerId == bl.id && live.replace != null ? live.replace : bm.get(bl.id);
                if (base == null) continue;
            }
            if (b == null && !hasLive) continue;
            boolean simple = !hasLive && base == null;
            if (simple) {
                c.drawBitmap(b, null, FULL, layerPaint(LP, l));
                continue;
            }
            int sc = c.saveLayer(FULL, layerPaint(LP, l));
            if (b != null) c.drawBitmap(b, null, FULL, PLAIN);
            if (isLive && live.stroke != null) {
                if (live.mask != null) {
                    int s2 = c.saveLayer(FULL, live.strokePaint);
                    c.drawBitmap(live.stroke, 0, 0, PLAIN);
                    c.drawBitmap(live.mask, 0, 0, DST_IN);
                    c.restoreToCount(s2);
                } else c.drawBitmap(live.stroke, 0, 0, live.strokePaint);
            }
            if (isLive && live.floating != null) c.drawBitmap(live.floating, live.floatMatrix, PLAIN);
            if (base != null) c.drawBitmap(base, null, FULL, DST_IN);
            c.restoreToCount(sc);
        }
    }
}
