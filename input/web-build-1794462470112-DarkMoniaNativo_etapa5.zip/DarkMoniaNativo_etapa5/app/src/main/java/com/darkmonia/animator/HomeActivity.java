package com.darkmonia.animator;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/** Home no estilo Creative Studio 5.0. */
public class HomeActivity extends Activity {
    private LinearLayout grid;
    private TextView countTv, emptyTv, tabAll, tabDraw, tabAnim, sortBtn;
    private int filter = 0, sortMode = 0;
    private boolean listView = false;
    private static final int REQ_OPEN_IMAGE = 42;

    private static final String[] QUICK_NAMES = {
            "Quadrado", "Retrato", "Story", "Paisagem", "A4", "A5",
            "Wallpaper", "4K", "Ícone", "Quadrinho", "Pixel art", "HD"
    };
    private static final String[] QUICK_SUB = {
            "Post", "Feed 4:5", "9:16", "HD 16:9", "300 dpi", "Caderno",
            "Celular", "Monitor", "Avatar", "HQ", "Retrô", "1280×720"
    };
    private static final int[][] QUICK_SIZES = {
            {1080, 1080}, {1080, 1350}, {1080, 1920}, {1920, 1080}, {2480, 3508}, {1748, 2480},
            {1440, 3200}, {3840, 2160}, {512, 512}, {1988, 2810}, {256, 256}, {1280, 720}
    };
    private static final int[] PAPERS = {0xFFFFFFFF, 0xFFFBF7EF, 0xFFF0F0F0, 0xFFE8EEF8, 0xFF1A1A1E, 0};
    private static final String[] PAPER_NAMES = {"Branco", "Creme", "Cinza", "Azulado", "Escuro", "Transp."};

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        int pad = Ui.dp(this, 18);

        FrameLayout shell = new FrameLayout(this);
        shell.setBackgroundColor(0xFF080A12);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad + Ui.dp(this, 6), pad, Ui.dp(this, 88));
        sv.addView(root);
        shell.addView(sv, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // header
        LinearLayout header = row();
        LinearLayout logoBox = row();
        TextView mark = new TextView(this);
        mark.setText("DM");
        mark.setTextColor(0xFFF1EAFF);
        mark.setTextSize(11);
        mark.setTypeface(Typeface.DEFAULT_BOLD);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(rounded(0xFF2A3358, Ui.dp(this, 10)));
        mark.setWidth(Ui.dp(this, 34));
        mark.setHeight(Ui.dp(this, 34));
        logoBox.addView(mark);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(Ui.dp(this, 10), 0, 0, 0);
        TextView brand = new TextView(this);
        brand.setText("Dark Monia");
        brand.setTextColor(Ui.FG);
        brand.setTextSize(16);
        brand.setTypeface(Typeface.DEFAULT_BOLD);
        TextView studio = new TextView(this);
        studio.setText("Creative Studio · 5.0");
        studio.setTextColor(Ui.MUTE);
        studio.setTextSize(11);
        titles.addView(brand);
        titles.addView(studio);
        logoBox.addView(titles);
        header.addView(logoBox, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        Button gear = chip("⚙");
        gear.setOnClickListener(v -> settings());
        header.addView(gear);
        root.addView(header);

        TextView hi = new TextView(this);
        hi.setText("Olá!");
        hi.setTextColor(Ui.FG);
        hi.setTextSize(34);
        hi.setTypeface(Typeface.DEFAULT_BOLD);
        hi.setPadding(0, Ui.dp(this, 22), 0, 0);
        root.addView(hi);
        TextView sub = new TextView(this);
        sub.setText("O que vamos criar hoje?");
        sub.setTextColor(0xFFAEB5CC);
        sub.setTextSize(15);
        sub.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 16));
        root.addView(sub);

        root.addView(actionCard("Novo desenho", "Ilustração com camadas", 0xFFE5476B, 0xFF8B3A6A, 0));
        root.addView(spacer(10));
        root.addView(actionCard("Nova animação", "Timeline, onion skin e fps", 0xFF2F8FD9, 0xFF1A4A7A, 1));
        root.addView(spacer(10));
        root.addView(actionCard("Abrir imagem", "Importar foto ou PNG como desenho", 0xFF3F9D4B, 0xFF1F5A2A, 2));

        LinearLayout qHead = row();
        qHead.setPadding(0, Ui.dp(this, 22), 0, Ui.dp(this, 8));
        TextView qTitle = new TextView(this);
        qTitle.setText("Começar rápido");
        qTitle.setTextColor(Ui.FG);
        qTitle.setTextSize(16);
        qTitle.setTypeface(Typeface.DEFAULT_BOLD);
        qHead.addView(qTitle, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        TextView qSub = new TextView(this);
        qSub.setText("toque e já desenhe");
        qSub.setTextColor(Ui.MUTE);
        qSub.setTextSize(11);
        qHead.addView(qSub);
        root.addView(qHead);

        HorizontalScrollView qScroll = new HorizontalScrollView(this);
        qScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout qRow = row();
        for (int i = 0; i < QUICK_NAMES.length; i++) {
            final int fi = i;
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.VERTICAL);
            chip.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));
            chip.setBackground(rounded(0xFF161822, Ui.dp(this, 12)));
            TextView n = new TextView(this);
            n.setText(QUICK_NAMES[i]);
            n.setTextColor(Ui.FG);
            n.setTextSize(13);
            n.setTypeface(Typeface.DEFAULT_BOLD);
            TextView s2 = new TextView(this);
            s2.setText(QUICK_SUB[i] + " · " + QUICK_SIZES[i][0] + "×" + QUICK_SIZES[i][1]);
            s2.setTextColor(Ui.MUTE);
            s2.setTextSize(10);
            chip.addView(n);
            chip.addView(s2);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            clp.setMargins(0, 0, Ui.dp(this, 8), 0);
            qRow.addView(chip, clp);
            chip.setOnClickListener(v -> open(Project.create(this, QUICK_NAMES[fi], QUICK_SIZES[fi][0], QUICK_SIZES[fi][1], false)));
            chip.setOnLongClickListener(v -> {
                open(Project.create(this, "Anim " + QUICK_NAMES[fi], QUICK_SIZES[fi][0], QUICK_SIZES[fi][1], true));
                return true;
            });
        }
        qScroll.addView(qRow);
        root.addView(qScroll);

        LinearLayout gHead = row();
        gHead.setPadding(0, Ui.dp(this, 24), 0, Ui.dp(this, 8));
        TextView gTitle = new TextView(this);
        gTitle.setText("Minha galeria ");
        gTitle.setTextColor(Ui.FG);
        gTitle.setTextSize(16);
        gTitle.setTypeface(Typeface.DEFAULT_BOLD);
        countTv = new TextView(this);
        countTv.setText("0");
        countTv.setTextColor(Ui.MUTE);
        countTv.setTextSize(14);
        LinearLayout gTitleRow = row();
        gTitleRow.addView(gTitle);
        gTitleRow.addView(countTv);
        gHead.addView(gTitleRow, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        sortBtn = chip("Recentes");
        sortBtn.setOnClickListener(v -> {
            sortMode = (sortMode + 1) % 3;
            sortBtn.setText(sortMode == 0 ? "Recentes" : sortMode == 1 ? "Nome" : "Antigos");
            refresh();
        });
        final Button viewBtn = chip("▦");
        viewBtn.setOnClickListener(v -> {
            listView = !listView;
            viewBtn.setText(listView ? "☰" : "▦");
            refresh();
        });
        gHead.addView(sortBtn);
        gHead.addView(spacer(6));
        gHead.addView(viewBtn);
        root.addView(gHead);

        LinearLayout tabs = row();
        tabs.setPadding(0, 0, 0, Ui.dp(this, 10));
        tabAll = tab("Tudo", 0);
        tabDraw = tab("Desenhos", 1);
        tabAnim = tab("Animações", 2);
        tabs.addView(tabAll, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        tabs.addView(tabDraw, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        tabs.addView(tabAnim, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        root.addView(tabs);
        updateTabs();

        grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        emptyTv = new TextView(this);
        emptyTv.setTextColor(Ui.MUTE);
        emptyTv.setGravity(Gravity.CENTER);
        emptyTv.setPadding(0, Ui.dp(this, 36), 0, 0);
        emptyTv.setTextSize(14);
        emptyTv.setVisibility(View.GONE);
        grid.addView(emptyTv);
        root.addView(grid);

        TextView foot = new TextView(this);
        foot.setText("Dark Monia Creative Studio · v5.0 nativo");
        foot.setTextColor(0xFF5A6078);
        foot.setTextSize(11);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, Ui.dp(this, 28), 0, Ui.dp(this, 12));
        root.addView(foot);

        Button fab = new Button(this);
        fab.setText("+");
        fab.setTextSize(28);
        fab.setTextColor(0xFFFFFFFF);
        fab.setAllCaps(false);
        fab.setBackground(rounded(Ui.ACC, Ui.dp(this, 28)));
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(Ui.dp(this, 56), Ui.dp(this, 56));
        flp.gravity = Gravity.BOTTOM | Gravity.END;
        flp.setMargins(0, 0, Ui.dp(this, 20), Ui.dp(this, 24));
        shell.addView(fab, flp);
        fab.setOnClickListener(v -> fabMenu());

        setContentView(shell);
    }

    private View spacer(int dp) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, Ui.dp(this, dp)));
        return v;
    }

    private View actionCard(String title, String subtitle, int c1, int c2, final int mode) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        bg.setCornerRadius(Ui.dp(this, 18));
        card.setBackground(bg);
        LinearLayout text = new LinearLayout(this);
        text.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(17);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        TextView s = new TextView(this);
        s.setText(subtitle);
        s.setTextColor(0xE0FFFFFF);
        s.setTextSize(12);
        text.addView(t);
        text.addView(s);
        card.addView(text, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextColor(0xFFFFFFFF);
        arrow.setTextSize(28);
        card.addView(arrow);
        card.setOnClickListener(v -> {
            if (mode == 2) openImage();
            else newProjectSheet(mode == 1);
        });
        return card;
    }

    private TextView tab(String label, final int f) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(13);
        t.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
        t.setOnClickListener(v -> { filter = f; updateTabs(); refresh(); });
        return t;
    }

    private void updateTabs() {
        TextView[] tabs = {tabAll, tabDraw, tabAnim};
        for (int i = 0; i < 3; i++) {
            boolean on = filter == i;
            tabs[i].setTextColor(on ? Ui.FG : Ui.MUTE);
            tabs[i].setTypeface(null, on ? Typeface.BOLD : Typeface.NORMAL);
            tabs[i].setBackground(on ? rounded(0xFF2A2D42, Ui.dp(this, 10)) : null);
        }
    }

    private Button chip(String t) {
        Button b = Ui.btn(this, t);
        b.setTextSize(12);
        int p = Ui.dp(this, 10);
        b.setPadding(p, Ui.dp(this, 6), p, Ui.dp(this, 6));
        b.setBackground(rounded(0xFF1B1D2B, Ui.dp(this, 10)));
        return b;
    }

    private GradientDrawable rounded(int col, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(col);
        g.setCornerRadius(r);
        return g;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private void fabMenu() {
        new AlertDialog.Builder(this).setTitle("Criar novo")
                .setItems(new String[]{"Novo desenho", "Nova animação", "Abrir imagem", "Tamanho personalizado"}, (d, i) -> {
                    if (i == 0) newProjectSheet(false);
                    else if (i == 1) newProjectSheet(true);
                    else if (i == 2) openImage();
                    else customSize();
                }).show();
    }

    private void newProjectSheet(final boolean anim) {
        int pad = Ui.dp(this, 14);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, 0);
        final EditText name = new EditText(this);
        name.setHint("Nome do projeto");
        name.setText(anim ? "Animação" : "Desenho");
        box.addView(name);
        TextView th = new TextView(this);
        th.setText("Tamanho");
        th.setTextColor(Ui.MUTE);
        th.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 6));
        box.addView(th);
        final int[] chosen = {0};
        final LinearLayout sizeBox = new LinearLayout(this);
        sizeBox.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < QUICK_NAMES.length; i++) {
            final int fi = i;
            Button b = Ui.btn(this, QUICK_NAMES[i] + "  " + QUICK_SIZES[i][0] + "×" + QUICK_SIZES[i][1]);
            b.setOnClickListener(v -> {
                chosen[0] = fi;
                for (int j = 0; j < sizeBox.getChildCount(); j++) Ui.sel((Button) sizeBox.getChildAt(j), j == fi);
            });
            if (i == 0) Ui.sel(b, true);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = Ui.dp(this, 4);
            sizeBox.addView(b, lp);
        }
        ScrollView sizesScroll = new ScrollView(this);
        sizesScroll.addView(sizeBox);
        box.addView(sizesScroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 180)));

        TextView ph = new TextView(this);
        ph.setText("Fundo");
        ph.setTextColor(Ui.MUTE);
        ph.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 6));
        box.addView(ph);
        final int[] paper = {0xFFFFFFFF};
        LinearLayout papers = row();
        for (int i = 0; i < PAPERS.length; i++) {
            final int col = PAPERS[i];
            final int fi = i;
            View sw = new View(this);
            GradientDrawable g = rounded(col == 0 ? 0xFF333333 : col, Ui.dp(this, 8));
            if (col == 0) g.setStroke(Ui.dp(this, 2), 0xFF888888);
            sw.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 36), 1);
            lp.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0);
            papers.addView(sw, lp);
            sw.setOnClickListener(v -> { paper[0] = col; Ui.toast(this, PAPER_NAMES[fi]); });
        }
        box.addView(papers);

        final EditText fpsEt = anim ? new EditText(this) : null;
        if (anim) {
            TextView fh = new TextView(this);
            fh.setText("FPS inicial");
            fh.setTextColor(Ui.MUTE);
            fh.setPadding(0, Ui.dp(this, 10), 0, 0);
            box.addView(fh);
            fpsEt.setText("12");
            fpsEt.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
            box.addView(fpsEt);
        }

        new AlertDialog.Builder(this)
                .setTitle(anim ? "Nova animação" : "Novo desenho")
                .setView(box)
                .setPositiveButton("Criar", (d, w) -> {
                    String nm = name.getText().toString().trim();
                    if (nm.isEmpty()) nm = anim ? "Animação" : "Desenho";
                    int[] sz = QUICK_SIZES[chosen[0]];
                    float k = Math.min(1f, 4096f / Math.max(sz[0], sz[1]));
                    int mw = Math.max(16, Math.round(sz[0] * k));
                    int mh = Math.max(16, Math.round(sz[1] * k));
                    Project p = Project.create(this, nm, mw, mh, anim);
                    p.paper = paper[0];
                    if (anim && fpsEt != null) {
                        try { p.fps = Math.max(1, Math.min(60, Integer.parseInt(fpsEt.getText().toString().trim()))); }
                        catch (Exception ignored) {}
                    }
                    p.save();
                    open(p);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void customSize() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 14);
        box.setPadding(pad, pad, pad, 0);
        final EditText w = new EditText(this);
        final EditText h = new EditText(this);
        w.setHint("Largura");
        h.setHint("Altura");
        w.setText("1080");
        h.setText("1080");
        w.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        h.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        box.addView(w);
        box.addView(h);
        new AlertDialog.Builder(this).setTitle("Tamanho personalizado").setView(box)
                .setPositiveButton("Desenho", (d, i) -> open(Project.create(this, "Desenho", parseDim(w), parseDim(h), false)))
                .setNeutralButton("Animação", (d, i) -> open(Project.create(this, "Animação", parseDim(w), parseDim(h), true)))
                .setNegativeButton("Cancelar", null).show();
    }

    private int parseDim(EditText e) {
        try { return Math.max(16, Math.min(4096, Integer.parseInt(e.getText().toString().trim()))); }
        catch (Exception ex) { return 1080; }
    }

    private void openImage() {
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.setType("image/*");
        it.addCategory(Intent.CATEGORY_OPENABLE);
        try { startActivityForResult(Intent.createChooser(it, "Abrir imagem"), REQ_OPEN_IMAGE); }
        catch (Exception e) { Ui.toast(this, "Não há app de galeria"); }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_OPEN_IMAGE || res != RESULT_OK || data == null || data.getData() == null) return;
        try {
            Uri uri = data.getData();
            InputStream in = getContentResolver().openInputStream(uri);
            Bitmap src = BitmapFactory.decodeStream(in);
            if (in != null) in.close();
            if (src == null) { Ui.toast(this, "Não consegui ler a imagem"); return; }
            int w = src.getWidth(), h = src.getHeight();
            float k = Math.min(1f, 2048f / Math.max(w, h));
            int nw = Math.max(1, Math.round(w * k)), nh = Math.max(1, Math.round(h * k));
            Bitmap scaled = (nw == w && nh == h) ? src : Bitmap.createScaledBitmap(src, nw, nh, true);
            if (scaled != src) src.recycle();
            Project p = Project.create(this, "Importado", nw, nh, false);
            p.paper = 0;
            Project.writePng(scaled, p.layerFile(p.frames.get(0), p.layers.get(0).id));
            Project.writePng(scaled, p.thumbFile());
            scaled.recycle();
            p.save();
            open(p);
        } catch (Exception e) {
            Ui.toast(this, "Falha ao importar");
        }
    }

    private void settings() {
        new AlertDialog.Builder(this).setTitle("Configurações")
                .setMessage("Dark Monia nativo etapa 5\n\nJava puro · package com.darkmonia.animator\n\nGestos no editor:\n2 dedos = desfazer\n3 dedos = refazer\n⛶ = esconder UI")
                .setPositiveButton("OK", null).show();
    }

    private void open(Project p) {
        Intent it = new Intent(this, EditorActivity.class);
        it.putExtra("dir", p.dir.getPath());
        startActivity(it);
    }

    private void refresh() {
        while (grid.getChildCount() > 1) grid.removeViewAt(1);
        ArrayList<Project> all = Project.list(this);
        ArrayList<Project> list = new ArrayList<>();
        for (Project p : all) {
            if (filter == 1 && p.anim) continue;
            if (filter == 2 && !p.anim) continue;
            list.add(p);
        }
        if (sortMode == 1) Collections.sort(list, (a, b) -> a.name.compareToIgnoreCase(b.name));
        else if (sortMode == 2) Collections.sort(list, Comparator.comparingLong(a -> a.updated));

        countTv.setText(String.valueOf(list.size()));
        int draws = 0, anims = 0;
        for (Project p : all) { if (p.anim) anims++; else draws++; }
        tabAll.setText("Tudo " + all.size());
        tabDraw.setText("Desenhos " + draws);
        tabAnim.setText("Animações " + anims);

        if (list.isEmpty()) {
            emptyTv.setVisibility(View.VISIBLE);
            emptyTv.setText(filter == 0 ? "Nada aqui ainda.\nCrie um desenho ou uma animação." : "Nenhum projeto neste filtro.");
            return;
        }
        emptyTv.setVisibility(View.GONE);

        if (listView) {
            for (Project p : list) grid.addView(listCard(p));
        } else {
            int gap = Ui.dp(this, 8);
            LinearLayout row = null;
            for (int i = 0; i < list.size(); i++) {
                if (i % 2 == 0) { row = new LinearLayout(this); grid.addView(row); }
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
                lp.setMargins(gap / 2, gap / 2, gap / 2, gap / 2);
                row.addView(gridCard(list.get(i)), lp);
            }
            if (list.size() % 2 == 1) {
                View filler = new View(this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1);
                lp.setMargins(gap / 2, gap / 2, gap / 2, gap / 2);
                row.addView(filler, lp);
            }
        }
    }

    private View gridCard(final Project p) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(rounded(0xFF161822, Ui.dp(this, 14)));
        int pad = Ui.dp(this, 8);
        c.setPadding(pad, pad, pad, pad);
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackgroundColor(0xFF0C0D14);
        if (p.thumbFile().exists()) {
            Bitmap b = BitmapFactory.decodeFile(p.thumbFile().getPath());
            if (b != null) iv.setImageBitmap(b);
        }
        c.addView(iv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 120)));
        TextView n = new TextView(this);
        n.setText(p.name);
        n.setTextColor(Ui.FG);
        n.setTextSize(13);
        n.setSingleLine(true);
        n.setTypeface(Typeface.DEFAULT_BOLD);
        n.setPadding(0, pad, 0, 0);
        c.addView(n);
        TextView info = new TextView(this);
        info.setText((p.anim ? p.frames.size() + " quadros · " : "Desenho · ") + p.w + "×" + p.h);
        info.setTextColor(Ui.MUTE);
        info.setTextSize(11);
        c.addView(info);
        c.setOnClickListener(v -> open(p));
        c.setOnLongClickListener(v -> { projectSheet(p); return true; });
        return c;
    }

    private View listCard(final Project p) {
        LinearLayout c = row();
        c.setBackground(rounded(0xFF161822, Ui.dp(this, 12)));
        int pad = Ui.dp(this, 8);
        c.setPadding(pad, pad, pad, pad);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        mlp.bottomMargin = Ui.dp(this, 8);
        c.setLayoutParams(mlp);
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackgroundColor(0xFF0C0D14);
        if (p.thumbFile().exists()) {
            Bitmap b = BitmapFactory.decodeFile(p.thumbFile().getPath());
            if (b != null) iv.setImageBitmap(b);
        }
        c.addView(iv, new LinearLayout.LayoutParams(Ui.dp(this, 64), Ui.dp(this, 64)));
        LinearLayout text = new LinearLayout(this);
        text.setOrientation(LinearLayout.VERTICAL);
        text.setPadding(Ui.dp(this, 10), 0, 0, 0);
        TextView n = new TextView(this);
        n.setText(p.name);
        n.setTextColor(Ui.FG);
        n.setTextSize(14);
        n.setTypeface(Typeface.DEFAULT_BOLD);
        TextView info = new TextView(this);
        info.setText((p.anim ? p.frames.size() + " quadros · " : "Desenho · ") + p.w + "×" + p.h);
        info.setTextColor(Ui.MUTE);
        info.setTextSize(11);
        text.addView(n);
        text.addView(info);
        c.addView(text, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        c.setOnClickListener(v -> open(p));
        c.setOnLongClickListener(v -> { projectSheet(p); return true; });
        return c;
    }

    private void projectSheet(final Project p) {
        new AlertDialog.Builder(this).setTitle(p.name)
                .setMessage((p.anim ? "Animação · " + p.frames.size() + " quadros\n" : "Desenho\n") + p.w + "×" + p.h)
                .setPositiveButton("Editar", (d, w) -> open(p))
                .setNeutralButton("⋯", (d, w) -> moreOptions(p))
                .setNegativeButton("Fechar", null).show();
    }

    private void moreOptions(final Project p) {
        new AlertDialog.Builder(this).setTitle(p.name)
                .setItems(new String[]{"Renomear", "Duplicar", "Excluir"}, (dlg, i) -> {
                    if (i == 0) rename(p);
                    else if (i == 1) duplicate(p);
                    else confirmDelete(p);
                }).show();
    }

    private void rename(final Project p) {
        final EditText et = new EditText(this);
        et.setText(p.name);
        new AlertDialog.Builder(this).setTitle("Renomear").setView(et)
                .setPositiveButton("OK", (dlg, w) -> {
                    String s = et.getText().toString().trim();
                    if (s.length() > 0) {
                        p.name = s.length() > 40 ? s.substring(0, 40) : s;
                        p.save();
                        refresh();
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    private void duplicate(Project src) {
        try {
            Project p = Project.create(this, src.name + " cópia", src.w, src.h, src.anim);
            p.paper = src.paper;
            p.fps = src.fps;
            p.layers.clear();
            for (Project.Layer l : src.layers) {
                Project.Layer nl = p.addLayer(l.name);
                nl.visible = l.visible;
                nl.locked = l.locked;
                nl.opacity = l.opacity;
            }
            p.frames.clear();
            for (int fid : src.frames) {
                int nid = p.nextFrame++;
                p.frames.add(nid);
                for (int i = 0; i < src.layers.size() && i < p.layers.size(); i++) {
                    File sf = src.layerFile(fid, src.layers.get(i).id);
                    if (!sf.exists()) continue;
                    File df = p.layerFile(nid, p.layers.get(i).id);
                    FileInputStream in = new FileInputStream(sf);
                    FileOutputStream out = new FileOutputStream(df);
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    in.close();
                    out.close();
                }
            }
            if (src.thumbFile().exists()) {
                FileInputStream in = new FileInputStream(src.thumbFile());
                FileOutputStream out = new FileOutputStream(p.thumbFile());
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close();
                out.close();
            }
            p.save();
            refresh();
            Ui.toast(this, "Projeto duplicado");
        } catch (Exception e) {
            Ui.toast(this, "Falha ao duplicar");
        }
    }

    private void confirmDelete(final Project p) {
        new AlertDialog.Builder(this).setTitle("Excluir “" + p.name + "”?")
                .setMessage("Isso não pode ser desfeito.")
                .setPositiveButton("Excluir", (dlg, w) -> { p.deleteAll(); refresh(); })
                .setNegativeButton("Cancelar", null).show();
    }
}
