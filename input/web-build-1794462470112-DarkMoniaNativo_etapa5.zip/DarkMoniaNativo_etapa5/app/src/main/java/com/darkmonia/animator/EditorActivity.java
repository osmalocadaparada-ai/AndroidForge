package com.darkmonia.animator;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Editor tela cheia: canvas ocupa tudo; barras flutuantes compactas.
 * Mais ferramentas no estilo da v5.0.
 */
public class EditorActivity extends Activity implements CanvasView.Listener {
    private Project p;
    private CanvasView cv;
    private LinearLayout strip, selBar, bottomBar;
    private TextView frameLbl, sizeLbl, opLbl, fpsLbl, titleTv;
    private Button colorBtn, undoBtn, redoBtn, playBtn, onionBtn, symHBtn, symVBtn, fillShapeBtn;
    private final Button[] toolBtns = new Button[14];
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ConcurrentHashMap<Integer, Bitmap> thumbs = new ConcurrentHashMap<>();
    private ArrayList<Bitmap> playFrames;
    private boolean playing, uiHidden;
    private int playI;
    private Integer clipFrameId;
    private View topBar, timelineBar;

    private static final String[] TOOLS = {
            "Lápis", "G-Pen", "Marcador", "Aero", "Borracha",
            "Balde", "Gotas", "Mão",
            "Sel.", "Laço", "Reta", "Ret.", "Elipse", "Texto"
    };

    private static final int[] SWATCHES = {
            0xFF16161D, 0xFFFFFFFF, 0xFF8B8680, 0xFFE5472B, 0xFFFF6A1A, 0xFFF2A516, 0xFFFFE27A, 0xFF3F9D4B,
            0xFF1F6B3A, 0xFF39E6FF, 0xFF2D6CDF, 0xFF7B4BD1, 0xFFFF4FD8, 0xFFE58FB1, 0xFF7A5230, 0xFFD9A066
    };

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        immersive();
        String dir = getIntent().getStringExtra("dir");
        p = dir == null ? null : Project.load(new File(dir));
        if (p == null) { finish(); return; }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);

        /* CANVAS — ocupa a tela inteira */
        cv = new CanvasView(this);
        cv.listener = this;
        root.addView(cv, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        int g = Ui.dp(this, 3);
        int barPad = Ui.dp(this, 6);

        /* TOP BAR flutuante */
        topBar = makeTopBar(g, barPad);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        tlp.gravity = Gravity.TOP;
        root.addView(topBar, tlp);

        /* SELEÇÃO bar */
        selBar = row();
        selBar.setBackgroundColor(0xE0161822);
        selBar.setPadding(barPad, g, barPad, g);
        selBar.setVisibility(View.GONE);
        for (String[] act : new String[][]{
                {"Apagar", "del"}, {"Preencher", "fill"}, {"Recortar", "cut"},
                {"Copiar", "copy"}, {"Colar", "paste"}, {"OK", "ok"}
        }) {
            Button b = smallBtn(act[0]);
            String id = act[1];
            b.setOnClickListener(v -> {
                switch (id) {
                    case "del": cv.deleteSelection(); break;
                    case "fill": cv.fillSelection(); break;
                    case "cut": cv.cutSelection(); break;
                    case "copy": cv.copySelection(); break;
                    case "paste": cv.pasteClipboard(); break;
                    case "ok": cv.commitFloating(); cv.clearSelection(); break;
                }
            });
            add(selBar, b, g);
        }
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        slp.gravity = Gravity.TOP;
        slp.topMargin = Ui.dp(this, 48);
        root.addView(selBar, slp);

        /* BOTTOM BAR: ferramentas + size */
        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.VERTICAL);
        bottomBar.setBackgroundColor(0xF0161822);
        bottomBar.setPadding(barPad, g, barPad, barPad);

        HorizontalScrollView ts = new HorizontalScrollView(this);
        ts.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = row();
        colorBtn = smallBtn("Cor");
        colorBtn.setOnClickListener(v -> pickColor());
        add(tools, colorBtn, g);
        Button ly = smallBtn("Camadas");
        ly.setOnClickListener(v -> layersDialog());
        add(tools, ly, g);
        for (int i = 0; i < TOOLS.length; i++) {
            final int t = i;
            toolBtns[i] = smallBtn(TOOLS[i]);
            toolBtns[i].setOnClickListener(v -> setTool(t));
            add(tools, toolBtns[i], g);
        }
        ts.addView(tools);
        bottomBar.addView(ts);

        LinearLayout opts = row();
        opts.setPadding(0, g, 0, 0);
        sizeLbl = Ui.label(this, "");
        opLbl = Ui.label(this, "");
        SeekBar sz = new SeekBar(this);
        SeekBar op = new SeekBar(this);
        sz.setMax(99);
        op.setMax(99);
        opts.addView(sizeLbl);
        opts.addView(sz, new LinearLayout.LayoutParams(0, Ui.dp(this, 28), 1));
        opts.addView(opLbl);
        opts.addView(op, new LinearLayout.LayoutParams(0, Ui.dp(this, 28), 1));
        symHBtn = smallBtn("SymH");
        symVBtn = smallBtn("SymV");
        fillShapeBtn = smallBtn("Preench.");
        symHBtn.setOnClickListener(v -> {
            cv.symH = !cv.symH;
            Ui.sel(symHBtn, cv.symH);
        });
        symVBtn.setOnClickListener(v -> {
            cv.symV = !cv.symV;
            Ui.sel(symVBtn, cv.symV);
        });
        fillShapeBtn.setOnClickListener(v -> {
            cv.shapeFill = !cv.shapeFill;
            Ui.sel(fillShapeBtn, cv.shapeFill);
        });
        add(opts, symHBtn, g);
        add(opts, symVBtn, g);
        add(opts, fillShapeBtn, g);
        bottomBar.addView(opts);

        if (p.anim) {
            timelineBar = makeTimeline(g, barPad);
            bottomBar.addView(timelineBar);
        }

        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        blp.gravity = Gravity.BOTTOM;
        root.addView(bottomBar, blp);

        /* toque no canvas com 4 dedos ou botão esconde UI */
        setContentView(root);

        cv.setProject(p);
        sz.setProgress(cv.size - 1);
        op.setProgress(cv.opacity - 1);
        sz.setOnSeekBarChangeListener(new Ui.Seek() {
            @Override void change(int v) { cv.size = v + 1; labels(); }
        });
        op.setOnSeekBarChangeListener(new Ui.Seek() {
            @Override void change(int v) { cv.opacity = v + 1; labels(); }
        });
        setTool(CanvasView.GPEN);
        setColor(cv.color);
        labels();
        onChanged();
        if (p.anim) { setFps(p.fps); rebuildStrip(); }

        // toque longo no título esconde/mostra UI
        titleTv.setOnLongClickListener(v -> {
            toggleUi();
            return true;
        });
    }

    private View makeTopBar(int g, int barPad) {
        LinearLayout top = row();
        top.setBackgroundColor(0xE0161822);
        top.setPadding(barPad, barPad + (Build.VERSION.SDK_INT >= 28 ? Ui.dp(this, 8) : 0), barPad, barPad);
        Button back = smallBtn("‹");
        back.setTextSize(18);
        back.setOnClickListener(v -> finish());
        top.addView(back);
        titleTv = new TextView(this);
        titleTv.setText(p.name);
        titleTv.setTextColor(Ui.FG);
        titleTv.setTextSize(14);
        titleTv.setSingleLine(true);
        titleTv.setPadding(Ui.dp(this, 8), 0, 0, 0);
        top.addView(titleTv, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        undoBtn = smallBtn("↶");
        redoBtn = smallBtn("↷");
        undoBtn.setOnClickListener(v -> cv.undo());
        redoBtn.setOnClickListener(v -> cv.redo());
        add(top, undoBtn, g);
        add(top, redoBtn, g);
        if (p.anim) {
            playBtn = smallBtn("▶");
            playBtn.setOnClickListener(v -> { if (playing) stopPlay(); else startPlay(); });
            add(top, playBtn, g);
        }
        Button hide = smallBtn("⛶");
        hide.setOnClickListener(v -> toggleUi());
        add(top, hide, g);
        Button menu = smallBtn("⋮");
        menu.setOnClickListener(v -> menu());
        add(top, menu, g);
        return top;
    }

    private View makeTimeline(int g, int barPad) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        HorizontalScrollView fs = new HorizontalScrollView(this);
        fs.setHorizontalScrollBarEnabled(false);
        LinearLayout fr = row();
        fr.setPadding(0, g, 0, 0);
        frameLbl = Ui.label(this, "");
        fr.addView(frameLbl);
        Button prev = smallBtn("◀"), next = smallBtn("▶");
        Button addF = smallBtn("+Q"), dup = smallBtn("Dup"), del = smallBtn("Del");
        Button copyF = smallBtn("CopQ"), pasteF = smallBtn("ColQ");
        onionBtn = smallBtn("Onion");
        Button fm = smallBtn("−"), fp = smallBtn("+");
        fpsLbl = Ui.label(this, "");
        prev.setOnClickListener(v -> goFrame(cv.frameIdx - 1));
        next.setOnClickListener(v -> goFrame(cv.frameIdx + 1));
        addF.setOnClickListener(v -> addFrame(false));
        dup.setOnClickListener(v -> addFrame(true));
        del.setOnClickListener(v -> deleteFrame());
        copyF.setOnClickListener(v -> { clipFrameId = cv.frameId(); Ui.toast(this, "Quadro copiado"); });
        pasteF.setOnClickListener(v -> pasteFrame());
        onionBtn.setOnClickListener(v -> {
            cv.onion = !cv.onion;
            Ui.sel(onionBtn, cv.onion);
            cv.invalidate();
        });
        fm.setOnClickListener(v -> setFps(p.fps - 1));
        fp.setOnClickListener(v -> setFps(p.fps + 1));
        add(fr, prev, g); add(fr, next, g); add(fr, addF, g); add(fr, dup, g);
        add(fr, del, g); add(fr, copyF, g); add(fr, pasteF, g); add(fr, onionBtn, g);
        add(fr, fm, g); fr.addView(fpsLbl); add(fr, fp, g);
        fs.addView(fr);
        wrap.addView(fs);
        Ui.sel(onionBtn, true);

        HorizontalScrollView ss = new HorizontalScrollView(this);
        strip = row();
        strip.setPadding(0, g, 0, 0);
        ss.addView(strip);
        wrap.addView(ss);
        return wrap;
    }

    private void immersive() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    private void toggleUi() {
        uiHidden = !uiHidden;
        int vis = uiHidden ? View.GONE : View.VISIBLE;
        topBar.setVisibility(vis);
        bottomBar.setVisibility(vis);
        if (!uiHidden && cv.hasSel) selBar.setVisibility(View.VISIBLE);
        else if (uiHidden) selBar.setVisibility(View.GONE);
        Ui.toast(this, uiHidden ? "UI oculta — toque ⛶ ou segure o título" : "UI visível");
    }

    private Button smallBtn(String t) {
        Button b = Ui.btn(this, t);
        b.setTextSize(11);
        int p = Ui.dp(this, 8);
        b.setPadding(p, Ui.dp(this, 6), p, Ui.dp(this, 6));
        return b;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private void add(LinearLayout parent, View v, int gap) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(gap, 0, 0, 0);
        parent.addView(v, lp);
    }

    private void labels() {
        sizeLbl.setText("T" + cv.size);
        opLbl.setText(cv.opacity + "%");
    }

    private void setTool(int t) {
        if (cv.tool != t) cv.commitFloating();
        cv.tool = t;
        for (int i = 0; i < toolBtns.length; i++) Ui.sel(toolBtns[i], i == t);
    }

    private void setColor(int c) {
        cv.color = c | 0xFF000000;
        colorBtn.setBackground(Ui.bg(cv.color, Ui.dp(this, 8)));
        float[] hsv = new float[3];
        Color.colorToHSV(cv.color, hsv);
        colorBtn.setTextColor(hsv[2] > 0.6f && hsv[1] < 0.6f ? 0xFF000000 : 0xFFFFFFFF);
    }

    @Override public void onChanged() {
        undoBtn.setAlpha(cv.canUndo() ? 1f : 0.35f);
        redoBtn.setAlpha(cv.canRedo() ? 1f : 0.35f);
    }

    @Override public void onColorPicked(int c) {
        setColor(c);
        setTool(CanvasView.GPEN);
        Ui.toast(this, "Cor capturada");
    }

    @Override public void onMessage(String m) { Ui.toast(this, m); }

    @Override public void onSelectionChanged(boolean has) {
        if (!uiHidden) selBar.setVisibility(has ? View.VISIBLE : View.GONE);
    }

    @Override public void onRequestText() {
        EditText et = new EditText(this);
        et.setHint("Texto");
        new AlertDialog.Builder(this).setTitle("Texto").setView(et)
                .setPositiveButton("OK", (d, w) -> cv.stampText(et.getText().toString()))
                .setNegativeButton("Cancelar", null).show();
    }

    private void pickColor() {
        final float[] hsv = new float[3];
        Color.colorToHSV(cv.color, hsv);
        int pad = Ui.dp(this, 14);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, 0);
        final View prev = new View(this);
        prev.setBackground(Ui.bg(cv.color, Ui.dp(this, 10)));
        box.addView(prev, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 40)));
        final SeekBar sh = new SeekBar(this), ss = new SeekBar(this), sv = new SeekBar(this);
        sh.setMax(360); ss.setMax(100); sv.setMax(100);
        for (int r = 0; r < 2; r++) {
            LinearLayout line = row();
            line.setPadding(0, Ui.dp(this, 6), 0, 0);
            for (int i = 0; i < 8; i++) {
                final int col = SWATCHES[r * 8 + i];
                View sw = new View(this);
                sw.setBackground(Ui.bg(col, Ui.dp(this, 6)));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 28), 1);
                lp.setMargins(Ui.dp(this, 2), 0, Ui.dp(this, 2), 0);
                line.addView(sw, lp);
                sw.setOnClickListener(v -> {
                    Color.colorToHSV(col, hsv);
                    sh.setProgress(Math.round(hsv[0]));
                    ss.setProgress(Math.round(hsv[1] * 100));
                    sv.setProgress(Math.round(hsv[2] * 100));
                    prev.setBackground(Ui.bg(col, Ui.dp(this, 10)));
                });
            }
            box.addView(line);
        }
        String[] names = {"Matiz", "Saturação", "Brilho"};
        SeekBar[] bars = {sh, ss, sv};
        for (int i = 0; i < 3; i++) {
            TextView t = Ui.label(this, names[i]);
            t.setPadding(0, Ui.dp(this, 8), 0, 0);
            box.addView(t);
            box.addView(bars[i], new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 32)));
        }
        sh.setProgress(Math.round(hsv[0]));
        ss.setProgress(Math.round(hsv[1] * 100));
        sv.setProgress(Math.round(hsv[2] * 100));
        Ui.Seek upd = new Ui.Seek() {
            @Override void change(int v) {
                hsv[0] = sh.getProgress();
                hsv[1] = ss.getProgress() / 100f;
                hsv[2] = sv.getProgress() / 100f;
                prev.setBackground(Ui.bg(Color.HSVToColor(hsv), Ui.dp(EditorActivity.this, 10)));
            }
        };
        sh.setOnSeekBarChangeListener(upd);
        ss.setOnSeekBarChangeListener(upd);
        sv.setOnSeekBarChangeListener(upd);
        new AlertDialog.Builder(this).setTitle("Cor").setView(box)
                .setPositiveButton("OK", (d, w) -> setColor(Color.HSVToColor(hsv)))
                .setNegativeButton("Cancelar", null).show();
    }

    private void layersDialog() {
        ScrollView sc = new ScrollView(this);
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 10);
        box.setPadding(pad, pad, pad, 0);
        sc.addView(box);
        fillLayers(box);
        new AlertDialog.Builder(this).setTitle("Camadas").setView(sc)
                .setPositiveButton("Fechar", null)
                .setNeutralButton("+ Camada", (d, w) -> {
                    if (p.layers.size() >= 16) { Ui.toast(this, "Máximo 16 camadas"); return; }
                    cv.saveCurrent();
                    p.addLayer("Camada " + p.layers.size());
                    p.save();
                    cv.active = p.layers.size() - 1;
                    Ui.toast(this, "Camada criada");
                }).show();
    }

    private void fillLayers(final LinearLayout box) {
        box.removeAllViews();
        int g = Ui.dp(this, 3);
        for (int i = p.layers.size() - 1; i >= 0; i--) {
            final int idx = i;
            final Project.Layer l = p.layers.get(i);
            LinearLayout r = row();
            r.setPadding(0, 0, 0, g * 2);
            Button name = smallBtn((l.locked ? "🔒" : "") + l.name);
            Ui.sel(name, idx == cv.active);
            name.setOnClickListener(v -> { cv.active = idx; fillLayers(box); });
            name.setOnLongClickListener(v -> { renameLayer(l, box); return true; });
            r.addView(name, new LinearLayout.LayoutParams(Ui.dp(this, 96), LinearLayout.LayoutParams.WRAP_CONTENT));
            Button eye = smallBtn(l.visible ? "👁" : "—");
            eye.setOnClickListener(v -> { l.visible = !l.visible; p.save(); cv.invalidate(); fillLayers(box); });
            add(r, eye, g);
            Button lock = smallBtn(l.locked ? "🔒" : "🔓");
            lock.setOnClickListener(v -> { l.locked = !l.locked; p.save(); fillLayers(box); });
            add(r, lock, g);
            Button up = smallBtn("↑");
            up.setOnClickListener(v -> {
                if (idx + 1 < p.layers.size()) {
                    Project.Layer tmp = p.layers.remove(idx);
                    p.layers.add(idx + 1, tmp);
                    if (cv.active == idx) cv.active = idx + 1;
                    else if (cv.active == idx + 1) cv.active = idx;
                    p.save(); cv.invalidate(); fillLayers(box);
                }
            });
            add(r, up, g);
            Button dn = smallBtn("↓");
            dn.setOnClickListener(v -> {
                if (idx > 0) {
                    Project.Layer tmp = p.layers.remove(idx);
                    p.layers.add(idx - 1, tmp);
                    if (cv.active == idx) cv.active = idx - 1;
                    else if (cv.active == idx - 1) cv.active = idx;
                    p.save(); cv.invalidate(); fillLayers(box);
                }
            });
            add(r, dn, g);
            if (p.layers.size() > 1) {
                Button del = smallBtn("✕");
                del.setOnClickListener(v -> {
                    cv.saveCurrent();
                    cv.removeLayerBitmap(l.id);
                    for (int fid : p.frames) p.layerFile(fid, l.id).delete();
                    p.layers.remove(idx);
                    if (cv.active >= p.layers.size()) cv.active = p.layers.size() - 1;
                    p.save(); cv.invalidate(); fillLayers(box);
                });
                add(r, del, g);
            }
            SeekBar op = new SeekBar(this);
            op.setMax(255);
            op.setProgress(l.opacity);
            op.setOnSeekBarChangeListener(new Ui.Seek() {
                @Override void change(int v) { l.opacity = v; cv.invalidate(); }
            });
            LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(Ui.dp(this, 80), Ui.dp(this, 32));
            olp.setMargins(g, 0, 0, 0);
            r.addView(op, olp);
            box.addView(r);
        }
        Button merge = smallBtn("Mesclar com a de baixo");
        merge.setOnClickListener(v -> { cv.mergeDown(); fillLayers(box); });
        box.addView(merge);
        Button flipH = smallBtn("Espelhar H");
        flipH.setOnClickListener(v -> cv.flipLayer(true));
        box.addView(flipH);
        Button flipV = smallBtn("Espelhar V");
        flipV.setOnClickListener(v -> cv.flipLayer(false));
        box.addView(flipV);
    }

    private void renameLayer(Project.Layer l, LinearLayout box) {
        EditText et = new EditText(this);
        et.setText(l.name);
        new AlertDialog.Builder(this).setTitle("Renomear").setView(et)
                .setPositiveButton("OK", (d, w) -> {
                    String s = et.getText().toString().trim();
                    if (s.length() > 0) {
                        l.name = s.length() > 24 ? s.substring(0, 24) : s;
                        p.save();
                        fillLayers(box);
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    private void goFrame(int idx) {
        if (idx < 0 || idx >= p.frames.size()) return;
        if (playing) stopPlay();
        cv.loadFrame(idx);
        updateFrameLbl();
        rebuildStrip();
    }

    private void updateFrameLbl() {
        if (frameLbl != null) frameLbl.setText("Q" + (cv.frameIdx + 1) + "/" + p.frames.size());
    }

    private void setFps(int f) {
        p.fps = Math.max(1, Math.min(60, f));
        if (fpsLbl != null) fpsLbl.setText(p.fps + "fps");
        p.save();
    }

    private void addFrame(boolean dup) {
        cv.saveCurrent();
        int curId = cv.frameId();
        int nid = p.nextFrame++;
        if (dup) p.copyFrameFiles(curId, nid);
        p.frames.add(cv.frameIdx + 1, nid);
        p.save();
        goFrame(cv.frameIdx + 1);
    }

    private void deleteFrame() {
        if (p.frames.size() <= 1) { Ui.toast(this, "Precisa de 1 quadro"); return; }
        cv.saveCurrent();
        int id = p.frames.remove(cv.frameIdx);
        p.deleteFrameFiles(id);
        p.save();
        thumbs.remove(id);
        goFrame(Math.min(cv.frameIdx, p.frames.size() - 1));
    }

    private void pasteFrame() {
        if (clipFrameId == null) { Ui.toast(this, "Nenhum quadro copiado"); return; }
        cv.saveCurrent();
        int nid = p.nextFrame++;
        p.copyFrameFiles(clipFrameId, nid);
        p.frames.add(cv.frameIdx + 1, nid);
        p.save();
        goFrame(cv.frameIdx + 1);
    }

    private void rebuildStrip() {
        if (strip == null) return;
        strip.removeAllViews();
        int g = Ui.dp(this, 3);
        updateFrameLbl();
        for (int i = 0; i < p.frames.size(); i++) {
            final int idx = i;
            final int fid = p.frames.get(i);
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setPadding(g, g, g, g);
            cell.setBackground(Ui.bg(idx == cv.frameIdx ? Ui.ACC : Ui.BTN, Ui.dp(this, 6)));
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackgroundColor(0xFF0C0D14);
            int side = Ui.dp(this, 48);
            strip.addView(cell, new LinearLayout.LayoutParams(side + g * 2, LinearLayout.LayoutParams.WRAP_CONTENT));
            cell.addView(iv, new LinearLayout.LayoutParams(side, side));
            TextView n = new TextView(this);
            n.setText(String.valueOf(i + 1));
            n.setTextColor(Ui.FG);
            n.setTextSize(9);
            n.setGravity(Gravity.CENTER);
            cell.addView(n);
            cell.setOnClickListener(v -> goFrame(idx));
            Bitmap th = thumbs.get(fid);
            if (th != null) iv.setImageBitmap(th);
            else new Thread(() -> {
                Bitmap b = p.composite(fid, 96, true);
                thumbs.put(fid, b);
                runOnUiThread(() -> { if (iv.getParent() != null) iv.setImageBitmap(b); });
            }).start();
        }
    }

    private void startPlay() {
        cv.saveCurrent();
        playFrames = new ArrayList<>();
        for (int fid : p.frames) playFrames.add(p.composite(fid, Math.max(p.w, p.h), true));
        playing = true;
        playI = 0;
        playBtn.setText("■");
        tick();
    }

    private void stopPlay() {
        playing = false;
        if (playBtn != null) playBtn.setText("▶");
        if (playFrames != null) {
            for (Bitmap b : playFrames) b.recycle();
            playFrames = null;
        }
        cv.playBmp = null;
        cv.invalidate();
    }

    private void tick() {
        if (!playing || playFrames == null) return;
        cv.playBmp = playFrames.get(playI % playFrames.size());
        cv.invalidate();
        playI++;
        h.postDelayed(this::tick, Math.max(16, 1000 / Math.max(1, p.fps)));
    }

    private void menu() {
        ArrayList<String> items = new ArrayList<>();
        items.add("Salvar PNG (com fundo)");
        items.add("Salvar PNG transparente");
        if (p.anim) items.add("Exportar todos os quadros");
        items.add(p.paper == 0 ? "Fundo branco" : "Fundo transparente");
        items.add("Ajustar à tela");
        items.add("Limpar quadro");
        items.add("Espelhar camada H");
        items.add("Espelhar camada V");
        items.add("Mesclar com a de baixo");
        items.add("Renomear projeto");
        new AlertDialog.Builder(this).setTitle("Projeto")
                .setItems(items.toArray(new String[0]), (d, which) -> {
                    String it = items.get(which);
                    if (it.startsWith("Salvar PNG (com")) exportOne(true);
                    else if (it.startsWith("Salvar PNG t")) exportOne(false);
                    else if (it.startsWith("Exportar")) exportAll();
                    else if (it.contains("transparente") || it.contains("branco")) {
                        p.paper = p.paper == 0 ? 0xFFFFFFFF : 0;
                        p.save();
                        cv.invalidate();
                        Ui.toast(this, p.paper == 0 ? "Fundo transparente" : "Fundo branco");
                    } else if (it.startsWith("Ajustar")) cv.fitView();
                    else if (it.startsWith("Limpar")) {
                        new AlertDialog.Builder(this).setTitle("Limpar quadro?")
                                .setPositiveButton("Limpar", (a, b) -> { cv.clearFrame(); onChanged(); })
                                .setNegativeButton("Cancelar", null).show();
                    } else if (it.contains("H")) cv.flipLayer(true);
                    else if (it.contains("V")) cv.flipLayer(false);
                    else if (it.startsWith("Mesclar")) cv.mergeDown();
                    else if (it.startsWith("Renomear")) renameProject();
                }).show();
    }

    private void renameProject() {
        EditText et = new EditText(this);
        et.setText(p.name);
        new AlertDialog.Builder(this).setTitle("Renomear").setView(et)
                .setPositiveButton("OK", (d, w) -> {
                    String s = et.getText().toString().trim();
                    if (s.length() > 0) {
                        p.name = s.length() > 40 ? s.substring(0, 40) : s;
                        p.save();
                        titleTv.setText(p.name);
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    private boolean savePng(Bitmap b, String name) {
        try {
            if (Build.VERSION.SDK_INT < 29 &&
                    checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return false;
            }
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (Build.VERSION.SDK_INT >= 29)
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DarkMonia");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (u == null) return false;
            OutputStream os = getContentResolver().openOutputStream(u);
            if (os == null) return false;
            b.compress(Bitmap.CompressFormat.PNG, 100, os);
            os.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String fileBase() {
        return p.name.replaceAll("[^a-zA-Z0-9À-ÿ_-]+", "_") + "_" + (System.currentTimeMillis() / 1000 % 100000);
    }

    private void exportOne(boolean paper) {
        cv.commitFloating();
        Bitmap b = cv.renderComposite(paper);
        boolean ok = savePng(b, fileBase() + ".png");
        b.recycle();
        Ui.toast(this, ok ? "Salvo em Imagens/DarkMonia" : "Falha ao salvar");
    }

    private void exportAll() {
        cv.commitFloating();
        cv.saveCurrent();
        final ArrayList<Integer> ids = new ArrayList<>(p.frames);
        final String base = fileBase();
        Ui.toast(this, "Salvando " + ids.size() + " quadros…");
        new Thread(() -> {
            int ok = 0;
            for (int i = 0; i < ids.size(); i++) {
                Bitmap b = p.composite(ids.get(i), Math.max(p.w, p.h), true);
                if (savePng(b, base + "_" + String.format("%04d", i + 1) + ".png")) ok++;
                b.recycle();
            }
            final int n = ok;
            runOnUiThread(() -> Ui.toast(this, n + " quadros salvos"));
        }).start();
    }

    @Override protected void onPause() {
        super.onPause();
        if (p == null || cv == null) return;
        if (playing) stopPlay();
        cv.commitFloating();
        cv.saveCurrent();
        try {
            Bitmap full = cv.renderComposite(true);
            float k = 320f / Math.max(p.w, p.h);
            Bitmap t = Bitmap.createScaledBitmap(full, Math.max(1, Math.round(p.w * k)), Math.max(1, Math.round(p.h * k)), true);
            Project.writePng(t, p.thumbFile());
            if (t != full) t.recycle();
            full.recycle();
        } catch (Throwable ignored) {}
        p.updated = System.currentTimeMillis();
        p.save();
    }
}
