# Dark Monia — nativo etapa 5

Java puro. `applicationId` = `com.darkmonia.animator`.

## Home estilo Creative Studio 5.0
- Header com logo **DM** + “Dark Monia / Creative Studio · 5.0” + ⚙
- Saudação “Olá! / O que vamos criar hoje?”
- Cartões grandes: **Novo desenho**, **Nova animação**, **Abrir imagem**
- **Começar rápido** com os mesmos presets da v5 (Quadrado, Story, A4, 4K, Pixel…)
- Galeria com contagem, ordenar (Recentes / Nome / Antigos), grade ou lista
- Abas **Tudo / Desenhos / Animações** com contadores
- FAB **+**, sheet de novo projeto (tamanho + fundo + fps)
- Duplicar / renomear / excluir projeto
- Importar imagem da galeria do celular

## Editor (da etapa 4+)
Tela cheia, seleção/laço, formas, texto, simetria, camadas, timeline, export PNG.

## Compilar
Android Studio / AndroidIDE → Build APK
